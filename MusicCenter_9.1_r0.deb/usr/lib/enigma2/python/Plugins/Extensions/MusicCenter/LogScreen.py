# -*- coding: UTF-8 -*-

#  Music Center E2
#
#  Coded by bobo71 (c) 2014
#  Support: www.dreambox-tools.info
#
#  All Files of this Software are licensed under the Creative Commons
#  Attribution-NonCommercial-ShareAlike 3.0 Unported
#  License if not stated otherwise in a Files Head. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.

#  Additionally, this plugin may only be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.

#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially
#  distributed other than under the conditions noted above.
#  This applies to the source code as a whole as well as to parts of it, unless
#  explicitely stated otherwise.

from Globals import *
from myLogger import logger
from Components.ScrollLabel import ScrollLabel


class LogScreen(Screen):


	if RESOLUTIONx>1800:
		skin="""
			<screen name="LogScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#00000000" zPosition="0" title="Music Center Log">
				<widget name="log_text" position="50,130" zPosition="1" size="1820,930" scrollbarMode="showOnDemand" backgroundColor="#00000000"/>
				<!-- Buttons -->
					<widget render="Label" font="SansReg;26" transparent="1" position="60,128" size="450,45" source="key_red" foregroundColor="#ff0000" halign="center" valign="center" zPosition="1"/>
					<widget render="Label" font="SansReg;26" transparent="1" position="510,128" size="450,45" source="key_green" foregroundColor="#00ff21" halign="center" valign="center" zPosition="1"/>
					<widget render="Label" font="SansReg;26" transparent="1" position="960,128" size="450,45" source="key_yellow" foregroundColor="#FFD800" halign="center" valign="center" zPosition="1"/>
					<widget render="Label" font="SansReg;26" transparent="1" position="1410,128" size="3450,45" source="key_blue" foregroundColor="#3D8DFF" halign="center" valign="center" zPosition="1"/>			
			
				<widget name="headertext" position="165,6" size="1500,110" font="SansReg;24" foregroundColor="#04931c" backgroundColor="#00000000" halign="center" valign="center" zPosition="1" />
				<!-- line -->
					<eLabel backgroundColor="#04931c" position="0,120" size="1920,1" zPosition="1" />
			</screen>"""

	else:
		skin="""
			<screen name="LogScreen" position="0,0" size="1280,720" flags="wfNoBorder" backgroundColor="#00000000" zPosition="0" title="Music Center Log">
				<widget name="log_text" position="33,86" zPosition="1" size="1213,620" scrollbarMode="showOnDemand" backgroundColor="#00000000"/>
				<!-- Buttons -->
					<widget render="Label" font="SansReg;17" transparent="1" position= "40,85" size="300,30" source="key_red" foregroundColor="#ff0000" halign="center" valign="center" zPosition="1"/>
					<widget render="Label" font="SansReg;17" transparent="1" position="340,85" size="300,30" source="key_green" foregroundColor="#00ff21" halign="center" valign="center" zPosition="1"/>
					<widget render="Label" font="SansReg;17" transparent="1" position="640,85" size="300,30" source="key_yellow" foregroundColor="#FFD800" halign="center" valign="center" zPosition="1"/>
					<widget render="Label" font="SansReg;17" transparent="1" position="940,85" size="300,30" source="key_blue" foregroundColor="#3D8DFF" halign="center" valign="center" zPosition="1"/>			
			
				<widget name="headertext" position="110,4" size="1000,73" font="SansReg;16" foregroundColor="#04931c" backgroundColor="#00000000" halign="center" valign="center" zPosition="1" />
				<!-- line -->
					<eLabel backgroundColor="#04931c" position="0,80" size="1280,1" zPosition="1" />
			</screen>"""


	def __init__(self, session, filename=None, title=''):
		logger.info('LogScreen]init...')
		self.session=session
		self.skin_path='/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images'
		Screen.__init__(self, session)

		self.keyLocked = True
		self["actions"] = ActionMap(["WizardActions", "ColorActions"],
		{
			"back": self.close,
			"red": self.keyRed,
			"green" : self.keyGreen,
		}, -1)

		self["key_red"]=StaticText("")
		self["key_green"]=StaticText("")
		self["key_yellow"]=StaticText("")
		self["key_blue"]=StaticText("")
		self["headertext"]=Label()
		
		self.filename=filename
		self.title=title
		self.text = []
		self["log_text"] = MenuList(self.text)
		self.fn = None
		self.onLayoutFinish.append(self.startRun)

	def startRun(self):
		logger.info('LogScreen]startRun')
		if self.filename is None:
			try:
				self.fn = os_path.join('/var/log/', max([ f for f in os_listdir('/var/log') if 'musiccenter-' in f and f.endswith('.log')]))	
				with open(self.fn,'r') as f:
					for line in f:
						self.text.append(line)
				self["headertext"].setText(self.fn)
				self.keyRed(True)
			except Exception, e:
				logger.error('LogScreen]Error:%s'%e)
				self["headertext"].setText('No Logfile found! %s'%e)
			
			log1=self.fn+'.1'
			if fileExists(log1):
				with open(log1,'r') as f:
					for line in f:
						self.text.append(line)
		else:
			try:
				with open(self.filename,'r') as f:
					for line in f:
						self.text.append(line)
				self["headertext"].setText(self.title)
			except Exception, e:
				logger.error('LogScreen]Error:%s'%e)
				self["headertext"].setText('No Logfile found! %s'%e)
		
	def keyRed(self, firstrun = False):
		logger.info('LogScreen]keyRed')
		if self.keyLocked and not firstrun:
			return
		self["key_green"]=StaticText("Show All")
		self.keyLocked = True
		with open(self.fn,'r') as flines:
			for line in flines:
				if 'MusicCenter]plugin.py]reload MusicCenter...' in line:
					self.text=[]
				self.text.append(line)
		self.keyLocked = False

	def keyGreen(self):
		logger.info('LogScreen]keyGreen')
		if self.keyLocked:
			return
		self["key_red"]=StaticText("Show last session")
		self.keyLocked = True
		with open(self.fn,'r') as flines:
			for line in flines:
				self.text.append(line)
		self.keyLocked = False
		
	def __onClose(self):
		logger.info('LogScreen]__onClose] Start destroying...')
		self.text=''
		self.giventext=''