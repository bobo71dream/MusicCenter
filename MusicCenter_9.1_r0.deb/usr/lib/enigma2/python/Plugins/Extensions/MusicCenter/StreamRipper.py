# -*- coding: utf-8 -*-

"""
Codebase https://github.com/jpaille/streamripper

Main recording loop. For more information on the shoutcast protocol, check this nice
tutorial http://www.smackfu.com/stuff/programming/shoutcast.html
"""


from shutil import move as shutil_move
from threading import Thread
from requests import get as requests_get, exceptions as requests_exceptions
from os import path as os_path, makedirs as os_makedirs, remove as os_remove, listdir as os_listdir
from re import search as re_search, findall as re_findall, S as re_S
from datetime import datetime as datetime_datetime
from time import time as time_time, sleep as time_sleep
from mutagen.mp3 import MP3
from mutagen.id3 import ID3, error, TPE1, TIT2, TALB, TCON, TRSN, TRCK, TDRC
import socket

from myLogger import logger
from ThreadQueue import ThreadQueue
from enigma import ePythonMessagePump

'''
import sys
sys.path.append('/usr/script/pstreamripper')
import streamripper
streamripper.streamripperinstance.Start( "http://ww3.servemp3.com:5000/Single-Charts", "/hoeck/Local-320gb/Musik/Streamripper/", user_agent="Simpleplayer" )


def LOG(text):
	print text
	
	
def ELOG(text):
	print text
'''
	
class HotmixradioParser(object):
	"""Parser for hotmix radio style metadata.
	   Hotmixradio metadata format is "StreamTitle='title of the song - artist ||'.
	"""

	def parse(self, metadata):
		logger.info('HotmixradioParser]parse]: {}'.format(metadata))
		group_dict = re_search(r"^StreamTitle='(?P<title>.+?) - (?P<artist>.+?) \|", metadata).groupdict()
		return (group_dict["artist"], group_dict["title"]) if group_dict else (None, None)


class DefaultParser(HotmixradioParser):
	"""Standard parser for metadata"""
	def parse(self, metadata):
		if '|' in metadata:
			res=re_findall(r"StreamTitle='(.*?)-(.*?)\|.*?';", metadata, re_S)
		else:
			res=re_findall(r"StreamTitle='(.*?)-(.*?)';", metadata, re_S)
		if res:
			res=res[0]
			if len(res)==2:
				artist,title=res[0].strip(),res[1].strip()
			elif res:
				artist,title='n/a', res[0].strip()
		else:
			res=re_findall(r"StreamTitle='(.*?)';", metadata, re_S)
			logger.info('DefaultParser]parse]res:{0}'.format(res))
			if res:
				artist, title = 'unknown', res[0].strip()
			else:
				artist,title='', ''
		artist=artist.replace('/','_')
		title=title.replace('/','_')
		logger.info('DefaultParser]parse]Metadata:{} artist:{} title:{}'.format(metadata[:200],artist, title))
		return artist, title


metadata_parsers = {"Hotmixradio" : HotmixradioParser, "Default" : DefaultParser}


class StreamRipper(Thread):

	start_time=0

	def __init__(self):
		logger.info('StreamRipper]__init__]')
		Thread.__init__(self)
		self.__running=False
		self.__cancel=False
		self.__url = ''
		self.__base_directory = "."
		self.__record_length = -1
		self.__track_number_format='counter'
		self.__start_number = -1
		self.__min_song_duration = 60
		self.__user_agent = None
		self.__stationname = None
		self.__genre = ''
		self.__check_for_dublicates = True
		self.__save_dublicates = True
		self.__messages=ThreadQueue()
		self.__messagePump=ePythonMessagePump()

	def __getRunning(self):
		return self.__running

	def __getMessagePump(self):
		return self.__messagePump

	def __getMessageQueue(self):
		return self.__messages

	MessagePump=property(__getMessagePump)
	Message=property(__getMessageQueue)
	isRunning=property(__getRunning)

	def Start(self, url, base_directory=".", record_length=-1, track_number_format='no', start_number=-1, min_song_duration=60, user_agent=None, stationname=None, genre='', check_for_dublicates=True, save_dublicates=True):
		logger.info('StreamRipper]Start]url:{}, base_directory: {}, record_length:{}, track_number_format:{}, start_number:{}, min_song_duration:{}, user_agent:{}, check_for_dublicates:{}, save_dublicates:{}'.format(url, base_directory, record_length, track_number_format, start_number, min_song_duration, user_agent, check_for_dublicates, save_dublicates))

		if self.__running:
			logger.info('StreamRipper]Start]old Thread is running, cancel ripping:{}'.format(self.__url))
			self.Cancel()
			while self.__running:
				time_sleep(0.2)
			logger.info('StreamRipper]Start]old Thread is canceled')

		self.__url = url
		self.__base_directory = base_directory
		self.__record_length = int(record_length)
		self.__track_number_format=track_number_format
		self.__start_number = int(start_number)
		self.__min_song_duration = int(min_song_duration)
		self.__user_agent = user_agent
		self.__stationname = stationname
		self.__genre = genre
		self.__check_for_dublicates = check_for_dublicates
		self.__save_dublicates = save_dublicates

		self.start()

	def build_header(self):
		"""Build a custom header"""
		if self.__user_agent is None:
			user_agent='streamripper'
		else:
			user_agent=self.__user_agent
		headers = {"User-Agent": self.__user_agent, 'Icy-MetaData': "1"}
		return headers

	def Cancel(self):
		self.__cancel=True

	def get_metadata_length(self, stream):
		byte_length = stream.raw.read(1)
		if byte_length == "":
			raise NoDataReceivedError
		return ord(byte_length) * 16

	def run(self):
		logger.info('StreamRipper]start run')

		RETRY=0
		MAX_RETRYS=6
		TIMEOUT=4
		start_time=time_time()
		m='StreamRipper]starttime {}'.format(start_time)
		logger.info(m)

		while MAX_RETRYS > RETRY: # for i in range(MAX_RETRYS):
			
			last_try_time= time_time()
			logger.info('StreamRipper]start try:{} time:{}'.format(RETRY, last_try_time))
			RETRY+=1
			
			if self.__cancel:
				logger.info('StreamRipper]cancel on start')
				RETRY=7
				break
				
			else:
				try:
					can_rip = True

					self.__running=True
					mp=self.__messagePump
					ms=self.__messages

					m="StreamRipper]Connecting... {}".format(self.__url)
					logger.info(m)
					ms.push(('THREAD_WORKING', m,))
					mp.send(0)

					stream = requests_get(self.__url, stream=True, headers=self.build_header(), timeout=TIMEOUT)
					m="StreamRipper]stream header: {}".format(stream.headers)
					logger.info(m)
					ms.push(('THREAD_WORKING', m,))
					mp.send(0)

					if stream.headers.get('Content-Type'):
						content_type = stream.headers['Content-Type']
					else:
						content_type = 'unknown'
					if content_type not in ('audio/mpeg',):
						can_rip = False
					m="StreamRipper]Content-Type:{}".format(content_type)
					logger.info(m)
					ms.push(('THREAD_WORKING', m,))
					mp.send(0)

					stationname = stream.headers['icy-name']

					if self.__stationname is not None:
						m="StreamRipper]icy-name:{} use given stationname:{}".format(stationname, self.__stationname)
						stationname= self.__stationname
					else:
						m="StreamRipper]icy-name:{} use it, not stationname was given".format(stationname)
					logger.info(m)
					ms.push(('THREAD_WORKING', m,))
					mp.send(0)

					if stream.headers.get('Server'):
						m="StreamRipper]server name:{}".format(stream.headers['Server'])
					else:
						m="StreamRipper]server name:unknown"
					logger.info(m)
					ms.push(('THREAD_WORKING', m,))
					mp.send(0)

					if stream.headers.get('icy-br'):
						m="StreamRipper]declared bitrate: {}kbit".format(stream.headers['icy-br'])
						byterate = int(stream.headers["icy-br"].split(',')[0][:3]) * 1000 / 8
						logger.info("StreamRipper]used bytrate: {}bytes".format(byterate))
					else:
						m="StreamRipper]declared bitrate: unknown"
						byterate=-1
					logger.info(m)
					ms.push(('THREAD_WORKING', m,))
					mp.send(0)

					if stream.headers.get('icy-genre'):
						genre=stream.headers['icy-genre']
					else:
						genre=self.__genre
					m="StreamRipper]declared genre: {}".format(genre)
					logger.info(m)
					ms.push(('THREAD_WORKING', m,))
					mp.send(0)

					block_size = int(stream.headers.get("icy-metaint", -1))
					if block_size == -1:
						can_rip = False
					m="StreamRipper]meta interval: {}".format(block_size)
					logger.info(m)
					ms.push(('THREAD_WORKING', m,))
					mp.send(0)

					if not os_path.exists(self.__base_directory):
						m='StreamRipper]No valid base_directory given'
						logger.info(m)
						ms.push(('THREAD_WORKING', m,))
						mp.send(0)
						can_rip = False

					if not can_rip:
						#self.ripper(stream, block_size, stationname, genre)
						m='StreamRipper]can´t rip this station, shut down...'
						logger.info(m)
						ms.push(('THREAD_WORKING', m,))
						mp.send(0)
						time_sleep(1)
						self.shutdown()
					else:

						if self.__cancel:
							logger.info('StreamRipper]cancel on startup')
							RETRY=7
							self.shutdown()

						artist,title='',''

						songdir=os_path.join(self.__base_directory, stationname)
						incompletedir=os_path.join(songdir, 'incomplete')
						dublicatedir=os_path.join(songdir, 'dublicates')
						#for debug
						#jinglesdir=os_path.join(songdir, 'jingles')
						if not os_path.exists(songdir):
							os_makedirs(songdir)
						if not os_path.exists(incompletedir):
							os_makedirs(incompletedir)
						if self.__check_for_dublicates:
							track_list_file=os_path.join(songdir, 'streamripper_track.lst')
							track_list=[]
							if os_path.exists(track_list_file):
								with open (track_list_file, 'r') as f:
									for track in f:
										track_list.append(track.strip())

							if self.__save_dublicates and not os_path.exists(dublicatedir):
								os_makedirs(dublicatedir)
						#for debug
						#if not os_path.exists(jinglesdir):
						#	os_makedirs(jinglesdir)

						last_time_stamp=0
						first_song=True
						ms.push(('THREAD_WORKING', m,))
						mp.send(0)
						
						first_mp3_bytes = stream.raw.read(block_size)
						metadata_length = self.get_metadata_length(stream)
						
						m='StreamRipper]metadata_length: {}'.format(metadata_length)
						logger.info(m)
						ms.push(('THREAD_WORKING', m,))
						mp.send(0)

						if metadata_length: # initial metadata
							m='StreamRipper]we receive metadata from stream: first song is coming'
							logger.info(m)
							ms.push(('THREAD_WORKING', m,))
							mp.send(0)
							artist, title = metadata_parsers['Default']().parse(stream.raw.read(metadata_length))

						while 1: # now start ripping...

							if RETRY > 0 and last_try_time+15*60 < time_time():
								m='StreamRipper]RETRY counter reset now, more then 15 minutes ripped without error...'
								logger.info(m)
								RETRY=0

							if self.__cancel:
								logger.info('StreamRipper]cancel on snow start ripping')
								RETRY=7
								break

							if self.__track_number_format == 'counter' and self.__start_number > -1:
								record_mount_day=None
								tracknr_for_id3='{}'.format('%0.4d' %self.__start_number)
								local_filename='{} - {} - {}.mp3'.format(tracknr_for_id3, artist, title)
								track_name=local_filename.split('-',1)[-1].rsplit('.',1)[0].strip() #0101 - jggnfnfj - bhjfnf f.mp3
								
							elif self.__track_number_format == 'date_and_counter' and self.__start_number > -1:
								record_mount_day=datetime_datetime.now().strftime("%m%d")
								tracknr_for_id3='{}_{}'.format(record_mount_day, '%0.3d' %self.__start_number)
								local_filename='{} - {} - {}.mp3'.format(tracknr_for_id3, artist, title)
								track_name=local_filename.split('-',1)[-1].rsplit('.',1)[0].strip() #0206_101 - jggnfnfj - bhjfnf f.mp3
								
							elif self.__track_number_format == 'no':
								record_mount_day=None
								tracknr_for_id3=-1
								local_filename='{} - {}.mp3'.format(artist, title)
								track_name=local_filename.rsplit('.',1)[0].strip() #jggnfnfj - bhjfnf f.mp3
								
							else:
								record_mount_day=None
								tracknr_for_id3=-1
								local_filename='{} - {}.mp3'.format(artist, title)
								track_name=local_filename.rsplit('.',1)[0].strip() #jggnfnfj - bhjfnf f.mp3

							full_song_path = os_path.join(incompletedir, local_filename)
							m="StreamRipper]Ripping {}".format(full_song_path)
							logger.info(m)
							ms.push(('THREAD_WORKING', m,))
							mp.send(0)

							with open(full_song_path, 'wb') as songfile:

								song_start_time=time_time()
								data_length=0
								track_name=local_filename.split('-',1)[-1].rsplit('.',1)[0].strip() #0206_101 - jggnfnfj - bhjfnf f.mp3
								track_is_in_tracklist=track_name in track_list
										
								skip_song = self.__check_for_dublicates and not self.__save_dublicates and track_is_in_tracklist
								logger.info('StreamRipper]skip_song ?:{}'.format(skip_song))
								
								if first_mp3_bytes:
									songfile.write(first_mp3_bytes)
									data_length+=len(first_mp3_bytes)
								first_mp3_bytes=''

								for mp3_bytes in stream.iter_content(chunk_size=block_size):

									if self.__cancel:
										logger.info('StreamRipper]cancel on ripping song')
										RETRY=7
										break
					
									data_length+=len(mp3_bytes)
									
									currenttime=time_time()
									if currenttime>last_time_stamp + 2:
										last_time_stamp=currenttime

										if data_length/1024 < 1024:
											if skip_song:
												m="skip {}-{}-{} [{}]KB".format(stationname, artist, title, data_length/1024)
											else:
												m="ripping {}-{}-{} [{}]KB".format(stationname, artist, title, data_length/1024)
										else:
											if skip_song:
												m="skip {}-{}-{} [{}]MB".format(stationname, artist, title, format(data_length/1024/1024.0, '.2f'))
											else:
												m="ripping {}-{}-{} [{}]MB".format(stationname, artist, title, format(data_length/1024/1024.0, '.2f'))
										#LOG(m)
										ms.push(('THREAD_WORKING', m,))
										mp.send(0)
									if not skip_song:
										songfile.write(mp3_bytes)

									try:
										metadata_length = self.get_metadata_length(stream)
									except NoDataReceivedError:
										logger.info("StreamRipper] Request.raw.read returned an empty string. Process end.")
										raise RuntimeError

									if metadata_length:
										song_length=time_time()-song_start_time
										artist_for_id3=artist[:]
										title_for_id3=title[:]
										artist, title = metadata_parsers['Default']().parse(stream.raw.read(metadata_length))
										if artist or title:
											m='StreamRipper]we receive valid metadata from stream: a new song is coming'
											logger.info(m)
											ms.push(('THREAD_WORKING', m,))
											mp.send(0)
											break
										else:
											m=('StreamRipper]we received metadata from stream, but empty, skip')
											logger.info(m)
											ms.push(('THREAD_WORKING', m,))
											mp.send(0)

							if not self.__cancel:

								if song_length < self.__min_song_duration:
									m='StreamRipper] song duration is:{} ,less then minimum song length:{} remove'.format(song_length, self.__min_song_duration)
									logger.info(m)
									ms.push(('THREAD_WORKING', m,))
									mp.send(0)
									os_remove(full_song_path) #self.move_song(full_song_path, jinglesdir, local_filename)
								else:
									if self.__start_number > -1:
										self.__start_number+=1
									if first_song:
										first_song=False
									else:
										if self.__check_for_dublicates:
											if track_is_in_tracklist:
												if self.__save_dublicates:
													logger.info('StreamRipper]dublicate found, move to dublicatesdir')
													self.add_id3_tags(full_song_path, tracknr_for_id3, artist_for_id3, title_for_id3, genre, stationname, record_mount_day)
													self.move_song(full_song_path, dublicatedir, local_filename)
												else:
													logger.info('StreamRipper]dublicate found, remove')
													os_remove(full_song_path)
											else:
												track_list.append(track_name)
												with open (track_list_file, 'a') as f:
													f.write(track_name+'\n')
												logger.info('StreamRipper]track_name not as dublicate found, move to songdir and append to track_list and track_list_file')
												self.add_id3_tags(full_song_path, tracknr_for_id3, artist_for_id3, title_for_id3, genre, stationname, record_mount_day)
												self.move_song(full_song_path, songdir, local_filename)
										else:
											logger.info('StreamRipper]move to songdir')
											shutil_move(full_song_path, songdir)

									if self.__record_length >-1:
										if time_time()-start_time > self.__record_length:
											m='StreamRipper]End of record length is reached, close now...'
											logger.info(m)
											ms.push(('THREAD_WORKING', m,))
											mp.send(0)
											self.Cancel()
										else:
											logger.info('StreamRipper]record length:{} is not reached is now:{}'.format(int(self.__record_length), time_time()-start_time))

				except requests_exceptions.ConnectionError:
					m='StreamRipper]build http connection failed'
					logger.exception(m)
					ms.push(('THREAD_WORKING', m,))
					mp.send(0)
					time_sleep(TIMEOUT)

				except socket.timeout:
					m='StreamRipper]download failed'
					logger.exception(m)
					ms.push(('THREAD_WORKING', m,))
					mp.send(0)
					time_sleep(TIMEOUT)

				except Exception, e:
					m='StreamRipper]error:{}'.format(e)
					logger.exception(m)
					ms.push(('THREAD_WORKING', m,))
					mp.send(0)
					time_sleep(TIMEOUT)
					self.shutdown(restart=True)

		logger.error('StreamRipper]all connection trys failed, shutdown...')
		self.shutdown()

	def move_song(self, src, dst, local_filename):
		dstfn=os_path.join(dst, local_filename)
		if not os_path.exists(dstfn):
			logger.info('StreamRipper]dstfilename not exist, move song src:{}   dst:{}'.format(src, dstfn))
			shutil_move(src, dstfn)
		else:
			orig_dst=dstfn
			count=0
			while os_path.exists(dstfn):
				count+=1
				a,b=orig_dst.rsplit('.',1)
				dstfn = a + '(' + str(count) + ').' + b
				logger.info('StreamRipper]dstfilename:{} exist,try now new filename'.format(dstfn))
			logger.info('StreamRipper]move song src:{} dst{}'.format(src, dstfn))
			shutil_move(src, dstfn)

	def shutdown(self):
		m='StreamRipper]shutdown...'
		logger.info(m)
		self.__messages.push(('THREAD_WORKING', m,))
		self.__messagePump.send(0)

		self.__running=False
		self.__cancel=False
		
		Thread.__init__(self)

		time_sleep(1)
		m='' # clear console
		logger.info(m)
		self.__messages.push(('THREAD_WORKING', m,))
		self.__messagePump.send(0)


	def add_id3_tags(self, full_song_path, tracknr_for_id3, artist, title, genre, stationname, record_mount_day):
		logger.info('StreamRipper]add_id3_tags]full_song_path: {} tracknr: {} artist: {} title: {} genre: {}'.format(full_song_path, tracknr_for_id3, artist, title, genre))
		audio = MP3(full_song_path, ID3=ID3)
		try:
			audio.add_tags()
		except error:
			pass
		if tracknr_for_id3 > -1:
			audio.tags.add(TRCK(encoding = 3, text = unicode(tracknr_for_id3)))
		audio.tags.add(TIT2(encoding = 3, text = unicode(title.title(), errors='replace')))
		audio.tags.add(TPE1(encoding = 3, text = unicode(artist.title(), errors='replace')))
		if genre != '':
			audio.tags.add(TCON(encoding = 3, text = unicode(genre.split(',',1)[0].title(), errors='replace')))
		audio.tags.add(TRSN(encoding = 3, text = unicode(stationname, errors='replace')))
		audio.tags.add(TDRC(encoding = 3, text = unicode(self.recordtime(), errors='replace')))

		audio.save()

	def recordtime(self):
		return datetime_datetime.now().strftime("%Y-%m-%d")

	def __del__(self):
		logger.info('StreamRipper]__del__]....')


streamripperinstance=StreamRipper()


class NoDataReceivedError(Exception):
	"""Exception raised when request.raw.read() returns
	   an empty string.
	"""
	logger.info('NoDataReceivedError]request.raw.read() returns an empty string.')
