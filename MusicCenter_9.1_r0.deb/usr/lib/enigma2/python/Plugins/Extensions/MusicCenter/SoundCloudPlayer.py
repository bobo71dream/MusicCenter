# -*- coding: UTF-8 -*-

#  Music Center E2
#
#  Coded by bobo71 (c) 2014
#  Support: www.dreambox-tools.info
#
#  All Files of this Software are licensed under the Creative Commons
#  Attribution-NonCommercial-ShareAlike 3.0 Unported
#  License if not stated otherwise in a Files Head. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.

#  Additionally, this plugin may only be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.

#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially
#  distributed other than under the conditions noted above.
#  This applies to the source code as a whole as well as to parts of it, unless
#  explicitely stated otherwise.

from Globals import *

# local plugin
from JobCenter import *
from JobCenter2 import *
from SelectPath import SelectPath
from myLogger import logger
from ItemClasses import PicDownloadItem
from LogScreen import *
from soundcloud.resource import Resource as soundcloud_Resource
from SoundCloudHelper import resolveArtistartwork, SCItem, SCAllItem

from Setup import MusicCenterSetup
from TaskViewScreen import MusicCenterTasksScreen

import Image
import ImageOps


if fileExists('/usr/lib/enigma2/python/Plugins/Extensions/MediaInfo/plugin.py'):
	from Plugins.Extensions.MediaInfo.plugin import MediaInfo as PluginMediainfo
	MEDIAINFO=True
else:
	MEDIAINFO=False



class SCPlayer(Screen, InfoBarBase, InfoBarSeek, InfoBarNotifications):

	def __init__(self, session, songList=[], index=0, currentService=None, serviceList=None, sc_client=None, playermode=2, soundcloudInstance=None):
	
		logger.info('SCPlayer]__init__ start...')
		self.session=session	
		self.skin_path='/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images'
		self.buildSkin()
		Screen.__init__(self, session)
		InfoBarNotifications.__init__(self)
		InfoBarBase.__init__(self)
		
		logger.info('SCPlayer]skin->%s' %self.skin)
		self.session.nav.stopService()
		self.songList=songList
		self.playermode=playermode
		self['actions']=ActionMap(["WizardActions", "MediaPlayerActions", "EPGSelectActions", "MediaPlayerSeekActions", "ColorActions", "InfobarAudioSelectionActions", "StandbyActions", "InfobarActions"],
		{
			"input_date_time": self.menu_pressed,
			"back": self.closePlayer,
			"pause": self.pauseEntry,
			"stop": self.stopEntry,
			"right": self.playNext,
			"left": self.playPrevious,
			"up": self.showSongList,
			"down" : self.showSongList,
			"prevBouquet": self.shuffleList,
			"nextBouquet": self.repeatSong,
			"info" : self.info_pressed,
			"yellow": self.pauseEntry,
			"green": self.play,
			"ok": self.keyOk,
			"audioSelection": self.audio_pressed,
			"showMovies": self.pvr_pressed,
		}, -1)
		self.onClose.append(self.__onClose)
		self["coverArt"]=VideoDBPictureBox()
		self['artistavatar']=VideoDBPictureBox()
		self['wave']=PicLoaderScale(1240,96, transparent=True, cached=False, name='wave')
		self['useravatar']=PicLoaderScale(70, 70, transparent=False, cached=False, name='useravatar')
		self['following']=MultiPixmap()
		self['PositionGauge']=myServicePositionGauge(self.session.nav)
		self['repeat']=MultiPixmap()
		self['islike']=MultiPixmap()
		self['isrepost']=MultiPixmap()
		self['isrepost2']=MultiPixmap()
		self['iscomment']=MultiPixmap()
		self['downloadable']=MultiPixmap()
		self['youtube']=MultiPixmap()
		self['shuffle']=MultiPixmap()
		self['title']=Label()
		self['textext']=Label()
		self['artist']=Label()
		self['artistonfollowing']=Label()
		self['genre']=Label()
		self['sc_plays']=Label('')
		self['reposted_by']=Label('')
		self['repost_count']=Label('')

		self['sc_likes']=Label('')
		self['sc_comments']=Label('')
		self['headertext']=Label()

		self.__event_tracker=ServiceEventTracker(screen=self, eventmap=
			{
				iPlayableService.evUser+10: self.__evAudioDecodeError,
				iPlayableService.evUser+12: self.__evPluginError,
				iPlayableService.evStart: self.__serviceStarted,
			})
			
		InfoBarSeek.__init__(self, actionmap="MediaPlayerSeekActions")
		self.songListOrig=[]
		self.hlpdict={}
		self.soundcloudInstance=soundcloudInstance
		self.currentIndex=index
		self.shuffle=False
		self.repeat=False
		self.currentFilename=""
		self.hasCover=False
		self.init=0
		self.onLayoutFinish.append(self.__onShown)
		# for lcd
		self.currentTitle=""
		self.dlrunnig=[]
		self.TOKEN=sc_client
		self.TVScreen=None

	def buildSkin(self):
		logger.info('SCPlayer]buildSkin]resolution->%s' %RESOLUTIONx)
		head1=SCSKINHEAD.split('	<!-- Buttons -->',)[0]
		head2=SCSKINHEAD.split('''<widget name="headertext"''',)[1]
		head=head1+'''<widget name="headertext"'''+head2
		if RESOLUTIONx>1800:
			self.skin= """
				<screen name="SCPlayerScreen" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#00000000" title="SoundCloud Player" zPosition="0">
					<!-- coverrahmen -->
						<eLabel backgroundColor="#191919" position="45,180" size="650,650" zPosition="1" /> 
						<widget name="coverArt" position="70,205" size="600,600" zPosition="3" />
					<!-- description -->
						<eLabel backgroundColor="#191919" position="720,210" size="1170,570" zPosition="1" />
						<widget name="title" position="750,300" size="1125,60" zPosition="3" transparent="1" font="SansReg;28" halign="left" valign="center"  foregroundColor="#ffffff" />
						<widget name="following" position="912,422" size="42,42" pixmaps="~/placeholder1.png,~/follow_x28.png" transparent="1" alphatest="on" zPosition="4"/>
						<widget name="artist" position="915,420" size="930,45" zPosition="3" transparent="1" font="SansReg;24" halign="left" valign="center"  foregroundColor="#ffffff" />
						<widget name="artistonfollowing" position="960,420" size="930,45" zPosition="3" transparent="1" font="SansReg;24" halign="left" valign="center"  foregroundColor="#ffffff" />
						<widget name="artistavatar" position="750,390" size="150,150" zPosition="4"/>
						<widget name="textext" position="915,495" size="390,48" zPosition="3" transparent="1" font="SansReg;22" halign="left" valign="center"  foregroundColor="#ffffff" />
						<widget name="genre" position="1500,495" size="300,54" zPosition="3" transparent="1" font="SansReg;24" halign="right" valign="center" foregroundColor="#ffffff" />
					<!-- wave  -->	
						<widget name="wave" position="60,915" size="1800,140" alphatest="on" zPosition="5"/>
						<widget name="PositionGauge" position="60,915" size="1800,140" zPosition="4" pointer="~/SC_progressbar.png:1920,90" backgroundColor="#00ffffff" />
					<widget source="session.CurrentService" render="Label" position="1725,870" size="150,45" zPosition="3" font="SansReg;22" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" >
							<convert type="ServicePosition">Length,ShowHours</convert>
					</widget>
					<widget source="session.CurrentService" render="Label" position="45,870" size="150,45" zPosition="3" font="SansReg;22" halign="right" valign="center" foregroundColor="#ffffff" transparent="1" >
							<convert type="ServicePosition">Position,ShowHours</convert>
					</widget>
					<widget name="shuffle" position="1718,900" size="75,54" pixmaps="~/placeholder1.png,~/shuffle.png" transparent="1" alphatest="on" zPosition="4"/>
					<widget name="repeat" position="1635,900" size="75,54" pixmaps="~/placeholder1.png,~/repeat.png" transparent="1" alphatest="on" zPosition="4"/>				
					<!-- Plays -->				
						<ePixmap position="780,630" size="40,40" pixmap="~/headphone30_white.png" alphatest="on" zPosition="4"/>
						<widget name="sc_plays" position="855,630" size="255,62" zPosition="3" transparent="1" font="SansReg;22" halign="left" valign="center" foregroundColor="#ff7700" />
					<!-- repost -->		
						<widget name="isrepost2" position="1755,630" size="20,20" pixmaps="~/placeholder1.png,~/repost_x16.png" transparent="1" alphatest="on" zPosition="4"/>
						<widget name="repost_count" position="1795,630" size="150,26" zPosition="3" transparent="1" font="SansReg;22" halign="left" valign="center" foregroundColor="#ffffff" />						
					<!-- likes -->				
						<widget name="islike" position="1110,630" size="40,40" pixmaps="~/heart32_white.png,~/heart32_orange.png" transparent="1" alphatest="on" zPosition="4"/>
						<widget name="sc_likes" position="1185,630" size="190,26" zPosition="3" transparent="1" font="SansReg;22" halign="left" valign="center" foregroundColor="#ff7700" />
					<!-- comment -->				
						<widget name="iscomment" position="1365,630" size="35,35" pixmaps="~/comment32_white.png,~/comment32_orange.png" transparent="1" alphatest="on" zPosition="4"/>
						<widget name="sc_comments" position="1440,630" size="200,30" zPosition="3" transparent="1" font="SansReg;22" halign="left" valign="center" foregroundColor="#ff7700" />
					<!-- download reposte -->	
						<widget name="isrepost" position="760,709" size="22,22" pixmaps="~/placeholder1.png,~/repost_x16.png" transparent="1" alphatest="on" zPosition="4"/>
						<widget name="reposted_by" position="825,705" size="470,30" zPosition="3" transparent="1" font="SansReg;22" halign="left" valign="center" foregroundColor="#ffffff" />
					<!-- youtube -->				
						<widget name="youtube" position="1660,630" size="108,108" pixmaps="~/placeholder1.png,~/youtube_32x32.png" transparent="1" alphatest="on" zPosition="4"/>
				""" + head + """
				</screen>""" 
		else:
			self.skin= """
				<screen name="SCPlayerScreen" position="0,0" size="1280,720" flags="wfNoBorder" backgroundColor="#00000000" title="SoundCloud Player" zPosition="0">
					<!-- coverrahmen -->
						<eLabel backgroundColor="#191919" position="30,120" size="430,430" zPosition="1" /> 
						<widget name="coverArt" position="45,135" size="400,400" zPosition="3" />
					<!-- description -->
						<eLabel backgroundColor="#191919" position="480,140" size="780,380" zPosition="1" />
						<widget name="title" position="500,200" size="750,58" zPosition="3" transparent="1" font="SansReg;26" halign="left" valign="center"  foregroundColor="#ffffff" />
						<widget name="following" position="608,281" size="28,28" pixmaps="~/placeholder1.png,~/follow_x28.png" transparent="1" alphatest="on" zPosition="4"/>
						<widget name="artist" position="610,280" size="620,30" zPosition="3" transparent="1" font="SansReg;22" halign="left" valign="center"  foregroundColor="#ffffff" />
						<widget name="artistonfollowing" position="640,280" size="620,30" zPosition="3" transparent="1" font="SansReg;22" halign="left" valign="center"  foregroundColor="#ffffff" />
						<widget name="artistavatar" position="500,260" size="100,100" zPosition="4"/>
						<widget name="textext" position="610,330" size="390,48" zPosition="3" transparent="1" font="SansReg;22" halign="left" valign="center"  foregroundColor="#ffffff" />
						<widget name="genre" position="1000,330" size="200,46" zPosition="3" transparent="1" font="SansReg;22" halign="right" valign="center" foregroundColor="#ffffff" />
					<!-- wave  -->	
						<widget name="wave" position="40,610" size="1200,96" alphatest="on" zPosition="5"/>
						<widget name="PositionGauge" position="40,610" size="1200,96" zPosition="4" pointer="~/SC_progressbar.png:1920,60" backgroundColor="#00ffffff" />
					<widget source="session.CurrentService" render="Label" position="1150,580" size="100,30" zPosition="3" font="SansReg;22" halign="left" valign="center" foregroundColor="#ffffff" transparent="1" >
							<convert type="ServicePosition">Length,ShowHours</convert>
					</widget>
					<widget source="session.CurrentService" render="Label" position="30,580" size="100,30" zPosition="3" font="SansReg;22" halign="right" valign="center" foregroundColor="#ffffff" transparent="1" >
							<convert type="ServicePosition">Position,ShowHours</convert>
					</widget>
					<widget name="shuffle" position="1145,600" size="50,35" pixmaps="~/placeholder1.png,~/shuffle.png" transparent="1" alphatest="on" zPosition="4"/>
					<widget name="repeat" position="1090,600" size="50,35" pixmaps="~/placeholder1.png,~/repeat.png" transparent="1" alphatest="on" zPosition="4"/>
					<!-- Plays -->				
						<ePixmap position="520,420" size="32,32" pixmap="~/headphone30_white.png" alphatest="on" zPosition="4"/>
						<widget name="sc_plays" position="570,420" size="170,26" zPosition="3" transparent="1" font="SansReg;22" halign="left" valign="center" foregroundColor="#ff7700" />
					<!-- repost -->		
						<widget name="isrepost2" position="1170,420" size="20,20" pixmaps="~/placeholder1.png,~/repost_x16.png" transparent="1" alphatest="on" zPosition="4"/>
						<widget name="repost_count" position="1195,420" size="100,26" zPosition="3" transparent="1" font="SansReg;22" halign="left" valign="center" foregroundColor="#ffffff" />						
					<!-- likes -->				
						<widget name="islike" position="740,420" size="32,32" pixmaps="~/heart32_white.png,~/heart32_orange.png" transparent="1" alphatest="on" zPosition="4"/>
						<widget name="sc_likes" position="790,420" size="190,26" zPosition="3" transparent="1" font="SansReg;22" halign="left" valign="center" foregroundColor="#ff7700" />
					<!-- comment -->				
						<widget name="iscomment" position="910,420" size="32,32" pixmaps="~/comment32_white.png,~/comment32_orange.png" transparent="1" alphatest="on" zPosition="4"/>
						<widget name="sc_comments" position="960,420" size="200,30" zPosition="3" transparent="1" font="SansReg;22" halign="left" valign="center" foregroundColor="#ff7700" />
					<!-- download reposte -->	
						<widget name="isrepost" position="520,475" size="20,20" pixmaps="~/placeholder1.png,~/repost_x16.png" transparent="1" alphatest="on" zPosition="4"/>
						<widget name="reposted_by" position="550,470" size="470,30" zPosition="3" transparent="1" font="SansReg;22" halign="left" valign="center" foregroundColor="#ffffff" />
					<!-- youtube -->				
						<widget name="youtube" position="1140,420" size="32,32" pixmaps="~/placeholder1.png,~/youtube_32x32.png" transparent="1" alphatest="on" zPosition="4"/>
				""" + head + """
				</screen>""" 
	
	def __onShown(self):
		logger.info('Player]__onShown]set duration...')
		self['artistavatar'].setTransitionDuration(700)
		self['coverArt'].setTransitionDuration(700)
		self.onShownAppend()
		
	def onShownAppend(self):
		if self.init == 0:
			logger.info('SCPlayer]onShownAppend]init=0')
			self.init=1
			self.playSong(self.currentIndex)
			self.showuseravatar()
		else:
			logger.info('SCPlayer]onShownAppend]init=1')

	def showuseravatar(self):
		logger.info('SCPlayer]showuseravatar]...')
		if self.TOKEN.me is not None:
			self['headertext'].setText(_("%s (%s)" %(myenCode(self.TOKEN.me.username), myenCode(self.TOKEN.me.full_name))))
		else:
			self['headertext'].setText(_("MusicCenter SoundCloud"))			
		if self.TOKEN.useravatar is not None:
			self['useravatar'].doshow(self.TOKEN.useravatar)
		else:
			self['useravatar'].hide()

	def pvr_pressed(self):
		options=[]
		if MEDIAINFO:
			options.append((_("Open Mediainfo"), self.openMediainfo),)
		if self.songList[self.currentIndex][0].fullitem.downloadable:# or fileExists('/etc/oscam/MCzuHause.txt'):
			options.append((_("Download current song"), self.dlPlayingSong),)
		options.append((_("Selct path for downloads"), self.startSelectPath),)
		self.session.openWithCallback(self.mycallback, ChoiceBox, title=_("Playeroptions"), list=options, keys=MYKEYSORT, titlebartext=_("MusicCenter"))

	def audio_pressed(self):
		options=[]
		if fileExists(resolveFilename(SCOPE_PLUGINS, 'Extensions/YTTrailer/plugin.pyo')):
			if len(self.songList[self.currentIndex][0].video_url):
				options.append((_("Play Youtube"), self.startYtTrailer),)
			options.append((_("Search video on Youtube"), self.startYtTrailerList),)
		if fileExists(resolveFilename(SCOPE_PLUGINS, 'Extensions/Wikipedia/plugin.pyo')):
			options.append((_("Get Artistinfo from Wikipedia"), self.wiki),)
		self.session.openWithCallback(self.mycallback, ChoiceBox, title=_(" Playeroptions"), list=options, keys=MYKEYSORT, titlebartext=_("MusicCenter"))

	def mycallback(self, ret):
		if ret is not None:
			if len(ret) == 3:
				ret and ret[1](ret[2])
			else:
				ret and ret[1]()

	def wiki(self):
		from Plugins.Extensions.Wikipedia.plugin import wikiSearch
		self.session.open(wikiSearch, self.songList[self.currentIndex][0].artist)

	def startYtTrailerList(self):
		eventname=self.songList[self.currentIndex][0].title+self.songList[self.currentIndex][0].artist
		logger.info('SCPlayer]startYtTrailerList]event:%s' %eventname)
		self.session.open(SearchYTList, eventname, self.playermode, self.TOKEN)

	def startYtTrailer(self):
		url=self.songList[self.currentIndex][0].video_url
		logger.info('SCPlayer]startYtTrailer]url:%s' %url)
		# http://youtu.be/8suiTp2v9ig 
		# http://www.youtube.com/watch?v=KYoT86d8kBc
		if 'youtu.be' in url:
			myid=url.rsplit('/')[-1]
		else:
			if not 'www.youtube.com' in url:
				url=self.unshorten_url(url)
				logger.info('SCPlayer]startYtTrailer]unshorten url:%s' %url)
			try:
				myid=url.split('?')[1].split('=')[1].split('&')[0]
			except Exception, e:
				logger.info('SCPlayer]startYtTrailer]Exception:%s' %e)
				return
		logger.info('SCPlayer]startYtTrailer]url found try to play id:%s' %myid)
		eventname=self.songList[self.currentIndex][0].title+self.songList[self.currentIndex][0].artist
		myytTrailer=SearchYT(self.session)
		myytTrailer.showTrailer(eventname, myid=myid)
		
	def unshorten_url(self, url):
		parsed=urlparse_urlparse(url)
		h=httplib_HTTPConnection(parsed.netloc)
		h.request('HEAD', parsed.path)
		response=h.getresponse()
		if response.status/100 == 3 and response.getheader('Location'):
			return response.getheader('Location')
		else:
			return url
		
	def menu_pressed(self):
		options=[]
		options.append((_("Global Configuration"), self.config),)
		options.append((_("View current running jobs"), self.jobView),)
		options.append((_("View Logfile"), self.startLog ),)
		self.session.openWithCallback(self.mycallback, ChoiceBox, title=_("Mainscreen Options"), list=options, keys=MYKEYSORT, titlebartext=_("MusicCenter"))

	def config(self):
		self.session.openWithCallback(self.setupFinished, MusicCenterSetup, 2)

	def startSelectPath(self):
		self.session.openWithCallback(self.cbPathSelected, SelectPath, config.plugins.musiccenter.sc_downloadfolder.value)
	
	def cbPathSelected(self, res):
		if res is not None:
			logger.info('SCPlayer]cbPathSelected]new path selected%s' %str(res))
			config.plugins.musiccenter.sc_downloadfolder.value=res[0]
			config.plugins.musiccenter.sc_downloadfolder.save()
			configfile.save()
	
	def dlPlayingSong(self):
		tracknr=time_strftime("%m%d", time_gmtime())
		title=myenCode(self.songList[self.currentIndex][0].title).replace('/','_')
		artist=myenCode(self.songList[self.currentIndex][0].artist).replace('/','_')
		genre=myenCode(self.songList[self.currentIndex][0].genre).replace('/','_')
		date=myenCode(self.songList[self.currentIndex][0].artist).replace('/','_')
		fn=''.join((config.plugins.musiccenter.sc_downloadfolder.value, tracknr, ' - ', artist, ' ', title,'.mp3'))
		url=str(self.TOKEN.client.get(self.songList[self.currentIndex][0].streamurl, allow_redirects=False).location)
		thumb=self.songList[self.currentIndex][0].thumb
		if fileExists(thumb):
			sh_copy2(thumb, '/tmp/.dl_cover.jpg')		
		logger.info('SCPlayer]dlPlayingSong]title->%s url->%s to->%s'%(title, url, fn))
		job_manager.AddJob(downloadJob(url, fn, title))
		#job_manager.AddJob(coverEmbedJob(coverfn='/tmp/.dl_cover.jpg', item=self.songList[self.currentIndex][0], addid3=(tracknr, artist, title, genre, date)))

	def startLog(self):
		self.session.open(LogScreen)
		
	def jobView(self):
		self.tasklist=[]
		for job in job_manager.getPendingJobs():
			self.tasklist.append((job,job.name,job.getStatustext(),int(100*job.progress/float(job.end)) ,str(100*job.progress/float(job.end)) + "%" ))
		self.session.open(MusicCenterTasksScreen, self.tasklist)

	def openMediainfo(self):
		logger.info('SCPlayer]openMediainfo...')
		tracknr=time_strftime("%m%d", time_gmtime())
		title=myenCode(self.songList[self.currentIndex][0].title).replace('/','_').strip()
		artist=myenCode(self.songList[self.currentIndex][0].artist).replace('/','_').replace('by','').strip()
		downloadfilename=''.join((config.plugins.musiccenter.sc_downloadfolder.value, tracknr, ' - ', artist, ' - ', title,'.mp3'))
		self.session.open(PluginMediainfo, downloadfilename)
	
	def keyOk(self):
		logger.info('SCPlayer]keyOk]')
		options=[]
		curr=self.songList[self.currentIndex][0]
		options.append((_("Show comments"), self.openSCComments, curr),)
		options.append((_("Show description"), self.showdescription, curr),)
		options.append((_("Show userinfo"), self.showUserinfo, curr),)
		options.append((_("Add a comment"), self.openSCAddComment, curr),)
		if self.TOKEN.me is not None:
			if not curr.fullitem.user_favorite:
				options.append((_("Like playing song"), self.likeTrack, curr),)
			else:
				options.append((_("Unlike playing song"), self.unlikeTrack, curr),)
			options.append((_("Repost playing song"), self.repostTrack, curr),)
			if not curr.fullitem.user_id in self.TOKEN.myfollowing_ids:
				options.append((_("Follow %s" %curr.artist[3:]), self.follow, curr),)
			else:
				options.append((_("Unfollow %s" %curr.artist[3:]), self.unfollow, curr),)
		self.session.openWithCallback(self.mycallback, ChoiceBox, title=_("Trackoptions"), list=options, keys=MYKEYSORT, titlebartext=_("MusicCenter"))

	def openSCComments(self, curr):
		timestamp=self['PositionGauge'].get()
		time=str(datetime_timedelta(0,timestamp[1]/90000))
		self.session.open(SCCommentScreen, curr, self.TOKEN, self.skin_path, time)
	
	def openSCAddComment(self, curr):
		timestamp=self['PositionGauge'].get()
		time=str(datetime_timedelta(0,timestamp[1]/90000))
		self.session.openWithCallback(self.addCommentNow, SCAddComment, curr, self.TOKEN, self.skin_path, time)
	
	def addCommentNow(self, curr=None, t0=None, body=None):
		if curr is not None:
			logger.info('SCPlayer]addCommentNow]result:%s %s %s' %(str(curr), str(t0), body))
			t1=t0.split(':')
			t2=datetime_time(int(t1[0]),int(t1[1]),int(t1[2]))
			timestamp=(t2.hour*3600+t2.minute*60+t2.second)*1000
			comment=self.TOKEN.client.post('/tracks/%d/comments' % curr.fullitem.id, comment={'body': body,'timestamp': timestamp})
			logger.info('SCPlayer]addCommentNow]timestamp-> %d ->comment-> %s' %(timestamp, str(comment)))
			del curr, body
			
	def follow(self, curr):
		res=self.TOKEN.client.put('/users/%d/followings/%d' %(self.TOKEN.me.id, curr.fullitem.user_id))
		logger.info('SCPlayer]follow]result:%s' %res)
		self.updatemyfollowingsTOKEN(curr)
		
	def updatemyfollowingsTOKEN(self, curr):
		myfollowings, myfollowing_ids=getSoundCloudaccesstoken.getMyfollowings(self.TOKEN.client)
		self.TOKEN.myfollowings=myfollowings
		self.TOKEN.myfollowing_ids=myfollowing_ids
		saveToken(self.TOKEN)
		self.setartist(curr)
		del curr
		
	def unfollow(self, curr):
		res=self.TOKEN.client.delete('/users/%d/followings/%d' %(self.TOKEN.me.id, curr.fullitem.user_id))
		logger.info('SCPlayer]follow]result:%s' %res)
		self.updatemyfollowingsTOKEN(curr)
		
	def likeTrack(self, curr):
		logger.info('SCPlayer]likeTrack]start')
		try:
			res=self.TOKEN.client.put('/users/%d/favorites/%d' %(self.TOKEN.me.id, curr.fullitem.id))
			res=myenCode(res.status)
			logger.info('SCPlayer]likeTrack]res->%s' %res)
			if res.startswith('2'):
				self['islike'].setPixmapNum(1)
				self.songList[self.currentIndex][0].islike=True
				self.TOKEN.me=self.TOKEN.client.get('/me')
				self.TOKEN.mylikedTracks_ids.append(curr.fullitem.id)
				saveToken(self.TOKEN)
				self.soundcloudInstance.clearCache()#
			else:
				self.session.open(MessageBox, _("Error like track\n-->%s") %res, type=MessageBox.TYPE_ERROR, title="MusicCenter", timeout=6 )
		except Exception, e:
			logger.error('SCPlayer]likeTrack]%s' %e)
		del curr
			
	def unlikeTrack(self, curr):
		res=self.TOKEN.client.delete('/users/%d/favorites/%d' %(self.TOKEN.me.id, curr.fullitem.id))
		if res.startswith('2'):
			self['islike'].setPixmapNum(0)
			curr.islike=False
			self.TOKEN.me=self.TOKEN.client.get('/me')
			f=[ self.TOKEN.mylikedTracks_ids.pop(id) for id in self.TOKEN.mylikedTracks_ids if id==curr.fullitem.id ]
			saveToken(self.TOKEN)
		else:
			self.session.open(MessageBox, _("Error unlike track\n-->%s") %res, type=MessageBox.TYPE_ERROR, title="MusicCenter", timeout=6 )
			del curr

	def repostTrack(self, curr):
		logger.info('SCPlayer]repostTrack]start')
		try:
			res=self.TOKEN.client.put('/e1/me/track_reposts/%d' %( curr.fullitem.id))
			res=myenCode(res.status)
			logger.info('SCPlayer]repostTrack]res->%s' %res)
			if res.startswith('2'):
				self['isrepost'].setPixmapNum(1)
			else:
				self.session.open(MessageBox, _("Error repost track\n-->%s") %res, type=MessageBox.TYPE_ERROR, title="MusicCenter", timeout=6 )
		except Exception, e:
			logger.error('SCPlayer]repostTrack]%s' %e)
		del curr

	def unrepostTrack(self, curr):
		logger.info('SCPlayer]repostTrack]start')
		try:
			res=self.TOKEN.client.delete('/e1/me/track_reposts/%d' %( curr.fullitem.id))
			res=myenCode(res.status)
			logger.info('SCPlayer]repostTrack]res->%s' %res)
			if res.startswith('2'):
				self['isrepost'].setPixmapNum(0)
			else:
				self.session.open(MessageBox, _("Error unrepost track\n-->%s") %res, type=MessageBox.TYPE_ERROR, title="MusicCenter", timeout=6 )
		except Exception, e:
			logger.error('SCPlayer]repostTrack]%s' %e)
		del curr
		
	def showdescription(self, curr):
		self.session.open(SCTrackinfo, curr, self.TOKEN)

	def showUserinfo(self, curr):
		self.session.open(SCUserinfo, curr, self.TOKEN, curr.artistpic)
		
	def setupFinished(self, result):
		pass
		#self.resetScreenSaverTimer()

	def playSong(self, currentIndex):
		logger.info('SCPlayer]playSong]currentIndex->%s' %currentIndex)
		try:# end of list
			curr=self.songList[currentIndex][0]
		except Exception, e:
			logger.error('SCPlayer]playSong]->%s' %e)
			currentIndex=0
			curr=self.songList[currentIndex][0]
		self.currentFilename=curr.streamurl # hier ist es der neue Song
		self.currentIndex=currentIndex
		#self['artistavatar'].dohide()
		self.session.nav.stopService()
		self.setartist(curr)
		self['title'].setText(curr.title)
		self['textext'].setText('Powered by SoundCloud')
		self['genre'].setText(curr.genre)
		try:
			sessionstreamurl=str(self.TOKEN.client.get(curr.streamurl, allow_redirects=False).location)
			logger.info('SCPlayer]playSong]sessionstreamurl %s' %sessionstreamurl)
			#stream_url=self.TOKEN.client.get('/i1/tracks/' + str(curr.fullitem.user.id) + '/streams?client_id=' + self.TOKEN.client.client_id).rtmp_mp3_128_url
			self.session.nav.playService(eServiceReference(4097, 0, sessionstreamurl))
		except Exception, e:
			logger.error('SCPlayer]playSong]1 Error get sessionstreamurl with error:%s' %e)
			try:
				logger.info('SCPlayer]playSong]track id->%s' %curr.fullitem.id)
				q=('/i1/tracks/%d/streams?client_id=%s' %(curr.fullitem.id, self.TOKEN.client.client_id))
				res=self.TOKEN.client.get(q)
				stream_url_rtmp=str(res.preview_mp3_128_url)
				#stream_url_rtmp=str(self.TOKEN.client.get('/i1/tracks/' + str(curr.fullitem.id) + '/streams?client_id=' + self.TOKEN.client.client_id).rtmp_mp3_128_url)
				logger.info('SCPlayer]playSong]retry play with rtmp stream_url_rtmp->%s' %stream_url_rtmp)
				if len(stream_url_rtmp):
					self.session.nav.playService(eServiceReference(4097, 1, stream_url_rtmp))#
					logger.info('SCPlayer]playSong]play now mp3 prev...')
				else:
					t='Error, can´t resolve streamurl'
					self['textext'].setText(t)
					logger.error('SCPlayer]playSong]->%s' %t)
			except Exception, e:
				logger.error('SCPlayer]playSong]2Error get sessionstreamurl %s with error:%s' %(curr.streamurl,e))
				self['textext'].setText('Error: %s' %e)
				self['wave'].hide()
				self['sc_plays'].setText('')
				self['reposted_by'].setText('')
				self['repost_count'].setText('')
				self['sc_likes'].setText('')
				self['sc_comments'].setText('')			
		#sref=eServiceReference(4097, 0, sessionstreamurl)
		#self.session.nav.playService(sref)
		self.getArtistpic(curr)
		self['sc_plays'].setText(str(curr.playback_count))
		if curr.type=='track-repost':
			self['reposted_by'].setText(curr.reposted_by)
			self['isrepost'].setPixmapNum(1)
			self['isrepost2'].setPixmapNum(1)
		else:
			self['reposted_by'].setText('')
			self['isrepost'].setPixmapNum(0)
			self['isrepost2'].setPixmapNum(0)
			
		self['sc_comments'].setText(str(curr.comment_count))
		if curr.iscomment:
			self['iscomment'].setPixmapNum(1)
		else:
			self['iscomment'].setPixmapNum(0)
			
		self['repost_count'].setText(str(curr.fullitem.reposts_count))
			
		if curr.fullitem.downloadable:
			self['downloadable'].setPixmapNum(1)
		else:
			self['downloadable'].setPixmapNum(0)
		if curr.video_url:
			self['youtube'].setPixmapNum(1)
		else:
			self['youtube'].setPixmapNum(0)
		self.coverShow(curr.thumb)
		#wave
		wavefn='/tmp/mc/%d_wave.png' %curr.fullitem.id
		if os_path.exists(wavefn):
			self.waveShow(wavefn)
		else:
			if not curr.fullitem.waveform_url:
				new_fullitem=self.TOKEN.client.get('/tracks/%s'%curr.fullitem.id)
				curr=SCItem(cache_it=True, fullitem=new_fullitem, mode=curr.mode, thumb=curr.thumb, islike=curr.islike, iscomment=curr.iscomment, isfollower=curr.isfollower, isfollowing=curr.isfollowing, isplaylist_trackcount=curr.isplaylist_trackcount, type=curr.type, reposted_by=curr.reposted_by)
				self.songList[currentIndex]=(curr,)
			
			waveurl=curr.fullitem.waveform_url
			waveurl=waveurl.replace('https://w1.', 'http://wis.').replace('.png','.json').replace('https://','http://')
			logger.info('SCPlayer]getWave]url->%s' %waveurl)
			getPage(myenCode(waveurl),).addCallback(self.paintWaveFromJson, wavefn).addErrback(self.wavedownloadError, 'wave')
			
		self['sc_likes'].setText(curr.likes_count)	
		if curr.islike:
			self['islike'].setPixmapNum(1)
		else:
			self['islike'].setPixmapNum(0)

	def setartist(self, curr):
		if curr.fullitem.user_id in self.TOKEN.myfollowing_ids:
			self['artistonfollowing'].setText(curr.artist)
			self['artist'].setText('')
			self['following'].setPixmapNum(1)
		else:
			self['artist'].setText(curr.artist)
			self['artistonfollowing'].setText('')
			self['following'].setPixmapNum(0)

	def getArtistpic(self, curr):
		artwork_url, artwork_fn=resolveArtistartwork(curr.fullitem, resolvecover=False)
		if os_path.exists(artwork_fn):
			self.artistavatarShow(artwork_fn)
		else:
			logger.info('SCPlayer]getArtistpic]NEW=>artwork_url->%s artwork_fn-->%s' %(artwork_url, artwork_fn))
			downloadPage(artwork_url, artwork_fn).addCallback(self.dlFinishShowArtistpic, artwork_fn).addErrback(self.dlerrorArtistpic, 'artistavatar')

	def dlFinishShowArtistpic(self, result, fn):
		if fileExists(fn):
			self.artistavatarShow(fn)
	
	def dlerrorArtistpic(self, error='', comment=''):
		self['artistavatar'].hide()
		logger.error('SCPlayer]dlerrorArtistpic]error->%s ->comment->%s' %(error, comment))		

	def artistavatarShow(self, fn):
		self['artistavatar'].setPicture(fn)
		self['artistavatar'].show()
	
	def __serviceStarted(self):
		logger.info('SCPlayer]__serviceStarted]')
		
	def paintWaveFromJson(self, res, wavefn):
		#LOG('SCPlayer]paintWaveFromJson]res->%s' %str(res))
		jsonres=json_loads(res)
		#LOG('SCPlayer]paintWaveFromJson]jsonres->%s' %str(jsonres))
		scaled_loudness=jsonres.get('samples')
		pixel_x=jsonres.get("width")
		pixel_y=jsonres.get("height")
		color='black'
		im = Image.new('RGBA',(pixel_x, pixel_y))
		for i in xrange(pixel_x):
			im.paste(color,(i, 0, i+1, pixel_y-scaled_loudness[i]))
		im.save(wavefn)
		self.waveShow(wavefn)

	def wavedownloadError(self, error, type):
		logger.info('SCPlayer]wavedownloadError]%s-->%s'%(type, error))

	def waveShow(self, wavefn=''):
		logger.info('SCPlayer]waveShow] show pic:%s'  %wavefn)
		self['wave'].doshow(wavefn)
		
	def coverShow(self, coverfn=''):
		logger.info('SCPlayer]coverShow] show pic:%s'  %coverfn)
		self['coverArt'].setPicture(coverfn)
		self['coverArt'].show()

	def __evAudioDecodeError(self):
		currPlay=self.session.nav.getCurrentService()
		sAudioType=currPlay.info().getInfoString(iServiceInformation.sUser+10)
		logger.info("SCPlayer]__evAudioDecodeError]audio-codec %s can't be decoded by hardware" % (sAudioType))
		self.session.open(MessageBox, _("This Dreambox can't decode %s streams!") % sAudioType, type=MessageBox.TYPE_INFO, title="MusicCenter",timeout=20 )

	def __evPluginError(self):
		currPlay=self.session.nav.getCurrentService()
		message=currPlay.info().getInfoString(iServiceInformation.sUser+12)
		logger.info('SCPlayer]__evPluginError]Error: %s' %message)
		self.session.open(MessageBox, message, type=MessageBox.TYPE_INFO, title="MusicCenter",timeout=20 )

	def doEofInternal(self, playing):
		logger.info('SCPlayer]doEofInternal]Start, playNext')
		if playing:
			self.playNext()

	def checkSkipShowHideLock(self):
		pass
		#self.updatedSeekState()

	def updatedSeekState(self):
		if self.seekstate == self.SEEK_STATE_PAUSE:
			self['dvrStatus'].setPixmapNum(1)
		elif self.seekstate == self.SEEK_STATE_PLAY:
			self['dvrStatus'].setPixmapNum(0)

	def pauseEntry(self):
		self.pauseService()

	def play(self): # play the current song from beginning again
		self.playSong(self.currentIndex)

	def unPauseService(self):
		self.setSeekState(self.SEEK_STATE_PLAY)

	def stopEntry(self):
		logger.info('SCPlayer]stopEntry]clear list now...')
		self.session.nav.stopService()
		self.songListOrig=[]
		self.songList=[]
		self.close()

	def playNext(self):
		currentIndex=self.currentIndex
		try:
			curr=self.songList[currentIndex][0]
			if not self.hlpdict.get('repeat', False):
				currentIndex += 1
			self.playSong(currentIndex)
			self.currentIndex=currentIndex
		except Exception, e:
			logger.error('SCPlayer]playNext]->%s' %e)
			self.playSong(0)
			self.currentIndex=0
		if len(self.songList)-1==currentIndex:
			logger.info('SCPlayer]playNext]index->%s is one  step for List end, get now more entrys...' %currentIndex)
			self.soundcloudInstance.getNextEntries(result=True)

	def playPrevious(self):
		index=self.currentIndex
		curr=self.songList[index][0]
		if not self.hlpdict.get('repeat', False):
			if index - 1 < 0:
				self.currentIndex=len(self.songList) - 1
			else:
				self.currentIndex -= 1
		self.playSong(self.currentIndex)

	def shuffleList(self):
		self.hlpdict['shuffle']=not self.hlpdict.get('shuffle', False)
		if self.hlpdict.get('shuffle'):
			self['shuffle'].setPixmapNum(1)
			if not self.hlpdict.get('filtered', False):
				self.songListOrig=self.songList[:]
			shuffle(self.songList)
		else:
			self.songList=self.songListOrig[:]
			if not self.hlpdict.get('filtered', False):
				self.songListOrig=[]
			self['shuffle'].setPixmapNum(0)
		index=0
		for x in self.songList:
			if x[0].filename == self.currentFilename:
				self.currentIndex=index
				break
			index += 1

	def shuffleList_old(self):
		self.shuffle=not self.shuffle
		if self.shuffle:
			self['shuffle'].setPixmapNum(1)
			self.songListOrig=self.songList[:]
			shuffle(self.songList)
		else:
			self.songList=self.songListOrig[:]
			self.songListOrig=[]
			self['shuffle'].setPixmapNum(0)
		index=0
		for x in self.songList:
			if x[0].filename == self.currentFilename:
				self.currentIndex=index
				break
			index += 1

	def repeatSong(self):
		self.hlpdict['repeat']= not self.hlpdict.get('repeat', False)
		if self.hlpdict.get('repeat'):
			self['repeat'].setPixmapNum(1)
		else:
			self['repeat'].setPixmapNum(0)

	def info_pressed(self):
		options=[]
		if fileExists(resolveFilename(SCOPE_PLUGINS, 'Extensions/PicturePlayer/plugin.pyo')):
			options.append((_("Start Pictureviewer"), self.startPicshow),)
		if fileExists(resolveFilename(SCOPE_PLUGINS, 'Extensions/PicturePlayer2/plugin.pyo')):
			options.append((_("Start Pictureviewer2"), self.startPicshow2),)
		self.session.openWithCallback(self.mycallback, ChoiceBox, title=_(" Infooptions"), list=options, keys=MYKEYSORT, titlebartext=_("MusicCenter"))

	def startPicshow(self):
		from Plugins.Extensions.PicturePlayer.plugin import picshow
		self.session.open(picshow)

	def startPicshow2(self):
		from Plugins.Extensions.PicturePlayer2.pictureplayer2 import picshow2
		self.session.open(picshow2)
		
	def showSongList(self):
		reload(SongList)
		if config.plugins.musiccenter.songliststyle.value==0:
			self.session.openWithCallback(self.showSongListCallback, SongList.SongList0, self.songList, self.currentIndex, playermode=2, TOKEN=self.TOKEN)
		elif config.plugins.musiccenter.songliststyle.value==1:
			self.session.openWithCallback(self.showSongListCallback, SongList.SongList1, self.songList, self.currentIndex, playermode=2, TOKEN=self.TOKEN)
		elif config.plugins.musiccenter.songliststyle.value==2:
			self.session.openWithCallback(self.showSongListCallback, SongList.SongList2, self.songList, self.currentIndex, playermode=2, TOKEN=self.TOKEN)

	def showSongListCallback(self, index):
		logger.info('Player]showSongListCallback]...')
		if index==-2:
			self.showSongList()
		elif index!=-1:
			self.playSong(index)

	def destroy(self):
		logger.info('SCPlayer]destroy]')
		self['coverArt'].destroy()
		self['wave'].destroy()
		self['artistavatar'].destroy()
		self['useravatar'].destroy()
		
	def closePlayer(self):
		self.close()

	def __onClose(self):
		logger.info('SCPlayer]__onClose]')


class SCUserinfo(Screen):

	def __init__(self, session, curr, TOKEN, artistavatarfn):
		logger.info('SCUserinfo]init...')
		Screen.__init__(self, session)
		self.skin_path='/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images'
		self.buildSkin()
		self['actions']=ActionMap(["WizardActions", "DirectionActions", "ColorActions", "EventViewActions"],
		{
			"back": self.close,
			"pageUp": self.pageUp,
			"pageDown": self.pageDown,
		}, -1)
		self.curr=curr
		self.text=[]
		self['log_text']=ScrollLabel()
		self['log_text_2']=ScrollLabel()
		self['headertext']=Label()
		self['useravatar']=PicLoaderScale(70,70)
		self['artistavatar']=PicLoaderScale(100,100)
		self.TOKEN=TOKEN
		self.artistavatarfn=artistavatarfn
		self.onLayoutFinish.append(self.startRun)

	def buildSkin(self):
	
		head1=SCSKINHEAD.split('	<!-- Buttons -->',)[0]
		head2=SCSKINHEAD.split('''<widget name="headertext"''',)[1]
		head=head1+'''<widget name="headertext"'''+head2
		self.skin="""
			<screen name="SCUserinfo" position="0,0" size="1280,720" flags="wfNoBorder" backgroundColor="#00000000" title="MusicCenter SCUserinfo">
				<widget name="log_text" position="20,190" zPosition="3" size="1240,520" font="SansReg;21" transparent="1" halign="left" valign="top" foregroundColor="#ffffff" backgroundColor="#00000000"/>
				<widget name="log_text_2" position="130,80" zPosition="3" size="1130,100" font="SansReg;21" transparent="1" halign="left" valign="top" foregroundColor="#ffffff" backgroundColor="#00000000"/>
				<widget name="artistavatar" position="20,80" size="100,100" zPosition="4"/>
			""" + head + """
			</screen>"""
		
	def startRun(self):
	
		logger.info('SCUserinfo]startRun')
		user=self.TOKEN.client.get('/users/%d' %(self.curr.fullitem.user_id))
		text2=myenCode('Name: %s Username: %s Online: %s)\n' %(user.full_name, user.username, str(user.online))).replace("\r\n","\n")
		text2+=myenCode('Website: %s (%s)\n' %(user.website, user.website_title)).replace("\r\n","\n")
		text2+=myenCode('Plan: %s\n' %user.plan).replace("\r\n","\n")
		text2+=myenCode('City: %s  Country: %s\n' %(user.city, user.country)).replace("\r\n","\n")
		text=myenCode('Description:\n%s' %user.description).replace("\r\n","\n")
		self['headertext'].setText('%s by %s' %(myenCode(self.curr.fullitem.title), myenCode(self.curr.artist)))
		self['log_text'].setText(text)
		self['log_text_2'].setText(text2)
		self.showuseravatar()
		self.showuserAvatar2()
		
	def showuseravatar(self):
		if self.TOKEN.useravatar is not None:
			self['useravatar'].doshow(self.TOKEN.useravatar)

	def showuserAvatar2(self):
		self['artistavatar'].doshow(self.artistavatarfn)


	def pageUp(self):
		self['log_text'].pageUp()

	def pageDown(self):
		self['log_text'].pageDown()
		
	def destroy(self):
		logger.info('SCUserinfo]destroy]')
		self['artistavatar'].destroy()
		self['useravatar'].destroy()
		
	def __onClose(self):
		logger.info('SCUserinfo]__onClose] Start')

			
class SCTrackinfo(Screen):


	def __init__(self, session, curr, TOKEN):
		logger.info('SCTrackinfo]init...')
		Screen.__init__(self, session)
		self.skin_path='/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images'
		self.buildSkin()
		self['actions']=ActionMap(["WizardActions", "DirectionActions", "ColorActions", "EventViewActions"],
		{
			"back": self.close,
			"pageUp": self.pageUp,
			"pageDown": self.pageDown,
		}, -1)
		self.curr=curr
		self.text=[]
		self['log_text']=ScrollLabel()
		self['headertext']=Label()
		self['useravatar']=PicLoaderScale(70,70)
		self.TOKEN=TOKEN
		self.onLayoutFinish.append(self.startRun)

	def buildSkin(self):
		head1=SCSKINHEAD.split('	<!-- Buttons -->',)[0]
		head2=SCSKINHEAD.split('''<widget name="headertext"''',)[1]
		head=head1+'''<widget name="headertext"'''+head2
		self.skin="""
			<screen name="SCTrackinfo" position="0,0" size="1280,720" flags="wfNoBorder" backgroundColor="#00000000" title="MusicCenter SCTrackinfo">
				<widget name="log_text" position="20,130" zPosition="3" size="1240,550" font="SansReg;21" transparent="1" foregroundColor="#ffffff" backgroundColor="#00000000"/>
			""" + head + """
			</screen>"""

	def startRun(self):
		logger.info('SCTrackinfo]startRun')
		#for line in myenCode(self.curr.fullitem.description).split('\r\n'):
		#	self.text.append(line)
		text=myenCode(self.curr.fullitem.description).replace("\r\n","\n")
		text +="Tags\n\n"
		text +=myenCode(self.curr.fullitem.tag_list).replace("\r\n","\n")
		self['headertext'].setText('%s by %s' %(myenCode(self.curr.fullitem.title), myenCode(self.curr.artist)))
		self['log_text'].setText(text)
		#self.setTitle('%s by %s' %(myenCode(self.curr.fullitem.title), myenCode(self.curr.fullitem.title)))
		self.showuseravatar()
		
	def showuseravatar(self):
		if self.TOKEN.useravatar is not None:
			self['useravatar'].doshow(self.TOKEN.useravatar)
			
	def pageUp(self):
		self['log_text'].pageUp()

	def pageDown(self):
		self['log_text'].pageDown()
		
	def destroy(self):
		logger.info('SCTrackinfo]destroy]')
		self['useravatar'].destroy()
		
	def __onClose(self):
		logger.info('SCTrackinfo]__onClose] Start')


class SCAddComment(Screen, ConfigListScreen):
	
	def __init__(self, session, curr, TOKEN, skin_path, time):#, servicelist):
		logger.info('SCAddComment]init...')
		self.session=session
		self.skin_path=skin_path
		self.buildSkin()
		Screen.__init__(self, session)
		
		self['actions']=ActionMap(["WizardActions", "DirectionActions", "ColorActions", "EPGSelectActions", "InfobarAudioSelectionActions"],
		{
			"back": self.cancel,
			"ok": self.keyOk
		}, -1)

		self['key_red']=StaticText("")
		self['key_green']=StaticText("")
		self['key_yellow']=StaticText("")
		self['key_blue']=StaticText("")
		self['headertext']=Label()
		self['useravatar']=PicLoaderScale(70,70)

		config.plugins.musiccenter.comment= NoSave(ConfigText(default='' , fixed_size=False))
		self.curr=curr
		self.time=time
		self.config=[]
		self.config.append(getConfigListEntry(_("Enter your Comment here:"), config.plugins.musiccenter.comment))
		ConfigListScreen.__init__(self, self.config, session)
		self['headertext'].setText(_('Add a comment to the playing song @%s' %time))
		self.TOKEN=TOKEN

	def buildSkin(self):
		self.skin="""
			<screen name="SCAddCommentScreen" position="center,180" size="1280,280" backgroundColor="#00000000" title="MusicCenter SoundCloud Add Comment" zPosition="0">
				<widget name="config" position="100,190" size="1080,40" scrollbarMode="showOnDemand"/>
				"""+SCSKINHEAD+"""		
			</screen>"""
		
	def __onShown(self):
		if self.TOKEN.useravatar is not None:
			self['useravatar'].doshow(self.TOKEN.useravatar)

	def keyOk(self):		
		if config.plugins.musiccenter.comment.value:
			self.close(self.curr, self.time, config.plugins.musiccenter.comment.value)
		else:
			self.cancel()

	def keyAudio(self):
		pass#self.close([config.plugins.musiccenter.sc_search.value, "Genres'])
	
	def cancel(self):
		self.close(None)
		
	def destroy(self):
		logger.info('SCAddComment]destroy]')
		self['useravatar'].destroy()


def buildCommententry(comment, ptr):
	imagesize=100 + 1
	res=[ comment ]
	if ptr==None:#tumb
		ptr=LoadPixmap(cached=True, path='/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/default_avatar_badge.png')
	offset0=10
	if ptr is not None:
		t=myenCode(comment.fullitem.body)
		if t.startswith('@') and ':' in t:
				offset0+=25
		res.append((eListboxPythonMultiContent.TYPE_PIXMAP, offset0, 0, imagesize, imagesize, ptr))
	offset=offset0 + imagesize + 10
	name=myenCode(comment.fullitem.user[u'username'])
	try:time=str(datetime_timedelta(0, comment.fullitem.timestamp/1000))
	except: time='0:00:00'
	res.append((eListboxPythonMultiContent.TYPE_TEXT, offset,  3, 850-offset, 26, 0, RT_HALIGN_LEFT | RT_VALIGN_CENTER, ''.join((name,' @ ',time)))) # user + timestamp 1160
	res.append((eListboxPythonMultiContent.TYPE_TEXT, offset,  32, 1130-offset, 44, 1, RT_HALIGN_LEFT | RT_VALIGN_CENTER | RT_WRAP , myenCode(comment.fullitem.body)))
	res.append((eListboxPythonMultiContent.TYPE_TEXT, 850,  3, 300, 26, 0, RT_HALIGN_RIGHT | RT_VALIGN_CENTER, str(comment.fullitem.created_at.rsplit(' ',1)[0]))) # date
	return res


class SCCommentScreen(Screen):
		
	def __init__(self, session, entry, TOKEN, skin_path, time):
		self.session=session
		self.skin_path=skin_path
		self.buildSkin()
		self.time=time
		
		Screen.__init__(self, session)
		self['headertext']=Label()
		self['useravatar']=PicLoaderScale(70,70)
		self.picloader_100=PicLoaderScale(100,100, transparent=False, cached=True)
		self['key_red']=StaticText("Close")
		self['key_green']=StaticText("Sort by Playtime")
		self['key_yellow']=StaticText("Sort by Createtime")
		self['key_blue']=StaticText("")
		self['waittext']=Label()
		self['waittext'].hide()
		
		self['actions'] =ActionMap(["WizardActions", "DirectionActions", "ColorActions", "EPGSelectActions", "InfobarAudioSelectionActions", "InfobarActions", "MediaPlayerActions"],
		{
			"ok"    : self.keyOK,
			"back": self.keyCancel,
			"red": self.keyRed,
			"green" : self.keyGreen,
			"yellow" : self.keyYellow,
			"down": self.keyDown,
			"right": self.keyRight,
		}, -1)
		
		self.chooseMenuList=MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		self.chooseMenuList.l.setFont(0, gFont("SansReg", 24))
		self.chooseMenuList.l.setFont(1, gFont("SansReg", 20))
		self.chooseMenuList.l.setItemHeight(101)
		self.piccount=0
		self['imagelist']=self.chooseMenuList
		self.list=[]
		self.entry=entry
		self.TOKEN=TOKEN
		self.offset=0
		self.commentlist=[]
		self.picdir=''.join((config.plugins.musiccenter.downloadcache.value, 'soundcloud/'))
		if not pathExists(self.picdir + 'tmp/'):
			if not createDir(self.picdir + 'tmp/', makeParents=True):
				self.picdir='/tmp/mc/'
		self.isendoflist=False
		self.onLayoutFinish.append(self.startRun)

	def buildSkin(self):
		self.skin="""
			<screen name="SCCommentScreen" position="0,0" size="1280,720" flags="wfNoBorder" backgroundColor="#00000000" zPosition="0">
			<widget name="imagelist" position="50,140" zPosition="1" size="1180,505" scrollbarMode="showOnDemand" backgroundColor="#00000000"/>
			<widget name="waittext" position="100,335" size="1080,50" font="SansReg;40" foregroundColor="#ffffff" backgroundColor="#00000000" halign="center" valign="center" zPosition="6" />
			""" + SCSKINHEAD + """
		</screen>"""

	def startRun(self):
		limit, offset, commentlisttmp, res=200, 0, [], 1
		self.showuseravatar()
		while res:
			#LOG('SCCommentScreen]buildCommentlist]res:%s' %str(res))
			res =[commentlisttmp.append(i) for i in self.TOKEN.client.get('/tracks/%d/comments' %self.entry.fullitem.id, offset=offset, limit=limit )]
			offset += limit
		logger.info('SCCommentScreen]buildCommentlist]%d comments fetched' %len(commentlisttmp))
		self.commentlist=commentlisttmp
		commentlisttmp=[]
		self.buildCommentlist() # keyGreen() mmmmmmmmmmmmmmmmmmmmmmmmmmm
		
	def buildCommentlist(self, isresort=False):
		limit=64
		if isresort:
			commentlistpart=self.commentlist
		else:
			commentlistpart=self.commentlist[self.offset:self.offset+limit]
		if commentlistpart:
			if len(commentlistpart) < limit:
				self.isendoflist=True
			imagedllist, picis=[],[]
			for index,comment in enumerate(commentlistpart):
				url=myenCode(comment.user[u'avatar_url'].replace('large','t500x500').replace('https://','http://'))
				if 'default_avatar_large.png' in url:
					fn ='/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/default_avatar_large.png'
				else:
					fn=''.join((self.picdir, url.rsplit('/',1)[1].rsplit('?',1)[0]))
					if not fileExists(fn) and fn not in picis :
						picis.append(fn)
						imagedllist.append(PicDownloadItem(url=url,filename=fn, index=index))
				self.list.append(SCAllItem(fullitem=comment, thumb=fn))
			picis=None
			self.offset += limit
			ds=defer.DeferredSemaphore(tokens=10)
			#downloads=[ ds.run(download,item).addCallback(self.finishedPicDownload, item.index) for item in imagedllist ]
			downloads=[ ds.run(download,item) for item in imagedllist ]
			finished=defer.DeferredList(downloads).addCallback(self.finishedAllPicDownloads).addErrback(self.errorAllPicDownloads)
			imagedllist=None
		logger.info('SCCommentScreen]buildCommentlist]%d comments loaded' %len(commentlistpart))
		self.chooseMenuList.setList([ buildCommententry(entry, self.picloader_100.load(entry.thumb)) for entry in self.list])
		commentcount=self.entry.comment_count
		lenshowinglist=len(self.list)
		self['headertext'].setText("%s (%d/%s comments) @ %s" %(self.entry.title, lenshowinglist, commentcount, self.time))
		
	def finishedPicDownload(self, result, index):
		if self.piccount == 5:
			self.chooseMenuList.setList([ buildCommententry(entry, self.picloader_100.load(entry.thumb)) for entry in self.list])
			self.piccount=0
		else:
			self.piccount += 1
			
	def finishedAllPicDownloads(self, result):
		self['waittext'].hide()
		logger.info('SCCommentScreen]finishedAllPicDownloads]done...')
		self.chooseMenuList.setList([ buildCommententry(entry, self.picloader_100.load(entry.thumb)) for entry in self.list])

	def errorAllPicDownloads(self, error):
		logger.error('SCCommentScreen]errorAllPicDownloads]error %s' %str(error))
				
	def keyDownbak(self):
		if self['imagelist'].getSelectionIndex()+1 == len(self.list):
			if not self.isendoflist:
				if config.plugins.musiccenter.sc_autoloadnextfeeds.value:
					self.session.openWithCallback(self.getNextEntries, MessageBox, _("Do you want to see more results?"))	
				else:
					self.getNextEntries(True)
			else:
				self['imagelist'].moveToIndex(0)
		else:
			self['imagelist'].moveToIndex(self['imagelist'].getSelectionIndex()+1)

	def keyDown(self):
		index=self['imagelist'].getSelectionIndex()
		count=len(self.list)
		if index in(count-1,count):	
			if not self.isendoflist:
				if config.plugins.musiccenter.sc_autoloadnextfeeds.value:
					self.session.openWithCallback(self.getNextEntries, MessageBox, _("Do you want to see more results?"))	
				else:
					self['waittext'].setText('Load more results...')
					self['waittext'].show()	
					self.getNextEntries(True)
			else:
				if index in(count-1,):
					self['imagelist'].down()#self['list'].moveToIndex(index+1)# down
				else:
					self['imagelist'].moveToIndex(0)
		else:
			self['imagelist'].down()#.moveToIndex(index+1)# down

	def keyRight(self):
		index=self['imagelist'].getSelectionIndex()
		count=len(self.list)
		logger.info('SCCommentScreen]keyRight]index->%d count->%d' %(index, count))
		
		if index==count:	
			if not self.isendoflist:
				if config.plugins.musiccenter.sc_autoloadnextfeeds.value:
					self.session.openWithCallback(self.getNextEntries, MessageBox, _("Do you want to see more results?"))	
				else:
					self['waittext'].setText('Load more results...')
					self['waittext'].show()	
					self.getNextEntries(True)
		else:
			self['imagelist'].pageDown()

	def getNextEntries(self, result):
		if not result:
			return
		self.buildCommentlist()
				
	def keyOK(self):
		pass
	
	def keyCancel(self):
		self.close()
		
	def showuseravatar(self):
		if self.TOKEN.useravatar is not None:
			self['useravatar'].doshow(self.TOKEN.useravatar)

	def keyRed(self):
		self.keyCancel()
		
	def keyGreen(self):
		self.list=[]
		l=sorted(self.commentlist, key=lambda a:a.timestamp)
		self.commentlist=l
		del l
		#self.offset=0
		self.buildCommentlist(True)

	def keyYellow(self):
		self.list=[]
		l =sorted(self.commentlist, key=lambda a:a.created_at)
		self.commentlist=l
		del l
		self.buildCommentlist(True)
	
	def destroy(self):
		logger.info('SCAddComment]destroy]')
		self['useravatar'].destroy()
		self.picloader_100.destroy()
	

		