# -*- coding: UTF-8 -*-

#  Music Center E2
#
#  Coded by bobo71 (c) 2014
#  Support: www.dreambox-tools.info
#
#  All Files of this Software are licensed under the Creative Commons
#  Attribution-NonCommercial-ShareAlike 3.0 Unported
#  License if not stated otherwise in a Files Head. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.

#  Additionally, this plugin may only be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.

#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially
#  distributed other than under the conditions noted above.
#  This applies to the source code as a whole as well as to parts of it, unless
#  explicitely stated otherwise.


from Globals import *
from JobCenter import *
from JobCenter2 import *
from ItemClasses import CacheItem, Item, PicDownloadItem, MethodArguments
from ListClasses import *
import Player
from RadioBrowser import RadioBrowserList, load_obj, save_obj
from Setup import MusicCenterSetup
from EditStreamFavorite import EditFavoriteStreamDB
from radiodeApi import RadioDeApi


class RadioDeMain(Screen):

	if RESOLUTIONx>1800:

		skin='''<screen name="RadioDeMain" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#00000000" zPosition="0">
			<!-- Header -->
				<ePixmap position="20,20" size="100,100" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/RadioDex200.png" scale="1" zPosition="2"/>
				<eLabel backgroundColor="#191919" position="20,20" size="1900,100" zPosition="1" />
				<widget name="headertext" position="140,39" size="1760,42" font="SansReg;35" foregroundColor="#ffffff" backgroundColor="#191919" halign="center" valign="center" zPosition="3" />
			<!-- Buttons -->
				<eLabel position="20,135" size="1900,50" backgroundColor="#191919" zPosition="1" />
				<!-- arrow left -->
					<widget render="Label" font="SansReg;44" position="30,138" size="40,44" source="key_arrow_left" foregroundColor="#ffffff" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
				<!-- red -->
					<widget render="Label" font="SansReg;38" position="100,138" size="450,42" source="key_red" foregroundColor="#ff0000" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
					<widget name="line_red" position="105,180" size="440,3" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/white450x3.png" />
				<!-- green -->
					<widget render="Label" font="SansReg;38" position="510,138" size="450,42" source="key_green" foregroundColor="#00ff21" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
					<widget name="line_green" position="515,180" size="440,3" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/white450x3.png" />
				<!-- yellow -->
					<widget render="Label" font="SansReg;38" position="960,138" size="450,42" source="key_yellow" foregroundColor="#FFD800" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
					<widget name="line_yellow" position="965,180" size="440,3" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/white450x3.png" />
				<!-- blue -->
					<widget render="Label" font="SansReg;38" position="1410,138" size="450,42" source="key_blue" foregroundColor="#3D8DFF" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
					<widget name="line_blue" position="1415,180" size="440,3" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/white450x3.png" />
				<!-- arrow right -->
					<widget render="Label" font="SansReg;44" position="1870,138" size="40,44" source="key_arrow_right" foregroundColor="#ffffff" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
			<widget name="list" position="35,195" zPosition="1" size="1850,855" scrollbarMode="showOnDemand" backgroundColor="#00000000"/>
		</screen>'''
	
	else:
	
		skin='''<screen name="RadioDeMain" position="0,0" size="1280,720" flags="wfNoBorder" backgroundColor="#00000000" zPosition="0">
			<!-- Header -->
				<ePixmap position="13,13" size="66,66" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/RadioDex200.png" scale="1" zPosition="2"/>
				<eLabel backgroundColor="#191919" position="13,13" size="1266,66" zPosition="1" />
				<widget name="headertext" position="93,26" size="1173,28" font="SansReg;23" foregroundColor="#ffffff" backgroundColor="#191919" halign="center" valign="center" zPosition="3" />
			<!-- Buttons -->
				<eLabel position="13,90" size="1266,33" backgroundColor="#191919" zPosition="1" />
				<!-- arrow left -->
					<widget render="Label" font="SansReg;29" position="20,92" size="26,29" source="key_arrow_left" foregroundColor="#ffffff" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
				<!-- red -->
					<widget render="Label" font="SansReg;25" position="66,92" size="300,28" source="key_red" foregroundColor="#ff0000" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
					<widget name="line_red" position="70,120" size="293,2" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/white450x3.png" />
				<!-- green -->
					<widget render="Label" font="SansReg;25" position="340,92" size="300,28" source="key_green" foregroundColor="#00ff21" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
					<widget name="line_green" position="343,120" size="293,2" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/white450x3.png" />
				<!-- yellow -->
					<widget render="Label" font="SansReg;25" position="640,92" size="300,28" source="key_yellow" foregroundColor="#FFD800" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
					<widget name="line_yellow" position="643,120" size="293,2" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/white450x3.png" />
				<!-- blue -->
					<widget render="Label" font="SansReg;25" position="940,92" size="300,28" source="key_blue" foregroundColor="#3D8DFF" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
					<widget name="line_blue" position="943,120" size="293,2" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/white450x3.png" />
				<!-- arrow right -->
					<widget render="Label" font="SansReg;44" position="1246,92" size="26,29" source="key_arrow_right" foregroundColor="#ffffff" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
			<widget name="list" position="23,130" zPosition="1" size="1233,570" scrollbarMode="showOnDemand" backgroundColor="#00000000"/>
		</screen>'''

	def __init__(self, session, player, currentService, serviceList):

		logger.info('RadioDe]init...')
		self.session=session
		self.currentService=currentService
		self.serviceList=serviceList
		self.skin_path='/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images'

		Screen.__init__(self, session)
		
		self['list']=RadioBrowserList([])
		self["actions"]=ActionMap(["WizardActions", "DirectionActions", "ColorActions", "EPGSelectActions", "InfobarAudioSelectionActions","HelpActions"],
		{
			"input_date_time": self.menuPressed,
			"info" : self.infoPressed,
			"ok": self.okPressed,
			"back": self.closing,
			"red": self.redPressed,
			"green": self.greenPressed,
			"yellow": self.yellowPressed,
			"blue": self.bluePressed,
			"prevService": self.keyLeft,
			"nextService": self.keyRight,
			"audioSelection": self.audioPressed,
		}, -1)

		self.onLayoutFinish.append(self.startRun)
		self.onClose.append(self.__onClose)

		self.player=player
		self["key_arrow_left"]=StaticText("")
		self["key_red"]=StaticText("")
		self["line_red"] = Pixmap()
		self["line_red"].hide()
		self["key_green"]=StaticText("")
		self["line_green"] = Pixmap()
		self["line_green"].hide()
		self["key_yellow"]=StaticText("")
		self["line_yellow"] = Pixmap()
		self["line_yellow"].hide()
		self["key_blue"]=StaticText("")
		self["line_blue"] = Pixmap()
		self["line_blue"].hide()
		self["key_arrow_right"]=StaticText(">")
		self.bottomlineindex=0

		self['headertext']=Label()
		self.hlp={}
		self.dllist=[]
		self.piccount=0
		self.picdir=self.initPicDir()
		self.mode='MainMenu'
		self.headerpos=0
		self.hl=[]
		if fileExists(resolveFilename(SCOPE_CONFIG, 'mc_RadioDeSearchhist')):
			self.suchhistorylist=load_obj(resolveFilename(SCOPE_CONFIG, 'mc_RadioDeSearchhist'))
		else:
			self.suchhistorylist=[]

	def initPicDir(self):
		picdir=''.join((config.plugins.musiccenter.downloadcache.value, 'RadioDe/'))
		if not pathExists(picdir):
			if not createDir(picdir, makeParents=True):
				picdir='/tmp/mc/'
		return picdir

	def startRun(self):
		logger.info('RadioDe]startRun]')
		self.api=RadioDeApi()
		self.api.__init__('german')
		self.MainMenu() # self.buildRoot(navigator=False)#redPressed()

	def MainMenu(self):
		self.hl=['Favoriten', 'Meine letzt gespielt', 'Empfohlene Stationen', 'Locale Stationen', 'Top 100', 'Meist gesucht','Stationen nach Kategorie', 'Suche', 'Suchhistory', '','','']
		header='Willkommen bei Radio.de'
		self.setListNow(list=[], header=header, red=self.hl[0], green=self.hl[1], yellow=self.hl[2], blue=self.hl[3])

	def setListNow(self, list=[], index=0, header=None, red=None, green=None, yellow=None, blue=None, aussortiert=0, dllist=[]):
		logger.info('RadioDe]setListNow]')
		self['list'].setList(list)
		self['list'].moveToIndex(index)
		if header !=None:
			itemcount=self['list'].getItemCount()
			if aussortiert==0:
				self['headertext'].setText(_('%s(%d)' %(header, itemcount)))
			else:
				self['headertext'].setText(_('%s(%d) aussortiert(%d)' %(header, itemcount, aussortiert)))
		self.setButtons(red, green, yellow, blue)
		if len(dllist):
			stationiconDownloader.Start(dllist, self.picdir, 'RADIODE')

	def clearListNow(self):
		self['list'].setList([])
		self['list'].moveToIndex(0)

	def setButtons(self, red=None, green=None, yellow=None, blue=None):
		if red!=None:
			self["key_red"].setText(red)
		if green!=None:
			self["key_green"].setText(green)
		if yellow!=None:
			self["key_yellow"].setText(yellow)
		if blue!=None:
			self["key_blue"].setText(blue)

	def setBottomline(self, key=-1):
		logger.info('RadioDe]setBottomline]key->%d' %key)
		if key>-1:
			self.bottomlineindex=key
		self["line_red"].hide()
		self["line_green"].hide()
		self["line_yellow"].hide()
		self["line_blue"].hide()
		if key in range(0,12,4):
			self["line_red"].show()
		elif key in  range(1,12,4):
			self["line_green"].show()
		elif key in  range(2,12,4):
			self["line_yellow"].show()
		elif key in  range(3,12,4):
			self["line_blue"].show()

	def keyLeft(self):
		if self.headerpos>0:
			self.headerpos-=4
			self['key_arrow_left'].setText('<')
			self.setButtons(red=self.hl[self.headerpos+0], green=self.hl[self.headerpos+1], yellow=self.hl[self.headerpos+2], blue=self.hl[self.headerpos+3])
			if not self.headerpos>0:
				self['key_arrow_left'].setText('')

		if self.headerpos>0:
			self['key_arrow_right'].setText('>')
		self.updateBottomline()

	def keyRight(self):
		if self.headerpos < len(self.hl)-4:
			self.headerpos+=4
			self['key_arrow_right'].setText('>')
			self.setButtons(red=self.hl[self.headerpos+0], green=self.hl[self.headerpos+1], yellow=self.hl[self.headerpos+2], blue=self.hl[self.headerpos+3])
			if not self.headerpos < len(self.hl)-4:
				self['key_arrow_right'].setText('')

		if self.headerpos>0:
			self['key_arrow_left'].setText('<')
		self.updateBottomline()

	def updateBottomline(self):
		if self.bottomlineindex not in range(self.headerpos, self.headerpos+4):
			self.setBottomline(-1)
		else:
			self.setBottomline(self.bottomlineindex)

	def redPressed(self):
		logger.info('RadioDe]redPressed]')
		self.selectMode(0)

	def greenPressed(self):
		logger.info('RadioDe]greenPressed]')
		self.selectMode(1)

	def yellowPressed(self):
		logger.info('RadioDe]yellowPressed]')
		self.selectMode(2)

	def bluePressed(self):
		logger.info('RadioDe]bluePressed]')
		self.selectMode(3)

	def selectMode(self, mode):
		mode=self.headerpos+mode
		logger.info('RadioDe]selectMode]get new mode:{}'.format(mode))
		self.setBottomline(mode)
		self.setListNow([], header='')
		#'0 Favoriten',1 Meine letzt gespielt', 2 Empfohlene Stationen, 3 Locale Stationen, 4 Top 100, 5 Meist gesucht, 6 Stationen nach Kategorie, 7 Suche, 8 Suchhistory
		if mode==0:
			self.listeFavoriten()
			self.mode='listeFavoriten'
		elif mode==1:
			self.meineLetztGespielt()
			self.mode='meineLetztGespielt'
		elif mode==2:
			self.empfohleneStationen()
			self.mode='empfohleneStationen'
		elif mode==3:
			self.localeStationen()
			self.mode='localeStationen'
		elif mode==4:
			self.top100()
			self.mode='top100'
		elif mode==5:
			self.meistGesucht()
			self.mode='meistGesucht'
		elif mode==6:
			self.stationenNachKategorie()
			self.mode='stationenNachKategorie'
		elif mode==7:
			self.startSuche()
			self.mode='startSuche'
		elif mode==8:
			self.startSuchhistory()
			self.mode='startSuchhistory'			
		logger.info('RadioDe]selectMode]call:{}'.format(self.mode))

	def buildStationlistEntrys(self, stationen):
		outsorted=0
		list=[]
		dllist=[]
		for station in stationen:
			#LOG('RadioDe]getrecommendationStationList]%s'%str(station))# s[u'currentTrack']
			codec=myenCode(station[u'streamContentFormat'])
			bitrate=station[u'bitrate']
			if (codec == 'MP3' and int(bitrate) >= int(config.plugins.musiccenter.minmp3streamingrate.value)) or (codec == 'AAC' and int(bitrate) >= int(config.plugins.musiccenter.minaacstreamingrate.value)) or (codec == 'WMA' and int(bitrate) >= int(config.plugins.musiccenter.minwmastreamingrate.value)):
				stationname=myenCode(station[u'name']).replace('/','-')				
				stationiconpath=self.buildStationIconsDownload(station, stationname)
				if not fileExists(stationiconpath):
					dllist.append(station)
				list.append((Item(streamID=station[u'id'], text=myenCode(station[u'name']), mode='PLAY', title=myenCode(station[u'currentTrack']), stationname=stationname, genre=myenCode(station[u'genresAndTopics']), location=myenCode(station[u'country']), bitrate=str(bitrate), codec=codec, stationicon=stationiconpath, join=True, filetype='RADIODE', playcount=station[u'rank'], votes=station[u'rating'] , audio=True),))
			else:
				outsorted+=1
		return list, outsorted, dllist

	def buildStationIconsDownload(self, station, stationname):
		stationiconurl=myenCode(station[u'pictureBaseURL']+'t175.png')
		filename=''.join((cleanName(stationname), '.png'))
		stationiconfilename=os_path.join(self.picdir, filename)
		return stationiconfilename

	def downloadIconsNow(self):
		logger.info('RadioDe]downloadIconsNow]')
		ds = defer.DeferredSemaphore(tokens=4)
		downloads = [ ds.run(mcdownloadPage,item.url, item.filename) for item in self.dllist ]
		self.dllist=[]
		finished = defer.DeferredList(downloads).addCallback(self.finishedAllPicDownloads).addErrback(self.errorOnAllPicDownloads)
		logger.info('RadioDe]downloadIconsNow]end')

	def finishedAllPicDownloads(self, result):
		logger.info('RadioDe]finishedAllPicDownloads]:'.format(result[:10]))

	def errorOnAllPicDownloads(self, error):
		logger.info('RadioDe]errorOnAllPicDownloads]:'.format(error[:10]))

	def menuPressed(self):
		options=[(_("Configuration"), self.config),]
		if self.mode == 'listeFavoriten':
			options.extend(((_("Edit stream favorite"), self.editStreamFromFavoriteList),))
			options.extend(((_("Remove stream from favorites"), self.removeStreamFromFavoriteList),))		
		else:
			options.extend(((_("Add selected stream to favorite list"), self.addStreamToFavoriteList),))
			if self.player is not None and self.player.songList:
				options.extend(((_("Add current playing stream to favorite list"), self.addCurrentStreamToFavorite),))
		self.session.openWithCallback(self.generallyCallback, ChoiceBox, list=options)

	def config(self):
		self.session.openWithCallback(self.setupFinished, MusicCenterSetup)

	def setupFinished(self, result):
		if result:
			pass#self.redPressed()

	def infoPressed(self):
		self.showRadioChannelList()		

	def generallyCallback(self, ret):
		if ret is not None:
			if len(ret) == 3:
				ret and ret[1](ret[2])
			else:
				ret and ret[1]()

	def okPressed(self):
		logger.info('RadioDe]okPressed]start')
		if self.player is not None:
			if self.player.hlp.get('currIndex')!=-2: # -2 ->is stopPlay!
				self.player.stopPlay()
			logger.debug('RadioDe]okPressed]is player instance, delete now...')
			self.session.deleteDialog(self.player)
			self.player=None			
		try:
			if JCcheckModuleIsUpdated('Player'):
				reload(Player)
		except Exception, e:
			logger.exception('RadioDe]Error reload Player')
			self.session.open(MessageBox, _("Error reload Player\n%s" %e), type=MessageBox.TYPE_ERROR, timeout=10 )
	
		logger.debug('RadioDe]okPressed]instantiate new player dialog')
		self.player=self.session.instantiateDialog(Player.Player, songList=self['list'].getList(), index=self['list'].getSelectedIndex(), playermode=RADIODE, currentService=self.currentService, serviceList=self.serviceList, radiodeinstance=self)
		self.player.setShowHideAnimation("quick_fade")
		self.session.execDialog(self.player)
# lists...
	def listeFavoriten(self):
		sql='''
		SELECT *
		FROM Stream_Favorites
		ORDER BY stationname;'''
		cursor=sqlCommand_Streaming_WithReturn(sql, dbname='musiccenter_stream_favorites.db')
		
		list=[]
		for row in cursor.fetchall():
			stationicon=row['stationicon']
			#stationiconpath=self.buildStationIconsDownload(station, stationname)

			if not pathExists(stationicon):
				stationname=row['stationname']
				stationicon=''.join((self.picdir, stationname, '.png'))
				if not pathExists(stationicon):
					stationicon=drawImageJobWithLongMultilineText(text=stationname, round=20)
			codec=row['codec']
			if codec=='UNKNOWN':
				codec='n/a'
			list.append((Item(songID=row['station_id'], streamID=row['streamID'], text=row['stationname'], stationname=row['stationname'], genre=row['genre'], location=row['location'], bitrate=row['bitrate'], codec=codec, streamurl=row['streamurl'], join=True, filetype=row['filetype'], audio=True, stationicon=stationicon, playcount=row['clicks'], rating=10, votes=row['votes']),))
		self.setListNow(list=list, header='Favoriten ')

	def meineLetztGespielt(self):
		sql='''
		SELECT *
		FROM Stream_Recent
		ORDER BY station_id DESC;'''
		cursor=sqlCommand_Streaming_WithReturn(sql, dbname='musiccenter_stream_favorites.db')
		list=[]
		for row in cursor:
			stationname=row['stationname']
			stationicon=row['stationicon']
			if not pathExists(stationicon):
				stationicon=''.join((self.picdir, stationname, '.png'))
				if not pathExists(stationicon):
					stationicon=drawImageJobWithLongMultilineText(text=stationname, round=20)
			codec=row['codec']
			if codec=='UNKNOWN':
				codec='n/a'
			list.append((Item(id=row['station_id'], streamID=row['streamID'], text=row['stationname'], stationname=row['stationname'], genre=row['genre'], location=row['location'], bitrate=row['bitrate'], codec=codec, streamurl=row['streamurl'], join=True, filetype=row['filetype'], audio=True, stationicon=stationicon, playcount=row['clicks'], votes=row['votes']),))
		self.setListNow(list=list, header='Letzt gespielte Stationen ')

	def empfohleneStationen(self):
		logger.info('RadioDe]empfohleneStationen]')
		stationen=self.api.get_recommendation_stations()
		list, aussortiert, dllist=self.buildStationlistEntrys(stationen)
		header=_("Empfohlene Stationen ")
		self.setListNow(list=list, header=header, aussortiert=aussortiert, dllist=dllist)

	def localeStationen(self):
		logger.info('RadioDe]localeStationen]')
		stationen= self.api.get_local_stations()
		list, aussortiert, dllist=self.buildStationlistEntrys(stationen)
		header=_("Locale Stationen ")
		self.setListNow(list=list, header=header, aussortiert=aussortiert, dllist=dllist)
		self.downloadIconsNow()
		
	def top100(self):
		logger.info('RadioDe]top100]')
		stationen= self.api.get_top_stations()
		list, aussortiert, dllist=self.buildStationlistEntrys(stationen)
		header=_("Top 100 Stationen ")
		self.setListNow(list=list, header=header, aussortiert=aussortiert, dllist=dllist)
		self.downloadIconsNow()

	def meistGesucht(self):
		logger.info('RadioDe]meistGesucht]')
		res=self.api._get_most_wanted()#[u'topBroadcasts', u'bookmarkedBroadcasts', u'recommendedBroadcasts', u'localBroadcasts', u'historyBroadcasts']
		list=[]
		aussortiert=0
		dllist=[]
		for stationskey in iter(res):
			logger.debug('RadioDe]meistGesucht]{}'.format(stationskey))
			stationen=res[stationskey]
			t_list, t_aussortiert, t_dllist=self.buildStationlistEntrys(stationen)
			list+=t_list
			aussortiert+=t_aussortiert
			dllist+=t_dllist
		header=_("Meist gesuchte Stationen ")
		self.setListNow(list=list, header=header, aussortiert=aussortiert, dllist=dllist)
		self.downloadIconsNow()

# Categorias...
	def buildLists(self, list, favorites):
		entrylist=[]
		favlist=[]
		for entry in list:
			name=entry['name'].encode()
			stationcount=entry['stationcount'].encode()
			if name in favorites:
				favlist.append((_("* %s(%s) *" %(name.title(), stationcount)), name),)
			else:
				entrylist.append((_("%s(%s)" %(name.title(), stationcount)), name),)
		return favlist+entrylist
		
	def stationenNachKategorie(self):
		logger.info('RadioDe]stationenNachKategorie]')
		categorytypes= []
		for cat in self.api.get_category_types(): #(u'genre', u'topic', u'country', u'city', u'language')
			categorytypes.append((myenCode(cat).title().replace('/','-'), cat))
		self.session.openWithCallback(self.selectedKategorie, ChoiceBox, title=_('Bitte Kategorie ausw�hlen'), list=categorytypes, keys=MYKEYSORT, titlebartext='MusicCenter Radio.de')

	def selectedKategorie(self, categorytype):
		if categorytype is not None:
			categorytype=categorytype[1]
			logger.info('RadioDe]selectedKategorie]{}'.format(categorytype))
			self.hlp['categorytype']=categorytype
			cats=[]
			for cat in self.api.get_categories(categorytype):#[u'2000s', u'20s', u'20s 30s 40s', u'30s', u'40s', u'50s', u'60s', ..... u'World', u'Zarzuela', u'Zouk']
					cats.append((myenCode(cat).title().replace('/','-'), cat))
			self.session.openWithCallback(self.buildCategorieStationList, ChoiceBox, title=_('Bitte %s ausw�hlen'.format(categorytype)), list=cats, keys=MYKEYSORT, titlebartext='MusicCenter Radio.de')

	def buildCategorieStationList(self, category):
		if category is not None:
			category=category[1]
			logger.info('RadioDe]buildCategorieStationList]{}'.format(category))
			categorytype=self.hlp.get('categorytype', '')
			stationen=self.api.get_stations_by_category(categorytype, category)
			list, aussortiert, dllist=self.buildStationlistEntrys(stationen)
			header=_("{}/{}  Stationen ".format(categorytype,category))
			self.setListNow(list=list, header=header, aussortiert=aussortiert, dllist=dllist)
			self.downloadIconsNow()
# suche
	def startSuche(self):
		self.session.openWithCallback(self.sucheJetzt, vInputBox, title=_('Suchbegriff eingeben!'), windowTitle=_("Radio.de Suche"), text=LAST_STREAM_SEARCH)

	def sucheJetzt(self, suchwort):
		if suchwort:
			LAST_STREAM_SEARCH=suchwort
			global LAST_STREAM_SEARCH
			logger.info('RadioDe]sucheJetzt]res:{}'.format(suchwort))
			self.buildSearchStationList(suchwort)
			self.updateSearchhistory(suchwort)
		else:
			header="No Searchword given"
			self.setListNow(list=[], header=header)

	def buildSearchStationList(self, res):
		stationen=self.api.search_stations_by_string(res.decode('utf-8'))
		list, aussortiert, dllist=self.buildStationlistEntrys(stationen)
		header=_("{}  Stationen ".format(res))
		self.setListNow(list=list, header=header, aussortiert=aussortiert, dllist=dllist)
		self.downloadIconsNow()
# suchhistory...
	def startSuchhistory(self):
		logger.debug('RadioDe]startSuchhistory]suchhistorylist:{}'.format(self.suchhistorylist))
		list=[]
		for wort, count in sorted(self.suchhistorylist,reverse=True,  key=lambda a:a[1]):
			list.append(('{} ({})'.format(wort, count), wort))
		self.session.openWithCallback(self.suchHistoryCB, ChoiceBox, title=_('Bitte Suchwort ausw�hlen'), list=list, keys=MYKEYSORT, titlebartext='MusicCenter Radio.de')

	def suchHistoryCB(self, suchwort):
		logger.debug('RadioDe]suchHistoryCB]suchwort:{}'.format(suchwort))
		if suchwort is not None:
			self.buildSearchStationList(suchwort[1])
			self.updateSearchhistory(suchwort[1])
		else:
			header="No Searchword given"
			self.setListNow(list=[], header=header)

	def updateSearchhistory(self, suchwort):
		history_neu=[]
		neues_wort=True
		for entry in self.suchhistorylist:
			wort, count=entry
			if suchwort==wort:
				count+=1
				neues_wort=False
			history_neu.append((wort, count))
			
		if neues_wort:
			history_neu.append((suchwort, 1))
		logger.debug('RadioDe]updateSearchhistory]save suchhistorylist neu:{}'.format(history_neu))
		save_obj(history_neu, resolveFilename(SCOPE_CONFIG ,"mc_RadioDeSearchhist"))
		self.suchhistorylist=history_neu

	def addStreamToFavoriteList(self):
		sel=self.getCurrentSelection()
		if sel:
			addStreamToFavoriteList(sel)

	def removeStreamFromFavoriteList(self, sel=None):# also called from player
		if sel is None:
			sel=self.getCurrentSelection()
		if sel is not None:
			removeStreamFromFavoriteList(sel)
			logger.info('RadioDe]removeStreamFromFavoriteList]remove station->%s' %sel.stationname)
			i=self['list'].getCurrentIndex()
			self['list'].removeItem(i)
			self['list'].refreshList()

	def editStreamFromFavoriteList(self):
		sel=self.getCurrentSelection()
		if sel:
			self.session.openWithCallback(self.MusicCenterEditFavoriteStreamDBClosed, EditFavoriteStreamDB, sel.stationname)

	def MusicCenterEditFavoriteStreamDBClosed(self, res):
		if res!=None:# stationname
			logger.info('RadioDe]MusicCenterEditFavoriteStreamDBClosed]update Favoritelist stationname  %s ' %(res))
			self.buildMyFavoriteStationList()

	def addCurrentStreamToFavorite(self):
		self.player.addCurrentStreamToFavorite()

	def infoCallback(self, ret):
		ret and ret[1]()

	def sortFavoritesByStation(self):
		
		self.favoriteList=sorted(self.favoriteList, key=lambda a:a[0].stationname)
		self.setFavoriteslist(order='Station')

	def sortFavoritesByGenre(self):

		self.favoriteList=sorted(self.favoriteList, key=lambda a:a[0].genre)
		self.setFavoriteslist(order='Genre')

	def sortFavoritesByLocation(self):

		self.favoriteList=sorted(self.favoriteList, key=lambda a:a[0].location)
		self.setFavoriteslist(order='Location')

	def sortFavoritesByCodec(self):

		self.favoriteList=sorted(self.favoriteList, key=lambda a:a[0].codec)
		self.setFavoriteslist(order='Codec')

	def sortFavoritesByStreamurl(self):
		self.favoriteList=sorted(self.favoriteList, key=lambda a:a[0].streamurl)
		self.setFavoriteslist(order='Streamurl')

	def setFavoriteslist(self, order):
		self['list'].setList(self.favoriteList)
		self['headertext'].setText(_("Favorites (%d Stations) -> List Order by %s ") % (len(self.favoriteList),order))

	def audioPressed(self):
		if self.player is not None and self.player.songList:
			self.session.execDialog(self.player)

	def closePlayerNow(self):
		logger.info('RadioDe]closePlayerNow]')
		self.player.closePlayer()
		self.session.deleteDialog(self.player)
		self.player=None

	def getCurrentSelection(self):
		try: sel=self['list'].l.getCurrentSelection()[0]
		except: sel=None
		return sel

	def keyNumberPressed(self, number):
		if number == 0 and self.mode!='buildRoot':
			self['list'].moveToIndex(0)
			self.ok()

	def closing(self):
		logger.info('RadioDe]closing]')
		if stationiconDownloader.isRunning:
			logger.info('RadioDe]closing]cancel stationiconDownloader')
			stationiconDownloader.cancel()
		self.close(self.player)

	def __onClose(self):
		logger.info('RadioDe]__onClose]...')


class RadioDeSearch(Screen, ConfigListScreen):

	def __init__(self, session, skin_path):
		logger.info('RadioDeSearch]init...')
		self.session=session
		self.skin_path=skin_path
		self.buildSkin()
		Screen.__init__(self, session)

		self["actions"]=ActionMap(["WizardActions", "DirectionActions", "ColorActions", "EPGSelectActions", "InfobarAudioSelectionActions"],
		{
			"back": self.cancel,
			"red": self.keyRed,
			"green": self.keyGreeen,
			"yellow": self.keyYellow,
			"blue": self.keyBlue,
			"ok": self.keyOk
		}, -1)

		self["key_red"]=StaticText("")
		self["key_green"]=StaticText("")
		self["key_yellow"]=StaticText("")
		self["key_blue"]=StaticText("")
		self["headertext"]=Label()

		self.config=[]
		self.config.append(getConfigListEntry(_("Enter Searchword here"), config.plugins.musiccenter.sc_search))
		ConfigListScreen.__init__(self, self.config, session)
		self['headertext'].setText(_('Search...'))

	def  buildSkin(self):

		self.skin="""
		<screen name="RadioDeSearch" position="center,180" size="1280,280" backgroundColor="#00000000" title="MusicCenter Radio.de Search" zPosition="0">
			<widget name="config" position="100,190" size="1080,40" scrollbarMode="showOnDemand"/>
		""" + RDESKINHEAD +  """
		</screen>"""
		logger.debug('RadioDeSearchSkin->%s' %self.skin)

	def __onShown(self):
		pass

	def keyOk(self):
		self.close(config.plugins.musiccenter.sc_search.value)

	def keyRed(self):
		pass#self.close([config.plugins.musiccenter.sc_search.value, "Tracks"])

	def keyGreeen(self):
		pass#self.close([config.plugins.musiccenter.sc_search.value, "Playlists"])

	def keyYellow(self):
		pass#self.close([config.plugins.musiccenter.sc_search.value, "Users"])

	def keyBlue(self):
		pass#self.close([config.plugins.musiccenter.sc_search.value, "Groups"])

	def cancel(self):
		self.close(None)
