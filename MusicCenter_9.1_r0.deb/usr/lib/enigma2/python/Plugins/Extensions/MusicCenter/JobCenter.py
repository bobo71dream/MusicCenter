# -*- coding: UTF-8 -*-

#  Music Center E2
#
#  Coded by bobo71 (c) 2014
#  Support: www.dreambox-tools.info
#
#  All Files of this Software are licensed under the Creative Commons
#  Attribution-NonCommercial-ShareAlike 3.0 Unported
#  License if not stated otherwise in a Files Head. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.

#  Additionally, this plugin may only be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.

#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially
#  distributed other than under the conditions noted above.
#  This applies to the source code as a whole as well as to parts of it, unless
#  explicitely stated otherwise.
from enigma import loadSizedImage, eSize

from Globals import *
from myLogger import logger
from ItemClasses import *
#from struct import unpack_from as struct_unpack_from wof�r?

from JobCenter2 import convertImageToRGB, parsePictoCovercollection, drawImageJobWithLongMultilineText, calcPointerColors, createGradientPNG, tint_image, drawImageJobWithLongText
from tagger import tagWriter, getID3Tags, myenCode
from threading import Lock

class MC_LCDText(Screen):

	skin="""
		<screen position="0,0" size="132,64">
			<widget name="text1" position="3,5" size="128,14" font="SansReg;12"/>
			<widget name="text2" position="3,21" size="128,14" font="SansReg;12"/>
			<widget name="text3" position="3,37" size="128,12" font="SansReg;10"/>
			<widget name="text4" position="3,51" size="128,10" font="SansReg;8"/>
		</screen>"""

	def __init__(self, session, parent):
		Screen.__init__(self, session)
		self["text1"]=Label()
		self["text2"]=Label()
		self["text3"]=Label()
		self["text4"]=Label()

	def setText(self, text, line):
		if line == 1:
			self["text1"].setText(text)
		elif line == 2:
			self["text2"].setText(text)
		elif line == 3:
			self["text3"].setText(text)
		elif line == 4:
			self["text4"].setText(text)


class PicLoaderScale(Pixmap):

	def __init__(self, width=None, height=None, transparent=True, cached=False, name='n/a'):
		logger.info('PicLoaderScale]__init__->%s '%name)
		Pixmap.__init__(self)
		self.__picload=ePicLoad()
		self.__width=width
		self.__height=height
		self.__name=name
		self.currentpic=None
		sc=AVSwitch().getFramebufferScale()
		if transparent:
			bcolor="#ff000000"
		else:
			bcolor="#00000000"
		#config.pic.resize = ConfigSelection(default="2", choices = [("0", _("simple")), ("1", _("better")), ("2", _("fast JPEG"))])
		#config.pic.resize.value = 2 # 2 = fast JPEG (non JPEG fallback to 1)
		#0=Width 1=Height 2=Aspect 3=use_cache 4=resize_type 5=Background(#AARRGGBB)
		#params=(self._scaleSize.width(), self._scaleSize.height(), sc[0], sc[1], config.pic.cache.value, int(config.pic.resize.value), "#00000000")
		if width is None and height is None:
			self.__bcolor=bcolor
		else:
			self.__picload.setPara((width, height, sc[0], sc[1], False, 1, bcolor)) # False, 1 ,color ->bis 11.04.2015

	def loadSpecial(self, filename, w, h):
		self.__picload.setPara((w, h, sc[0], sc[1], False, 1, self.__bcolor)) # False, 1 ,color ->bis 11.04.2015
		logger.debug('PicLoaderScale]loadSpecial]filename:{}'.format(filename))
		ptr=self._getPtr(filename)
		return ptr
		
	def load(self, filename):
		if self.__width is None and self.__height is None:
			sc=AVSwitch().getFramebufferScale()
			width=self.instance.size().width()
			height=self.instance.size().height()
			logger.debug('PicLoaderScale]load]filename:{} width:{} height:{}'.format(filename, width, height))
			self.__picload.setPara((width, height, sc[0], sc[1], False, 1, self.__bcolor)) # False, 1 ,color ->bis 11.04.2015
			size=eSize()
			ptr = loadSizedImage(filename, size)
			if ptr is None:
				logger.error('PicLoaderScale]load]filename:{} failed, try old loader Pixmap'.format(filename))
				ptr=self._getPtr(filename)
		else:
			ptr=self._getPtr(filename)
		return ptr

	def _getPtr(self, filename):
		self.__picload.startDecode(filename, False) # (Filename, x, y, async) ... x und y sind nun weggefallen
		return self.__picload.getData()

	def dosetPixmap(self, filename=None, ptr=None):
		if ptr==None:
			ptr=self.load(filename)
		if ptr is not None:
			self.currentpic=filename
			self.instance.setPixmap(ptr)
			#self.instance.show()
		else:
			self.currentpic=None

	def doshow(self, filename=None, ptr=None):
		if ptr is None:
			ptr=self.load(filename)
		if ptr is not None:
			self.currentpic=filename
			self.instance.setPixmap(ptr)
			self.instance.show()
		else:
			self.currentpic=None
	
	def dohide(self):
		self.instance.hide()

	def destroy(self):
		del self.__picload

class PicLoader:

	def __init__(self):
		logger.info('PicLoader]__init__')
		self.__pixmap_cache = {}

	def loadPic(self, path):
		return loadSizedImage(path, eSize())

	def loadPicCached(self, path):
		if path in self.__pixmap_cache:
			return self.__pixmap_cache[path]
		else:
			ptr = loadSizedImage(path, eSize())
			self.__pixmap_cache[path] = ptr
			return ptr

	def clearCache(self):
		logger.info('PicLoader]clearCache]len dict:{}'.format(len(self.__pixmap_cache)))
		self.__pixmap_cache.clear()

	def destroy(self):
		logger.info('PicLoader]destroy')
		self.clearCache()

def mygetPage(*args, **kwargs):
	if 'agent' not in kwargs:
		kwargs['agent'] =MCUSERAGNET#'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.117 Safari/537.36'
	return getPage(*args, **kwargs)

def downloadFunction(item):
	#logger.info('JobCenter]downloadFunction]Starturl->%s fn->%s' %(item.url, item.filename))
	#return downloadPage(item.url, file(item.filename, 'wb'),  headers={'Content-Type':'application/x-www-form-urlencoded'})
	return downloadPage(item.url, item.filename,  headers={'Content-Type':'application/x-www-form-urlencoded'})

def downloadFunktionTLSSNI(item):
	# init TLS SNI support ->located on Globals.py
	#from requests.packages.urllib3.contrib import pyopenssl
	#pyopenssl.inject_into_urllib3()#
	if item.filename.lower().endswith(('jpg','jpeg','png')):
		r = requests_get(item.url, headers=None)
		if r.status_code==requests_codes.ok:
			with open(item.filename, 'wb') as fd:
				fd.write(r.content)
		else:
			logger.info('JobCenterdownloadFunktionTLSSNI]error->%s' %r.status_code)
	else:
		r = requests_get(item.url, headers=None, stream=True)
		if r.status_code==requests_codes.ok:
			total_length = r.headers.get('content-length')
			with open(item.filename, 'wb') as fd:
				for chunk in r.iter_content(1024*1024):
					fd.write(chunk)
		else:
			logger.info('JobCenterdownloadFunktionTLSSNI]error->%s' %r.status_code)
	logger.info('JobCenterdownloadFunktionTLSSNI]done')

class vInputBox(InputBox):

	if RESOLUTIONx>1800:
		skin='''<screen name="vInputBox" position="center,center" size="1860,105" title="Input...">
				<widget name="text" position="6,6" size="1830,36" font="SansReg;30"/>
				<widget name="input" position="0,40" size="1830,39" font="SansReg;33"/>
			</screen>'''
	else:
		skin='''<screen name="vInputBox" position="center,center" size="1240,70" title="Input...">
				<widget name="text" position="4,4" size="1220,24" font="SansReg;20"/>
				<widget name="input" position="0,40" size="11220,26" font="SansReg;22"/>
			</screen>'''

	def __init__(self, session, title="MusikCenter", windowTitle=_("Input"), useableChars=None, **kwargs):
		self.session=session
		InputBox.__init__(self, session, title, windowTitle, useableChars, **kwargs)


def cleanName(name):# fit all other names
	return ' '.join(name.replace('_',' ').replace('/',' ').replace(':','.').replace('*','.').replace('-',' ').split('(',1)[0].split('[',1)[0].split('{',1)[0].split())

def fitArtistname(name): #Fit artistname
	return name.lower().split('feat',1)[0].split(' ft',1)[0].replace('_','').replace('/','').replace("'",'').replace(' | ',' ').strip().title()


def getmyip():
	s= socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
	try:
		return socket.inet_ntoa(fcntl_ioctl(s.fileno(),0x8915,struct_pack('256s', 'eth0'[:15]))[20:24])
	except:
		try:
			return socket.inet_ntoa(fcntl_ioctl(s.fileno(),0x8915,struct_pack('256s', 'wl0'[:15]))[20:24])
		except:
			return ([(s.connect(('8.8.8.8', 80)), s.getsockname()[0], s.close()) for s in [socket.socket(socket.AF_INET, socket.SOCK_DGRAM)]][0][1])


def getRealPath(fn):
	if os_path.islink(fn):
		realfn=os_path.realpath(fn)
		return realfn
	else:
		return fn


def buildCoverfilename(artist, title, album, albumartist, cleannames=True):
	logger.info('buildCoverfilename]artist->%s title->%s album->%s albumartist->%s' %(artist,title,album,albumartist))
	nogos=('','n/a','n a','n_a', 'soundcloud')
	if cleannames:
		albumartist=cleanName(albumartist)
		artist=cleanName(artist)
		album=cleanName(album)
		title=cleanName(title)
	trysampler=False
	if album.lower() not in nogos and albumartist.lower() not in nogos:	#if album!="" and albumartist!="" :
		nameforcoverfile=album.lower() + " " + albumartist.lower()
		if albumartist.lower() in 'sampler various artists va diverse':
			nameforcoverfile=album.lower()
	elif album.lower() not in nogos and artist.lower() not in nogos: # album!="" and artist!="":
		nameforcoverfile=album.lower() + " " + artist.lower()
		trysampler=True
	elif artist.lower() not in nogos and title.lower() not in nogos :
		nameforcoverfile=artist.lower() + " " + title.lower()
	elif title.lower() not in nogos:
		titlelist=list(title)
		if not titlelist:
			logger.error('buildCoverfilename]bad! Why nothing in title?')
			nameforcoverfile=''
		else:
			while 1:
				i=titlelist[0]
				if not i.isdigit() and i not in ('',' ','-','_'):
					break
				else:
					titlelist.pop(0)
			nameforcoverfile=''.join(titlelist).strip().rsplit('.',1)[0].lower()
	else:
		nameforcoverfile=''
		logger.error('buildCoverfilename]bad! Why nothing in title?')
	logger.info('buildCoverfilename]->%s' %nameforcoverfile)

	return (nameforcoverfile, trysampler)


def buildCoverpath(folder, nameforcoverfile):
	fndir=os_path.join(folder, nameforcoverfile[0:1]+'/')
	logger.info('buildCoverpath] dir is ' + fndir)
	if not pathExists(fndir):
		logger.info('buildCoverpath]directory no exist, create now->%s' %fndir)
		if not createDir(fndir, makeParents=True):
			logger.error('buildCoverpath] Error use /tmp/mc/')
			fndir="/tmp/mc/"
	return os_path.join(fndir, nameforcoverfile)


class myServicePositionGauge(baseServicePositionGauge):

	def __init__(self, navcore):
		GUIComponent.__init__(self)
		baseServicePositionGauge.__init__(self, navcore)
		self.onPollAppend=[ ]

	def pollAppend(self, data):
		for f in self.onPollAppend:
			f(data)

	def newService(self):
		#logger.info('myServicePositionGauge]newService]self.enablePolling(interval=200)')
		if self.get() is None:
			self.disablePolling()
		else:
			self.enablePolling(interval=300) # old 200
			self.newCuesheet()

	def poll(self):
		data = self.get()
		if data is None:
			return

		if self.instance is not None:
			self.instance.setLength(data[0])
			self.instance.setPosition(data[1])
			self.pollAppend(data)

	def connectPollAppend(self, fnc):
		#logger.info('myServicePositionGauge]connectSelChanged]')
		if not fnc in self.onPollAppend:
			self.onPollAppend.append(fnc)


# ########## new on 08.04.2015
def JCdeleteSongfileonThread(filename, songID):
	try:
		logger.info('JCdeleteSongfileonThread]-->%s songID-->%s' %(filename, songID))
		if filename.startswith(config.plugins.musiccenter.defaultfilebrowserpath.value):# file is in musiclib
			fullfnindb=filename[len(config.plugins.musiccenter.defaultfilebrowserpath.value):]

			if songID==-1:
				logger.info('JCdeleteSongfileonThread]songID is unknown, resolve fullfnindb-->%s' %fullfnindb)
				cursor=execSQLCommandWithReturn('''SELECT song_id FROM Songs  WHERE filename=?''', (fullfnindb,)).fetchone()
				if cursor is not None:
					logger.info('JCdeleteSongfileonThread]songID is-->%s' %songID)

			if songID!=None:
				execSQLCommand('''DELETE FROM Songs  WHERE filename=?''', (fullfnindb,))
				execSQLCommand('''DELETE FROM playlist_songs WHERE song_id=?''', (songID,))
			else:
				logger.info('JCdeleteSongfileonThread]file not found in database, abort!')

		if fileExists(filename):
			os_remove(filename)

	except Exception, e:
		logger.error('JCdeleteSongfileonThread]%s' %e)

	logger.info('JCdeleteSongfileonThread]done')

	return 'JCdeleteSongfileonThread]done'


def JCcreateminiartistthumbonThread(sourcefile, tumbfile, x, y):
	logger.info('JCcreateminiartistthumbonThread]start')
	img=Image.open(sourcefile)
	img.thumbnail((x, y), Image.ANTIALIAS)
	img.save(tumbfile, "JPEG")
	del img
	logger.info('JCcreateminiartistthumbonThread]done')


class downloadJob(Job):

	def __init__(self, url, file, title, soundcloud=None):
		Job.__init__(self, title)
		# fit this the error crash?
		self.state_changed = CList()

		downloadTask(self, url, file, soundcloud)

class downloadTask(Task):

	def __init__(self, job, url, file, soundcloud):
		Task.__init__(self, job, ("download task"))
		self.waitTimer=eTimer()
		self.waitTimer_mc_conn=self.waitTimer.timeout.connect(self.http_failed)
		self.end=100
		self.url=url
		self.local=file
		self.progress=0
		self.soundcloud=soundcloud

	def prepare(self):
		self.error=None

	def run(self, callback):
		self.callback=callback
		downloadPage(self.url, self.local, agent='Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.56 Safari/537.17').addCallback(self.http_finished).addErrback(self.http_failed)

	def http_finished(self, res):
		logger.info('downloadTask]dlPlayingSongFinish]res->%s' %res)
		if self.soundcloud:
			pass

		fileToDatabase.Start(self.local)
		self.progress=100
		Task.processFinished(self, 0)

	def http_failed(self, error='None'):
		logger.error('downloadTask]dlPlayingSongError]error->%s' %error)
		self.progress=100
		Task.processFinished(self, 1)


def buildSonglistEntry(row): 
	# globale eintr�ge der songlisten
	#logger.info('buildSonglistEntry]row[cover]:{}'.format(row['cover']))
	fullfilename=config.plugins.musiccenter.defaultfilebrowserpath.value+row['filename']
	if row['cover']==1:
		CoverLoader().load(fullfilename)
	slentry=Item(mode='PLAY', songID=row['song_id'], text=os_path.split(row['filename'])[-1], filename=fullfilename, title=row['title'], artist=row['artist'], bitrate=row['bitrate'], length=row['length'], genre=row['genre'], track=row['track'], date=row['date'], album=row['album'], audio=True, albumartist=row['albumartist'], filetype=row['filetype'], playcount=row['playcount'], rating=row['rating'], wave=row['wave'], cover=row['cover'], join=True)
	return slentry

def constructArtistthumbfilename(artist):
	c=fitName(artist)
	thumb=''.join((config.plugins.musiccenter.downloadcache.value, "artistpics/", c[:1], '/', c, '/artist.tumb'))
	if not pathExists(thumb):
		thumb='/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/no_artist_125x125.png'
	return thumb


class Audio_ID3_Actions_Job(Job):

	def __init__(self, jobtype, coverfn=None, item=None, audio=None):

		if item is not None:
			filename=item.filename
			title='{}:{}'.format(jobtype, filename.rsplit('/',1)[1])
			logger.info('Audio_ID3_Actions_Job] __init__ %s' %title)
			Job.__init__(self, title)
			Audio_ID3_Actions_Task(self, jobtype, coverfn, item, audio)
		else:
			logger.debug('Audio_ID3_Actions_Job]__init__]no item given, abort!')

class Audio_ID3_Actions_Task(Task):

	def __init__(self, job, jobtype, coverfn, item, audio):
		Task.__init__(self, job, ("Embed cover"))
		self.waitTimer=eTimer()
		self.waitTimer_mc_conn=self.waitTimer.timeout.connect(self.checkfinish)
		self.jobtype=jobtype
		self.coverfn=coverfn
		self.item=item
		self.audio=audio
		self.progress=0

	def run(self, callback):
	
		if tagWriter.isLocked(self.item.filename):
			logger.info('Audio_ID3_Actions_Task] run]file is used on old job, break')
			self.progress=100
			self.callback=callback
			Task.processFinished(self, 0)
		else:
			tagWriter.addToLock(self.item.filename)
			self.callback=callback
			audio_id3_actions.Start(self.jobtype, self.coverfn, self.item.filename, self.item, self.audio)
			self.waitTimer.start(50,1)
			self.progress=10

	def checkfinish(self):
		if audio_id3_actions.isRunning:
			self.progress=audio_id3_actions.theProgress
			self.waitTimer.start(50,1)
		else:
			if self.waitTimer.isActive():
				self.waitTimer.stop()
			self.progress=100
			Task.processFinished(self, 0)

class Audio_ID3_Actions(Thread):
	'''
	embed cover on song file and refresh cover and poster
	'''
	def __init__(self):
		Thread.__init__(self)
		self.__jobtype=''
		self.__running=False
		self.__coverfn=None
		self.__item=None
		self.__audio=None
		self.__progress=0
		self.__tagWriter=tagWriter

	def __getRunning(self):
		return self.__running

	def __getProgress(self):
		return self.__tagWriter.stat

	isRunning=property(__getRunning)
	theProgress=property(__getProgress)

	def Start(self, jobtype='', coverfn=None, audiofilename=None, item=None, audio=None):
		# Audio_ID3_Actions.Start( songlist=None, coverfn=None, filename=None)
		if not self.__running:
			self.__running=True
			self.__jobtype=jobtype
			self.__coverfn=coverfn
			self.__item=item
			self.__audio=audio
			self.__audiofilename=audiofilename
			self.__tagWriter.stat=0
			self.start()
		else:
			logger.info('Audio_ID3_Actions]Start]old thread running abort!')


	def run(self):
		#try:
		if self.__jobtype=='saveID3Tags':
			if self.__audiofilename is not None: # only save Id3
				logger.info('Audio_ID3_Actions]run]tagWriter.saveID3Tags:{}'.format(self.__item))
				result=tagWriter.saveID3Tags(self.__audio, self.__audiofilename)
				coveradd=False
			else:
				logger.error('Audio_ID3_Actions]run]no audiofile given, tagWriter.saveID3Tags:{}'.format(self.__item))
				
		elif self.__jobtype=='embedcoverandID3Tags':
			if  self.__coverfn is not None and self.__item is not None:
				logger.info('Audio_ID3_Actions]run]tagWriter.embedCoverOnFile cover:{} on songfile:{}'.format(self.__coverfn, self.__item.filename))
				result=tagWriter.embedCoverOnFile(self.__item.filename, self.__coverfn, self.__audio)
				coveradd=True
			else:
				logger.error('Audio_ID3_Actions]run]no given cover:{} or songfile:{}'.format(self.__coverfn, self.__item.coverfn))
				
		else:
			logger.error('Audio_ID3_Actions]run]hmm, not good:{} coverfn:{}'.format(self.__audiofilename, self.__coverfn))
			result=False

		logger.info('Audio_ID3_Actions]run]tagwriting result is:{}'.format(result))

		if result is True and self.__item.filename.startswith(config.plugins.musiccenter.defaultfilebrowserpath.value):# file is in my musiclib
			self.updateSongDBonThread(self.__item)
		else:
			logger.info('Audio_ID3_Actions]run]file not in db, or False result, skip')

		#except Exception, e:
		#	logger.error('Audio_ID3_Actions]run]->%s' %e)

		#finally:
		self.__running=False
		Thread.__init__(self)
		self.__coverfn=None
		self.__item=None
		self.__audio=None
		logger.info('Audio_ID3_Actions]Embed end')
	
	def updateSongDBonThread(self, slentry):
		song_id=slentry.songID
		logger.info('Audio_ID3_Actions]updateSongDBonThread]song_id->%d filename->%s' %(song_id, slentry.filename))
		root, filename=os_path.split(slentry.filename)	
		ID3=getID3Tags(root, filename)
		file_m_time=(os_path.getmtime(slentry.filename))
		file_size=(os_path.getsize(slentry.filename))
		fullfnindb=slentry.filename[len(config.plugins.musiccenter.defaultfilebrowserpath.value):]
		sql='''UPDATE Songs SET filename=?, title=?, artist=?, album=?, albumartist=?, genre=?, date=?, tracknumber=?, bitrate=?, length=?, track=?, file_m_time=?, file_size=?, playcount=?, rating=?, wave=?, cover=? WHERE song_id=?;'''
		args=(fullfnindb, ID3.title, ID3.artist, ID3.album, ID3.albumartist, ID3.genre, ID3.date, ID3.tracknr, ID3.bitrate, ID3.length, ID3.track, file_m_time, file_size, ID3.playcount, ID3.rating, ID3.wave, ID3.hasapicframes, song_id)
		execSQLCommand(sql,args)
		logger.info('Audio_ID3_Actions]updateSongDBonThread]done')
					
					
audio_id3_actions=Audio_ID3_Actions()

# Database

def OpenDB_Streaming(dbname=None, getpath=None):
	if dbname is None:
		return None
	dbpath=os_path.join(config.plugins.musiccenter.databasepath.value ,dbname)
	db_exists=False
	if os_path.exists(dbpath):
		db_exists=True
	try:
		connection=sqlite.connect(dbpath, timeout=10)
		if not os_access(dbpath, os_W_OK):
			logger.error("OpenDB_Streaming]Error: database file needs to be writable, can not open %s for writing..." % dbpath)
			connection.close()
			return None
	except Exception, e:
		logger.error("OpenDB_Streaming]unable to open database file: %s" %dbpath)
		logger.error("OpenDB_Streaming]unable to open database file:Exception %s" %e)
		return None
	if not db_exists :
		if dbname == 'musiccenter_stream_favorites.db':
			connection.execute('CREATE TABLE IF NOT EXISTS Stream_Favorites (station_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, stationname TEXT NOT NULL, genre TEXT, location TEXT, bitrate INTEGER, codec TEXT, streamtype TEXT, stationhp TEXT, streamurl TEXT, stationicon TEXT, streamID INTEGER, filetype TEXT, clicks INTEGER DEFAULT 0, votes INTEGER DEFAULT 0);')
			connection.execute('CREATE TABLE IF NOT EXISTS Stream_Recent (station_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, stationname TEXT NOT NULL, genre TEXT, location TEXT, bitrate INTEGER, codec TEXT, streamtype TEXT, stationhp TEXT, streamurl TEXT, stationicon TEXT, streamID INTEGER ,filetype TEXT, clicks INTEGER DEFAULT 0, votes INTEGER DEFAULT 0);')
	if getpath is None:
		return connection
	else:
		return connection, dbpath

def sqlCommand_Streaming_WithReturn(sql, args=None, dbname=None):
	logger.info('sqlCommand_Streaming_WithReturn]sql->%s args->%s' %(str(sql), str(args)))
	c=OpenDB_Streaming(dbname)
	if c is not None:
		with c:
			c.row_factory = sqlite3_Row
			c.text_factory=str
			csr=c.cursor()
			if args!=None:
				csr.execute(sql, args)
			else:
				csr.execute(sql)
		return csr
	else:
		csr=None
		return csr

def addStreamToFavoriteList(sel): # radiobrowser, radio.de ->streamtype is fromsearch
	bitrate=sel.bitrate.replace('kbit','')
	logger.info('addStreamToFavoriteList]add stream bitrate:{}'.format(bitrate))
	sql='''INSERT INTO Stream_Favorites(stationname, genre, location, bitrate, codec, streamurl, stationicon, streamID, filetype, clicks, votes)
	VALUES(?,?,?,?,?,?,?,?,?,?,?);'''
	args=(sel.stationname, sel.genre, sel.location, bitrate, sel.codec, sel.streamurl, sel.stationicon, sel.streamID, sel.filetype, sel.playcount, sel.rating)
	cursor=sqlCommand_Streaming_WithReturn(sql, args, dbname='musiccenter_stream_favorites.db')
	logger.info('addStreamToFavoriteList]%s' %cursor)

def removeStreamFromFavoriteList(sel):
	logger.info('removeStreamFromFavoriteList]station_id->%s streamID->%s filetype->%s' %(sel.songID, sel.streamID, sel.filetype))
	sql='''DELETE FROM  Stream_Favorites WHERE station_id=?;'''
	args=(sel.songID,)
	cursor=sqlCommand_Streaming_WithReturn(sql, args, dbname='musiccenter_stream_favorites.db')
	logger.info('removeStreamFromFavoriteList]%s' %cursor)
	sql='''VACUUM'''
	cursor=sqlCommand_Streaming_WithReturn(sql, dbname='musiccenter_stream_favorites.db')
	logger.info('removeStreamFromFavoriteList] vacuum db-->%s' %cursor)

def JCgetPlayList():
	cursor=sqlCommandWithReturn("SELECT playlist_id, playlist_text FROM playlists order by playlist_text;")
	playList=[]
	if cursor is not None:
		for row in cursor:
			playList.append((row[1], row[0]))
		return playList
	else:
		return None
# ------------------------------------------------> new clean 10.10.2015

def OpenDatabase():
	logger.info('OpenDatabase]start')
	dbpath=os_path.join(config.plugins.musiccenter.databasepath.value ,"songs.db")
	db_exists=os_path.exists(dbpath)
	try:
		connection=sqlite.connect(dbpath, isolation_level=None, timeout=6)# connection=sqlite.connect('cache.db', timeout=10)
		connection.execute("PRAGMA synchronous = OFF ") # OFF
		connection.execute("PRAGMA journal_mode = OFF") #MEMORY WAL
		if not os_access(dbpath, os_W_OK):
			logger.info("OpenDatabase]Error: database file needs to be writable, can not open %s for writing..." % dbpath)
			connection.close()
			return None
	except Exception, e:
		logger.error("OpenDatabase]unable to open database->%s error->%s" %(dbpath, e))
		return None
	if not db_exists :
		connection.execute(
		'''CREATE TABLE IF NOT EXISTS Songs (song_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,  filename TEXT NOT NULL UNIQUE,  title TEXT DEFAULT 'n/a',  artist TEXT DEFAULT 'n/a',  album TEXT DEFAULT 'n/a',  albumartist TEXT DEFAULT 'n/a',  genre TEXT DEFAULT 'n/a',  date TEXT DEFAULT 'n/a', tracknumber INTEGER,  bitrate INTEGER, length TEXT DEFAULT '0', track TEXT DEFAULT 'n/a',  lyrics TEXT DEFAULT 'n/a',  filetype TEXT,  file_m_time INTEGER,  file_size INTEGER,  playcount INTEGER,  rating INTEGER,  wave INTEGER, scantime INTEGER, cover INTEGER );'''
		)
		connection.execute('''CREATE TABLE IF NOT EXISTS Playlists (
		playlist_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
		playlist_text TEXT NOT NULL DEFAULT 'n/a'
		);''')
		connection.execute('''CREATE TABLE IF NOT EXISTS Playlist_Songs (
		id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
		playlist_id INTEGER NOT NULL,
		song_id INTEGER NOT NULL,
		length INTEGER
		);''')
		connection.execute('''CREATE TABLE IF NOT EXISTS Artists (artist_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, artist_text TEXT NOT NULL UNIQUE DEFAULT 'n/a');''')
		connection.execute('''CREATE TABLE IF NOT EXISTS Albums (album_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, album_text TEXT NOT NULL UNIQUE DEFAULT 'n/a');''')
		connection.execute('''CREATE TABLE IF NOT EXISTS Albumartists (albumartist_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, albumartist_text TEXT NOT NULL UNIQUE DEFAULT 'n/a');''')
		connection.execute('''CREATE TABLE IF NOT EXISTS Genres (genre_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, genre_text TEXT NOT NULL UNIQUE DEFAULT 'n/a');''')
		connection.execute('''CREATE TABLE IF NOT EXISTS Dates (date_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, date_text TEXT NOT NULL UNIQUE DEFAULT 'n/a');''')
		connection.execute('''CREATE TABLE IF NOT EXISTS Playlists (playlist_id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, playlist_text TEXT NOT NULL DEFAULT 'n/a');''')
		connection.execute('''CREATE TABLE IF NOT EXISTS Playlist_Songs (id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, playlist_id INTEGER NOT NULL, song_id INTEGER NOT NULL DEFAULT 'n/a');''')

		connection.execute('''CREATE TRIGGER check_tablesentrys_after_song_inserted
		AFTER INSERT ON Songs
		FOR EACH ROW
		BEGIN
			INSERT INTO Artists (artist_text) SELECT NEW.artist WHERE (SELECT 1 FROM Artists WHERE artist_text=NEW.artist LIMIT 1) is Null;
			INSERT INTO Albums (album_text) SELECT NEW.album WHERE (SELECT 1 FROM Albums WHERE album_text=NEW.album LIMIT 1) is Null;
			INSERT INTO Albumartists (albumartist_text) SELECT NEW.albumartist WHERE (SELECT 1 FROM Albumartists WHERE albumartist_text=NEW.albumartist LIMIT 1) is Null;
			INSERT INTO Genres (genre_text) SELECT NEW.genre WHERE (SELECT 1 FROM Genres WHERE genre_text=NEW.genre LIMIT 1) is Null;
			INSERT INTO Dates (date_text) SELECT NEW.date WHERE (SELECT 1 FROM Dates WHERE date_text=NEW.date LIMIT 1) is Null;
		END;''')

		connection.execute('''CREATE TRIGGER check_tablesentrys_after_song_updated
		AFTER UPDATE ON Songs
		FOR EACH ROW
		BEGIN
			INSERT INTO Artists (artist_text) SELECT NEW.artist WHERE (SELECT 1 FROM Artists WHERE artist_text=NEW.artist LIMIT 1) is Null;
			INSERT INTO Albums (album_text) SELECT NEW.album WHERE (SELECT 1 FROM Albums WHERE album_text=NEW.album LIMIT 1) is Null;
			INSERT INTO Albumartists (albumartist_text) SELECT NEW.albumartist WHERE (SELECT 1 FROM Albumartists WHERE albumartist_text=NEW.albumartist LIMIT 1) is Null;
			INSERT INTO Genres (genre_text) SELECT NEW.genre WHERE (SELECT 1 FROM Genres WHERE genre_text=NEW.genre LIMIT 1) is Null;
			INSERT INTO Dates (date_text) SELECT NEW.date WHERE (SELECT 1 FROM Dates WHERE date_text=NEW.date LIMIT 1) is Null;
			DELETE FROM Artists WHERE artist_text=OLD.artist AND (SELECT 1 FROM Songs WHERE artist=OLD.artist LIMIT 1) is Null;
			DELETE FROM Albums WHERE album_text=OLD.album AND (SELECT 1 FROM Songs WHERE album=OLD.album LIMIT 1) is Null;
			DELETE FROM Albumartists WHERE albumartist_text=OLD.albumartist AND (SELECT 1 FROM Songs WHERE albumartist=OLD.albumartist LIMIT 1) is Null;
			DELETE FROM Genres WHERE genre_text=OLD.genre AND (SELECT 1 FROM Songs WHERE genre=OLD.genre LIMIT 1) is Null;
			DELETE FROM Dates WHERE date_text=OLD.date AND (SELECT 1 FROM Songs WHERE date=OLD.date LIMIT 1) is Null;
		END;''')

		connection.execute('''CREATE TRIGGER cleanup_tables_after_song_deleted
		AFTER DELETE ON Songs
		FOR EACH ROW
		BEGIN
			DELETE FROM Artists WHERE artist_text=OLD.artist AND (SELECT 1 FROM Songs WHERE artist=OLD.artist LIMIT 1) is Null;
			DELETE FROM Albums WHERE album_text=OLD.album AND (SELECT 1 FROM Songs WHERE album=OLD.album LIMIT 1) is Null;
			DELETE FROM Albumartists WHERE albumartist_text=OLD.albumartist AND (SELECT 1 FROM Songs WHERE albumartist=OLD.albumartist LIMIT 1) is Null;
			DELETE FROM Genres WHERE genre_text=OLD.genre AND (SELECT 1 FROM Songs WHERE genre=OLD.genre LIMIT 1) is Null;
			DELETE FROM Dates WHERE date_text=OLD.date AND (SELECT 1 FROM Songs WHERE date=OLD.date LIMIT 1) is Null;
		END;''')

		connection.execute('''CREATE VIEW table_entry_counts AS
		SELECT count(1), (SELECT count(distinct(artist_id)) FROM Artists AS artists), (SELECT count(distinct(album_id)) FROM Albums AS albums), (SELECT count(distinct(genre_id)) FROM Genres AS genres), (SELECT count(distinct(date_id)) FROM Dates AS dates), (SELECT count(1) FROM Songs AS songs), (SELECT count(1) FROM Songs AS playcounts WHERE playcount>0), (SELECT count(1) FROM Songs AS ratings WHERE rating <257) FROM Playlists AS playlists;''')
	logger.info('OpenDatabase]end')

	return connection

def OpenDatabasePool():

	def setRowFactory(connection):
		connection.row_factory = sqlite3_Row
		connection.text_factory=str

	logger.info('OpenDatabasePool]start')
	dbpath=os_path.join(config.plugins.musiccenter.databasepath.value ,"songs.db")
	db_exists=os_path.exists(dbpath)

	if not db_exists:
		logger.info('OpenDatabasePool]no database found create now...')
		c=OpenDatabase()
		c.close()

	if not os_access(dbpath, os_W_OK):
		logger.error("OpenDatabasePool]Error: database file needs to be writable, can not open %s for writing..." % dbpath)
		return None
		
	try:
		return adbapi.ConnectionPool("sqlite3", dbpath, check_same_thread=False, cp_openfun=setRowFactory)
	except Exception, e:
		logger.error("OpenDatabasePool]unable to open database->%s error->%s" %(dbpath, e))
		return None
	
def sqlCommand(sql):
	logger.error('sqlCommand]->%s' %str(sql)[:300])
	c=OpenDatabase()
	if c is not None:
		with c:
			csr=c.cursor()
			csr.execute(sql)

def sqlCommandWithReturn(sql, db='songs'):
	logger.error('sqlCommandWithReturn]->%s' %str(sql)[:100])
	c=None
	if db=='songs':
		c=OpenDatabase()

	if c is not None:
		with c:
			c.row_factory = sqlite3_Row
			c.text_factory=str
			csr=c.cursor()
			csr.execute(sql)
	else:
		csr=None
	return csr

def execSQLCommand(sql, args,  con=None):
	logger.info('execSQLCommand]sql:{} args:{}'.format(str(sql)[:200], str(args)[:300]))
	if con is None:
		con=OpenDatabase()
	if con is not None:
		with con:
			con.text_factory=str
			#cur=con.cursor()
			if args:
				con.execute(sql, args)
			else:
				con.execute(sql, args)

def execSQLCommandWithReturn(sql, args='', con=None):
	logger.info('execSQLCommandWithReturn]sql->%s args->%s' %(str(sql)[:100], str(args)[:100]))
	if con is None:
		con=OpenDatabase()
	if con is not None:

		with con:
			con.row_factory = sqlite3_Row
			con.text_factory=str
			#cur=con.cursor()
			if args:
				logger.info('execSQLCommandWithReturn]end')
				return con.execute(sql, args)
			else:
				logger.info('execSQLCommandWithReturn]end')
				return con.execute(sql)
	else:
		logger.error('execSQLCommandWithReturn]error, no con!')

class CoverLoader(object):
	'''
	version 02.11.15
	'''
	mimetypes={'JPEG':'image/jpeg','PNG':'image/png'}

	def load(self, songfilename, imagefilename=None):
		coverfilename=buildCoverthumbFilename(songfilename)
		coverfilenamewithendswith=coverfilename+'.jpeg'
		if imagefilename is None:
			if os_path.exists(coverfilename+'.jpeg'):
				return coverfilename+'.jpeg'
			elif os_path.exists(coverfilename+'.png'):
				return coverfilename+'.png'
			elif os_path.exists(coverfilename+'.gif'):
				return coverfilename+'.gif'
			elif os_path.exists(coverfilename+'.bmp'):
				return coverfilename+'.bmp'
			else:		
				if os_path.exists(songfilename):
					if songfilename.lower().endswith('mp3'):
						starttime=time_time()
						audio=MP3(songfilename)
						timing=time_time()-starttime
						if timing > 0.5:
							file_size=(os_path.getsize(songfilename))
							logger.error('getID3Tags]slow!! songfilename:{} size:{} scantime:{}'.format(songfilename, file_size, timing))
						# type "Front cover"->3
						#frontcover=[audio[d] for d in [key for key in audio.keys() if key.startswith('APIC') ] if audio[d].type==3]
						#if frontcover:
						frames=audio.get(u'APIC:Cover (front)', None)
						if frames is not None:
							print ('CoverLoader]load]Front cover found in:{}'.format(songfilename))
							coverframes=frames.data
							coverfilenamewithendswith=self.createThumbFromString(coverframes, coverfilename)
						else:
							frameslist=[audio[i] for i in audio.keys() if 'APIC:' in i]
							if len(frameslist):
								print ('CoverLoader]load]no Front cover found, use first cover in:{}'.format(songfilename))
								coverframes=frameslist[0].data
								coverfilenamewithendswith=self.createThumbFromString(coverframes, coverfilename)
							else:
								print ('CoverLoader]load]no cover found')

					elif songfilename.lower().endswith('flac'):
						audio=FLAC(songfilename)
						if audio and audio.pictures:
							for pic in audio.pictures:
								if pic.type==3:
									coverframes=str(pic.data)
									if len(coverframes) > 0:
										coverfilenamewithendswith=self.createThumbFromString(coverframes, coverfilename)
									break
						else:
							print ('CoverLoader]load]no cover found')

					elif songfilename.lower().endswith('ogg'):
						audio=OggVorbis(songfilename)
						meta=audio.get('METADATA_BLOCK_PICTURE')
						if meta and len(meta)==1:
							apicframes=Picture(base64_b64decode(meta[0])).data
							if apicframes:
								coverfilenamewithendswith=self.createThumbFromString(apicframes, coverfilename)
						elif meta:
							iscoverfront=False
							for cov in meta:
								covtype=Picture(base64_b64decode(cov)).type
								if covtype==3: # 3-Cover front
									apicframes=Picture(base64_b64decode(cov)).data
									if apicframes:
										coverfilenamewithendswith=self.createThumbFromString(apicframes, coverfilename)
										iscoverfront=True
										break
							if not iscoverfront:
								apicframes=Picture(base64_b64decode(meta[0])).data
								if apicframes:
									coverfilenamewithendswith=self.createThumbFromString(apicframes, coverfilename)
						else:
							print ('CoverLoader]load]no cover found')
					else:
						print ('CoverLoader]load]filenameextension not supported')
					return coverfilenamewithendswith
		else:
			return self.createThumbFromFile(imagefilename, coverfilename)
			
	def createThumbFromFile(self, imagefilename, coverfilename):
		
		try:
			im=Image.open(imagefilename)
			logger.info('CoverLoader]createThumbFromFile]create thumb from imagefilename:{} size:{}'.format(imagefilename, im.size))
			if im.size[0]>400:
				im.thumbnail((400,400),Image.ANTIALIAS)
			fn='{}.{}'.format(coverfilename, im.format.lower())
			logger.info('CoverLoader]createThumbFromFile]save to.{}'.format(fn))
			im.save(fn, im.format, quality=90)
			return fn 
		except:
			logger.exception('CoverLoader]createThumbFromFile]error...')
			return coverfilename+'.error'

	def createThumbFromString(self, coverframes, coverfilename):
	
		try:
			tempBuff = StringIO()
			tempBuff.write(coverframes)
			tempBuff.seek(0)
			im=Image.open(tempBuff)
			logger.info('CoverLoader]createThumbFromString]create thumb to coverfilename:{} size:{}'.format(coverfilename, im.size))
			if im.size[0]>400:
				im.thumbnail((400,400),Image.ANTIALIAS)
			fn='{}.{}'.format(coverfilename, im.format.lower())
			logger.info('CoverLoader]createThumbFromString]save to.{}'.format(fn))
			im.save(fn, im.format, quality=90)
			return fn
		except:
			logger.exception('CoverLoader]createThumbFromString]error...')
			return coverfilename+'.error'

def JCcheckModuleIsUpdated(m):
	# check if is reload module nessesarry...
	old_size=FILESSIZE[m]
	new_size=os_path.getsize('/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/%s.py' %m)
	if old_size!=new_size:
		FILESSIZE[m]=new_size
		logger.info('JCcheckModuleIsUpdated]-> reload Module %s' %m)
		return True
	else:
		logger.info('JCcheckModuleIsUpdated]-> no reload Module %s' %m)
		return False

def buildCoverPosterFilenameNoMusiclib(fn):
	return fn[1:].replace('/','_')

class ScanPath(Thread):

	def __init__(self):
		Thread.__init__(self)
		self.__running=False
		self.__cancel=False
		self.__fileList=[]
		self.__messages=ThreadQueue()
		self.__messagePump=ePythonMessagePump()

	def __getRunning(self):
		return self.__running

	def __getMessagePump(self):
		return self.__messagePump

	def __getMessageQueue(self):
		return self.__messages

	MessagePump=property(__getMessagePump)
	Message=property(__getMessageQueue)
	isRunning=property(__getRunning)

	def Start(self, fileList=[],update_event_after_run=True):
		if not self.__running:
			self.__fileList=fileList
			self.__update_event_after_run=update_event_after_run
			self.__running=True
			self.start()
		else:
			m='ScanPath]Start]old thread is running, abort!'
			logger.info(m)
			self.__messages.push(('THREAD_EXCEPTED', m))
			self.__messagePump.send(0)

	def Cancel(self):
		self.__cancel=True

	def run(self):

		logger.info('ScanPath]run]start')
		#try:
		mp=self.__messagePump
		ms=self.__messages
		__fileList=self.__fileList
		stime=time_time()
		lensongList=len(__fileList)

		if lensongList:
			connection=OpenDatabase()
			coverLoader=CoverLoader()
			toinsertsongs=[]
			toupdatesongs=[]
			if connection!=None:
				with connection:
					connection.row_factory = sqlite3_Row
					connection.text_factory=str
					cursor=connection.cursor()
					logger.info('ScanPath]run]songlist has len...')
					musiclibbasepath=config.plugins.musiccenter.defaultfilebrowserpath.value
					pathoffset=len(musiclibbasepath)
					row=cursor.execute('''select seq from sqlite_sequence where name="Songs";''').fetchone()
					if row is not None:
						lastrowid=int(row['seq'])
					else:
						lastrowid=-1
						
					logger.info('ScanPath]run]lastrowid->%d' %lastrowid)
					for index, fullfn in enumerate(__fileList):

						if self.__cancel:
							self.__cancel=False
							break

						root, filename=os_path.split(fullfn)
						if not fullfn.startswith(musiclibbasepath): # path is not in musiclib
							ID3=getID3Tags(root, filename)
							#logger.info('ScanPath]run]getID3Tags finish')
							slentry=Item(songID=index, text=filename, filename=fullfn, title=ID3.title, artist=ID3.artist, bitrate=ID3.bitrate, length=ID3.length, genre=ID3.genre, track=ID3.track, date=ID3.date, album=ID3.album, audio=ID3.audio, tracknr=ID3.tracknr, albumartist=ID3.albumartist, filetype=ID3.filetype, playcount=ID3.playcount, rating=ID3.rating, wave=ID3.wave, cover=ID3.hasapicframes, coverfn=coverLoader.load(fullfn))
						else:
							fullfnindb=fullfn[pathoffset:]
							toupdsongID=-1

							#logger.info('ScanPath]run]check file is in db fullfnindb->%s root->%s filename->%s' %(fullfnindb,root, filename))
							#songisindb=cursor.execute('''SELECT song_id, file_m_time, file_size FROM Songs WHERE filename=? LIMIT 1;''', (fullfnindb,)).fetchone()
							songisindb=cursor.execute('''SELECT song_id, track, title, bitrate, length, filetype, playcount, rating, wave, file_m_time, file_size, artist, albumartist, album, genre, date, cover from Songs WHERE filename=? LIMIT 1;''', (fullfnindb,)).fetchone()

							if songisindb: # schon in db, pr�fe auf Ver�nderung...
								#logger.info('ScanPath]run]songisindb->%s' %str(songisindb))
								if (os_path.getmtime(fullfn)) > songisindb['file_m_time'] or songisindb['file_size'] != (os_path.getsize(fullfn)):
									toupdsongID=songisindb['song_id']
									#logger.info('ScanPath]run]File time->%s or size->%s was changed ->update song_id->%s'%(os_path.getmtime(fullfn), songisindb['file_m_time'], toupdsongID))
									songisindb=None
								else:
									#row=cursor.execute('''SELECT song_id, track, title, bitrate, length, filetype, playcount, rating, wave, file_m_time, file_size, artist, albumartist, album, genre, date, cover from Songs WHERE filename=? LIMIT 1;''', (fullfnindb,)).fetchone()
									slentry=Item(songID=songisindb['song_id'], text=filename, filename=fullfn, title=songisindb['title'], artist=songisindb['artist'], bitrate=songisindb['bitrate'], length=songisindb['length'], genre=songisindb['genre'], track=songisindb['track'], date=songisindb['date'], album=songisindb['album'], audio=True, albumartist=songisindb['albumartist'], filetype=songisindb['filetype'], playcount=songisindb['playcount'], rating=songisindb['rating'], wave=songisindb['wave'], cover=songisindb['cover'], coverfn=coverLoader.load(fullfn))
									#logger.info('ScanPath]run]File is unchanged, get db wave?->%s' %str(songisindb['wave'][:50]))
							else:
								logger.info('ScanPath]run]File not in db,scan now...')

							if not songisindb:
								ID3=getID3Tags(root, filename)
								#logger.info('ScanPath]run]getID3Tags finish')
								if ID3.audio:
									try:
										file_m_time=(os_path.getmtime(fullfn))
										file_size=(os_path.getsize(fullfn))
										if toupdsongID == -1 :
											logger.info('ScanPath]run]Insert new song->%s'%fullfn)
											toinsertsongs.append((fullfnindb, ID3.title, ID3.artist, ID3.album, ID3.albumartist, ID3.genre, ID3.date, ID3.tracknr, ID3.bitrate, ID3.length, ID3.track, ID3.filetype, file_m_time, file_size, ID3.playcount, ID3.rating, ID3.wave, time_time(), ID3.hasapicframes))
											lastrowid=lastrowid+1
											song_id=lastrowid
										else:
											logger.info('ScanPath]run]Update song->%s'%fullfn)
											toupdatesongs.append((fullfnindb, ID3.title, ID3.artist, ID3.album, ID3.albumartist, ID3.genre, ID3.date, ID3.tracknr, ID3.bitrate, ID3.length, ID3.track, ID3.filetype, file_m_time, file_size, ID3.playcount, ID3.rating, ID3.wave, ID3.hasapicframes, toupdsongID))
											song_id=toupdsongID

										slentry=Item(songID=song_id, text=filename, filename=fullfn, title=ID3.title, artist=ID3.artist, bitrate=ID3.bitrate, length=ID3.length, genre=ID3.genre, track=ID3.track, date=ID3.date, album=ID3.album, audio=ID3.audio, tracknr=ID3.tracknr, albumartist=ID3.albumartist, filetype=ID3.filetype, playcount=ID3.playcount, rating=ID3.rating, wave=ID3.wave, cover=ID3.hasapicframes, coverfn=coverLoader.load(fullfn))
									except Exception, e:
										logger.error('ScanPath]run]WRITE DB error->%s file->%s' %(e, fullfn))

									#logger.info('ScanPath]run]add to DB done')

								else:
									logger.info('ScanPath]run]Hmm here to not good... song->%s'%fullfn)

						if index==lensongList-1:
							m=('THREAD_SCAN_FINISHED', slentry)
							logger.info('ScanPath]run]push->%s' %str(m))
						else:
							m=('THREAD_WORKING', slentry)
						ms.push(m)
						mp.send(0)

		else:
			logger.info('ScanPath]run]no songlist given...')

		logger.info('ScanPath]run]done execute now sql')
		if toupdatesongs or toinsertsongs:
			if connection!=None:
				with connection:
					connection.text_factory=str
					cursor=connection.cursor()
					logger.info('ScanPath]DROP INDEX index_filename')
					connection.execute('''DROP INDEX IF EXISTS index_filename;''')
					if toupdatesongs:
						logger.info('ScanPath]run]update rows now...')
						cursor.executemany('''UPDATE Songs SET filename=?, title=?, artist=?, album=?, albumartist=?, genre=?, date=?, tracknumber=?, bitrate=?, length=?, track=?, filetype=?, file_m_time=?, file_size=?, playcount=?, rating=?, wave=?, cover=? WHERE song_id=?;''' ,toupdatesongs)
					if toinsertsongs:
						logger.info('ScanPath]run]insert rows now...')
						cursor.executemany('''INSERT INTO Songs (filename, title, artist, album, albumartist, genre, date, tracknumber, bitrate, length, track, filetype, file_m_time, file_size, playcount, rating, wave, scantime, cover) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);''' ,toinsertsongs)
					logger.info('ScanPath]Recreate INDEX index_filename on songs')
					cursor=connection.cursor()
					cursor.execute('''CREATE INDEX IF NOT EXISTS index_filename ON Songs(filename);''')
					logger.info('ScanPath]Recreate INDEX done')

		else:
			logger.info('ScanPath]run]no sql toupdatesongs wait 1 second')
			time_sleep(1)
		'''
		except Exception, e:
			logger.error('ScanPath]run]error>%s' %e)

		finally:
		'''
		logger.info('ScanPath]run]done send now -> (THREAD_FINISHED, %s), Scanzeit->%s' %(str(self.__update_event_after_run), str(time_time()-stime)))
		ms.push(('THREAD_FINISHED', self.__update_event_after_run))
		mp.send(0)

		Thread.__init__(self)
		self.__running=False
		self.__cancel=False
		self.__fileList=[]


scanPath=ScanPath()

class SPThreadQueue:
	def __init__(self):
		self.__list = [ ]
		self.__lock = Lock()

	def push(self, val):
		lock = self.__lock
		lock.acquire()
		self.__list.append(val)
		lock.release()

	def pop(self):
		lock = self.__lock
		lock.acquire()
		ret = self.__list.pop()
		lock.release()
		return ret

class PathToDatabase(Thread):

	def __init__(self):

		Thread.__init__(self)
		self.__running=False
		self.__cancelscandb=False
		self.__path=None

		self.__messages=SPThreadQueue()
		self.__messagePump=ePythonMessagePump()

	def __getMessagePump(self):
		return self.__messagePump

	def __getMessageQueue(self):
		return self.__messages

	def __getRunning(self):
		return self.__running

	def CancelScanDB(self):
		logger.info('DB]PathToDatabase]CancelScanDB]')
		self.__cancelscandb=True

	MessagePump=property(__getMessagePump)
	Message=property(__getMessageQueue)
	isRunning=property(__getRunning)

	def Start(self, path):
		if not self.__running:
			self.__running=True
			logger.info('DB]PathToDatabase]Start]not running, start run! with job:%s' %path)
			self.__path=path
			self.start()
		else:
			logger.info('DB]PathToDatabase]Start]old job is running, abort!')
			return

	def run(self):

		logger.info('DB]PathToDatabase]start!')
		mp=self.__messagePump
		ms=self.__messages
		musiclibbasepath=config.plugins.musiccenter.defaultfilebrowserpath.value
		path=self.__path
		coverLoader=CoverLoader()
		if path is None:
			ms.push(('THREAD_WORKING',"Cleanup Database Start!",))
			mp.send(0)
			connection=OpenDatabase()
			deletecount=self.cleaningDatabase('Cleanup Database ', connection)
			ms.push(('THREAD_FINISHED',"Cleanup Database complete {} Songs deleted".format(deletecount),))
			mp.send(0)

		elif not path.startswith(musiclibbasepath): # path is not in musiclib 
			logger.info('PathToDatabase]path is not on musiclibrary abort!')
			ms.push(('THREAD_FINISHED', "Scan aborted, path is not in Musiclibrary!\nMusiclibrary->%s\nPath to scan was->%s" %(musiclibbasepath, path),))
			mp.send(0)
		else:
			insert, update, skip=0,0,0
			stime=time_time()

			pathoffset=len(musiclibbasepath)

			connection=OpenDatabase()

			if connection!=None:

					#try:
					ms.push(('THREAD_WORKING', "Start Scan Database now",))
					mp.send(0)

					with connection:
						logger.info('DB]PathToDatabase]DROP INDEX index_filename')
						connection.execute('''DROP INDEX IF EXISTS index_filename;''')
					lasttime=time_time()

					with connection:
						connection.row_factory = sqlite3_Row
						connection.text_factory=str
						cursor=connection.cursor()

						for root, subFolders, files in os_walk(path):

							if self.__cancelscandb:
								break

							subFolders.sort()
							files.sort()

							#with connection:
							#	connection.row_factory = sqlite3_Row
							#	connection.text_factory=str
							#	cursor=connection.cursor()

							logger.info('PathToDatabase]Start path scan->%s'%root)
							toupdatedentrys=[]
							for filename in files: # folder
								if self.__cancelscandb:
									break

								if filename.lower().endswith(PLAYABLEFORMATS):

									fullfn=os_path.join(root,filename)
									fullfnindb=fullfn[pathoffset:]
									toupdsongID=-1
									#logger.info('PathToDatabase]chech file is in db fullfnindb -->%s fullfn -->%s' %(fullfnindb,fullfn))
									songisindb=cursor.execute('''SELECT song_id, file_m_time, file_size FROM Songs WHERE filename=? LIMIT 1;''', (fullfnindb,)).fetchone()

									if songisindb: # schon in db, pr�fe auf Ver�nderung...
										#logger.info('PathToDatabase]songisindb->%s' %str(songisindb))
										if (os_path.getmtime(fullfn)) > songisindb['file_m_time'] or songisindb['file_size'] != (os_path.getsize(fullfn)):
											toupdsongID=songisindb['song_id']
											#logger.info('PathToDatabase]File time->%s or size->%s was changed ->update song_id->%s'%(os_path.getmtime(fullfn), songisindb['file_m_time'], toupdsongID))
											songisindb=[]
										else:
											skip+=1
											#logger.info('PathToDatabase]File is unchanged, skip')
									#else:
										#logger.info('PathToDatabase]File not in db,scan now...')

									if not songisindb:
										ID3=getID3Tags(root, filename)
										if ID3.audio: # old audio, changed 30.08.15
											try:
												file_m_time=(os_path.getmtime(fullfn))
												file_size=(os_path.getsize(fullfn))
												if toupdsongID == -1 :
													#logger.info('PathToDatabase]Insert song->%s'%fullfn)
													cursor.execute('''INSERT INTO Songs (filename, title, artist, album, albumartist, genre, date, tracknumber, bitrate, length, track, filetype, file_m_time, file_size, playcount, rating, wave, scantime, cover) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);''' , (fullfnindb, ID3.title, ID3.artist, ID3.album, ID3.albumartist, ID3.genre, ID3.date, ID3.tracknr, ID3.bitrate, ID3.length, ID3.track, ID3.filetype, file_m_time, file_size, ID3.playcount, ID3.rating, ID3.wave, time_time(), ID3.hasapicframes))
													song_id=cursor.lastrowid
													insert+=1
												else:
													#logger.info('PathToDatabase]Update song->%s'%fullfn)
													#cursor.execute('''UPDATE Songs SET filename=?, title=?, artist=?, album=?, albumartist=?, genre=?, date=?, tracknumber=?, bitrate=?, length=?, track=?, filetype=?, file_m_time=?, file_size=?, playcount=?, rating=?, cover=? WHERE song_id=?;''' ,
													toupdatedentrys.append((fullfnindb, ID3.title, ID3.artist, ID3.album, ID3.albumartist, ID3.genre, ID3.date, ID3.tracknr, ID3.bitrate, ID3.length, ID3.track, ID3.filetype, file_m_time, file_size, ID3.playcount, ID3.rating, ID3.hasapicframes,  toupdsongID))
													update+=1
												if ID3.hasapicframes:
													coverLoader.load(fullfn)
											except Exception, e:
												logger.error('PathToDatabase]WRITE DB error->%s file->%s' %(e, fullfn))
											#logger.info('PathToDatabase]add to DB done')

										else:
											logger.error('PathToDatabase]Hmm here to not good... song->%s'%fullfn)
								#else:
								#	logger.info('PathToDatabase]no Musikfile skip -->%s'%filename)
								if time_time() - 0.5 > lasttime:
									lasttime=time_time()
									ms.push(('THREAD_WORKING', 'Scan folder:{}\n{} songs added\n{} songs updated\n{} songs skipped\n{} duration'.format(root, insert, update, skip, self.getDuration(stime)),))
									mp.send(0)
							logger.info('PathToDatabase]update sql now-->%s' %str(toupdatedentrys))
							cursor.executemany('''UPDATE Songs SET filename=?, title=?, artist=?, album=?, albumartist=?, genre=?, date=?, tracknumber=?, bitrate=?, length=?, track=?, filetype=?, file_m_time=?, file_size=?, playcount=?, rating=?, cover=? WHERE song_id=?;''' ,toupdatedentrys)
							logger.info('PathToDatabase]update sql done')

					text='Scan Database complete\n{} songs added\n{} songs updated\n{} songs skipped\nscan duration{}'.format(insert, update, skip, self.getDuration(stime))
					ms.push(('THREAD_FINISHED',text+'\ncleanup database now...',))
					mp.send(0)
					deletecount=self.cleaningDatabase(text, connection)
					ms.push(('THREAD_FINISHED',"Scan Database complete\n{} songs added\n{} songs updated\n{} songs skipped\n{} songs removed\nscan duration{}\ncleaned up database done, create indexe now...".format(insert, update, skip, deletecount, self.getDuration(stime)),))
					mp.send(0)

					#except Exception, e:
					#logger.error('DB]PathToDatabase]->%s' %e)

					#finally:
					logger.info('DB]PathToDatabase]finally recreate indexes...')
					with connection:
						logger.info('DB]PathToDatabase]create INDEX index_filename on songs')
						cursor=connection.cursor()
						cursor.execute('''CREATE INDEX IF NOT EXISTS index_filename ON Songs(filename);''')
						logger.info('DB]PathToDatabase]create INDEX done')
					ms.push(('THREAD_FINISHED',"Scan Database complete\n{} songs added\n{} songs updated\n{} songs skipped\n{} songs removed\nscan duration{}\ncleaned up database done, create index done".format(insert, update, skip, deletecount, self.getDuration(stime)),))
					mp.send(0)

			else: # no connection !
				logger.error('DB]PathToDatabase]no songs, abort...')
				ms.push(('THREAD_EXCEPTED', "Scan Database aborted!\nError->databases not found!",))
				mp.send(0)

				logger.info('DB]PathToDatabase]done, Scanzeit:{}'.format(time_time()-stime))
				
		Thread.__init__(self)
		self.__cancelscandb=False
		self.__running=False
		self.__path=None

	def getDuration(self, stime):
		return str(datetime_timedelta(seconds=int(time_time()-stime)))
		
	def cleaningDatabase(self, text, connection):

		if connection is not None:
			logger.info('PathToDatabase]cleaningDatabase]Start')
			with connection:
				connection.text_factory=str
				connection.row_factory = sqlite3_Row
				cursor=connection.cursor()
				sql='''SELECT song_id, filename FROM Songs;'''
				cursor.execute(sql)

			checkTime, count=0, 0
			musiclibbasepath=config.plugins.musiccenter.defaultfilebrowserpath.value
			to_delete_song_ids=()
			for row in cursor:
				count +=1
				fn=os_path.join(musiclibbasepath, row["filename"])
				if not os_path.exists(fn):
					logger.info('PathToDatabase]cleaningDatabase]Remove DB entry %s' %row["filename"])
					to_delete_song_ids+=(row["song_id"],)
				if time_time() - checkTime >= 0.5:
					self.__messages.push(('THREAD_WORKING', "{}\n{} songs checked {} songs cleaned".format(text, count, len(to_delete_song_ids))))
					self.__messagePump.send(0)
					checkTime=time_time()


			if to_delete_song_ids:
				self.__messages.push(('THREAD_WORKING', "{}\ndelete now dropped {} songs...".format(text, len(to_delete_song_ids))))
				self.__messagePump.send(0)
				logger.info('PathToDatabase]cleaningDatabase]delete now to_delete_song_ids->%s' %str(to_delete_song_ids))
				with connection:
					cursor=connection.cursor()
					cursor.execute('''DELETE FROM Songs WHERE song_id in %s;''' %str(to_delete_song_ids))
				logger.info('PathToDatabase]cleaningDatabase]delete songs done.')
				self.__messages.push(('THREAD_WORKING', "{}\nall {} dropped songs deleted!".format(text, len(to_delete_song_ids))))
				self.__messagePump.send(0)

		return (len(to_delete_song_ids))


pathToDatabase=PathToDatabase()


class SuggestionsThread(Thread):

	def __init__(self):
		self.__running=False
		Thread.__init__(self)
		self.__searchlist=[]
		self.canceled=False
		self.__messages=ThreadQueue()
		self.__messagePump=ePythonMessagePump()

	def cancel(self):
		self.canceled=True

	def __getMessagePump(self):
		return self.__messagePump

	def __getMessageQueue(self):
		return self.__messages

	def __getRunning(self):
		return self.__running

	def Start(self, searchword, searchsuggestiontype):
		if 	not self.__running:
			self.__running=True
			self.__searchlist=[(searchword, searchsuggestiontype)]
			self.start()
		else:
			logger.info('DB]SuggestionsThread]Start]old thread is running')
			self.__searchlist=[(searchword, searchsuggestiontype,)]
		logger.info('DB]SuggestionsThread]Start]__searchlist->%s' %str(self.__searchlist))

	def run(self):
		logger.info('DB]SuggestionsThread]run]start')
		while self.__searchlist:
			try:
				searchword, searchsuggestiontype=self.__searchlist.pop(0)
				reslist=[]
				if searchword!='' and not self.canceled:

					searchword2=searchword.replace(' ','%')
					args=('%%%s%%' %searchword, '%%%s%%' %searchword2)

					if searchsuggestiontype=='ARTIST':
						sql='''SELECT artist_text FROM Artists WHERE artist_text LIKE ? OR artist_text LIKE ? GROUP BY artist_text ORDER BY artist_text LIMIT 31;'''
						cursor=execSQLCommandWithReturn(sql, args)
						for row in cursor:
							reslist.append((Item(text="%s" %row[0], mode='openArtistSuggestSelectionMenu', artist=row[0], coverfn=constructArtistthumbfilename(row[0])),))
						if len(reslist)-1 >=31:
							headertext='>50 Artists'
						else:
							headertext='%d Artists' %(len(reslist)-1)
					elif searchsuggestiontype=='TITLES':
						sql='''SELECT * FROM Songs WHERE title LIKE ? OR title LIKE ? ORDER BY title  LIMIT 31;'''
						cursor=execSQLCommandWithReturn(sql, args)
						for row in cursor:
							slentry=buildSonglistEntry(row)
							reslist.append((slentry,))
						if len(reslist)-1 >=31:
							headertext='> 50 Songs'
						else:
							headertext='%d Songs' %(len(reslist)-1)
					elif searchsuggestiontype=='ALBUMS':
						sql='''SELECT album, albumartist FROM Songs WHERE album LIKE ? OR album LIKE ? GROUP BY album ORDER BY album LIMIT 31;'''
						cursor=execSQLCommandWithReturn(sql, args)
						for row in cursor:
							reslist.append((Item(text="%s - %s" % (row[0], row[1]), mode='buildAlbumSongList',artistID=-2, album=row[0], albumartist=row[1]),))
						if len(reslist)-1 >=31:
							headertext='>50 Albums'
						else:
							headertext='%d Albums' %(len(reslist)-1)
					elif searchsuggestiontype=='ALL':
						sql='''SELECT * FROM Songs WHERE title LIKE ? OR title LIKE ? OR artist LIKE ? OR artist LIKE ? OR album LIKE ? OR album LIKE ? LIMIT 31;'''
						args=('%%%s%%' %searchword, '%%%s%%' %searchword2,'%%%s%%' %searchword, '%%%s%%' %searchword2,'%%%s%%' %searchword, '%%%s%%' %searchword2)
						cursor=execSQLCommandWithReturn(sql, args)
						for row in cursor:
							slentry=buildSonglistEntry(row)
							reslist.append((slentry,))
						if len(reslist)-1 >=31:
							headertext='>30 Hits'
						else:
							headertext='%d Hits' %(len(reslist)-1)

				else:
					headertext='n/a'
				self.__messages.push((reslist, headertext))
				self.__messagePump.send(0)
			except Exception, error:
				logger.error('DB]SuggestionsThread]run]error->%s' %error)
				l=[(Item(text=_(error), mode='buildMainMenuListDB'),)]
				self.__messages.push((l,error))
				self.__messagePump.send(0)

		Thread.__init__(self)
		self.__running=False
		self.canceled=False
		logger.info('DB]SuggestionsThread]run]done')


	def finished(self, val):
		if not self.canceled:
			message=self.__messages.pop()
			message[1](message[0])

	MessagePump=property(__getMessagePump)
	Message=property(__getMessageQueue)
	isRunning=property(__getRunning)


suggestionsThread=SuggestionsThread()



class StationiconDownloader(Thread):

	def __init__(self):
		self.__running=False
		Thread.__init__(self)

		self.__stations=[]
		self.__dlcounts=0
		self.canceled=False

	def cancel(self):
		self.canceled=True

	def __getRunning(self):
		return self.__running

	def Start(self, stations, picdir, type):
		if 	not self.__running:
			self.__running=True
			self.__stations=stations
			self.__type=type
			self.__picdir=picdir
			logger.info('StationiconDownloader]Start]new thread')
			self.start()
		else:
			logger.info('StationiconDownloader]Start]old thread is running update dllist')
			self.__stations=stations			
	
	def run(self):
		logger.info('StationiconDownloader]run]start len stations:{}'.format(len(self.__stations)))
		c=0
		while self.__stations:	
			if self.canceled:
				logger.debug('StationiconDownloader]run]cancel 0')
				break

			station=self.__stations.pop(0)
			if str(c).endswith('0'): 
				logger.info('StationiconDownloader]run]{} dlcounts check station:{}'.format(len(self.__stations), station['name'].encode()))
			c+=1
			if self.__type=='RADIOBROWSER':
				result=self.resolveStationiconRadiobrowser(station)
			elif self.__type=='RADIODE':
				result=self.resolveStationiconRadioDe(station)
			logger.info('StationiconDownloader]run]stationiconfilename:{} url:{}'.format(result[0], result[1]))
			
			if result is not None:
				try:
					stationiconfilename, url=result
					#url=url.replace('https://', 'http://')
					if url.startswith('www.'):
						url='http://{}'.format(url)	
					response = requests_get(url, timeout=(1, 2.5), verify=False)
					if response.status_code == 200:
						if stationiconfilename.lower().endswith('.svg'):
							with open(stationiconfilename, 'wb') as f:
								logger.info('StationiconDownloader]run]is svg save untouched...')
								f.write(response.content)	
						else:
							im=Image.open(StringIO(response.content))
							if im.size[0]>175 or im.size[1]>175:
								logger.info('StationiconDownloader]downloadFinished]thumnail image x:{} to x:175 y:{} to y:175'.format(im.size[0], im.size[1]))
								im.thumbnail((175, 175), Image.ANTIALIAS)
							im.save(stationiconfilename, im.format)
							del im
					else:
						logger.error('StationiconDownloader]run]error:{}'.format(response.status_code))
				except:
					logger.exception('StationiconDownloader]run]error...')

		Thread.__init__(self)
		self.__running=False
		self.canceled=False
		logger.info('StationiconDownloader]run]done')

	def resolveStationiconRadioDe(self, station):
		stationname=myenCode(station[u'name']).replace('/','-')	
		stationiconurl=myenCode(station[u'pictureBaseURL']+'t175.png')
		filename=''.join((cleanName(stationname), '.png'))
		stationiconfilename=os_path.join(self.__picdir, filename)
		if stationiconurl!='':
			return stationiconfilename, stationiconurl
		else:
			return None

	def resolveStationiconRadiobrowser(self, station):
		stationname=station['name'].encode()
		stationiconurl=station['favicon'].encode()
		if stationiconurl.startswith('data:image/jpeg;base64'):
			filename=''.join((cleanName(stationname), '.jpeg'))
			stationiconfilename=os_path.join(self.__picdir, filename)
			if not fileExists(stationiconfilename):
				base64_image_str=stationiconurl[stationiconurl.find(",")+1:]
				logger.debug('StationiconDownloader]resolveStationiconRadiobrowser]stationiconurl is jpeg, save stationname.{} to stationiconfilename'.format(stationname, stationiconfilename))
				with open(stationiconfilename, "wb") as f:
					f.write(base64_image_str.decode('base64'))
			return None
				
		elif stationiconurl.startswith('data:image/png;base64'):
			filename=''.join((cleanName(stationname), '.png'))
			stationiconfilename=os_path.join(self.__picdir, filename)
			if not fileExists(stationiconfilename):
				base64_image_str=stationiconurl[stationiconurl.find(",")+1:]
				logger.debug('StationiconDownloader]resolveStationiconRadiobrowser]stationiconurl is png, save stationname.{} to stationiconfilename'.format(stationname, stationiconfilename))
				with open(stationiconfilename, "wb") as f:
					f.write(base64_image_str.decode('base64'))
			return None
				
		else:
			endswithbase=stationiconurl.rsplit('/',1)[-1].lower()
			endswith=None
			for e in ('.jpg', '.png', '.jpeg', '.bmp', '.gif', '.svg'):
				if e in endswithbase:
					endswith=e
					break

			if endswith is not None:
				filename=''.join((cleanName(stationname), endswith))
				stationiconfilename=os_path.join(self.__picdir, filename)
			else:
				filename=cleanName(stationname)
				stationiconfilename=os_path.join(self.__picdir, filename)
			return stationiconfilename, stationiconurl
	
	isRunning=property(__getRunning)


stationiconDownloader=StationiconDownloader()