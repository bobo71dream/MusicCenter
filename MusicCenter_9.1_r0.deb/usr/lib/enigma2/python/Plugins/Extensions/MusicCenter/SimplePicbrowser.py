#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.

#  Additionally, this plugin may only be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.

#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially
#  distributed other than under the conditions noted above.
#  This applies to the source code as a whole as well as to parts of it, unless
#  explicitely stated otherwise.


from Globals import *
from myLogger import logger
from JobCenter2 import drawImageJobWithLongText


class Picbrowser(Screen):
	
	if RESOLUTIONx>1800:
		
		skin = """
			<screen name="MusicCenterPlayer" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#FF000000" title="MC Player" zPosition="0">
				<widget name="artistname" position="165,6" size="1500,110" font="SansReg;24" foregroundColor="#04931c" backgroundColor="#00000000" halign="center" valign="center" zPosition="1" />
				<widget name="artistpicslist" position="0,200" size="1920,400" transparent="1" zPosition="2" coverSize="384,216" selectedCoverScale="1.3" unselectedCoverDimm="0.7"  coverflowCurrentPosition="960,200" coverflowCurrentXDistance="35" coverflowCurrentCenterDistance="20" style="1"/>
				<!-- Buttons -->
					<widget render="Label" font="SansReg;28" transparent="1" position="60,116" size="450,32" source="key_red" foregroundColor="#ff0000" halign="center" valign="center" zPosition="3"/>
					<widget render="Label" font="SansReg;28" transparent="1" position="510,116" size="450,32" source="key_green" foregroundColor="#00ff21" halign="center" valign="center" zPosition="3"/>
					<widget render="Label" font="SansReg;28" transparent="1" position="960,116" size="450,32" source="key_yellow" foregroundColor="#FFD800" halign="center" valign="center" zPosition="3"/>
					<widget render="Label" font="SansReg;28" transparent="1" position="1410,116" size="450,32" source="key_blue" foregroundColor="#3D8DFF" halign="center" valign="center" zPosition="3"/>
				<widget name="bottomtext" position="165,750" size="1500,110" font="SansReg;24" foregroundColor="#04931c" backgroundColor="#00000000" halign="center" valign="center" zPosition="1" />
			</screen>"""
		
	else:
	
		skin = """
			<screen name="MusicCenterPlayer" position="0,0" size="1280,720" flags="wfNoBorder" backgroundColor="#FF000000" title="MC Player" zPosition="0">
				<widget name="artistname" position="110,4" size="1000,73" font="SansReg;16" foregroundColor="#04931c" backgroundColor="#00000000" halign="center" valign="center" zPosition="1" />
				<widget name="artistpicslist" position="0,133" size="1280,268" transparent="1" zPosition="2" coverSize="256,144" selectedCoverScale="1.3" unselectedCoverDimm="0.7"  coverflowCurrentPosition="640,133" coverflowCurrentXDistance="35" coverflowCurrentCenterDistance="13" style="1"/>
				<!-- Buttons -->
					<widget render="Label" font="SansReg;18" transparent="1" position= "40,77" size="300,21" source="key_red" foregroundColor="#ff0000" halign="center" valign="center" zPosition="3"/>
					<widget render="Label" font="SansReg;18" transparent="1" position="340,77" size="300,21" source="key_green" foregroundColor="#00ff21" halign="center" valign="center" zPosition="3"/>
					<widget render="Label" font="SansReg;18" transparent="1" position="640,77" size="300,21" source="key_yellow" foregroundColor="#FFD800" halign="center" valign="center" zPosition="3"/>
					<widget render="Label" font="SansReg;18" transparent="1" position="940,77" size="300,21" source="key_blue" foregroundColor="#3D8DFF" halign="center" valign="center" zPosition="3"/>
				<widget name="bottomtext" position="110,500" size="1000,73" font="SansReg;16" foregroundColor="#04931c" backgroundColor="#00000000" halign="center" valign="center" zPosition="1" />
			</screen>"""
	
	def __init__(self, session, artistdir):
		logger.info('Picbrowser]__init__ ]')
		self.skin_path='/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images'
		self.session=session
		Screen.__init__(self, session)
		self.artistdir=artistdir
		self.piclist=[]
		self["key_red"]=StaticText("delete")
		self["key_green"]=StaticText("close")
		self["key_yellow"]=StaticText("")
		self["key_blue"]=StaticText("")
		
		self["actions"]=ActionMap(["ColorActions", "SetupActions"],
		{
			"cancel": self.cancel,
			"red": self.okPressed,
			"green": self.cancel,
			"yellow": self.dummy,
			"blue": self.dummy,
			"ok": self.dummy,
			"left": self.left,
			"right": self.right,
			"up": self.up,
			"down": self.down,
		}, -1)

		self['artistname']=Label()
		self['bottomtext']=Label()
		self["artistpicslist"] = CoverCollection()
		self.onLayoutFinish.append(self.__startRun)
	
	def dummy(self):
		pass
		
	def __startRun(self):
		logger.info('Picbrowser]__startRun]')
		self['artistname'].setText(self.artistdir.rsplit('/',2)[-2])
		self["artistpicslist"].connectSelChanged(self.artistpicChangedAppend)
		self.buildArtistpicFlowlist()
		
	def buildArtistpicFlowlist(self, selectedindex=0):
		logger.info('Picbrowser]buildArtistpicFlowlist]start')
		self.piclist = []
		covers = []
		for fake, picfile in enumerate(os_listdir(self.artistdir)):
			if picfile.lower().endswith(('jpg','jpeg','png','bmp',)):
				self.piclist.append((picfile,))
				covers.append(os_path.join(self.artistdir, picfile))
		logger.info('Picbrowser]buildAndShowCoverFlowlist]set collection')
		self['artistpicslist'].setList(self.piclist, covers, selectedindex)
		#self['artistpicslist'].show()
		
	def artistpicChangedAppend(self, index):
		self['bottomtext'].setText('File -> %s' %str(self.piclist[index]))	

	def okPressed(self):
		sel=self["artistpicslist"].getCurrent()
		logger.info('Picbrowser]okPressed]->%s' %str(sel))
		if fileExists(os_path.join(self.artistdir, sel)):
			logger.info('os_remove(%s)' %os_path.join(self.artistdir, sel))
			os_remove(os_path.join(self.artistdir, sel))
			index=self["artistpicslist"].getCurrentIndex()
			filename=drawImageJobWithLongText(text='Deleted Artistpic', size=(384,216),)
			self["artistpicslist"].updateIndexRowData(index, 'deleted', filename)
		
	def up(self):
		pass

	def down(self):
		pass
		
	def left(self):
		self["artistpicslist"].MoveLeft()

	def right(self):
		self["artistpicslist"].MoveRight()
		
	def cancel(self):
		logger.info('Picbrowser]cancel]')
		self.close()
		
		