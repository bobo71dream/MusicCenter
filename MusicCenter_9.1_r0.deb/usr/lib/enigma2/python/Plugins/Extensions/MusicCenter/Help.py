# -*- coding: UTF-8 -*-

#  Music Center E2
#
#  Coded by bobo71 (c) 2014
#  Support: www.dreambox-tools.info
#
#  All Files of this Software are licensed under the Creative Commons
#  Attribution-NonCommercial-ShareAlike 3.0 Unported
#  License if not stated otherwise in a Files Head. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.

#  Additionally, this plugin may only be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.

#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially
#  distributed other than under the conditions noted above.
#  This applies to the source code as a whole as well as to parts of it, unless
#  explicitely stated otherwise.

from Globals import *

class Helps(Screen):

	def __init__(self, session, screenname, help):
	
		self.session = session
		self.skin_path='/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images'

		skin = """
		<screen name="Helps" position="0,0" size="1280,720" title="MusicCenter Help" backgroundColor="#00000000" flags="wfNoBorder">
		<widget name="helptext" position="50,130" size="1180,570" font="SansReg;22" valign="top" halign="left" backgroundColor="#00000000" transparent="1" zPosition="1" />
		""" + DBSKINHEAD + """
		</screen>"""

		self.skin = skin

		self["helptext"] = ScrollLabel()

		Screen.__init__(self, session)
		LOG('Helps]skin->%s' %self.skin)

		self["actions"]  = ActionMap(["OkCancelActions", "ShortcutActions", "ColorActions", "SetupActions", "NumberActions", "MenuActions", "EPGSelectActions","DirectionActions"], {
			"cancel": self.cancel,
			"up" : self.pageUp,
			"down" : self.pageDown,
			"right" : self.pageDown,
			"left" : self.pageUp,
			"nextBouquet" : self.pageUp,
			"prevBouquet" : self.pageDown
		}, -1)
		self["key_red"]=StaticText("")
		self["key_green"]=StaticText("")
		self["key_yellow"]=StaticText("")
		self["key_blue"]=StaticText("")
		self["headertext"]=Label()
		self.screenname=screenname
		self.help=help
		self.onLayoutFinish.append(self.Finished)

	def Finished(self):
		self["headertext"].setText(_("MusicCenter %s Help" %self.screenname))		
		self["helptext"].setText(self.help.replace('\t',''))

	def pageUp(self):
		self["helptext"].pageUp()

	def pageDown(self):
		self["helptext"].pageDown()

	def cancel(self):
		self.close(None)
