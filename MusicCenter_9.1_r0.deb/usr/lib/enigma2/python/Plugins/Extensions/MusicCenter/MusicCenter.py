# -*- coding: UTF-8 -*-

#  Music Center E2
#
#  Coded by bobo71 (c) 2014
#  Support: www.dreambox-tools.info
#
#  All Files of this Software are licensed under the Creative Commons
#  Attribution-NonCommercial-ShareAlike 3.0 Unported
#  License if not stated otherwise in a Files Head. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.

#  Additionally, this plugin may only be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.

#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially
#  distributed other than under the conditions noted above.
#  This applies to the source code as a whole as well as to parts of it, unless
#  explicitely stated otherwise.


from Globals import *
# mobile devices
from Screens.Console import Console

# local plugin
from Help import Helps
from JobCenter import *
from JobCenter2 import *
from myLogger import logger
from SelectPath import SelectPath
from Setup import MusicCenterSetup
from tagger import getID3Tags

import Jukebox
import Player
import RadioDe
import RadioBrowser
import SoundCloud



class MusicCenterAddToDatabase(Screen):

	if RESOLUTIONx>1800:

		skin="""<screen name="MusicCenterAddToDatabase" position="center,center" size="1600,320" title="Add music files to MusicCenter database">
				<ePixmap pixmap="skin_default/buttons/red.png" position="0,0" zPosition="0" size="210,60" scale="1" transparent="1" alphatest="on" />
				<ePixmap pixmap="skin_default/buttons/green.png" position="210,0" zPosition="0" size="210,60" scale="1" transparent="1" alphatest="on" />
				<widget name="output" position="10,50" size="1500,250" valign="center" halign="center" font="SansReg;28" />
				<widget render="Label" source="key_red" position="0,0" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="SansReg;30" transparent="1" foregroundColor="white" />
				<widget render="Label" source="key_green" position="210,0" size="210,60" zPosition="5" valign="center" halign="center" backgroundColor="red" font="SansReg;30" transparent="1" foregroundColor="white" />
			</screen>"""

	else:

		skin="""<screen name="MusicCenterAddToDatabase" position="center,center" size="10200,210" title="Add music files to MusicCenter database">
				<ePixmap pixmap="skin_default/buttons/red.png"    position="0,0" zPosition="0" size="140,40" scale="1" transparent="1" alphatest="on" />
				<ePixmap pixmap="skin_default/buttons/green.png"  position="140,0" size="140,40" zPosition="0" scale="1" transparent="1" alphatest="on" />
				<widget name="output"                             position= "10,33" size="1000,170" valign="center" halign="center" font="SansReg;18" />
				<widget render="Label" source="key_red"           position=  "0,0"  size= "140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="SansReg;20" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_green"         position="140,0"  size= "140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="SansReg;20" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
			</screen>"""

	def __init__(self, session, initDir=None, autoclose=False, isCleanDB=False):
		logger.info('MusicCenterAddToDatabase]__init__]initDir:{} autoclose:{} isCleanDB:{}'.format(initDir, autoclose, isCleanDB))
		Screen.__init__(self, session)

		self["actions"]=ActionMap(["WizardActions", "ColorActions"],
		{
			"back": self.cancel,
			"green": self.green,
			"red": self.cancel,
			"ok": self.green,
		}, -1)

		self["output"]=Label()
		self.initDir=initDir
		self.autoclose=autoclose
		self.isCleanDB=isCleanDB

		if isCleanDB:
			self.pathToDatabase_mc_conn=pathToDatabase.MessagePump.recv_msg.connect(self.gotThreadMsg_isCleanDB)
			self["key_red"]=StaticText("")
			self["key_green"]=StaticText("")
		else:
			self.pathToDatabase_mc_conn=pathToDatabase.MessagePump.recv_msg.connect(self.gotThreadMsg)
			self["key_red"]=StaticText(_("Cancel"))
			self["key_green"]=StaticText(_("Background"))

		self.onClose.append(self.__onClose)
		self.onLayoutFinish.append(self.startRun)

	def startRun(self):
		if self.isCleanDB:
			logger.info('MusicCenterAddToDatabase]startRun]CleanDB')
			pathToDatabase.Start(None)
		elif self.initDir is not None:
			logger.info('MusicCenterAddToDatabase]startRun]Scan directory')
			pathToDatabase.Start(self.initDir)
		else:
			logger.info('MusicCenterAddToDatabase]startRun]Show only Screen')

	def gotThreadMsg(self, msg):# 0->State, 1->Message,
		msg=pathToDatabase.Message.pop()
		#logger.info('MusicCenterAddToDatabase]gotThreadMsg:{}'.format(msg))
		if msg[0] in ('THREAD_WORKING',):
			self["output"].setText(msg[1])

		elif msg[0] in ('THREAD_FINISHED', 'THREAD_STOPANDSAVE', 'THREAD_EXCEPTED'):
			logger.info('MusicCenterAddToDatabase]gotThreadMsg, not good here what is wrong?-->{}'.format(msg))
			self["output"].setText(msg[1])
			self["key_red"].setText(_("Close"))
			self["key_green"].setText(_("Close"))
			if self.autoclose:
				self.close()
		else:
			logger.error('MusicCenterAddToDatabase]gotThreadMsg, not good here what is wrong?-->{}'.format(msg))

	def gotThreadMsg_isCleanDB(self, msg):
		msg=pathToDatabase.Message.pop()
		logger.info('MusicCenterAddToDatabase]gotThreadMsg_isCleanDB]msg->%s' %str(msg))
		if msg[1] is not None:
			self["output"].setText(msg[1])
		if msg[0] in ('THREAD_FINISHED', 'THREAD_EXCEPTED'):
			self["key_green"].setText("Close")
			self["key_red"].setText("Close")
			self.isCleanDB=False

	def green(self):
		if not self.isCleanDB:
			self.close()

	def cancel(self):
		if not self.isCleanDB:
			if pathToDatabase.isRunning:
				pathToDatabase.CancelScanDB()
			self.close()

	def __onClose(self):
		logger.info('MusicCenterAddToDatabase]__onClose]...')
		self.pathToDatabase_mc_conn=None


class MusicCenterStart(object):

	def __init__(self, session, serviceList):
		logger.info('MusicCenterStart]init...')
		self.session = session
		self.serviceList = serviceList
		self.currentService = self.session.nav.getCurrentlyPlayingServiceReference()

	def open(self):
		logger.info('MusicCenterStart]open]')
		#if not fileExists(os_path.join(config.plugins.musiccenter.databasepath.value ,"songs.db")):
		#	self.session.openWithCallback(self.callbackCreateDatabase, MessageBox, _("No Database File was found. Want your open Setup to select path?"), MessageBox.TYPE_YESNO)
		#elif 
		if pathToDatabase.isRunning:
			self.session.openWithCallback(self.callbackScanner, MessageBox, _("You are updating your musiclibrary...\nShow Scanner Screen?"), MessageBox.TYPE_YESNO)
		else:
			self.session.open(MusicCenterMain, self.currentService, self.serviceList)

	def callbackCreateDatabase(self, result):
		if result:
			logger.info('MusicCenterStart]callbackCreateDatabase]openConfig')
			self.session.openWithCallback(self.setupFinished, MusicCenterSetup)
		else:
			logger.info('MusicCenterStart]callbackMusicCentermain]close...')
			#self.close()

	def callbackScanner(self, result):
		if result:
			logger.info('MusicCenterStart]callbackScanner]open(MusicCenterAddToDatabase')
			self.session.openWithCallback(self.callbackScannerClosed, MusicCenterAddToDatabase)
		else:
			logger.info('MusicCenterStart]callbackScanner]playService and close...')
			#self.close()

	def callbackScannerClosed(self):
		if pathToDatabase.isRunning:
			logger.info('MusicCenterStart]callbackScannerClosed]playService and close...')
			#self.close()
		else:
			self.session.open(MusicCenterMain, self.currentService. self.serviceList)

	def setupFinished(self, result):
		if result:
			self.session.open(MusicCenterMain, self.currentService, self.serviceList)
		else:
			logger.info('MusicCenterStart]setupFinished]close')


class MusicCenterMain(Screen):

	if RESOLUTIONx>1800:

		skin="""
			<screen name="MusicCenterMain" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="transparent" zPosition="0">
				<!-- Header -->
					<eLabel backgroundColor="#191919" position="10,10" size="1900,132" zPosition="2" />
					<widget name="headertext" position="165,30" size="1590,60" font="SansReg;30" foregroundColor="#ffffff" backgroundColor="#191919" halign="center" valign="center" zPosition="3" />
					<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/verlauf1920_300.png" position="0,0" size="1920,300" alphatest="blend" zPosition="1"/>
				<!-- list -->
					<widget name="covercollection" position="10,130" size="1900,200" transparent="1" zPosition="3" coverSize="265,159" selectedCoverScale="1.2" unselectedCoverDimm="0.5" coverBeginPosition="400,90" coverDistance="30,30" style="0" noCoverAvailablePic="/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/No Poster.png" />
			</screen>"""

	else:

		skin="""
			<screen name="MusicCenterMain" position="0,0" size="1280,720" flags="wfNoBorder" backgroundColor="transparent" zPosition="0">
				<!-- Header -->
					<eLabel backgroundColor="#191919" position="6,6" size="1268,88" zPosition="1" />
					<widget name="headertext" position="110,20" size="1060,40" font="SansReg;20" foregroundColor="#ffffff" backgroundColor="#191919" halign="center" valign="center" zPosition="3" />
					<ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/verlauf1920_300.png" position="0,0" size="1280,200" alphatest="blend" zPosition="1"/>
				<!-- list -->
					<widget name="covercollection" position="6,87" size="1267,133" transparent="1" zPosition="2" coverSize="177,106" selectedCoverScale="1.2" unselectedCoverDimm="0.5" coverBeginPosition="267,60" coverDistance="20,20" style="0" noCoverAvailablePic="/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/No Poster.png" />
			</screen>"""

	def __init__(self, session, currentService, serviceList):

		logger.info('MusicCenterMain]init]...')
		self.session=session

		Screen.__init__(self, session)

		self["covercollection"] = CoverCollection()

		self["actions"]=ActionMap(["WizardActions", "DirectionActions", "ColorActions", "EPGSelectActions", "InfobarAudioSelectionActions", "HelpActions"],
		{
			"ok": self.okPressed,
			"back": self.closing,
			"input_date_time": self.menuPressed,
			"audioSelection": self.audioPressed,
			"displayHelp": self.openHelp,
			"left": self.left,
			"right": self.right,
			"up": self.up,
			"down": self.down,
		}, -1)

		self.onLayoutFinish.append(self.startRun)
		self.onClose.append(self.__onClose)

		self.currentService=currentService
		self.serviceList = serviceList
		self.TOKEN=None
		self.mode='buildMainMenuList'

		self.player=None
		self.lastplaylist=None

		self['headertext']=Label('')
		self.session.nav.SleepTimer.on_state_change.append(self.sleepTimerEntryOnStateChange)

	def startRun(self):
		self.initCache()
		logger.info('MusicCenterMain]startRun]set Animation')
		self.instance.setShowHideAnimation("slide_zoom_left_to_right")
		self["covercollection"].connectSelChanged(self.updateLCTText)
		self.buildMainList()

	def initCache(self):
		logger.info('MusicCenterMain]initCache]...')
		if pathExists('/tmp/mc/'):
			logger.info('MusicCenterMain]initCache]clear old tmpCache...')
			sh_rmtree('/tmp/mc/')
		if not pathExists('/tmp/mc/'):
			res=createDir('/tmp/mc/')
			logger.info('MusicCenterMain]initCache]create /tmp/mc/ :{}'.format(res))
			
		cachebasedir=config.plugins.musiccenter.downloadcache.value
		if not pathExists(cachebasedir):
			if not createDir(cachebasedir):
				logger.debug('MusicCenterMain]initCache]cachebasedir:{} not present, use /tmp'.format(cachebasedir))
		cachedir=os_path.join(cachebasedir, "cache/" )
		if not pathExists(cachedir):
			createDir(cachedir)
		cachedir=os_path.join(cachebasedir, "screensaver/" )
		if not pathExists(cachedir):
			createDir(cachedir)
		logger.info('MusicCenterMain]initCache]...')

	def left(self):
	      self["covercollection"].MoveLeft()

	def right(self):
	      self["covercollection"].MoveRight()

	def down(self):
	      self["covercollection"].MoveDown()

	def up(self):
	      self["covercollection"].MoveUp()

	def nextpage(self):
	      self["covercollection"].NextPage()

	def previouspage(self):
	      self["covercollection"].PreviousPage()

	def buildMainList(self):
		self['headertext'].setText(_('Main MusicCenter {}'.format(MC_VERSION)))

		list=[]
		posterlist=[]
		
		list.append((Item(mode='openFilebrowser'),))
		filebrowserpic='/tmp/filebrowser.png'
		if not fileExists(filebrowserpic):
			drawTransparentImage(text='Filebrowser', size=(500,300), out=filebrowserpic, textsize=65)
		posterlist.append(filebrowserpic)
		
		list.append((Item(mode='openJukebox'),))
		jukeboxpic='/tmp/jukeboxpic.png'
		if not fileExists(jukeboxpic):
			drawTransparentImage(text='Jukebox', size=(500,300), out=jukeboxpic, textsize=65)
		posterlist.append(jukeboxpic)
		
		list.append((Item(mode='openRadiobrowser'),))
		rbpic='/tmp/rb.png'
		if not fileExists(rbpic):
			drawTransparentImage(text='Radio-Browser.info', size=(500,300), out=rbpic, textsize=50)
		posterlist.append(rbpic)
		
		list.append((Item(mode='openRadioDe'),))
		rdepic='/tmp/rde.png'
		if not fileExists(rdepic):
			drawTransparentImage(text='Radio.de', size=(500,300), out=rdepic, textsize=65)
		posterlist.append(rdepic)
		
		list.append((Item(mode='openSoundCloud'),))
		scpic='/tmp/sc.png'
		if not fileExists(scpic):
			drawTransparentImage(text='Soundcloud', size=(500,300), out=scpic, textsize=65)
		posterlist.append(scpic)		

		self["covercollection"].setList(list, posterlist, 0)

		# vielleicht mal... wenn ich bock habe...
		#newer_as_file=os_path.join(config.plugins.musiccenter.databasepath.value ,"songs.db")
		#basepath=config.plugins.musiccenter.defaultfilebrowserpath.value
		#deferToThread(self.findChangedFiles, basepath, newer_as_file).addCallback(self.findChangedFilesCB).addErrback(self.findChangedFilesErrorCB)
		
	def findChangedFiles(self, basepath, newer_as_file):
		logger.info('MusicCenterMain]findChangedFiles]basepath:{} newer_as_file{}'.format(basepath, newer_as_file))
		'''
		newer_as_file='/hoeck/Local-320gb/Musik/songs.db'
		basepath='/hoeck/Local-320gb/Musik/'
		'''
		try:
			reftime=os_path.getmtime(newer_as_file)
			changed_files = []
			counter=0
			for (root, subFolders, files) in os_walk(basepath):
				subFolders.sort()
				files.sort()
				for filename in (subFolders + files):
					if filename.lower().endswith(PLAYABLEFORMATS) and os_path.getmtime(os_path.join(root, filename))> reftime:
						changed_files.append(os_path.join(root, filename))
						counter+=1
			return (changed_files, counter)
		except:
			logger.exception('MusicCenterMain]findChangedFiles]....')
		
	def findChangedFilesCB(self, result):
		logger.info('MusicCenterMain]findChangedFilesCB]:{}'.format(result))
		changed_files, counter=result
		self.session.toastManager.showToast('{} new musicfiles found...'.format(counter), 3)
	
	def findChangedFilesErrorCB(self, error):
		logger.error('MusicCenterMain}findChangedFilesErrorCB]:{}'.format(error)) 
		
	def initStreamripping_unused(self):
		# python streamripper have not webserver
		s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		result = s.connect_ex(('127.0.0.1', 9191))
		if result==0:
			if fileExists('/tmp/rippedstation'):
				with open('/tmp/rippedstation', 'rb') as f:
					songList=pickle.load(f)
				return ('%s (%s)') %(songList[0][0].stationname, songList[0][0].genre)
			else:
				return 'Unknown station'
		else:
			return None

	def okPressed(self):
		sel = self["covercollection"].getCurrent()
		if sel is None:
			return
		self.mode=sel.mode
		if not isinstance(self.mode, int):
			logger.info('''MusicCenterMain]okPressed]exec"self.{}()"'''.format(self.mode))
			exec"self.{}()".format(self.mode)
		else:
			logger.info('''MusicCenterMain]okPressed error]exec"self.{}()"'''.format(self.mode))

	def openFilebrowser(self):
		self.session.openWithCallback(self.callbacks, MusicCenterFileList, self.player, self.currentService, self.serviceList)

	def opendbModewithstartplaylist(self):
		if JCcheckModuleIsUpdated('DatabaseBrowser'):
			reload(DatabaseBrowser)
		self.session.openWithCallback(self.callbacks, DatabaseBrowser.DatabaseBrowser, self.player, True, self.currentService, self.serviceList)

	def openJukebox(self):
		if JCcheckModuleIsUpdated('Jukebox'):
			reload(Jukebox)
		self.session.openWithCallback(self.callbacks,Jukebox.Jukebox, self.player, self.currentService, self.serviceList)

	def openSoundCloud(self):
		if JCcheckModuleIsUpdated('SoundCloud'):
			reload(SoundCloud)
		self.session.openWithCallback(self.callbacks, SoundCloud.SCMain, self.player, self.TOKEN)

	def openRadiobrowser(self):
		if JCcheckModuleIsUpdated('RadioBrowser'):
			reload(RadioBrowser)
		self.session.openWithCallback(self.callbacks, RadioBrowser.RadiobrowserMain, self.player, self.currentService, self.serviceList)

	def openRadioDe(self):
		if JCcheckModuleIsUpdated('RadioDe'):
			reload(RadioDe)
		self.session.openWithCallback(self.callbacks, RadioDe.RadioDeMain, self.player, self.currentService, self.serviceList)

	def openStreamripperPlayer(self):
		if fileExists('/tmp/rippedstation'):
			with open('/tmp/rippedstation', 'rb') as f:
				songList=pickle.load(f)
		else:
			station='Current ripping station'
			songList=[(Item(album=station, filename="http://localhost:9191", filetype='RADIOBROWSER', join=False, codec='MP3', audio=True),)]
		if self.player is not None:
			if self.player.playermode!=RADIOBROWSER:
				self.closePlayerNow()
			else:
				logger.info('MusicCenterMain]openStreamripperPlayer]is playermode 1(Stream) and songList -> only new station given')
				if self.player.songList!=songList:
					self.player.songList=songList
				self.player.playSong(0)
		if self.player is None:
			self.player=self.session.instantiateDialog(Player.Player, songList=songList, index=0, playermode=RADIOBROWSER, currentService=self.currentService, serviceList=self.serviceList)
			self.player.setShowHideAnimation("quick_fade")
		self.session.execDialog(self.player)

	def callbacks(self, player, TOKEN=None):
		logger.info('MusicCenterMain]callbacks...')
		if TOKEN is not None:
			self.TOKEN=TOKEN
		self.player=player
		self.mode='buildMainMenuList'
		if pathToDatabase.isRunning:
			self.closing()

	def sleepTimerEntryOnStateChange(self, timer):
		if timer.state == TimerEntry.StateEnded:
			self.close()

	def getCurrentSelection(self):
		try: sel=self['list'].l.getCurrentSelection()[0]
		except: sel=None
		return sel

	def menuPressed(self):
		options=[(_("Configuration"), self.openConfig),]
		self.session.openWithCallback(self.menuCallback, ChoiceBox,list=options)

	def menuCallback(self, ret):
		ret and ret[1]()

	def openHelp(self):
		pass
		#help='''MENU  -> Show SubSelections'''
		#self.session.open(Helps, 'Main', help)
# buttons
	def setButtons(self, red=False, green=False, yellow=False, blue=False):
		if red:
			if red == True:
				self["key_red"].setText("Main Menu")
			else:
				self["key_red"].setText(red)
		else:
			self["key_red"].setText("-")

		if green:
			if green == True:
				self["key_green"].setText("Play")
			else:
				self["key_green"].setText(green)
		else:
			self["key_green"].setText("-")

		if yellow:
			if yellow == True:
				self["key_yellow"].setText("All Artists")
			else:
				self["key_yellow"].setText(yellow)
		else:
			self["key_yellow"].setText("-")

		if blue:
			if blue == True:
				self["key_blue"].setText("Show Album")
			else:
				self["key_blue"].setText(blue)
		else:
			self["key_blue"].setText("-")

	def audioPressed(self):
		if self.player is not None and self.player.songList:
			self.session.execDialog(self.player)
# end
	def showScannerCallback(self):
		self.session.openWithCallback(self.scannerClosed, MusicCenterAddToDatabase, None)

	def openConfig(self):
		self.session.openWithCallback(self.setupFinished, MusicCenterSetup)

	def setupFinished(self, result):
		if result:
			self.startRun()

	def Error(self, error=None):
		if error is not None:
			self['list'].hide()
			self["statustext"].setText(str(error.getErrorMessage()))

	def cleanCovercache(self, cachedir, maxcachesizeMB=500):
		# 500MB default cache size
		logger.debug('MusicCenterMain]cleanCovercache]start, check size...')
		cachefilelist=[(int(os_stat(cachedir+f).st_size),os_stat(cachedir+f).st_ctime, cachedir+f) for f in os_listdir(cachedir)] # list files(size,ctime,filename
		cachesizeMB=sum([f[0] for f in cachefilelist])/1024/1024.0
		if cachesizeMB > maxcachesizeMB:
			logger.info('MusicCenterMain]cleanCovercache]cachesize is ->%dMB, start cleanup!' %cachesizeMB)
			cachefilelist.sort(key=lambda a:a[1]) # ctime ascend
			while cachesizeMB>maxcachesizeMB:
				cachefile=cachefilelist.pop(0)
				logger.debug('MusicCenterMain]cleanCovercache]remove -> %s' %cachefile[2])
				os_remove(cachefile[2])
				cachesizeMB-=cachefile[0]/1024/1024.0
			logger.debug('MusicCenterMain]cleanCovercache]stop removing new size is -> %d' %cachesizeMB)
		else:
			logger.info('MusicCenterMain]cleanCovercache]cachesize is ->%dMB, nothing to do.' %cachesizeMB)
		logger.debug('MusicCenterMain]cleanCovercache]done')

	def closePlayerNow(self):
		if self.player.playermode in (FILEMODE,):
			logger.info('MusicCenterMain]closePlayerNow]is FILEMODE, call updateRatingPlaycounterWaveCover')
			if self.player.hlp.get('currIndex')!=-2:# -2 = no playlist
				self.player.updateRatingPlaycounterWaveCover()
		logger.info('MusicCenterMain]closePlayerNow]')
		#self.player.closePlayer()
		
		if self.player.TVScreen:
			logger.info('MusicCenterMain]closePlayerNow] TVScreen instance found delete...')
			self.session.deleteDialog(self.player.TVScreen)
			self.player.TVScreen=None
		self.session.deleteDialog(self.player)
		self.player=None

	def closing(self):
		if self.mode!='buildMainMenuList':
			logger.info('MusicCenterMain]closing]no buildMainMenuList')
			self.keyNumberPressed(0)
		else:
			logger.info('MusicCenterMain]closing]Start')
			self.close()

	def errorSimpleThread(self, error, name):
		if error!=None:
			logger.error('MusicCenterMain]errorSimpleThread]%s error-->%s' %(name,error))

	def __onClose(self):
		logger.info('MusicCenterMain]__onClose]Start')
		self.session.nav.SleepTimer.on_state_change.remove(self.sleepTimerEntryOnStateChange)
		if self.player is not None: # and self.player.songList is not None: ->
			logger.info('MusicCenterMain]__onClose]Remove self.playerinstance...')
			self.closePlayerNow()
		if self.serviceList is None:
			self.session.nav.playService(self.currentService)
		else:
			current = ServiceReference(self.serviceList.getCurrentSelection())
			self.session.nav.playService(current.ref)
		logger.info('MusicCenterMain]__onClose]clear /tmp/mc/....')
		sh_rmtree('/tmp/mc/')

	def updateLCTText(self, index):
		entry=self['covercollection'].getCurrent()
		if entry is not None:
			self.summaries.setText(entry.text, 1)

	def createSummary(self):
		return MusicCenterMainLCD


class MusicCenterMainLCD(Screen):

	skin="""
		<screen position="0,0" size="132,64">
			<widget name="screenname" position="2,2" size="128,14" font="SansReg;12"/>
			<widget name="text1" position="2,32" size="128,14" font="SansReg;12"/>
		</screen>"""

	def __init__(self, session, parent):
		Screen.__init__(self, session)
		self["screenname"] = Label(_('MusicCenter Main'))
		self["text1"]=Label()


	def setText(self, text, line):
		if line == 1:
			self["text1"].setText(text)
		else:
			pass

			
class MC_MultiFileSelectList(BaseMultiFileSelectList):

	def __init__(self, preselectedFiles, directory, showMountpoints = False, matchingPattern = None, showDirectories = True, showFiles = True,  useServiceRef = False, inhibitDirs = False, inhibitMounts = False, isTop = False, enableWrapAround = False, additionalExtensions = None):

		logger.info('MC_MultiFileSelectList]__init__]...')

		BaseMultiFileSelectList.__init__(self, preselectedFiles, directory, showMountpoints, matchingPattern, showDirectories, showFiles,  useServiceRef, inhibitDirs, inhibitMounts, isTop, enableWrapAround, additionalExtensions)

	def inParentDirs(self, dir, parents):
		# override inhibitDirs from absolute to in path...
		dir = os_path.realpath(dir)
		dir=dir.rsplit('/',1)[-1]
		logger.debug('MC_MultiFileSelectList]inParentDirs:{} parents:{}'.format(dir, parents))
		for p in parents:
			if dir.startswith(p):
				return True
		return False

	def byNameFunc(self, a, b):
		return cmp(b[0][1], a[0][1]) or cmp(a[1][7], b[1][7])

	def sortName(self):
		self.list.sort(self.byNameFunc)
		#self.l.invalidate()
		self.l.setList(self.list)
		self.moveToIndex(0)

	def byDateFunc(self, a, b):
		try:
			stat1 = os_stat(self.current_directory + a[0][0])
			stat2 = os_stat(self.current_directory + b[0][0])
		except:
			return 0
		return cmp(b[0][1], a[0][1]) or cmp(stat2.st_ctime, stat1.st_ctime)

	def sortDate(self):
		self.list.sort(self.byDateFunc)
		#self.l.invalidate()
		self.l.setList(self.list)
		self.moveToIndex(0)


class MusicCenterFileList(Screen):

	if RESOLUTIONx >1800:
		skin='''
			<screen name="MusicCenterFileList1" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#00000000" title="MC_Filelist">
			<!-- headerfield  -->
				<eLabel backgroundColor="#191919" position="20,20" size="1880,132" zPosition="1" />
				<widget name="coverArt" position="20,20" size="132,132" zPosition="2"/>
				<!-- 1 zeile  -->
					<widget name="artistandtitle" position="190,26" size="1480,42" font="SansReg;35" halign="left" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" zPosition="2"/>
					<widget name="track" position="1675,26" size="225,42" font="SansReg;35" halign="center" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" zPosition="2"/>
				<!-- 2 zeile  -->
					<widget name="albumyearalbartist" position="190,76" size="1185,34" font="SansReg;28" halign="left" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" zPosition="2"/>
					<widget name="genre" position="1375,76" size="300,34" font="SansReg;28" halign="left" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" zPosition="2"/>
					<widget name="length" position="1675,76" size="225,34" font="SansReg;28" halign="center" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" zPosition="3"/>
				<!-- 3 zeile  -->
					<widget name="filename" position="190,117" size="985,28" font="SansReg;23" halign="left" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" zPosition="2"/>
					<widget name="rating" position="1175,116" size="300,32" alphatest="on" zPosition="3" scale="0" pixmaps="~/rating0.png,~/rating1.png,~/rating2.png,~/rating3.png,~/rating4.png,~/rating5.png,~/rating6.png,~/rating7.png,~/rating8.png,~/rating9.png,~/rating10.png,~/rating11.png"/>
					<widget name="plays" position="1475,117" size="200,28" font="SansReg;23" halign="center" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" zPosition="2"/>
					<widget name="bitrate" position="1675,117" size="225,28" font="SansReg;23" halign="center" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" zPosition="2"/>
				<!-- Buttons -->
					<eLabel position="20,167" size="1880,40" backgroundColor="#191919" zPosition="1" /> 
					<widget render="Label" font="SansReg;28" position="60,171" size="450,32" source="key_red" foregroundColor="#ff0000" transparent="1" halign="center" valign="center" zPosition="2"/>
					<widget render="Label" font="SansReg;28" position="510,171" size="450,32" source="key_green" foregroundColor="#00ff21" transparent="1" halign="center" valign="center" zPosition="2"/>
					<widget render="Label" font="SansReg;28" position="960,171" size="450,32" source="key_yellow" foregroundColor="#FFD800" transparent="1" halign="center" valign="center" zPosition="2"/>
					<widget render="Label" font="SansReg;28" position="1410,171" size="450,32" source="key_blue" foregroundColor="#3D8DFF" transparent="1" halign="center" valign="center" zPosition="2"/>
				<!-- list -->
					<widget name="filelist" position="20,222" zPosition="2" size="1880,840" scrollbarMode="showOnDemand" backgroundColor="#191919"/>
					<widget name="waittext" position="center,center" size="300,60" font="SansReg;30" foregroundColor="#ffffff" backgroundColor="#00000000" halign="center" valign="center" zPosition="8" />
			</screen>'''
	else:
		skin='''
			<screen name="MusicCenterFileList1" position="0,0" size="1280,720" flags="wfNoBorder" backgroundColor="#00000000" title="MC_Filelist">
			<!-- headerfield  -->
				<eLabel backgroundColor="#191919" position="13,13" size="1253,88" zPosition="1" />
				<widget name="coverArt" position="13,13" size="88,88" zPosition="2"/>
				<!-- 1 zeile  -->
					<widget name="artistandtitle" position="126,17" size="986,28" font="SansReg;23" halign="left" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" zPosition="2"/>
					<widget name="track" position="1116,17" size="150,28" font="SansReg;23" halign="center" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" zPosition="2"/>
				<!-- 2 zeile  -->
					<widget name="albumyearalbartist" position="126,50" size="790,22" font="SansReg;18" halign="left" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" zPosition="2"/>
					<widget name="genre" position="916,50" size="200,22" font="SansReg;18" halign="left" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" zPosition="2"/>
					<widget name="length" position="1116,50" size="150,22" font="SansReg;18" halign="center" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" zPosition="3"/>
				<!-- 3 zeile  -->
					<widget name="filename" position= "126,78" size="656,18" font="SansReg;15" halign="left" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" zPosition="2"/>
					<widget name="rating"   position= "783,78" size="200,21" alphatest="on" zPosition="3" scale="0" pixmaps="~/rating0.png,~/rating1.png,~/rating2.png,~/rating3.png,~/rating4.png,~/rating5.png,~/rating6.png,~/rating7.png,~/rating8.png,~/rating9.png,~/rating10.png,~/rating11.png"/>
					<widget name="plays"    position= "983,78" size="133,18" font="SansReg;15" halign="center" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" zPosition="2"/>
					<widget name="bitrate"  position="1116,78" size="150,18" font="SansReg;15" halign="center" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" zPosition="2"/>
				<!-- Buttons -->
					<widget render="Label" font="SansReg;18" position= "40,106" size="300,20" source="key_red" foregroundColor="#ff0000" transparent="1" halign="center" valign="center" zPosition="2"/>
					<widget render="Label" font="SansReg;18" position="340,106" size="300,20" source="key_green" foregroundColor="#00ff21" transparent="1" halign="center" valign="center" zPosition="2"/>
					<widget render="Label" font="SansReg;18" position="640,106" size="300,20" source="key_yellow" foregroundColor="#FFD800" transparent="1" halign="center" valign="center" zPosition="2"/>
					<widget render="Label" font="SansReg;18" position="940,106" size="300,20" source="key_blue" foregroundColor="#3D8DFF" transparent="1" halign="center" valign="center" zPosition="2"/>
				<!-- list -->
					<widget name="filelist" position="13,133" zPosition="2" size="1253,553" scrollbarMode="showOnDemand" backgroundColor="#191919"/>
					<widget name="waittext" position="center,center" size="200,40" font="SansReg;20" foregroundColor="#ffffff" backgroundColor="#00000000" halign="center" valign="center" zPosition="8" />
			</screen>'''

	def __init__(self, session, player, currentService, serviceList):

		self.session=session
		self.currentService=currentService
		self.serviceList=serviceList
		self.skin_path='/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images'
		Screen.__init__(self, session)

		self.currentService=self.session.nav.getCurrentlyPlayingServiceReference()
		self.MyBox=HardwareInfo().get_device_name()
		self.selectedDir="/tmp/"
		self.selectedFiles= []

		self.FileEraser=eBackgroundFileEraser.getInstance()
		self.coverLoader=CoverLoader()

		if config.plugins.musiccenter.rememberlastfilebrowserpath.value:
			startupPath=config.plugins.musiccenter.lastusedpath.value
		else:
			startupPath=config.plugins.musiccenter.defaultfilebrowserpath.value
		if not pathExists(startupPath):
			startupPath='/hdd/'

		self["artistandtitle"]=Label()
		self["albumyearalbartist"]=Label()
		self["genre"]=Label()
		self["plays"]=Label()
		self["track"]=Label()
		self["bitrate"]=Label()
		self["filename"]=Label()
		self["length"]=Label()
		self["rating"]=MultiPixmap()

		self["key_red"]=StaticText("Loesche")
		self["key_green"]=StaticText("Umbenennen")
		self["key_yellow"]=StaticText("Verschiebe/Kopiere")
		self["key_blue"]=StaticText("Lesezeichen")
		self.musicinfoupdatetimer=eTimer()
		self.musicinfoupdatetimer_mc_conn=self.musicinfoupdatetimer.timeout.connect(self.musicInfoUpdatetimerAppend)
		self["coverArt"]=PicLoaderScale(transparent=False, cached=False, name='Filelist coverArt')# VideoDBPictureBox()
		self['waittext']=Label()
		self['waittext'].hide()

		matchingPattern='(?i)^.*\.({})$'.format('|'.join(PLAYABLEFORMATS))
		logger.info('Filelist]__init__]init Filelist:{} with matchingPattern:{}'.format(startupPath, matchingPattern))
		self["filelist"]= MC_MultiFileSelectList(self.selectedFiles, startupPath, matchingPattern=matchingPattern, inhibitDirs=['.'], enableWrapAround = True)

		self["actions"]=ActionMap(["WizardActions", "DirectionActions", "ColorActions", "MenuActions", "EPGSelectActions", "InfobarActions", "InfobarAudioSelectionActions", "GlobalActions","NumberActions","InfobarChannelSelection","HelpActions"],
		{
			"ok": self.okPressed,
			"back": self.explExit,
			"green": self.ExecRename,
			"red": self.execDelete,
			"blue": self.listBookmarks,
			"yellow": self.go2CPmaniger,
			"menu": self.menuPressed,
			"audioSelection": self.audioPressed,
			"8": self.changeSelectionState,
			"0": self.directoryUp,
			"left": self.left,
			"right": self.right,
			"up": self.up,
			"down": self.down,
			"nextBouquet": self.sortName,
			"prevBouquet": self.sortDate,
			"info" : self.infoPressed,
			"showMovies": self.videoPressed,
			"displayHelp": self.openHelp,
		}, -1)

		self.songListtmp=[]
		#self.__dbpool = OpenDatabasePool()
		self.player=player
		self.foundIndex=""
		self.currfolder=""
		self.hlp={}
		self.scaned_count=0
		self.playable_songs_count=0
		self.scanPath_mc_conn=None

		self.onClose.append(self.__onClose)
		self.onLayoutFinish.append(self.startRun)

	def destroy(self):
		self["coverArt"].destroy()

	def changeSelectionState(self):
		pass # self["filelist"].changeSelectionState()

	def startRun(self):
		logger.info('FileList]startRun]start animation')
		self.instance.setShowHideAnimation("slide_top_to_bottom")
		try:
			sf='quick_fade'
			for element in ['coverArt']:
				self[element].instance.setShowHideAnimation(sf)
		except Exception, e:
			logger.exception('Filelist]startRun]Hmm, klappt  nicht...')
		self.updateLocationInfo()

	def updateLocationInfo(self):
		self.musicinfoupdatetimer.start(100, True) # call musicInfoUpdatetimerAppend

	def musicInfoUpdatetimerAppend(self):
		currfolder=self["filelist"].getCurrentDirectory()
		index=self["filelist"].getSelectedIndex()
		logger.info('Filelist]musicInfoUpdatetimerAppend currfolder:{} index:{}'.format(currfolder, index))
		if currfolder!=None:
			file=self["filelist"].getFilename()
			logger.info('Filelist]musicInfoUpdatetimerAppend file:{}'.format(file))
			if not self["filelist"].canDescent(): # file
				if file!=None:
					f=''.join((currfolder, file))
					t0=SimpleThread(lambda:self.gettitleInfoOnDefered(f))
					t0.deferred.addCallback(self.gettitleInfoOnDeferedAppend,)
					t0.deferred.addErrback(self.errorGettitleInfoOnDefered, f)
					t0.start()
			else: # directory
				self.getTitleInfoAppendShowID3(filename=currfolder, coverfilename=''.join((self.skin_path, '/folder_music_x200.png')))

	def gettitleInfoOnDefered(self, filename):

		coverfilename=self.coverLoader.load(filename)
		if not fileExists(coverfilename):
			coverfilename=''.join((self.skin_path, '/no-cover.png'))

		if filename.startswith(config.plugins.musiccenter.defaultfilebrowserpath.value):
			filenameindb=filename[len(config.plugins.musiccenter.defaultfilebrowserpath.value):]
			sql='''SELECT filename, artist, title, album, albumartist, genre, track, length, bitrate, date, playcount, rating FROM Songs WHERE filename=? LIMIT 1;'''
			args=(filenameindb,)
			res=execSQLCommandWithReturn(sql, args).fetchone()
			if res is None: # nicht gefunden in db
				logger.info('Filelist]gettitleInfoOnDefered]no in db found, get id3 now from file->%s' %filename)
				mypath, myfilename=os_path.split(filename)
				ID3=getID3Tags(mypath, myfilename)
				artist=ID3.artist
				title=ID3.title
				album=ID3.album
				albumartist=ID3.albumartist
				genre=ID3.genre
				track=ID3.track
				length=ID3.length
				bitrate=ID3.bitrate
				date=ID3.date
				playcount=ID3.playcount
				rating=ID3.rating
			else:
				filename, artist, title, album, albumartist, genre, track, length, bitrate, date, playcount, rating=res
		else:
			logger.info('Filelist]gettitleInfoOnDefered]musicfile not in Musiclib, get id3 now from file->%s' %filename)
			mypath, myfilename=os_path.split(filename)
			ID3=getID3Tags(mypath, myfilename)
			artist=ID3.artist
			title=ID3.title
			album=ID3.album
			albumartist=ID3.albumartist
			genre=ID3.genre
			track=ID3.track
			length=ID3.length
			bitrate=ID3.bitrate
			date=ID3.date
			playcount=ID3.playcount
			rating=ID3.rating
		if album in ('n/a',''):
			logger.info('Filelist]gettitleInfoOnDefered]set directory name as album')
			album=filename.rsplit('/',2)[1]

		return filename, artist, title, album, albumartist, genre, track, length, bitrate, date, playcount, rating, coverfilename

	def gettitleInfoOnDeferedAppend(self, res):
		#logger.info('Filelist]gettitleInfoOnDeferedAppend]res->%s' %str(res))
		filename, artist, title, album, albumartist, genre, track, length, bitrate, date, playcount, rating, coverfilename=res
		self.getTitleInfoAppendShowID3(filename, artist, title, album, albumartist, genre, track, length, bitrate, date, playcount, rating, coverfilename)

	def getTitleInfoAppendShowID3(self, filename='n/a', artist='n/a', title='n/a', album='n/a', albumartist='n/a', genre='n/a', track='n/a', length='n/a', bitrate='n/a', date='n/a', playcount='n/a', rating=281, coverfilename=''):
		if filename.startswith(config.plugins.musiccenter.defaultfilebrowserpath.value):
			filename='MyMusic/' + filename[len(config.plugins.musiccenter.defaultfilebrowserpath.value):]
		self['artistandtitle'].setText('%s - %s' %(artist, title))
		self['albumyearalbartist'].setText('%s [%s] %s' %(album, date, albumartist))
		self['filename'].setText(filename)
		self['track'].setText('Track %s' %track)
		self['genre'].setText(genre)
		self["plays"].setText('Plays %s' %playcount)
		self["bitrate"].setText(convertBitrate(bitrate))
		self["length"].setText(convertLength(length))
		ratingnum=calcRating(rating)
		self["rating"].setPixmapNum(ratingnum)
		self["coverArt"].doshow(coverfilename)
		# update LCD
		mypath, myfilename=os_path.split(filename)
		self.summaries.setText('MusicCenter Filebrowser', 1)
		self.summaries.setText(mypath, 2)
		self.summaries.setText(myfilename, 3)

	def errorGettitleInfoOnDefered(self, error, filename):
		if error!=None:
			logger.error('Filelist]errorGettitleInfoOnDefered]->%s-> %s' %(filename, error))

	def config(self):
		self.session.open(MusicCenterSetup)

	def menuPressed(self):
		menulist=[(_("Configuration"), self.config)]
		#if not self.hlp.get('multiselectmode', False):
		#	menulist.append((_("Activate multiselectmode"), self.activateMultiselectmode),)
		#else:
		#	menulist.append((_("Dectivate multiselectmode"), self.deactivateMultiselectmode),)
		#self.selectedFiles = self["filelist"].getSelectedList()
		menulist.append((_("Sort by name (bouquet+)"), self.sortName),)
		menulist.append((_("Sort by date (bouquet-)"), self.sortDate),)
		if self["filelist"].canDescent():
			self.selectedDir=self["filelist"].getSelection()[0]
			menulist.append((_("(Re)Scan my musiclibrary"), self.addSelectedPathToDB),)
			if self.selectedDir in self.loadBookmarks():
				BMtext="Remove folder from Bookmarks"
				BMstring=self.delBookmark
			else:
				BMtext="Add folder to Bookmarks"
				BMstring=self.addBookmark
			if self["filelist"].getSelectionIndex()!=0:
				menulist.append((_(BMtext), BMstring),)
			menulist.append((_("Create new directory"), self.createNewDir),)
		else:
			filename=self["filelist"].getFilename()
			menulist.append((_("Create new directory"), self.createNewDir),)
			menulist.append((_("Create softlink..."),self.createLink),)
			#if filename.lower().endswith(PLAYABLEFORMATS):
			#	menulist.append((_("Clear current songlist and play selected entry"), self.stopPlayingAndAppendFileToSongList),)
			#	menulist.append((_("Append file to current songlist"), self.appendFileToSongList),)
			#	if self.player is not None and self.player.songList:
			#		menulist.append((_("Insert file to current songlist and play next"), self.insertFileToSongList),)
		self.session.openWithCallback(self.menuCallback, ChoiceBox, title=_("Options:\n"), list=menulist, keys=MYKEYSORT, titlebartext=_("MusicCenter"))

	def menuCallback(self, ret):
		ret and ret[1]()

	def activateMultiselectmode(self):
		self.hlp['multiselectmode']=True
		self["key_red"]=setText("Multi Loeschen")
		self["key_green"]=setText("Multi Umbenennen")
		self["key_yellow"]=setText("Multi Verschiebe/Kopiere")

	def deactivateMultiselectmode(self):
		self.hlp['multiselectmode']=False
		self["key_red"]=setText("Loesche")
		self["key_green"]=setText("Umbenennen")
		self["key_yellow"]=setText("Verschiebe/Kopiere")

	def execDeleteMultiFiles(self):
		self.session.open(MessageBox, _("Delete selected Files\n%s")%self.selectedFiles, type=MessageBox.TYPE_INFO, title="MusicCenter",timeout=101 )

	def addSelectedPathToDB(self):
		self.session.open(MusicCenterAddToDatabase, config.plugins.musiccenter.defaultfilebrowserpath.value)

	def addBookmark(self):
		bookmarks=self.loadBookmarks()
		bookmarks.append(self.selectedDir)
		with open(resolveFilename(SCOPE_CONFIG, 'mc_Bookmarks'), 'w') as lst:
			for l in bookmarks:
				lst.write(l+'\n')

	def delBookmark(self):
		bookmarks=self.loadBookmarks()
		for index, entry in enumerate(bookmarks):
			if(self.selectedDir == entry):
				logger.info('FileList]delBookmark]dir%s entry%s' %(self.selectedDir, entry))
				bookmarks.pop(index)
		with open(resolveFilename(SCOPE_CONFIG, 'mc_Bookmarks'), 'w') as lst:
			for l in bookmarks:
				lst.write(l+'\n')

	def createNewDir(self):
		self.session.openWithCallback(self.callbackNewDir, vInputBox, title=_(self["filelist"].getCurrentDirectory()), windowTitle=_("MusicCenter Create new folder in..."), text="name")

	def openHelp(self):
		help=''' MENU -> Show SubSelections
				AUDIO -> Back to Player if is running
				  PV  ->
				  RED -> Delete selected File/Folder from List, HDD and Database
				GREEN -> Move File/Folder
				YELLOW-> Copy File/Folder
				 BLUE -> Show Favorite Folders
				  0   -> One Folderlevel back'''
		self.session.open(Helps, 'Filebrowser', help)

	def createLink(self):
		self.session.openWithCallback(self.callbackCPmaniger, SoftLinkScreen, self["filelist"].getCurrentDirectory())

	def stopPlayingAndAppendFileToSongList(self):
		if self.player is not None:
			self.player.closePlayerNow() # neu test keine Playlist
		self.appendFileToSongList()

	def appendFileToSongList(self):
		logger.info('Filelist]appendFileToSongList] Start')
		PlayerAvailable= self.player is not None and self.player.songList
		mypath, filename=self["filelist"].getCurrentDirectory(), self["filelist"].getFilename()
		logger.info('Filelist]appendFileToSongList  %s %s' %(mypath, filename))
		if filename.lower().endswith(PLAYABLEFORMATS):
			SongList=[]
			myaudio, mytitle, mygenre, myartist, myalbum, mytracknr, mytrack, mydate, mylength, mybitrate, myalbumartist, myfiletype, playcount, rating=getID3Tags(mypath, filename)
			a=Item(text=filename, filename=os_path.join(mypath,filename), title=mytitle, artist=myartist, bitrate=mybitrate, length=mylength, genre=mygenre,
				track=mytrack, date=mydate, album=myalbum, audio=myaudio, tracknr=mytracknr, albumartist=myalbumartist, filetype=myfiletype, playcount=playcount, rating=rating)
			if PlayerAvailable:
				self.player.songList.append((a,))
			else:
				SongList.append((a,))
			if not PlayerAvailable:
				if self.player is not None:
					self.player.closePlayerNow() # neu test keine Playlist
				try:
					if JCcheckModuleIsUpdated('Player'):
						reload(Player)
				except Exception, e:
					self.session.open(MessageBox, _("Error reload Player\n%s" %e), type=MessageBox.TYPE_ERROR, timeout=10 )
				self.player=self.session.instantiateDialog(Player.Player, songList=SongList, index=0, currentService=self.currentService, serviceList=self.serviceList)
				self.player.setShowHideAnimation("quick_fade")
				self.player.playSong(self.player.getCurrSonglistEntry().filename) # songList[self.player.currentIndex][0].filename)
				self.player["coverArt"].onShow()
				self.player.init=1
			else:
				self.session.open(MessageBox, _("%s\nappended to songlist")%a.text, type=MessageBox.TYPE_INFO, title="MusicCenter",timeout=3 )

	def insertFileToSongList(self):
		logger.info('Filelist]insertFileToSongList] Start')
		if self.player is not None and self.player.songList:
			index=self.player.hlp.get('currIndex')
			mypath, filename=self["filelist"].getCurrentDirectory(), self["filelist"].getFilename()
			logger.info('Filelist]insertFileToSongList]  %s %s' %(mypath, filename))
			if filename.lower().endswith(PLAYABLEFORMATS):
				myaudio, mytitle, mygenre, myartist, myalbum, mytracknr, mytrack, mydate, mylength, mybitrate, myalbumartist, myfiletype, playcount, rating=getID3Tags(mypath, filename)
				a=Item(text=filename, filename=os_path.join(mypath,filename), title=mytitle, artist=myartist, bitrate=mybitrate, length=mylength, genre=mygenre,
					track=mytrack, date=mydate, album=myalbum, audio=myaudio, tracknr=mytracknr, albumartist=myalbumartist, filetype=myfiletype, playcount=playcount, rating=rating)
				#a=Item(text=filename, filename=os_path.join(self["filelist"].getCurrentDirectory(),filename))
				self.player.songList.insert(index+1,(a,))
				self.player.songListOrig.insert(index+1,(a,))
				self.session.open(MessageBox, _("%s\ninserted and will be played as next song")%a.text, type=MessageBox.TYPE_INFO, title="MusicCenter",timeout=3 )
		else:
			logger.info('Filelist]appendFileToSongList] skip to appendFileToSongList')
			self.appendFileToSongList()

	def getListIndex(self, folder, filename):
		for index, file in enumerate(self["filelist"].getFileList()):
			logger.info('FileList]getListIndex]filename:{} file:{}'.format(filename, file[0][0]))
			if filename == file[0][0]:
				logger.info('FileList]getListIndex]match, folder:{} filename:{} foundindex:{}'.format(folder, filename, index))
				return index
		logger.debug('FileList]getListIndex]folder:{} filename:{} not found, return index:0'.format(folder, filename))
		return 0
#Ok
	def okPressed(self):
		if self["filelist"].canDescent(): # change directory
			self["filelist"].descent()
			self.updateLocationInfo()
		else:
			self.updateLastUsedDirectory()
			if not self.hlp.get('multiselectmode', False):
				self.scanPath_mc_conn=scanPath.MessagePump.recv_msg.connect(self.gotThreadMsg)
				self.songListtmp=[]
				playableSongs=[]
				foundIndex=-1
				self.scaned_count=0
				currfolder=self["filelist"].getCurrentDirectory()[:-1]
				selectedfilename=self["filelist"].getFilename()
				index=0
				for filename in sorted(os_listdir(currfolder)):
					if filename.lower().rsplit('.',1)[-1] in (PLAYABLEFORMATS):
						playableSongs.append(os_path.join(currfolder,filename))# playableSongs.append((Item(text=filename, filename=os_path.join(currfolder,filename)),))
						if selectedfilename == filename:
							foundIndex=index	
						index+=1

				if (foundIndex>=0):
					self.foundIndex=foundIndex
					self.playable_songs_count=len(playableSongs)
					scanPath.Start(playableSongs)
					self["waittext"].show()
					logger.info('MusicCenterFileList]okPressed]foundIndex:{} playable_songs_count:{}'.format(foundIndex, self.playable_songs_count))
					
				else:
					self.session.open(MessageBox, _("No music files found!"), type=MessageBox.TYPE_INFO,timeout=10 )
					self.clearThreadmessage()
				playableSongs=[]
			else:
				self["filelist"].changeSelectionState()
				logger.info('MusicCenterFileList]okPressed]selectedFiles:{}'.format(self.selectedFiles))

	def gotThreadMsg(self, msg):
		msg=scanPath.Message.pop()
		#logger.debug('FileList]gotThreadMsg]msg:{}'.format(msg))
		if msg[0] in ('THREAD_WORKING', 'THREAD_SCAN_FINISHED'):
			self.scaned_count +=1
			self.songListtmp.append((msg[1],))
			self["waittext"].setText('Process {}/{}'.format(self.scaned_count, self.playable_songs_count))

			if msg[0]=='THREAD_SCAN_FINISHED':
				self.scanFinished()

		elif msg[0]=='THREAD_FINISHED': # database updated
			self.clearThreadmessage()
			logger.debug('FileList]gotThreadMsg]THREAD_FINISHED database updated')

		elif msg[0]=='THREAD_EXCEPTED':
			t='Error read songlist->%s' %msg[1]
			logger.error('FileList]gotThreadMsg]THREAD_EXCEPTED set waittext->%s' %t)
			self["waittext"].setText(t)
			self.clearThreadmessage()
		else:
			self.scaned_count +=1
			t='Read %d/%s Error read file!!!' %(self.scaned_count, self.playable_songs_count)
			logger.error('FileList]gotThreadMsg]set waittext->%s' %t)
			self["waittext"].setText(t)

	def scanFinished(self):
		if not len(self.songListtmp):
			logger.error('FileList]scanFinished]No songs found!')
			self.session.open(MessageBox, _("No songs found!"), type=MessageBox.TYPE_ERROR, timeout=100 )
			return
	
		if self.player is not None:
			if self.player.hlp.get('currIndex')!=-2: #-2 is stopPlay
				self.player.stopPlay()
			logger.debug('MCFilelist]scanFinished]is player instance, delete now...')
			self.session.deleteDialog(self.player)
			self.player=None			
		try:
			if JCcheckModuleIsUpdated('Player'):
				reload(Player)
		except Exception, e:
			logger.exception('MCFilelist]scanFinished]exception')
			self.session.open(MessageBox, _("Error reload Player\n%s" %e), type=MessageBox.TYPE_ERROR, timeout=10 )
	
		logger.debug('MCFilelist]scanFinished]instantiate new player dialog')
		self.player=self.session.instantiateDialog(Player.Player, songList=self.songListtmp, index=self.foundIndex, playermode=FILEMODE, currentService=self.currentService, serviceList=self.serviceList)
		self.player.setShowHideAnimation("quick_fade")
		self.session.execDialog(self.player)
		self.songListtmp=[]
		logger.debug('MCFilelist]scanFinished]remove waittext now')
		self["waittext"].hide()

	def closePlayerNow(self):
		logger.info('MCFilelist]closePlayerNow]')
		self.player.closePlayer()
		self.session.deleteDialog(self.player)
		self.player=None

	def directoryUp(self):
		self.refreshSongList()
		self.updateLocationInfo()

	def up(self):
		self["filelist"].up()
		self.updateLocationInfo()

	def down(self):
		self["filelist"].down()
		self.updateLocationInfo()

	def left(self):
		self["filelist"].pageUp()
		self.updateLocationInfo()

	def right(self):
		self["filelist"].pageDown()
		self.updateLocationInfo()

	def listBookmarks(self):
		bookmarklist=[(_("Cancel"), "BACK")]
		bookmarklist.append((_('MyMusic/'), config.plugins.musiccenter.defaultfilebrowserpath.value))
		bookmarks=self.loadBookmarks()
		for bookmark in bookmarks:
			if bookmark.startswith(config.plugins.musiccenter.defaultfilebrowserpath.value):
				showedbookmark='MyMusic/' + bookmark[len(config.plugins.musiccenter.defaultfilebrowserpath.value):]
			else:
				showedbookmark=bookmark
			bookmarklist.append((_(showedbookmark), bookmark))
		bookmarklist.sort()
		dei=self.session.openWithCallback(self.goToSelectedBookmark, ChoiceBox, title=_("My Bookmarks"), list=bookmarklist,keys=MYKEYSORT,  titlebartext=_("MusicCenter"))
		dei.setTitle(_("MusicCenter"))

	def goToSelectedBookmark(self, bookmark):
		if bookmark is not None:
			bookmark=bookmark[1]
			logger.info('Filelist]goToSelectedBookmark] use bookmark:{}'.format(bookmark))
			try:
				if bookmark.startswith("/"):
					self["filelist"].changeDir(bookmark)
					self.updateLocationInfo()
			except Exception:
				logger.exception('Filelist]goToSelectedBookmark]changeDir:{}'.format(bookmark))
		else:
			logger.info('Filelist]goToSelectedBookmark]no bookmark was selected{}'.format(bookmark))

	def loadBookmarks(self):
		bookmarks=[]
		if fileExists(resolveFilename(SCOPE_CONFIG, 'mc_Bookmarks')):
			with open(resolveFilename(SCOPE_CONFIG, 'mc_Bookmarks'), 'r') as bookmarklist:
				for bookmark in bookmarklist:
					bookmark=bookmark.strip()
					if os_path.exists(bookmark):
						bookmarks.append(bookmark)
					else:
						logger.error('MusicCenterFileList]init]bookmark:{} not found, skip'.format(bookmark))
		return bookmarks

	def execDelete(self):
		if not(self["filelist"].canDescent()):
			todelfn=self["filelist"].getFilename()
			self.hlp['todelfn']=todelfn
			dei=self.session.openWithCallback(self.callbackDeleteFile, MessageBox,_("Do you realy want to DELETE:\n" + todelfn), MessageBox.TYPE_YESNO)
			dei.setTitle(_("MusicCenter - Delete File"))
		elif (self["filelist"].getSelectionIndex()!=0) and (self["filelist"].canDescent()):
			to_delete_directory=self["filelist"].getSelection()[0]
			dei=self.session.openWithCallback(boundFunction(self.callbackDeleteDir, to_delete_directory), MessageBox,_("Do you realy want to DELETE:\n" + to_delete_directory + '\n\nYou do it at your own risk!'), MessageBox.TYPE_YESNO)
			dei.setTitle(_("MusicCenter - Delete Folder"))
		self.refreshSongList()

	def callbackDeleteFile(self, answer):
		if answer is True:
			logger.info('Filelist]callbackDeleteFile]start...')
			mypath=self["filelist"].getCurrentDirectory()
			filename=self.hlp.get('todelfn')
			todelfile=os_path.join(mypath, filename)
			deferToThread(JCdeleteSongfileonThread, todelfile, -1).addCallback(self.finishedcallbackDeleteFileJob,).addErrback(self.errorJob, 'callbackDeleteFile')

	def finishedcallbackDeleteFileJob(self, result):
		logger.info('Filelist]finishedcallbackDeleteFileJob]refresh SongList')
		self.refreshSongList()

	def refreshSongList(self):
		fl=self["filelist"]
		index=fl.getSelectionIndex()
		logger.info('Filelist]refreshSongList]refresh songlist and move to index:{}'.format(index))
		fl.changeDir(fl.getCurrentDirectory())
		fl.moveToIndex(index)

	def errorJob(self, error, jobname=''):
		logger.error('Filelist]errorJob]job->%s error->%s' %(jobname, error))

	def callbackDeleteDir(self, to_delete_directory, answer):
		logger.info('Filelist]callbackDeleteDir]to_delete_directory:{}'.format(to_delete_directory))
		if answer is True:
			mypath=self["filelist"].getCurrentDirectory()
			#fullfolder=self.hlp.get('todelfolder')
			logger.info('Filelist]callbackDeleteDir]delete folder')
			try:
				sh_rmtree(to_delete_directory)
			except Exception, e:
				self.session.open(MessageBox,_("{}\n-->{}".format(to_delete_directory, e)), type=MessageBox.TYPE_ERROR, timeout=6)
				logger.exception('Filelist]callbackDeleteDir]->%s')
			logger.info('Filelist]callbackDeleteDir]folder deleted')
			if to_delete_directory.startswith(config.plugins.musiccenter.defaultfilebrowserpath.value):# folder is in musiclib
				to_delete_directory=to_delete_directory[len(config.plugins.musiccenter.defaultfilebrowserpath.value):]
			logger.info('Filelist]callbackDeleteDir]db open delete folder:%s' %(to_delete_directory +'%'))
			deferToThread(self.deleteFolderOnThread, to_delete_directory +'%').addErrback(self.errorJob, 'callbackDeleteDir')
			logger.info('Filelist]callbackDeleteDir]done')
			self.refreshSongList()

	def deleteFolderOnThread(self, foldername):
		logger.info('Filelist]deleteFolderOnThread]start')
		#execSQLCommand('''DELETE FROM Songs WHERE filename LIKE ?;''', (foldername,))
		sql='''DELETE FROM Songs WHERE filename LIKE ?;'''
		args=(foldername,)
		res=execSQLCommandWithReturn(sql, args)
		logger.info('Filelist]deleteFolderOnThread]done')
			
	def ExecRename(self):
		logger.info('Filelist]ExecRename]start')
		if not(self["filelist"].canDescent()):
			RENfilename=self["filelist"].getFilename()
			self.session.openWithCallback(self.callbackExecRename, vInputBox, title=_("old:  "+RENfilename), windowTitle=_("MusicCenter Rename file..."), text=RENfilename)
		elif (self["filelist"].getSelectionIndex()!=0) and (self["filelist"].canDescent()):
			RENDIR=self["filelist"].getSelection()[0]
			self.session.openWithCallback(self.callbackRenDir, vInputBox, title=_("old:  "+RENDIR), windowTitle=_("MusicCenter Rename directory..."), text=RENDIR)

	def callbackExecRename(self, answer):
		logger.info('Filelist]callbackExecRename]answer->%s' %str(answer))
		if answer is not None:
			mypath=self["filelist"].getCurrentDirectory()
			source=mypath + self["filelist"].getFilename()
			dest=mypath + answer
			try:
				os_rename(source, dest)
			except OSError:
				dei=self.session.open(MessageBox,_("Rename: %s \nFAILED with OSError!" %answer), MessageBox.TYPE_ERROR)
				dei.setTitle(_("MusicCenter"))
				return
			try:
				pathoffset=len(config.plugins.musiccenter.defaultfilebrowserpath.value)
				logger.info('Filelist]callbackExecRename]songlist has len...')
				musiclibbasepath=config.plugins.musiccenter.defaultfilebrowserpath.value
				if source.startswith(musiclibbasepath):
					sourceindb=source[pathoffset:]
					destindb=dest[pathoffset:]
					sql='''UPDATE Songs SET filename=? WHERE filename=?;'''
					args=(destindb, sourceindb)
					execSQLCommand(sql, args)

			except Exception, e:
				logger.exception('Filelist]callbackExecRename]error:%s' %e)
				dei=self.session.open(MessageBox,_("Rename: %s \nFAILED! \n%s" % (answer,e)), MessageBox.TYPE_ERROR)
				dei.setTitle(_("MusicCenter"))

			finally:
				self.refreshSongList()

	def callbackRenDir(self, answer):
		logger.info('Filelist]callbackRenDir]answer->%s' %str(answer))
		if answer is not None:
			source=self["filelist"].getSelection()[0]
			dest=answer
			try:
				os_rename(source, dest)
				self.refreshSongList()


			except OSError:
				logger.exception('Filelist]callbackExecRename]OSError')
				dei=self.session.open(MessageBox,_("Rename: %s \nFAILED!\nOSError" %answer), MessageBox.TYPE_ERROR)
				dei.setTitle(_("MusicCenter"))
				return

			try:
				pathoffset=len(config.plugins.musiccenter.defaultfilebrowserpath.value)
				logger.info('Filelist]callbackExecRename]songlist has len...')
				musiclibbasepath=config.plugins.musiccenter.defaultfilebrowserpath.value
				if source.startswith(musiclibbasepath) and dest.startswith(musiclibbasepath):
					logger.info('Filelist]callbackExecRename]source and dest in musikdb update directorys')
					sourceindb=source[pathoffset:]
					destindb=dest[pathoffset:]
					sql='''UPDATE Songs SET filename = replace( filename, ?, ? ) WHERE filename LIKE ?;'''
					args=(sourceindb, destindb, sourceindb+"%")
					execSQLCommand(sql, args)
				elif source.startswith(musiclibbasepath) and not dest.startswith(musiclibbasepath):
					logger.info('Filelist]callbackExecRename]only source in musikdb delete directory from musikdb')
					sourceindb=source[pathoffset:]
					sql='''DELETE from Songs WHERE filename LIKE ?;'''
					args=(sourceindb+"%",)
					execSQLCommand(sql, args)
				elif not source.startswith(musiclibbasepath) and dest.startswith(musiclibbasepath):
					logger.info('Filelist]callbackExecRename]only dest in musikdb, scan directory to musikdb')
					PathToDatabase.Start(dest)
				else:
					logger.info('Filelist]callbackExecRename]only dest or nothing in musikdb do nothing')

			except Exception, e:
				logger.exception('Filelist]callbackExecRename]error')
				dei=self.session.open(MessageBox,_("Rename: %s \nFAILED! \n%s" %(answer,e)), MessageBox.TYPE_ERROR)
				dei.setTitle(_("MusicCenter"))

			finally:
				self.refreshSongList()

	def callbackNewDir(self, answer):
		if answer is None:
			return
		dest=self["filelist"].getCurrentDirectory()
		if (answer==""):
			dei=self.session.open(MessageBox,_("Directory name error !"), MessageBox.TYPE_ERROR)
			dei.setTitle(_("MusicCenter"))
		else:
			order=dest + answer
			try:
				if not pathExists(dest + answer):
					createDir(order)
			except:
				dei=self.session.open(MessageBox,_("%s \nFAILED!" % order), MessageBox.TYPE_ERROR)
				dei.setTitle(_("MusicCenter"))
			self.refreshSongList()

	def go2CPmaniger(self):
		fl=self["filelist"]
		mypath=fl.getCurrentDirectory()
		filename=fl.getFilename()
		idx=fl.getSelectionIndex()
		if not(fl.canDescent()):#file
			source=fl.getCurrentDirectory() + filename
		elif (idx!=0) and (fl.canDescent()): #folder
			source=fl.getSelection()[0]
		else:
			message=_('Filelist]go2CPmaniger]no valid location')
			logger.error(message)
			self.session.toastManager.showToast(message, 5)
			return
		logger.info('Filelist]go2CPmaniger]CopyMoveManageropen ')
		self.session.openWithCallback(self.callbackCPmaniger, CopyMoveManager, source)

	def callbackCPmaniger(self):
		logger.info('Filelist]callbackCPmaniger]moveToIndex list')
		self.refreshSongList()

	def callbackSetStartDir(self, answerSD):
		if answerSD is True:
			config.plugins.musiccenter.defaultfilebrowserpath.value=self["filelist"].getSelection()[0]
			config.plugins.musiccenter.defaultfilebrowserpath.save()
			configfile.save()

	def sortName(self):
		self["filelist"].sortName()
		try:
			message=_("[sort by Name] {}".format(self["filelist"].getCurrentDirectory()))
		except:
			message=_("MusicCenter Filelist")
		self.session.toastManager.showToast(message, 5)

	def sortDate(self):
		self["filelist"].sortDate()
		try:
			message=_("[sort by Date] {}".format(self["filelist"].getCurrentDirectory()))
		except:
			message=_("MusicCenter Filelist")
		self.session.toastManager.showToast(message, 5)

	def infoPressed(self):
		devices=self.readMobiles()	
		infolist=[]
		if not(self["filelist"].canDescent()):
			self.hlp['to_sync_file']=os_path.join(self["filelist"].getSelection()[0], self["filelist"].getFilename())
			for dev in devices:
				infolist.append((_("Send selected song to {}".format(dev[0])), boundFunction(self.sendFileToMobile, dev)),)
		elif (self["filelist"].getSelectionIndex()!=0) and (self["filelist"].canDescent()):
			self.hlp['to_sync_directory']=self["filelist"].getSelection()[0]
			for dev in devices:
				infolist.append((_("Send selected Folder to {}".format(dev[0])), boundFunction(self.sendFolderToMobile, dev)),)
		self.session.openWithCallback(self.infoPressedCallback, ChoiceBox, title=_("Please select device for sync!"), list=infolist,keys=MYKEYSORT, titlebartext=_("MusicCenter mobile device sync actions"))

	def infoPressedCallback(self, ret):
		logger.debug('MusicCenterFileList]infoPressedCallback]ret:{}'.format(ret))
		ret and ret[1]()
# to mobile folder
	def sendFolderToMobile(self, dev):
		logger.debug('MusicCenterFileList]sendFolderToMobile]dev:{}'.format(dev))
		to_sync_directory=self.hlp.get('to_sync_directory')
		self.hlp['dev']=dev
		dei=self.session.openWithCallback(self.sendFolderToMobileCallback, MessageBox,_("Do you realy want send folder:\n" + to_sync_directory + '\n\nYou do it at your own risk!'), MessageBox.TYPE_YESNO)
		dei.setTitle(_("MusicCenter - Sync Console"))
		
	def sendFolderToMobileCallback(self, ret):
		if ret is True:
			logger.debug('MusicCenterFileList]sendFolderToMobileCallback]ret:{}'.format(ret))
			if fileExists('/usr/bin/rsync'):
				to_sync_directory=self.hlp.pop('to_sync_directory')
				dev=self.hlp.pop('dev')
				musiclibbasepath=config.plugins.musiccenter.defaultfilebrowserpath.value
				pathoffset=len(musiclibbasepath)
				if to_sync_directory.startswith(musiclibbasepath): # path is in musiclib
					relative_directory=to_sync_directory[pathoffset:]
					logger.debug('MusicCenterFileList]sendFolderToMobileCallback]musiclibbasepath:{}'.format(musiclibbasepath))
					passwort, srcfolder, ip, port, dstfolder=dev[1],to_sync_directory , dev[2], dev[3], os_path.join(dev[4], relative_directory)
					make_directorys_comand='''sshpass -p "{}" ssh -p {} {} "mkdir -p {}"'''.format(passwort, port, ip, dstfolder)
					rsync_comand='''sshpass -p "{}" rsync -e "ssh -p {}" -azsv --no-perms --no-times --size-only --delete-after --stats --human-readable --progress  --exclude 'unsynced' "{}" {}:"{}"'''.format(passwort, port, srcfolder, ip, dstfolder)
					logger.debug('MusicCenterFileList]sendFolderToMobileCallback]befehl:{}'.format(make_directorys_comand))
					logger.debug('MusicCenterFileList]sendFolderToMobileCallback]befehl:{}'.format(rsync_comand))
					self.session.openWithCallback(self.rsyncFinishd, Console, title='MusicCenter sync console', cmdlist = [make_directorys_comand, rsync_comand])
				else:
					self.session.open(MessageBox,_("To sync directory is not in musiclib, abort\n{}".format(to_sync_directory)), MessageBox.TYPE_ERROR)
			else:
				self.session.open(MessageBox,_("rsync binary not found, please install!\nAbort!"), MessageBox.TYPE_ERROR)
	
	def rsyncFinishd(self):
		logger.debug('MusicCenterFileList]rsyncFinishd]...')
# to mobile file	
	def sendFileToMobile(self, dev):
		logger.debug('MusicCenterFileList]sendFileToMobile]dev:{}'.format(dev))
		to_sync_file=self.hlp.get('to_sync_file')
		self.hlp['dev']=dev
		dei=self.session.openWithCallback(self.sendFileToMobileCallback, MessageBox,_("Do you realy want send file:\n" + to_sync_file + '\n\nYou do it at your own risk!'), MessageBox.TYPE_YESNO)
		dei.setTitle(_("MusicCenter - Sync Console"))

	def sendFileToMobileCallback(self, ret):
		if ret is True:
			logger.debug('MusicCenterFileList]sendFileToMobileCallback]ret:{}'.format(ret))
			if fileExists('/usr/bin/rsync'):
				to_sync_file=self.hlp.pop('to_sync_file')
				dev=self.hlp.pop('dev')
				logger.debug('MusicCenterFileList]sendFileToMobileCallback]to_sync_file:{}'.format(to_sync_file))
				relative_directory='unsynced'
				passwort, srcfolder, ip, port, dstfolder=dev[1],to_sync_file , dev[2], dev[3], os_path.join(dev[4], relative_directory)
				make_directorys_comand='''sshpass -p "{}" ssh -p {} {} "mkdir -p {}"'''.format(passwort, port, ip, dstfolder)
				rsync_comand='''sshpass -p "{}" rsync -e "ssh -p {}" -azsv --no-perms --no-times --stats --human-readable --progress "{}" {}:"{}"'''.format(passwort, port, srcfolder, ip, dstfolder)
				logger.debug('MusicCenterFileList]sendFileToMobileCallback]befehl:{}'.format(make_directorys_comand))
				logger.debug('MusicCenterFileList]sendFileToMobileCallback]befehl:{}'.format(rsync_comand))
				self.session.openWithCallback(self.rsyncFinishd, Console, title='MusicCenter sync console', cmdlist = [make_directorys_comand, rsync_comand]) # +' && '+rsync_comand]) # rsync_comand
			else:
				self.session.open(MessageBox,_("rsync binary not found, please install!\nAbort!"), MessageBox.TYPE_ERROR)
	
	def readMobiles(self):
		devices_list=[]
		if fileExists('/etc/enigma2/mc_mobiledevices'):
			with open('/etc/enigma2/mc_mobiledevices', "rb") as f:
				for line in f:
					if not line.startswith('#'):
						devices_list.append(line.strip().split(','))
		return devices_list

	def clearThreadmessage(self):
		logger.info('Filelist]clearThreadmessage]Start')
		self.scanPath_mc_conn=None

	def explExit(self):
		logger.info('Filelist]explExit]Start close, hlp len is %d' %len(self.hlp))
		if scanPath.isRunning:
			logger.info('FileList]__onClose]scanPath remove')
			scanPath.Cancel()
			self.clearThreadmessage()
		self.close(self.player) # isplayer)

	def videoPressed(self):
		options=[]
		options.append((_("Stop playing and append file to Songlist"), self.stopPlayingAndAppendFileToSongList),)
		options.append((_("Append file to Songlist"), self.appendFileToSongList),)
		options.append((_("Insert file in Songlist and play it after"), self.insertFileToSongList),)
		self.session.openWithCallback(self.videoPressed_callback, ChoiceBox, title=_("Songlist Modify Actions\n"), list=options,keys=MYKEYSORT, titlebartext=_("MusicCenter"))

	def videoPressed_callback(self, ret):
		ret and ret[1]()

	def audioPressed(self):
		if self.player is not None and self.player.songList:
			self.session.execDialog(self.player)

	def updateLastUsedDirectory(self):
		if config.plugins.musiccenter.rememberlastfilebrowserpath.value:
			tp=self["filelist"].getCurrentDirectory()
			logger.info('FileList]updateLastUsedDirectory]save lastusedpath:{}'.format(tp))
			config.plugins.musiccenter.lastusedpath.value=tp
			config.plugins.musiccenter.lastusedpath.save()
			configfile.save()
			
	def createSummary(self):
		return MC_LCDText

	def __onClose(self):
		logger.info('FileList]__onClose]start, close...')
		self.updateLastUsedDirectory()
		#self.__dbpool.close()
		logger.info('FileList]__onClose]done.')


class CopyMoveManager(Screen):

	skin="""
		<screen position="center,center" size="1000,550" title="Select Copy/Move location...">
		<widget name="File" font="SansReg;20" halign="center" position="5,0" size="890,100" transparent="1" valign="center" zPosition="4"/>
		<widget name="CPto" position="5,100" scrollbarMode="showOnDemand" size="890,312" zPosition="4"/>
		<eLabel backgroundColor="#555555" position="5,420" size="890,2" zPosition="5"/>
		<ePixmap alphatest="on" pixmap="~/red.png" position="0,425" size="35,25" zPosition="5"/>
		<ePixmap alphatest="on" pixmap="~/yellow.png" position="310,425" size="35,25" zPosition="5"/>
		<eLabel font="SansReg;18" halign="left" position="35,425" size="120,25" text="MOVE" transparent="1" valign="center" zPosition="6"/>
		<eLabel font="SansReg;18" halign="left" position="345,425" size="120,25" text="COPY" transparent="1" valign="center" zPosition="6"/>
	</screen>"""

	def __init__(self, session, source="/tmp/none", idx=0):
	
		self.session=session
		self.skin_path='/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images'
		
		Screen.__init__(self, session)
		
		self.src=source
		self["File"]=Label(_("WARNING! they doing now COPY or MOVE\n" + source + "\nto:"))
		self["CPto"]=MC_MultiFileSelectList([], config.plugins.musiccenter.copydestin.value, matchingPattern="^.*\.*")
		self["actions"]=ActionMap(["WizardActions", "ColorActions"],
		{
			"ok": self.okPressed,
			"back": self.NothingToDo,
			"red": self.startMoveJob,
			"yellow": self.startCopyJob
		}, -1)
		self.scanPath_mc_conn=None

	def OneDescent(self):
		if self["CPto"].canDescent():
			self["CPto"].descent()

	def okPressed(self):
		if self["CPto"].canDescent():
			self["CPto"].descent()

	def NothingToDo(self):
		self.close()

	def startCopyJob(self):
		if self["CPto"].getSelectionIndex()>0:
			destfolder=self["CPto"].getSelection()[0]
			if config.plugins.musiccenter.copydestin.value!=destfolder:
				config.plugins.musiccenter.copydestin.value=destfolder
				config.plugins.musiccenter.copydestin.save()
				configfile.save()

			if os_path.isfile(self.src):
				self.copyFile(self.src, destfolder)

			elif os_path.isdir(self.src):
				dest_new_subfolder=self.src.strip('/').rsplit('/',1)[-1]
				destfolder=os_path.join(destfolder, dest_new_subfolder)
				t=SimpleThread(lambda:self.copyFolder(self.src, destfolder))
				t.deferred.addCallback(self.copyFolderCallback, destfolder)
				t.deferred.addErrback(self.errorcopyFolder,)
				t.start()
				dei=self.session.open(MessageBox,_("Copy:%s\nTo:%s\It takes a longer time" %(self.src, destfolder)), MessageBox.TYPE_INFO)
				dei.setTitle(_("MusicCenter"))
			self.close()

	def copyFile(self, srcfile, destfolder):
		self.scanPath_mc_conn=scanPath.MessagePump.recv_msg.connect(self.gotThreadMsg)
		logger.info('CopyMoveManager]copyFile]->%s ->%s' %(srcfile, destfolder))
		sh_copy2(srcfile, destfolder)
		srcfolder, srcfilename=os_path.split(srcfile)
		logger.info('CopyMoveManager]copyFile]scan file now for database:{}'.format(os_path.join(destfolder, srcfilename)))
		# add file to database
		to_scan_song=[(Item(text=srcfilename, filename=os_path.join(destfolder, srcfilename)),)]
		scanPath.Start(to_scan_song)

	def gotThreadMsg(self, msg):
		msg=scanPath.Message.pop()
		logger.info('CopyMoveManager]gotThreadMsg]:{}'.format(msg))
		if msg[0]=='THREAD_FINISHED': # database updated
			self.scanPath_mc_conn=None
			logger.info('CopyMoveManager]gotThreadMsg]')
		elif msg[0]=='THREAD_EXCEPTED':
			logger.error('CopyMoveManager]gotThreadMsg]THREAD_EXCEPTED:{}'.format(msg[1]))
			self.scanPath_mc_conn=None
		else:
			logger.error('CopyMoveManager]gotThreadMsg]was ist das? :{}'.format(msg))

	def copyFolder(self, srcfolder, destfolder):
		logger.info('CopyMoveManager]copyFolder]->%s ->%s' %(srcfolder, destfolder))
		sh_copytree(srcfolder, destfolder)
		logger.info('CopyMoveManager]copyFolder]scan folder new ->%s' %destfolder)
		pathToDatabase.Start(destfolder)

	def copyFolderCallback(self, result, destfolder):
		# dst is in db
		if destfolder.startswith(config.plugins.musiccenter.defaultfilebrowserpath.value):
			logger.info('CopyMoveManager]copyFolder]scan destfolder-->%s' %destfolder)
			pathToDatabase.Start(destfolder)

	def errorcopyFolder(self, error):
		logger.error('CopyMoveManager]errorcopyFolder]->%s' %error)

	def startMoveJob(self):
		if self["CPto"].getSelectionIndex()!=0:
			destfolder=self["CPto"].getSelection()[0]
			if config.plugins.musiccenter.copydestin.value!=destfolder:
				config.plugins.musiccenter.copydestin.value=destfolder
				config.plugins.musiccenter.copydestin.save()
				configfile.save()
			if os_path.isfile(self.src):
				self.moveFile(self.src, destfolder)
			elif os_path.isdir(self.src):
				self.startMoveFolder(self.src,destfolder)
			self.close()

	def moveFile(self, srcfile, destfolder):
		logger.info('CopyMoveManager]moveFile]->%s ->%s' %(srcfile, destfolder))
		sh_move(srcfile, destfolder)

		srcfolder, srcfilename=os_path.split(srcfile)
		if srcfile.startswith(config.plugins.musiccenter.defaultfilebrowserpath.value):# file is in musiclib
			srcfnindb=srcfile[len(config.plugins.musiccenter.defaultfilebrowserpath.value):]
		else:
			srcfnindb=srcfile
		if destfolder.startswith(config.plugins.musiccenter.defaultfilebrowserpath.value):# file is in musiclib
			dstfolderindb=destfolder[len(config.plugins.musiccenter.defaultfilebrowserpath.value):]
		else:
			dstfolderindb=destfolder
		execSQLCommand('''UPDATE Songs SET filename=? WHERE filename=?;''', (dstfolderindb+srcfilename, srcfnindb))

	def startMoveFolder(self, srcfolder, destfolder):
		self.hlp['move_srcfolder']=srcfolder
		self.hlp['move_destfolder']=destfolder
		self.session.openWithCallback(self.moveFolder, MessageBox, _("Start move\n{} to\n{}?\drink a coffee and lets move...".format(srcfolder, destfolder)), MessageBox.TYPE_YESNO)
	
	def moveFolder(self, yes):
		if yes:
			srcfolder=self.hlp.pop('move_srcfolder')
			destfolder=self.hlp.pop('move_destfolder')
			logger.info('CopyMoveManager]moveFolder]start sourse:{} dest:{}'.format(srcfolder, destfolder))
			try:
				sh_move(srcfolder, destfolder)
			except Exception, e:
				logger.exception('CopyMoveManager]moveFolder]...?')
				self.session.open(MessageBox,_("Move failed\n{}".format(e)), MessageBox.TYPE_ERROR)
				return
				
			logger.info('CopyMoveManager]moveFolder]done')
			# src is in db and dst is in db
			if srcfolder.startswith(config.plugins.musiccenter.defaultfilebrowserpath.value) and destfolder.startswith(config.plugins.musiccenter.defaultfilebrowserpath.value):
				logger.info('CopyMoveManager]moveFolder]src is in db and dst is in db, update entrys now...')
				srcfolderdb=srcfolder[len(config.plugins.musiccenter.defaultfilebrowserpath.value):]
				destfolderdb=destfolder[len(config.plugins.musiccenter.defaultfilebrowserpath.value):]
				sql='''UPDATE Songs SET filename = replace( filename, ?, ? ) WHERE filename LIKE ?;'''
				args=(srcfolderdb, destfolderdb, srcfolderdb +'%')
				execSQLCommand(sql,args)
			# src is in db and dst is not in db
			elif srcfolder.startswith(config.plugins.musiccenter.defaultfilebrowserpath.value) and not destfolder.startswith(config.plugins.musiccenter.defaultfilebrowserpath.value):
				logger.info('CopyMoveManager]moveFolder]src is in db and dst is not in db, clean entry in db')
				srcfolderdb=srcfolder[len(config.plugins.musiccenter.defaultfilebrowserpath.value):]
				sql='''DELETE FROM Songs WHERE filename LIKE ?;'''
				args=(srcfolderdb +'%',)
				execSQLCommand(sql,args)

			# src is not in db and dst is in db
			elif not srcfolder.startswith(config.plugins.musiccenter.defaultfilebrowserpath.value) and destfolder.startswith(config.plugins.musiccenter.defaultfilebrowserpath.value):
				logger.info('CopyMoveManager]moveFolder]src is not in db and dst is in db, scan destfolder now:{}'.format(destfolder))
				pathToDatabase.Start(destfolder)
			logger.info('CopyMoveManager]moveFolder]db updates done...')


class SoftLinkScreen(Screen):

	skin="""
		<screen position="center,center" size="900,450" title="Make a softlink...">
		<widget name="File" font="SansReg;20" halign="center" position="5,0" size="890,100" transparent="1" valign="center" zPosition="4"/>
		<widget name="SLto" position="5,100" scrollbarMode="showOnDemand" size="890,312" zPosition="4"/>
		<eLabel backgroundColor="#555555" position="5,420" size="890,2" zPosition="5"/>
		<ePixmap alphatest="on" pixmap="~/red.png" position="0,425" size="35,25" zPosition="5"/>
		<ePixmap alphatest="on" pixmap="~/yellow.png" position="310,425" size="35,25" zPosition="5"/>
		<eLabel font="SansReg;18" halign="left" position="35,425" size="120,25" text="Set name" transparent="1" valign="center" zPosition="6"/>
		<eLabel font="SansReg;18" halign="left" position="345,425" size="220,25" text="Make a softlink" transparent="1" valign="center" zPosition="6"/>
	</screen>"""

	def __init__(self, session, source="/tmp/"):
		self.skin=SoftLinkScreen.skin
		Screen.__init__(self, session)
		self.session=session
		self.skin_path='/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images'
		self.src=source
		self.newSLname=" "
		self["File"]=Label("Set first the Softlink name ...")
		self["SLto"]=FileList([], '/', matchingPattern=None)
		self["actions"]=ActionMap(["WizardActions", "ColorActions"],
		{
			"ok": self.okPressed,
			"back": self.NothingToDo,
			"red": self.GetSLname,
			"yellow": self.MakeSLnow
		}, -1)

	def GetSLname(self):
		self.session.openWithCallback(self.callbackSetLinkName, vInputBox, title=_("Write the new softlink name here:"), windowTitle=_("MusicCenter"), text="newname")

	def callbackSetLinkName(self, answer):
		if answer is None:
			return
		if (" " in answer) or (answer==""):
			dei=self.session.open(MessageBox,_("Softlink name error !"), MessageBox.TYPE_ERROR)
			dei.setTitle(_("MusicCenter"))
			return
		else:
			self.newSLname=self.src + answer
			self["File"].setText(_("WARNING! they make now a softlink from\n" + self.newSLname + "\nto:"))

	def okPressed(self):
		if self["SLto"].canDescent():
			self["SLto"].descent()

	def NothingToDo(self):
		self.close(" ")

	def MakeSLnow(self):
		if self.newSLname!=" ":
			if self["SLto"].getSelectionIndex()!=0:
				if self["SLto"].canDescent():
					os_symlink(self["SLto"].getSelection()[0], self.newSLname)
				else:
					os_symlink((self["SLto"].getCurrentDirectory() + self["SLto"].getFilename()), self.newSLname)
				self.close(" ")
		else:
			dei=self.session.open(MessageBox,_("Softlink name error !"), MessageBox.TYPE_ERROR)
			dei.setTitle(_("MusicCenter"))

'''
atime: dieser Zeitstempel spiegelt den letzten Zugriff (lesend und schreibend) auf die Datei wieder
mtime: wann wurde das letzte mal in die Datei geschrieben. Wird also gesetzt wenn die Datei erstellt wird und jedes mal neu wenn sich am Inhalt der Datei was aendert
ctime: etwas missverstaendlich ChangeTime (nicht CreateTime!). Dieser Zeitstempel aendert sich wenn der Inhalt der Datei geaendert wird (also genau wie bei mtime), aber auch wenn sich an den Metadaten der Datei (Zugriffsrechte, Besitzer, ..) aendernFilelist]errorSimpleThread]
/usr/bin/jpg2mvi_dream.sh /Breesen/Steffen-Home/MusicCenterCache/musiccenter_artistpics/A/Abba/7065.jpg
'''
