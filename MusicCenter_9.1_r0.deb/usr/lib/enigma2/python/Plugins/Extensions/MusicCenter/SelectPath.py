# -*- coding: UTF-8 -*-

#  Music Center E2
#
#  Coded by bobo71 (c) 2014
#  Support: www.dreambox-tools.info
#
#  All Files of this Software are licensed under the Creative Commons
#  Attribution-NonCommercial-ShareAlike 3.0 Unported
#  License if not stated otherwise in a Files Head. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.

#  Additionally, this plugin may only be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.

#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially
#  distributed other than under the conditions noted above.
#  This applies to the source code as a whole as well as to parts of it, unless
#  explicitely stated otherwise.

from Screens.Screen import Screen
from Components.FileList import FileList
from Components.Label import Label
from Components.ActionMap import ActionMap
from Components.Sources.StaticText import StaticText
from JobCenter import *

class SelectPath(Screen):

	if RESOLUTIONx>1800:

		skin = """<screen name="SelectPath" position="center,center" size="760,420" title="Select path">
				<ePixmap pixmap="skin_default/buttons/red.png" position="0,0" zPosition="0" size="140,40" transparent="1" alphatest="on" />
				<ePixmap pixmap="skin_default/buttons/green.png" position="140,0" zPosition="0" size="140,40" transparent="1" alphatest="on" />
				<ePixmap pixmap="skin_default/buttons/yellow.png" position="280,0" zPosition="0" size="140,40" transparent="1" alphatest="on" />
				<ePixmap pixmap="skin_default/buttons/blue.png" position="420,0" zPosition="0" size="140,40" transparent="1" alphatest="on" />
				<widget name="target" position="0,58" size="640,24" valign="center" font="SansReg;22" />
				<widget name="filelist" position="0,100" zPosition="1" size="660,320" scrollbarMode="showOnDemand"/>
				<widget render="Label" source="key_red" position="0,0" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="SansReg;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_green" position="140,0" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="SansReg;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget render="Label" source="key_yellow" position="280,0" size="140,40" zPosition="5" valign="center" halign="center" backgroundColor="red" font="SansReg;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
			</screen>"""

	else:
		skin = """<screen name="SelectPath" position="center,center" size="506,280" title="Select path">
			<ePixmap pixmap="skin_default/buttons/red.png"    position=  "0,0" zPosition="0" size="93,26" transparent="1" alphatest="on" />
			<ePixmap pixmap="skin_default/buttons/green.png"  position= "93,0" zPosition="0" size="93,26" transparent="1" alphatest="on" />
			<ePixmap pixmap="skin_default/buttons/yellow.png" position="186,0" zPosition="0" size="93,26" transparent="1" alphatest="on" />
			<ePixmap pixmap="skin_default/buttons/blue.png"   position="280,0" zPosition="0" size="93,26" transparent="1" alphatest="on" />
			<widget name="target" position="0,38" size="426,16" valign="center" font="SansReg;14" />
			<widget name="filelist"                    position= "0,66" size="440,213" zPosition="1" scrollbarMode="showOnDemand"/>
			<widget render="Label" source="key_red"    position=  "0,0" size= "93, 26" zPosition="5" valign="center" halign="center" backgroundColor="red" font="SansReg;14" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
			<widget render="Label" source="key_green"  position= "93,0" size= "93, 26" zPosition="5" valign="center" halign="center" backgroundColor="red" font="SansReg;14" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
			<widget render="Label" source="key_yellow" position="186,0" size= "93, 26" zPosition="5" valign="center" halign="center" backgroundColor="red" font="SansReg;14" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
			</screen>"""


	def __init__(self, session, initDir, mediaPattern = '', showFiles = False):

		Screen.__init__(self, session)

		inhibitDirs = ["/bin", "/boot", "/dev", "/etc", "/lib", "/proc", "/sbin", "/sys", "/usr", "/var"]
		inhibitMounts = []
		self["filelist"] = FileList(initDir, matchingPattern = mediaPattern, inhibitMounts = inhibitMounts, inhibitDirs = inhibitDirs, showFiles = showFiles)
		self["target"] = Label()
		self["actions"] = ActionMap(["WizardActions", "DirectionActions", "ColorActions", "EPGSelectActions"],
		{
			"back": self.cancel,
			"left": self.left,
			"right": self.right,
			"up": self.up,
			"down": self.down,
			"ok": self.ok,
			"green": self.green,
			"red": self.cancel,
			"yellow": self.yellow,
		}, -1)
		self["key_red"] = StaticText(_("Cancel"))
		self["key_green"] = StaticText(_("Select"))
		self["key_yellow"] = StaticText(_("Create New Folder"))
		self.updateTarget()
		
	def cancel(self):
		self.close(None)

	def green(self):
		self.close([self["filelist"].getSelection()[0],self["filelist"].getCurrentDirectory()])

	def yellow(self):
		self.session.openWithCallback(self.callbackNewDir, vInputBox, title=_(self["filelist"].getCurrentDirectory()), windowTitle=_("MusicCenter Create new folder in..."), text="name")

	def callbackNewDir(self, answer):
		if answer is None:
			return
		dest=self["filelist"].getCurrentDirectory()
		if (answer==""): #(" " in answer) or (" " in dest) or 
			dei=self.session.open(MessageBox,_("Directory name error !"), MessageBox.TYPE_ERROR)
			dei.setTitle(_("MusicCenter"))
			return
		else:
			order=dest + answer
			try:
				if not pathExists(dest + answer):
					createDir(order)
			except:
				dei=self.session.open(MessageBox,_("%s \nFAILED!" % order), MessageBox.TYPE_ERROR)
				dei.setTitle(_("MusicCenter"))
			self["filelist"].refreshwithIndex(0)
	
	def up(self):
		self["filelist"].up()
		self.updateTarget()

	def down(self):
		self["filelist"].down()
		self.updateTarget()

	def left(self):
		self["filelist"].pageUp()
		self.updateTarget()

	def right(self):
		self["filelist"].pageDown()
		self.updateTarget()

	def ok(self):
		if self["filelist"].canDescent():
			self["filelist"].descent()
			self.updateTarget()

	def updateTarget(self):
		currfolder = self["filelist"].getSelection()[0]
		if currfolder is not None:
			self["target"].setText(currfolder)
		else:
			self["target"].setText(_("Invalid Location"))
			