# -*- coding: UTF-8 -*-

#  Music Center E2
#
#  Coded by bobo71 (c) 2014
#  Support: www.dreambox-tools.info
#
#  All Files of this Software are licensed under the Creative Commons
#  Attribution-NonCommercial-ShareAlike 3.0 Unported
#  License if not stated otherwise in a Files Head. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.

#  Additionally, this plugin may only be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.

#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially
#  distributed other than under the conditions noted above.
#  This applies to the source code as a whole as well as to parts of it, unless
#  explicitely stated otherwise.



from Globals import *
import SelectPath
from myLogger import logger, setLogLevel


class MusicCenterSetup(Screen, ConfigListScreen):

	if RESOLUTIONx>1800:
		skin='''<screen name="MusicCenterSetup" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#00000000" zPosition="0">
			<!-- Header -->
				<eLabel backgroundColor="#191919" position="20,20" size="1900,100" zPosition="1" />
				<widget name="headertext" position="140,39" size="1760,42" font="SansReg;35" foregroundColor="#ffffff" backgroundColor="#191919" halign="center" valign="center" zPosition="3" />
			<!-- Buttons -->
				<eLabel position="20,135" size="1900,40" backgroundColor="#191919" zPosition="1" />
				<!-- red -->
					<widget render="Label" font="SansReg;34" position="100,135" size="450,40" source="key_red" foregroundColor="#ff0000" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
				<!-- green -->
					<widget render="Label" font="SansReg;34" position="510,135" size="450,40" source="key_green" foregroundColor="#00ff21" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
			<widget name="config" position="35,190" size="1850,750" backgroundColor="#00000000" scrollbarMode="showOnDemand" />
			<widget source="help" render="Label" position="35,950" size="1850,110" font="SansReg;33" />
		</screen>'''

	else:
		skin='''<screen name="MusicCenterSetup" position="0,0" size="1280,720" flags="wfNoBorder" backgroundColor="#00000000" zPosition="0">
			<!-- Header -->
				<eLabel backgroundColor="#191919" position="13,13" size="1266,66" zPosition="1" />
				<widget name="headertext" position="93,26" size="1173,28" font="SansReg;23" foregroundColor="#ffffff" backgroundColor="#191919" halign="center" valign="center" zPosition="3" />
			<!-- Buttons -->
				<eLabel position="13,90" size="1266,33" backgroundColor="#191919" zPosition="1" />
				<!-- red -->
					<widget render="Label" font="SansReg;25" position="66,92" size="300,28" source="key_red" foregroundColor="#ff0000" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
				<!-- green -->
					<widget render="Label" font="SansReg;25" position="340,92" size="300,28" source="key_green" foregroundColor="#00ff21" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
			<widget name="config" position="24,126" size="1230,500" backgroundColor="#00000000" scrollbarMode="showOnDemand" />
			<widget source="help" render="Label" position="24,630" size="1850,110" font="SansReg;22" />
		</screen>'''

			
	def __init__(self, session):
	
		logger.info('MusicCenterSetup]__init__')
		Screen.__init__(self, session)
		
		self["key_red"] = StaticText(_("Cancel"))
		self["key_green"] = StaticText(_("OK"))
		self["help"] = StaticText()
		self['headertext']=Label('MusicCenter Setup')
		
		self.list = [ ]
		self.list.append(getConfigListEntry(_("-------- General configuration --------"), config.plugins.musiccenter.fake,_("Start General Configuration")))
		self.databasepath = getConfigListEntry(_("Select path for database file"), config.plugins.musiccenter.databasepath, _("Select folder for storage database. Fast device is good!"))
		self.list.append(self.databasepath)
		self.googleimage = getConfigListEntry(_("Select path for downloadcache"), config.plugins.musiccenter.downloadcache, _("Select folder for store downloaded content. Please use usb or hdd path with more then 2Gb free space!"))
		self.list.append(self.googleimage)
		self.list.append(getConfigListEntry(_("Show MusicCenter in mainmenu"), config.plugins.musiccenter.musiccentermainmenu, _("Show MusicCenter in Mainmenu")))
		self.list.append(getConfigListEntry(_("Show MusicCenter in extended-pluginlist"), config.plugins.musiccenter.musiccenterextendedpluginlist, _("Show MusicCenter in extended pluginlist")))
		self.list.append(getConfigListEntry(_("Time to start Screensaver"), config.plugins.musiccenter.screensaverstarttime, _("Time to start Screensaver, 0 disable screensaver")))
		self.list.append(getConfigListEntry(_("Activate debug log"),config.plugins.musiccenter.setdebug, _("Select the loglevel. High level will slow down the performace")))
		self.list.append(getConfigListEntry(_("-------- Filemode & Databasemode configuration --------"), config.plugins.musiccenter.fake,_("Start Filemode Configuration")))
		self.list.append(getConfigListEntry(_("Prozent of playing the song to increase playcounter"), config.plugins.musiccenter.playcountertriggerprozent, _("Prozent value to increase the playcounter in database and Songfile. Set to 0 to deactivate")))
		self.list.append(getConfigListEntry(_("Time of playing the song to increase playcounter"), config.plugins.musiccenter.playcountertriggertime, _("Time value to increase the playcounter in database and Songfile. Set to 0 to deactivate")))
		self.defaultFileBrowserPath = getConfigListEntry(_("Musiclibrary startup path"), config.plugins.musiccenter.defaultfilebrowserpath, _("This path is the root directory for your musiclibrary. All files under this dir will by added to database. If saving last browserpath not set, start on this path, and this path is showed under bookmarks as first entry"))
		self.list.append(self.defaultFileBrowserPath)
		self.list.append(getConfigListEntry(_("Embed downloaded covers in songfile"), config.plugins.musiccenter.addcoverautotosong, _("This option embed cover on songfile if cover was found on www.google.com")))
		self.list.append(getConfigListEntry(_("Artistart in Background"), config.plugins.musiccenter.useartistart, _("This option search for artistpictures on Theaudiodb and Fanart, and show them in bachground")))
		#self.list.append(getConfigListEntry(_("Artistart piccount"), config.plugins.musiccenter.artistartpicsmaxcount, _("Maximum count of pictures to download for any Artist")))
		self.list.append(getConfigListEntry(_("Remember last path of filebrowser"), config.plugins.musiccenter.rememberlastfilebrowserpath, _("Save last used filebrowserpath, and show after reopen")))
		self.list.append(getConfigListEntry(_("Activate filedelete function"), config.plugins.musiccenter.filedeletefunction, _("This option activate the global file deletefunction")))
		
		self.list.append(getConfigListEntry(_("-------- Internetradio configuration --------"), config.plugins.musiccenter.fake,_("Start Internetradio Configuration")))
		self.list.append(getConfigListEntry(_("Spectrum Analyzer"),config.plugins.musiccenter.visualization, _("Select the Style of Spectrum Analyzer")))
		self.list.append(getConfigListEntry(_("Set min MP3 streaming bitrate:"), config.plugins.musiccenter.minmp3streamingrate, _("Set the minimum bitrate for showing MP3 streaming stations")))
		self.list.append(getConfigListEntry(_("Set min AAC streaming bitrate:"), config.plugins.musiccenter.minaacstreamingrate, _("Set the minimum bitrate for showing AAC streaming stations")))
		self.list.append(getConfigListEntry(_("Set min WMA streaming bitrate:"), config.plugins.musiccenter.minwmastreamingrate, _("Set the minimum bitrate for showing WMA streaming stations")))
		
		self.list.append(getConfigListEntry(_("-------- Streamripper configuration --------"), config.plugins.musiccenter.fake,_("Start Streamripper Configuration")))
		self.defaultIRDirname = getConfigListEntry(_("Path to save song files"), config.plugins.musiccenter.streamripper_base_directory, _("Rootfolder for storing downloaded songs"))
		self.list.append(self.defaultIRDirname)
		self.list.append(getConfigListEntry(_("Add tracknumbers to song files:"), config.plugins.musiccenter.streamripper_addsequencenumber_on_outputfile, _("NO --> don`t add tracknumber\nCounter -->0000\nDate and >counter-->mmdd-000")))
		self.list.append(getConfigListEntry(_("Check ripped songs for dublicates:"), config.plugins.musiccenter.streamripper_check_for_dublicates, _("Ripped songs will by checked for dublicate. If dublicate found, song was moved or deleted. Select it on next entry!")))
		self.list.append(getConfigListEntry(_("Save dublicate songs?"), config.plugins.musiccenter.streamripper_save_dublicates, _("Selcect here if you want hold dublicate songs!")))		
		self.list.append(getConfigListEntry(_("Use different useragent for streamripper"), config.plugins.musiccenter.use_different_streamripper_useragent_for_rip,  _("If streamripper is blocked on radiostation, then set this option to get running ripping")))
		self.list.append(getConfigListEntry(_("Useragent"), config.plugins.musiccenter.different_streamripper_useragent,  _("Set different useragent here")))	
		#self.list.append(getConfigListEntry(_("-------- Soundcloud Configuration --------"), config.plugins.musiccenter.fake,_("Start Soundcloud Configuration")))
		#self.list.append(getConfigListEntry(_("Set picture refresh time:"), config.plugins.musiccenter.picrefreshtime, _("Set the time after avatars/covers will be reloaded form Soundcloud")))
		
		ConfigListScreen.__init__(self, self.list, session)
		
		self["setupActions"] = ActionMap(["SetupActions", "ColorActions"],
		{
			"green": self.keySave,
			"cancel": self.keyClose,
			"ok": self.keySelect,
		}, -2)


		def selectionChanged():
			self["config"].current = self["config"].getCurrent()
			if self["config"].current:
				self["config"].current[1].onDeselect(self.session)		
				self["config"].current[1].onSelect(self.session)
				
			for x in self["config"].onSelectionChanged:
				x()
		self["config"].selectionChanged = selectionChanged
		self["config"].onSelectionChanged.append(self.updateHelp)

	def keySelect(self):
		cur = self["config"].getCurrent()
		if cur == self.googleimage:
			self.session.openWithCallback(self.pathSelectedGoogleImage, SelectPath.SelectPath, config.plugins.musiccenter.downloadcache.value)
		elif cur == self.databasepath:
			self.session.openWithCallback(self.pathSelectedDatabasepath, SelectPath.SelectPath, config.plugins.musiccenter.databasepath.value)
		elif cur == self.defaultFileBrowserPath:
			self.session.openWithCallback(self.pathSelectedFilebrowser, SelectPath.SelectPath, config.plugins.musiccenter.defaultfilebrowserpath.value)
		elif cur == self.defaultIRDirname:
			self.session.openWithCallback(self.pathSelectedIR_Dirname, SelectPath.SelectPath, config.plugins.musiccenter.streamripper_base_directory.value)
			
	def pathSelectedGoogleImage(self, res):
		if res is not None:
			config.plugins.musiccenter.downloadcache.value = res[0]

	def pathSelectedDatabasepath(self, res):
		if res is not None:
			config.plugins.musiccenter.databasepath.value = res[0]
			
	def pathSelectedFilebrowser(self, res):
		if res is not None:
			config.plugins.musiccenter.defaultfilebrowserpath.value = res[0]

	def pathSelectedIR_Dirname(self, res):
		if res is not None:
			config.plugins.musiccenter.streamripper_base_directory.value = res[0]

	def keySave(self):
		setLogLevel(logger)
		for x in self["config"].list:
			x[1].save()
		configfile.save()
		self.close(True)

	def keyClose(self):
		for x in self["config"].list:
			x[1].cancel()
		self.close(False)

	def updateHelp(self):
		cur = self["config"].getCurrent()
		if cur:
			self["help"].text = cur[2]

