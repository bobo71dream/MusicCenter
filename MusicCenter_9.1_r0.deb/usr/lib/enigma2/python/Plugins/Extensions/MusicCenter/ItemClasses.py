# -*- coding: UTF-8 -*-

#  Music Center E2
#
#  Coded by bobo71 (c) 2014
#  Support: www.dreambox-tools.info
#
#  All Files of this Software are licensed under the Creative Commons
#  Attribution-NonCommercial-ShareAlike 3.0 Unported
#  License if not stated otherwise in a Files Head. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.

#  Additionally, this plugin may only be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.

#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially
#  distributed other than under the conditions noted above.
#  This applies to the source code as a whole as well as to parts of it, unless
#  explicitely stated otherwise.

from skin import parseColor # , parsePosition
from datetime import timedelta as datetime_timedelta
from myLogger import logger
from Components.config import config
from glob import glob as glob_glob
from os import path as os_path
from random import randrange
from Tools.LoadPixmap import LoadPixmap
from Tools.Directories import fileExists

def myenCode(value):
	returnValue='n/a'
	if value is not None:
		try:
			returnValue=value.encode("utf-8", 'ignore')
		except UnicodeDecodeError:
			try:
				returnValue=value.encode("iso8859-1", 'ignore')
			except UnicodeDecodeError:
				try:
					returnValue=value.decode("cp1252").encode("utf-8")
				except UnicodeDecodeError:
					try:
						returnValue=value.decode("utf-16").encode("utf-8")#, "replace")
					except UnicodeDecodeError:
						pass
	return returnValue


def convertLength(length):
	if isinstance(length, float):
		return myenCode(str(datetime_timedelta(seconds=int(length))))
	elif isinstance(length, str) and length!= 'n/a':
		return myenCode(str(datetime_timedelta(seconds=int(eval(length)))))
	else:
		return length

		
def convertBitrate(bitrate):
	if isinstance(bitrate, int):
		return "%skbit" %str(round(bitrate/1000.0))[:-2]
	else:
		return "%skbit" %str(bitrate)

		
def buildCoverthumbFilename(fn):
	if fn.startswith(config.plugins.musiccenter.defaultfilebrowserpath.value):
		fnlib='.' + fn[len(config.plugins.musiccenter.defaultfilebrowserpath.value):].rsplit('.',1)[0].replace('/','_')
	else:
		fnlib=fn.rsplit('.',1)[0][1:].replace('/','_')
	CACHEDIR=os_path.join(config.plugins.musiccenter.downloadcache.value, "cache/" )
	return '{}{}'.format(CACHEDIR, fnlib)

	
def fitName(name): #Fit artistname
	return name.lower().split('feat',1)[0].split(' ft',1)[0].replace('_','').replace('/','').replace("'",'').strip().title()


def shortFoldername(filename):
	path, filename=os_path.split(filename)
	dirs=[''.join((f[:6], '..', f[-3:]))  if len(f)> 10 else f for f in path.split('/') ]
	return '/'.join(dirs+[filename])


class Item:

	__slots__=('text', 'mode', 'id', 'artistID', 'albumID', 'title', 'artist', 'filename', 'bitrate', 'length', 'genre', 'track', 'date', 'album', 'playlistID', 'genreID', ' dateID', 'songID', 'join', 'audio', 'albumartist', 'tracknr', 'filetype', 'cover', 'votes', 'playcount', 'rating', 'streamID', 'stationname', 'streamurl', 'location', 'codec', 'stationicon', 'artistpic', 'wave', 'coverfn')
	'''
	filetype-> 'MP3','FLAC', 'OGG' ,'RADIOBROWSER','RADIODE'
	'''
	def __init__(self, text='n/a', mode=0, id=-1, artistID=0, albumID=0, title='n/a', artist='n/a', filename='n/a', bitrate='0', length='n/a', genre='n/a', track='n/a', date='n/a', album='n/a', playlistID=0, genreID=0,  dateID=0, songID=-1, join=True, audio=False, albumartist='n/a', tracknr='n/a', filetype="", cover=0, votes=0, playcount=0, rating=11, streamID='' ,stationname='n/a', streamurl='n/a', location='n/a', codec='', stationicon='', artistpic='', wave=0, coverfn=None):
		
		self.text=text
		self.mode=mode
		self.id=id
		self.artistID=artistID
		self.albumID=albumID
		self.title=title
		self.artist=artist
		self.filename=filename
		self.length=convertLength(length)
		self.genre=genre
		self.tracknr=tracknr
		self.track=track
		self.date=date
		self.album=album
		self.playlistID=playlistID
		self.genreID=genreID
		self.dateID=dateID
		self.songID=songID
		self.audio=audio
		self.albumartist=albumartist
		self.filetype=filetype
		self.votes=votes
		self.playcount=playcount
		self.rating=rating
		self.streamID=streamID# for streams
		self.stationname=stationname
		self.streamurl=streamurl
		if location is not None:
			self.location=location
		else:
			self.location='n/a'
		self.codec=codec
		self.stationicon=stationicon
		self.artistpic=startArtistart(artist)
		self.wave=wave
		
		selcolor = parseColor("#ffffff").argb()# white
		
		if filetype not in ('RADIOBROWSER','RADIODE'):
			# cover
			if coverfn==None:
				coverfn=buildCoverthumbFilename(filename)	
			self.bitrate=convertBitrate(bitrate)
			if audio:
				color = parseColor("#C6C6C6").argb()#fast weiß
			else:
				color = parseColor("#636363").argb()#grau
			# path
			if config.plugins.musiccenter.defaultfilebrowserpath.value in filename:
				mypath = shortFoldername('MyMusik/' + filename[len(config.plugins.musiccenter.defaultfilebrowserpath.value):])
			else:
				mypath = shortFoldername(filename)
			self.slhelper=('{} - {}'.format(artist, title), '{} [{}]'.format(album, date), mypath, color, selcolor)
		else:
			self.slhelper=('{} - {}'.format(artist, title), '{} [{}]'.format(album, date), '', '', selcolor)
			self.bitrate=str(bitrate)+'kbit'
			
		self.coverfn=coverfn
		self.cover=cover			


def startArtistart(artist):
		if artist and artist!='n/a': # artist vorhanden
			bd_artist=fitName(myenCode(artist))
			artistdirforart=buildArtistArtDir(bd_artist)
			return getLocalArtistPic(artistdirforart)
		else: # kein artist vorhanden
			return ''

			
def buildArtistArtDir(bd_artist):
	artistpicsroot=os_path.join(config.plugins.musiccenter.downloadcache.value, "artistpics/" )
	return os_path.join(artistpicsroot, bd_artist[:1] + '/', bd_artist + '/')
	
	
def getLocalArtistPic( artistfolder):
	f=glob_glob(artistfolder + '*.jpg')
	#logger.info('Item]getLocalArtistPic->%s' %f)
	if f:
		return f[randrange(len(f))]
	else:
		#logger.info('itemClasses]Artistbackdrop]getLocalArtistPic]no local artistpic')
		return ''

		
class MethodArguments:
	def __init__(self, method=None, arguments=None):
		self.method=method
		self.arguments=arguments

		
class CacheItem:
	def __init__(self, cache=True, mode=999, index=0, listview=[], headertext="", methodarguments=None, buttons=('', '', '', ''), hlp={}):
		self.cache=cache
		self.mode=mode
		self.index=index
		self.listview=listview
		self.headertext=headertext
		self.methodarguments=methodarguments
		self.buttons=buttons
		self.hlp=hlp

		
class PicDownloadItem:

	__slots__=('url', 'filename',' stationname', 'name', 'error', 'index')

	def __init__(self, url="", filename="", stationname='', name='Unknown', error=False, index=-1):
		self.url=url.replace('https://','http://')
		self.filename=filename
		self.stationname=stationname
		self.name=name
		self.error=error
		self.index=index
