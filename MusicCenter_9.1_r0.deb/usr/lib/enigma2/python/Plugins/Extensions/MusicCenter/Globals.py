#	-*-	coding:	utf-8	-*-

#  Music Center E2
#
#  Coded by bobo71 (c) 2014
#  Support: www.dreambox-tools.info
#
#  All Files of this Software are licensed under the Creative Commons
#  Attribution-NonCommercial-ShareAlike 3.0 Unported
#  License if not stated otherwise in a Files Head. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.

#  Additionally, this plugin may only be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.

#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially
#  distributed other than under the conditions noted above.
#  This applies to the source code as a whole as well as to parts of it, unless
#  explicitely stated otherwise.


# version...
MC_VERSION='9.1-r0 10.12.2017'

# global variables
from Components.AVSwitch import AVSwitch
from Components.ActionMap import ActionMap, NumberActionMap
from Components.config import config, ConfigSubsection, ConfigDirectory, ConfigYesNo, ConfigInteger, getConfigListEntry, ConfigLocations, configfile, ConfigText, ConfigSelection, NoSave, ConfigNumber, choicesList, ConfigElement
from Components.ConditionalWidget import BlinkingWidget
from Components.ConfigList import ConfigListScreen, ConfigList
from Components.CoverCollection import VideoDBPictureBox, CoverCollection
from Components.FileList import MultiFileSelectList as BaseMultiFileSelectList, FileList
from Components.GUIComponent import GUIComponent
from Components.Harddisk import harddiskmanager
from Components.HTMLComponent import HTMLComponent
from Components.Input import Input
from Components.Label import Label, BlinkingLabel# as BaseLabel
from Components.Label import BlinkingLabelConditional, MultiColorLabel
from Components.MenuList import MenuList
from Components.Pixmap import Pixmap, MultiPixmap
from Components.ScrollLabel import ScrollLabel
from Components.ServicePosition import ServicePositionGauge as baseServicePositionGauge, ServicePosition
from Components.ServiceEventTracker import ServiceEventTracker, InfoBarBase
from Components.Sources.StaticText import StaticText
from Components.Sources.List import List
from Components.SystemInfo import SystemInfo
from Components.VariableText import VariableText
from Components.VideoWindow import VideoWindow
from Components.Task import Task, Job, job_manager

from enigma import RT_VALIGN_CENTER, RT_HALIGN_LEFT, RT_HALIGN_RIGHT, RT_HALIGN_CENTER, RT_VALIGN_TOP, RT_WRAP, getDesktop, gFont, eListbox, ePoint, eListboxPythonMultiContent, loadJPG, loadPNG, getBestPlayableServiceReference 
from enigma import eEPGCache, eServiceCenter, eServiceReference, eTimer, ePicLoad, gPixmapPtr, ePythonMessagePump, eRect, gRGB, eSize
from enigma import iPlayableService, iServiceInformation, eConsoleAppContainer, eBackgroundFileEraser

from Screens.ChoiceBox import ChoiceBox
from Screens.EpgSelection import EPGSelection
from Screens.EventView import EventViewEPGSelect
from Screens.InfoBarGenerics import InfoBarSeek, InfoBarNotifications, NumberZap
from Screens.InputBox import InputBox
from Screens.MessageBox import MessageBox
from Screens.Screen import Screen
from Screens.VirtualKeyBoard import VirtualKeyBoard

from Plugins.SystemPlugins.Toolkit.SimpleThread import SimpleThread

from ServiceReference import ServiceReference
from skin import parseColor # , parsePosition

from timer import TimerEntry

from Tools.BoundFunction import boundFunction
from Tools.Downloader import HTTPProgressDownloader, downloadWithProgress
from Tools.Directories import fileExists, pathExists, SCOPE_CONFIG, SCOPE_PLUGINS, SCOPE_HDD, resolveFilename, createDir, removeDir
from Tools.HardwareInfo import HardwareInfo
from Tools.LoadPixmap import LoadPixmap
from Tools.Notifications import AddPopup, RemovePopup
from Tools.NumericalTextInput import NumericalTextInput

from base64 import b64decode as base64_b64decode, standard_b64encode as base64_standard_b64encode, b64encode as base64_b64encode, decodestring as base64_decodestring

from copy import deepcopy as copy_deepcopy, copy as copy_copy
import cPickle as pickle
from cStringIO import StringIO

from datetime import timedelta as datetime_timedelta, datetime as datetime_datetime, date as datetime_date, time as datetime_time

from fcntl import ioctl as fcntl_ioctl
import fileinput

import gc
from glob import glob as glob_glob

from httplib import HTTPConnection as httplib_HTTPConnection

from json import dumps as json_dumps, loads as json_loads, load as json_load, dump as json_dump

from mechanize import Browser as mechanize_Browser
from mutagen.asf import ASFUnicodeAttribute
from mutagen.asf import ASF
from mutagen.flac import FLAC, Picture
from mutagen.mp3 import MP3
from mutagen.id3 import ID3, APIC, PCNT, POPM, Frames as id3_Frames
from mutagen.easyid3 import EasyID3
from mutagen.easymp4 import EasyMP4
from mutagen.oggvorbis import OggVorbis

from os import path as os_path, listdir as os_listdir, stat as os_stat, popen as os_popen, walk as os_walk, system as os_system, rename as os_rename, symlink as os_symlink, remove as os_remove, error as os_error
from os import access as os_access, W_OK as os_W_OK, utime as os_utime

from PIL import Image, ImageDraw, ImageFont, ImageStat

from random import shuffle, randrange
from re import sub as re_sub, compile as re_compile, IGNORECASE as re_IGNORECASE, DOTALL as re_DOTALL, findall as re_findall, S as re_S, escape as re_escape, split as re_split
from requests import get as requests_get, codes as requests_codes

from shutil import copy as sh_copy2, move as sh_move,  rmtree as sh_rmtree, copyfileobj as sh_copyfileobj, copytree as sh_copytree
import socket
from sqlite3 import dbapi2 as sqlite, Row as sqlite3_Row
import string
from struct import pack as struct_pack
from subprocess import call as sp_call, Popen as sp_Popen, check_output as sp_check_output, PIPE as sp_PIPE
from sys import getsizeof as sys_getsizeof 

from threading import Thread
from time import time as time_time, strftime as time_strftime, localtime as time_localtime, sleep as time_sleep, gmtime as time_gmtime, ctime as time_ctime
from timer import TimerEntry
from twisted.enterprise import adbapi
from twisted.internet import defer
from twisted.internet.threads import deferToThread
from twisted.web import client
from twisted.web.client import HTTPClientFactory, getPage, downloadPage
from twisted.python import failure

from urllib import quote, urlencode, unquote
from urllib2 import URLError, Request, build_opener, HTTPError, urlopen

from xml.etree.cElementTree import fromstring as ET_fromstring, parse as ET_parse
from xml.dom.minidom import parseString

from ThreadQueue import ThreadQueue

from urlparse import urlparse as urlparse_urlparse

from myLogger import logger

BOXTYPE = HardwareInfo().get_device_name()

Numberhelper=False

MCUSERAGNET='Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36'

def mcgetPage(url, *args, **kwargs):
	if 'agent' not in kwargs:
		kwargs['agent'] =MCUSERAGNET
	return getPage(url.replace('https:','http:'), *args, **kwargs)


def mcdownloadPage(url, *args, **kwargs):	
	if 'agent' not in kwargs:
		kwargs['agent'] =MCUSERAGNET
	if 'timeout' not in kwargs:
		kwargs['timeout']=4
	return downloadPage(url.replace('https:','http:'), *args, **kwargs)


def rb_getPage(urlpart, *args, **kwargs):
	# getpage with RadioBrowser agent!
	#getPage(url, method='POST', postdata="hello, world, or whatever.")
	url='http://www.radio-browser.info/webservice/%s' %urlpart
	# RadioBrowser agent!
	kwargs['agent']='enigma2 MusicCenter/RadioBrowser'
	kwargs['timeout']=5
	return getPage(url, *args, **kwargs)


def rb_post(url=None,payload={}):
	#url='http://www.radio-browser.info/webservice/json/stations/search', payload = {'name': 'Ostseewelle', 'country': 'Germany'}
	headers = {'User-Agent':'enigma2 MusicCenter/RadioBrowser'}
	if url is not None:
		result=requests.post(url, headers=headers, data=payload)
		return result.content
	return []


def calcRating(rating, tobyte=False):
	#0-bomb.....254-10(5 stars)->280-11-<not set
	#[int(round(i/10.0*255)) for i in [0,  1,  2,  3,	4,	 5,	  6,   7,	8,	 9,	 10,  11]]
	#								  [0, 26, 51, 77, 102, 128, 153, 179, 204, 230, 255, 281]

	if not tobyte:
		newrating=int(round(rating*10.0/255))
	else:
		newrating=int(round(rating/10.0*255))
	logger.debug('calcRating]rating->%d newrating->%d'%(rating, newrating))
	return newrating


'''	
class Label(BaseLabel):
	
	#parse text to labels
	
	def __init__(self, text=""):
		BaseLabel.__init__(self, text=text)
			
	def setParsedText(self, text):#
		lentext=len(text)
		if lentext > 3:
			origtext=text
			self.setText(text)
			labelheigth=int(self.instance.size().height()*1.2)
			shorted=False
			#logger.info('setParsedText]->%s getSize->%d labelheigth->%d' %(text, self.getSize()[1], labelheigth))
			while self.getSize()[1] > labelheigth*1.2:
				shorted=True
				text=self.getText()
				text=text[:-1]
				self.setText(text)
				#logger.info('setParsedText]->%s' %text)
				
			if shorted:
				if len(text)==0:
					Elogger.info('setParsedText]error shorting, set origtext->%s' %origtext)
					self.setText(origtext)
				else:
					text=self.getText()
					text=text[:-3]+'...'
					self.setText(text)			
			#logger.info('setParsedText]->%s getSize->%d labelheigth->%d' %(text, self.getSize()[1], int(self.instance.size().height()*1.2)))
		else:
			#logger.info('setParsedText]text less 4 chars, not short!->%s' %text)
			self.setText(text)
			

class BlinkingLabel(Label, BlinkingWidget):
	#parse text to labels..
	def __init__(self, text = ""):
		Label.__init__(self, text = text)
		BlinkingWidget.__init__(self)

'''
		
#global WAVETHREADID
WAVETHREADID='nn'


PLAYABLEFORMATS=('mp3','ogg','flac','wav','wma')#,'mp4')

MYKEYSORT=["red", "green", "yellow", "blue", "0",  "1", "2", "3", "4", "5", "6", "7", "8", "9", "text"]
	
# reload modules check
FILESSIZE=dict([ (f.rsplit('.')[0], os_path.getsize('/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/'+f)) for f in os_listdir('/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/') if f.lower().endswith('.py') ])

# last search streams
LAST_STREAM_SEARCH=''

SCSEARCHHIST=resolveFilename(SCOPE_CONFIG, 'mc_SoundcloudSearchhist')
	
TWISTED_TIMEOUT=5

MAINSCREEN=0
FILEBROWSERSCREEN=1
PLAYERSCREEN=2

#Playermodes
FILEMODE=0
SOUNDCLOUDMODE=2
DBMODE=3
RADIODE=5
RADIOBROWSER=6

#Soundcloudmodes
ROOT=500
SEARCH=501
MYLIKEDTRACKLIST=510
MYLIKEDPLAYLIST=515
USERLIKEDTRACKLIST=522
USERLIKEDPLAYLIST=523
USERPLAYLIST=524
USERFOLLOWINGSLIST=525
USERFOLLOWERLIST=526
MYSETS=540
MYLIKEDPLAYLISTTRACKLIST=516
MYFOLLOWINGSLIST=520
MYFOLLOWERSLIST=530
SEARCHHISTORY=550
FOLLOWINGUSERTRACKLIST=560
STARTPLAYER=599
SELECTUSERACTION=521
MYCOMMENTLIST=580
MYCOMMENTLISTAFTER=581
LEARNSC=582


RESOLUTIONx = getDesktop(0).size().width()
