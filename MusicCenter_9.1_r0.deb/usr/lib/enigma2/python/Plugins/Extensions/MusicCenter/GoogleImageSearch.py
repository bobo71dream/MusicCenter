# -*- coding: UTF-8 -*-

#  Music Center E2
#
#  Coded by bobo71 (c) 2014
#  Support: www.dreambox-tools.info
#
#  All Files of this Software are licensed under the Creative Commons
#  Attribution-NonCommercial-ShareAlike 3.0 Unported
#  License if not stated otherwise in a Files Head. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.

#  Additionally, this plugin may only be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.

#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially
#  distributed other than under the conditions noted above.
#  This applies to the source code as a whole as well as to parts of it, unless
#  explicitely stated otherwise.

from Globals import *

from ItemClasses import PicDownloadItem
from myLogger import logger
from JobCenter import *

def downloadobsolete(item):	
	return downloadPage(item.url.replace('https:','http:'), item.filename, agent='Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.56 Safari/537.17')

def googleentry(entry, ptr, size, zoomfactor):
	x,y=size
	res = [entry]
	res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 15, 0, x, y, ptr))
	x=int((x+30)*zoomfactor)
	res.append((eListboxPythonMultiContent.TYPE_TEXT, x,  int(5*zoomfactor), int((1000-x)*zoomfactor), int(30*zoomfactor), 0, RT_HALIGN_CENTER|RT_VALIGN_CENTER, entry.url)) # url
	res.append((eListboxPythonMultiContent.TYPE_TEXT, x,  int(35*zoomfactor), int((1000-x)*zoomfactor), int(30*zoomfactor), 1, RT_HALIGN_CENTER|RT_VALIGN_CENTER, entry.filename))
	res.append((eListboxPythonMultiContent.TYPE_TEXT, x,  int(65*zoomfactor), int((1000-x)*zoomfactor), int(30*zoomfactor), 1, RT_HALIGN_CENTER|RT_VALIGN_CENTER, entry.name)) # resolution
	return res


class GoogleImageSearchScreen(Screen):

	if RESOLUTIONx>1800:
		skin = """
			<screen name="GoogleImageSearchScreen"  position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#00000000" zPosition="0">
			<!-- Header -->
				<eLabel backgroundColor="#191919" position="20,20" size="1880,100" zPosition="1" /> 
				<widget name="headertext" position="140,39" size="1760,42" font="SansReg;35" foregroundColor="#ffffff" backgroundColor="#191919" halign="center" valign="center" zPosition="3" />
				<ePixmap position="20,20" size="100,100" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/google_200x200.png" scale="1" zPosition="2"/>
			<!-- Buttons -->
				<eLabel position="20,135" size="1880,40" backgroundColor="#191919" zPosition="1" /> 
				<widget render="Label" font="SansReg;34" position="100,138" size="450,40" source="key_red" foregroundColor="#ff0000" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
				<widget render="Label" font="SansReg;34" position="510,138" size="450,40" source="key_green" foregroundColor="#00ff21" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
				<widget render="Label" font="SansReg;34" position="960,138" size="450,40" source="key_yellow" foregroundColor="#FFD800" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
				<widget render="Label" font="SansReg;34" position="1410,138" size="450,40" source="key_blue" foregroundColor="#3D8DFF" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>	
			<!-- lists -->
				<widget name="imagelist" position="75,195" zPosition="1" size="1800,855" scrollbarMode="showOnDemand" backgroundColor="#00000000"/>
			</screen>"""
	else:
		skin = """
			<screen name="GoogleImageSearchScreen"  position="0,0" size="1280,720" flags="wfNoBorder" backgroundColor="#00000000" zPosition="0">
			<!-- Header -->
				<eLabel backgroundColor="#191919" position="13,13" size="1253,67" zPosition="1" /> 
				<widget name="headertext" position="96,26" size="1173,28" font="SansReg;25" foregroundColor="#ffffff" backgroundColor="#191919" halign="center" valign="center" zPosition="3" />
				<ePixmap position="13,13" size="67,67" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/google_200x200.png" scale="1" zPosition="2"/>
			<!-- Buttons -->
				<eLabel position="13,90" size="1253,27" backgroundColor="#191919" zPosition="1" /> 
				<widget render="Label" font="SansReg;22" position="67,96" size="300,27" source="key_red" foregroundColor="#ff0000" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
				<widget render="Label" font="SansReg;22" position="340,96" size="300,27" source="key_green" foregroundColor="#00ff21" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
				<widget render="Label" font="SansReg;22" position="640,96" size="300,27" source="key_yellow" foregroundColor="#FFD800" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
				<widget render="Label" font="SansReg;22" position="940,956" size="300,27" source="key_blue" foregroundColor="#3D8DFF" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>	
			<!-- lists -->
				<widget name="imagelist" position="50,130" zPosition="1" size="1200,570" scrollbarMode="showOnDemand" backgroundColor="#00000000"/>
			</screen>"""
		
	def __init__(self, session, currenPlayingSongfFilename='', picname='', searchterm='', sizeX=-1, sizeY=-1, face=False):

		logger.info('GoogleImageSearchScreen]__init__')
		self.session = session
		self.skin_path='/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images'
		Screen.__init__(self, session)

		self['headertext'] = Label()
		self["key_red"] = StaticText(_("Back"))
		self["key_green"] = StaticText(_("Add selected pic"))
		self["key_yellow"] = StaticText(_("Edit Serachstring"))
		self["key_blue"] = StaticText(_("Exclude Youtube results"))
		self["actions"]  = ActionMap(["OkCancelActions", "WizardActions", "ColorActions", "SetupActions", "MenuActions", "EPGSelectActions"], {
			"cancel": self.keyCancel,
			"red": self.keyCancel,
			"green" : self.keyOK,
			"yellow" : self.keyEditSearchTerm,
			"blue" : self.toggleYoutuberesults,
			}, -1)
		
		self.imagelist = []
		self.chooseMenuList = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
		if RESOLUTIONx>1800:
			zoomfactor=1.5
		else:
			zoomfactor=1
		self.zoomfactor=zoomfactor
		self.chooseMenuList.l.setFont(0, gFont("SansReg", int(26*zoomfactor)))
		self.chooseMenuList.l.setFont(1, gFont("SansReg", int(22*zoomfactor)))
		itemhigth=100*zoomfactor
		self.chooseMenuList.l.setItemHeight(int(itemhigth))
		self['imagelist'] = self.chooseMenuList
		self.currenPlayingSongfFilename = currenPlayingSongfFilename
		self.picname=picname
		self.searchterm = searchterm
		self.sizeX=sizeX
		self.sizeY=sizeY
		self.face=face
		self.possibleimageurls=[]
		self.withyt=True
		self.imagedlurls=[]
		yptr=float(itemhigth)
		factor=sizeY/yptr
		xptr=sizeY/factor
		size=xptr,yptr
		self.picloader=PicLoaderScale(int(xptr*zoomfactor), int(yptr*zoomfactor), transparent=False, cached=False, name='Googleimage')
		self.size=size
		self.onLayoutFinish.append(self.startRun)

	def startRun(self):
		logger.debug('GoogleImageSearchScreen]startRun]searchterm->%s' %self.searchterm)			
		if self.searchterm !='':
			self.buildImageSearchUrl(self.searchterm)
			self['headertext'].setText("Google search start->%s" %self.searchterm)
		else:
			self['headertext'].setText("Google image search no valid album,artist,title given, do nothing")
			logger.debug('GoogleImageSearchScreen]startRun]no valid album,artist,title given, do nothing')

	def keyEditSearchTerm(self):
		self.session.openWithCallback(self.keyEditSearchTermCallback, vInputBox, title=_("old:  "+self.searchterm), windowTitle=_('MusicCenter Edit Searchstring'), text=self.searchterm)
		
	def keyEditSearchTermCallback(self, answer):
		logger.debug('GoogleImageSearchScreen]keyEditSearchTermCallback]answer->%s' %str(answer))
		if answer is not None:
			self['imagelist'].setList([])
			self.imagelist = []
			self.imagedlurls=[]
			self.searchterm=answer
			self.startRun()
		
	def keyOK(self):
		logger.debug('GoogleImageSearchScreen]keyOK]')
		picfilename=self['imagelist'].getCurrent()[0].filename
		self.picloader=None
		if os_path.isdir(self.picname):
			logger.debug('GoogleImageSearchScreen]keyOK]rename picfilename from dir to file')
			destfilename=os_path.join(self.picname, os_path.basename(picfilename))
		else:
			destfilename=self.picname
		logger.debug('GoogleImageSearchScreen]keyOK]sh_copy2picfilename:{} to destfilename:{}'.format(picfilename, destfilename))
		sh_copy2(picfilename, destfilename)
		self.close([self.currenPlayingSongfFilename, destfilename, None])

	def errorDownloadCover(self, error):
		logger.error('GoogleImageSearchScreen]errorDownloadCover]->%s' %error)
		self.keyCancel()
	
	def keyCancel(self):
		self.picloader=None
		self.close([None, None, 'No image found'])
		
	def buildImageSearchUrl(self, searchterm):

		if self.sizeX==-1 and self.sizeY==-1:
			if self.face:
				url='https://www.google.de/search?q=%s&tbs=isz:ex,itp:face&tbm=isch' %(quote(searchterm))
			else:
				url='https://www.google.de/search?q=%s&tbs=isz:ex&tbm=isch' %(quote(searchterm))			
		else:
			if self.face:
				url='https://www.google.de/search?q=%s&tbs=isz:ex,iszw:%d,iszh:%d,itp:face&tbm=isch' %(quote(searchterm),self.sizeX,self.sizeY)
			else:
				url='https://www.google.de/search?q=%s&tbs=isz:ex,iszw:%d,iszh:%d&tbm=isch' %(quote(searchterm), self.sizeX, self.sizeY)
		logger.info('GoogleImageSearchScreen]buildImageSearchUrl]url->%s' %url)
		getPage(url, timeout=TWISTED_TIMEOUT, agent='Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.56 Safari/537.17').addCallback(self.getImageUrlsGoogleImageSiteSearch,).addErrback(self.errorfetch, 'getpageEntry')
		
	def getImageUrlsGoogleImageSiteSearch(self, result):
		logger.debug('GoogleImageSearchScreen]getImageUrlsGoogleImageSiteSearch]result->%s' %result[:100])
		imageurls=re_findall(',"ou":"(.+?)","ow"',result) # new on 08.02.2017 urlsraw=re_findall('imgres\?imgurl.+?&amp;imgrefurl',result)
		if imageurls:
			logger.debug('GoogleImageSearchScreen]getImageUrlsGoogleImageSiteSearch]->%s' %imageurls[:5])
			self.possibleimageurls=imageurls
			self['headertext'].setText(_('Images found, please wait... download images...'))
			if len(imageurls) < 20:
				self.downloadImages(imageurls[:len(imageurls)])
			else:
				self.downloadImages(imageurls[:20])
		else:
			logger.warn('GoogleImageSearchScreen]getImageUrlsGoogleImageSiteSearch]->No images found..., show no cover')	
			self['headertext'].setText("No images found on Google.")
	
	def downloadImages(self, imageurls):
		dllist=[]
		for imageurl in imageurls:
			filename=imageurl[8:].split('/',1)[-1].replace('/','_')
			local_filename = '/tmp/mc/%s' %filename
			imageentry=PicDownloadItem(url = imageurl, filename=local_filename)
			self.imagedlurls.append(imageentry)
			if not fileExists(local_filename):
				logger.debug('GoogleImageSearchScreen]DownloadImages]add to dllist imageurl->%s local_filename->%s' %(imageurl, local_filename))
				dllist.append(imageentry)
		
		ds = defer.DeferredSemaphore(tokens=5)
		imagescount=len(dllist)
		downloads = [ ds.run(mcdownloadPage,item.url, item.filename).addCallback(self.finishedPicDownload, imagescount) for item in dllist ]
		finished = defer.DeferredList(downloads).addCallback(self.finishedAllPicDownloads).addErrback(self.errorAllPicDownloads)			
		self.dlcount=0
		
	def errorfetch(self, error, jobname):
		logger.error('GoogleImageSearchScreen]errorfetch]%s -> %s' %(jobname, error))
		self['headertext'].setText('error->%s ->%s' %(jobname, error))

	def finishedPicDownload(self, result, imagescount):
		self.dlcount+=1
		self['headertext'].setText(_('Images found, please wait... download images %d/%d' %(self.dlcount, imagescount)))
		
	def finishedAllPicDownloads(self, result):
		logger.debug('GoogleImageSearchScreen]finishedAllPicDownloads]')
		for entry in self.imagedlurls:
			try:
				im=Image.open(entry.filename)
				self.imagelist.append(googleentry(entry, self.picloader.load(filename=entry.filename), self.size, self.zoomfactor))
			except IOError:
				pass
		self['imagelist'].setList(self.imagelist)
		lenimagelist=len(self.imagelist)
		if lenimagelist:
			self['headertext'].setText("%d images->%s" %(lenimagelist, self.searchterm))
		else:
			self['headertext'].setText("No images found, press yellow key for edit search!")
	
	def errorAllPicDownloads(self, error):
		logger.error('GoogleImageSearchScreen]errorAllPicDownloads]error %s' %(error.getErrorMessage()))
		self['headertext'].setText("No images found for %s" %self.searchterm)

	def toggleYoutuberesults(self):
		logger.debug('GoogleImageSearchScreen]toggleYoutuberesults]reset image list')
		self.imagelist=[]
		self.imagedlurls=[]
		if self.withyt:
			logger.debug('GoogleImageSearchScreen]toggleYoutuberesults]exclude yt results')
			imageurls=[ url for url in self.possibleimageurls if 'ytimg.com' not in url]
			self.withyt=False
			self["key_blue"].setText(_("Include Youtube results"))
			self.downloadImages(imageurls[:20])
		else:
			logger.debug('GoogleImageSearchScreen]toggleYoutuberesults]include yt results')
			self["key_blue"].setText(_("Exclude Youtube results"))
			self.withyt=True
			self.downloadImages(self.possibleimageurls[:20])	
	