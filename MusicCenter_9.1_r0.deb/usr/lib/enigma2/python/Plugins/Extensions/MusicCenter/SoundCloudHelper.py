# -*- coding: UTF-8 -*-

#  Music Center E2
#
#  Coded by bobo71 (c) 2014
#  Support: www.dreambox-tools.info
#
#  All Files of this Software are licensed under the Creative Commons
#  Attribution-NonCommercial-ShareAlike 3.0 Unported
#  License if not stated otherwise in a Files Head. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.

#  Additionally, this plugin may only be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.

#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially
#  distributed other than under the conditions noted above.
#  This applies to the source code as a whole as well as to parts of it, unless
#  explicitely stated otherwise.

from Globals import *
from myLogger import logger
from soundcloud.resource import Resource as soundcloud_Resource


def resolveArtistartwork(fullitem, resolvecover=True):
	cover_url=None
	if resolvecover and fullitem.artwork_url!=None and len(fullitem.artwork_url):
		cover_url=fullitem.artwork_url
	elif fullitem.avatar_url!=None and len(fullitem.avatar_url):
		cover_url=fullitem.avatar_url
	elif soundcloud_Resource(fullitem.user).avatar_url!=None and len(soundcloud_Resource(fullitem.user).avatar_url):
		cover_url=soundcloud_Resource(fullitem.user).avatar_url
	if cover_url!=None:
		cover_url, artwork_fn=splitSoundcloudCoverurl(cover_url)
	else:
		cover_url='~/sc_default-t500x500.jpg'
	logger.info('resolveArtistartwork]thumburl-->%s tumbfn-->%s'%(cover_url ,artwork_fn))
	return cover_url, artwork_fn


def download(item):
	return downloadPage(item.url, file(item.filename, 'wb'))


def splitSoundcloudCoverurl(url, size='large'):
	'''
	t500x500: 500�500
	crop: 400�400
	t300x300: 300�300
	large: 100�100 (default)
	t67x67: 67�67 (only on artworks)
	badge: 47�47
	small: 32�32
	tiny: 20�20 (on artworks)
	tiny: 18�18 (on avatars)
	mini: 16�16
	'''
	picdir='/tmp/mc/'
	picurl=url.replace('https://','http://').replace('large',size).encode()
	picfn=''.join((picdir, picurl.rsplit('/',1)[1].rsplit('?',1)[0]))

	return picurl, picfn


class SCItem:

	__slots__=('text', 'fullitem',' thumb', 'cache_it', 'mode', 'islike','iscomment', 'isfollower', 'isfollowing', 'type', 'isplaylist_trackcount', 'reposted_by', 'track', 'artistpic', 'url')

	def __init__(self, text='', fullitem=None, thumb='', cache_it=False, mode=0, islike=False, iscomment=False, isfollower=False, isfollowing=False, type='track', isplaylist_trackcount=0, 
		reposted_by='', track='', artistpic='', url=''):
		self.cache_it=cache_it
		self.mode=mode
		self.text=text
		if fullitem is None:
			return
		if fullitem.title is not None:
			self.title=fullitem.title.encode("utf-8", 'ignore')
		else:
			logger.error('SCItem]title is empty-->%s' %text)
			self.title='-'

		try:
			if fullitem.user[u'username'] is not None:
					self.artist=fullitem.user[u'username'].encode("utf-8", 'ignore')
			else:
				self.artist= ''
				logger.error('SCItem]artist is empty-->%s' %text)
		except:
			self.artist= ''
			logger.error('SCItem]artist is empty-->%s' %text)

		try:
			if fullitem.duration is not None:
				self.length=str(datetime_timedelta(0, fullitem.duration/1000))
			else:
				logger.error('SCItem]artist is empty-->%s' %text)
				self.length=''
		except:
			logger.error('SCItem]artist is empty-->%s' %text)
			self.length=''

		self.streamurl=fullitem.stream_url.encode("utf-8", 'ignore')
		if not self.streamurl:
			logger.error('SCItem]no standard streamurl found, try now uri')
			self.streamurl=''.join((fullitem.uri.encode("utf-8", 'ignore'),  '/stream'))
			
		if fullitem.downloadable and fullitem.download_url is not None:
			self.downloadurl=fullitem.download_url.encode("utf-8", 'ignore')
		else:
			self.downloadurl=''
		self.downloadable=fullitem.downloadable

		if thumb is not None:
			self.thumb=thumb
		else:
			self.thumb=''
		
		if fullitem.playback_count == '':
			self.playback_count='0'
		else:
			self.playback_count=str(fullitem.playback_count)
			
		if fullitem.comment_count == '':
			self.comment_count='0'
		else:
			self.comment_count=str(fullitem.comment_count)
		
		if isplaylist_trackcount: # is playlist
			self.likes_count=str(fullitem.likes_count) # set fav count
		else: # is tracklist
			if fullitem.likes_count=='':
				if fullitem.favoritings_count=='':
					self.likes_count='0'
				else:
					self.likes_count=str(fullitem.favoritings_count) #old api
			else:
				self.likes_count=str(fullitem.likes_count)# new api
				
		if fullitem.genre is not None:
			self.genre=fullitem.genre.encode("utf-8", 'ignore')
		else:
			self.genre=''

		self.fullitem=fullitem

		try:
			if fullitem.created_at is not None:
				self.date=fullitem.created_at.split()[0].encode("utf-8", 'ignore')
			else:
				self.date=''
		except:
			self.date=''
			
		if fullitem.video_url is not None:
			self.video_url=fullitem.video_url
		else:
			self.video_url=''
			
		self.islike=islike
		self.iscomment=iscomment
		self.isfollower=isfollower
		self.isfollowing=isfollowing
		self.type=type
		self.isplaylist_trackcount=isplaylist_trackcount
		self.reposted_by=reposted_by
		self.track=track
		artisturl=fullitem.user[u'avatar_url'].encode()
		if artisturl:
			artisturl=artisturl.replace('large','t500x500')
			self.artistpic=''.join(('/tmp/mc/', artisturl.rsplit('/',1)[1].rsplit('?',1)[0]))
		self.url=url

		
class SCAllItem:

	__slots__=('text', 'fullitem', 'thumb', 'cache_it', 'mode', 'iscomment', 'isfollower', 'isfollowing')
	 
	def __init__(self, text='', fullitem=None, thumb='', cache_it=False, mode=0, iscomment=False, isfollower=False, isfollowing=False):
		self.text=text
		self.fullitem=fullitem
		self.thumb=thumb
		self.cache_it=cache_it
		self.mode=mode
		self.iscomment=iscomment
		self.isfollower=isfollower
		self.isfollowing=isfollowing


class SCPlaylistItem:

	__slots__=('text', 'fullitem', 'thumb', 'cache_it', 'mode', 'islike', 'iscomment')
	
	def __init__(self, text='', fullitem=None, thumb='', cache_it=False, mode=0, islike=False, iscomment=False):
		self.cache_it=cache_it
		self.mode=mode
		self.text=text
		if fullitem is None:
			return
		if fullitem[u'title'] is not None:
			self.title=fullitem['title'].encode("utf-8", 'ignore')
		else:
			self.title=''

		if fullitem[u'user'][u'username'] is not None:
			self.artist= ''.join(('by ' + fullitem[u'user'][u'username'].encode("utf-8", 'ignore')))
		else:
			self.artist= ''

		if fullitem[u'duration'] is not None:
			self.length=str(datetime_timedelta(0, fullitem[u'duration']/1000))
		else:
			self.length=''

		self.streamurl=fullitem[u'stream_url'].encode("utf-8", 'ignore')

		if fullitem[u'downloadable'] and fullitem[u'download_url'] is not None:
			self.downloadurl=fullitem[u'download_url'].encode("utf-8", 'ignore')
		else:
			self.downloadurl=''
		self.downloadable=fullitem[u'downloadable']

		if thumb is not None:
			self.thumb=thumb
		else:
			self.thumb=''
		
		if fullitem[u'playback_count'] == '':
			self.playback_count='0'
		else:
			self.playback_count=str(fullitem[u'playback_count'])
			
		if fullitem[u'comment_count'] == '':
			self.comment_count='0'
		else:
			self.comment_count=str(fullitem[u'comment_count'])
			
		if fullitem[u'likes_count'] == '':
			self.likes_count='0'
		else:
			self.likes_count=str(fullitem[u'likes_count'])

		if fullitem[u'genre'] is not None:
			self.genre=fullitem[u'genre'].encode("utf-8", 'ignore')
		else:
			self.genre=''

		self.fullitem=fullitem

		if fullitem[u'created_at'] is not None:
			self.date=fullitem[u'created_at'].split()[0].encode("utf-8", 'ignore')
		else:
			self.date=''
		
		if fullitem[u'video_url'] is not None:
			logger.error('title:%s ->Videourl:%s' %(self.title, fullitem[u'video_url']))
			
		self.islike=islike
		self.iscomment=iscomment

		
class SCToken:

	def __init__(self, client=None, me=None, mycomments=[], error='', useravatar=None, myfollowings=[], myfollowers=[], mylikedTracks=[], mylikedTracks_ids=[], mylikedPlaylists= [], 
			mylikedPlaylists_ids=[], myplaylists =[], mycomment_ids=[], myfollowing_ids=[], myfollower_ids=[], myrepostedTracks=[], myrepostedTracks_ids=[], myrepostedPlaylists=[], myrepostedPlaylists_ids=[]):
		self.client=client
		self.me=me
		self.mycomments=mycomments
		self.error=error
		self.useravatar=useravatar
		self.myfollowings=myfollowings
		self.myfollowers=myfollowers
		self.mylikedTracks=mylikedTracks
		self.mylikedTracks_ids=mylikedTracks_ids
		self.mylikedPlaylists=mylikedPlaylists
		self.mylikedPlaylists_ids=mylikedPlaylists_ids
		self.myplaylists=myplaylists
		self.mycomment_ids=mycomment_ids
		self.myfollowing_ids=myfollowing_ids
		self.myfollower_ids=myfollower_ids
		self.myrepostedTracks=myrepostedTracks
		self.myrepostedTracks_ids=myrepostedTracks_ids
		self.myrepostedPlaylists=myrepostedPlaylists
		self.myrepostedPlaylists_ids=myrepostedPlaylists_ids
