# -*- coding: UTF-8 -*-

#  Music Center E2
#
#  Coded by bobo71 (c) 2014
#  Support: www.dreambox-tools.info
#
#  All Files of this Software are licensed under the Creative Commons
#  Attribution-NonCommercial-ShareAlike 3.0 Unported
#  License if not stated otherwise in a Files Head. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.

#  Additionally, this plugin may only be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.

#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially
#  distributed other than under the conditions noted above.
#  This applies to the source code as a whole as well as to parts of it, unless
#  explicitely stated otherwise.


from Globals import *

# local plugin
from JobCenter import *
from JobCenter2 import *
from myLogger import logger
from SelectPath import SelectPath
from SoundCloudHelper import resolveArtistartwork, splitSoundcloudCoverurl, SCItem, SCAllItem, SCToken
from Setup import *

import SoundCloudPlayer

from soundcloud import Client as soundcloud_Client
from soundcloud.resource import Resource as soundcloud_Resource, ResourceList as soundcloud_Resource_List



class SCMain(Screen):

	def __init__(self, session, player, TOKEN=None):
		logger.info('SCMain]init...')
		self.session=session
		self.TOKEN=TOKEN
		self.skin_path='/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images'
		self.buildSkin()
		Screen.__init__(self, session)
		self['list']=SCList([])
		self["actions"]=ActionMap(["WizardActions", "DirectionActions", "ColorActions", "EPGSelectActions", "InfobarAudioSelectionActions", "MediaPlayerActions"],
		{
			"ok": self.ok,
			"back": self.closing,
			"red": self.redPressed,
			"green": self.greenPressed,
			"yellow": self.yellowPressed,
			"blue": self.bluePressed,
			"input_date_time": self.menuPressed,
			"audioSelection": self.audioPressed,
			"down": self.keyDown,
			"right": self.keyRight,
			"info" : self.infoPressed,
			"previous": self.keyArrowLeft,
			"next": self.keyArrowRight,
		}, -1) #

		self["actions2"]=NumberActionMap(["InputActions"],
		{
			"0": self.keyNumberPressed,
		}, -1)
		self.onLayoutFinish.append(self.startRun)
		self.onClose.append(self.__onClose)
		self.mode='buildMainmenu'
		self.cachedict={}
		self.LastMethod=None
		self.player=player
		self["useravatar"]=PicLoaderScale(70, 70, transparent=False, name='SCMain_useravatar')
		self["key_red"]=StaticText("")
		self["key_green"]=StaticText("")
		self["key_yellow"]=StaticText("")
		self["key_blue"]=StaticText("")
		self['headertext']=BlinkingLabel("Soundcloud get Accesstoken...")
		self['headertext'].setBlinkTime(300)
		self['headertext'].startBlinking()
		self.soundcloudsearchhist=[]
		self.piccount=0
		self.runningindex=0
		self.hlp={}
		self.isendoflist=False
		if fileExists(SCSEARCHHIST):
			with open(SCSEARCHHIST, 'r') as lst:
				for l in lst:
					self.soundcloudsearchhist.append(l)
		logger.info('SCMain]init...')
		self.getSoundCloudaccesstoken_mc_conn=None
		
	def buildSkin(self):
		if RESOLUTIONx>1800:
			self.skin='''
			<screen name="SCMain" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#00000000" zPosition="0">
				<widget name="list" position="75,195" zPosition="2" size="1770,855" scrollbarMode="showOnDemand" backgroundColor="#00000000"/>		
				<eLabel position="1580,25" size="120,27" text="MusicCenter" font="SansReg;15" transparent="1" foregroundColor="#ffffff" halign="center"  valign="center" zPosition="3"/>
				<!-- clock -->
					<widget position="1580,68" size="120,27" backgroundColor="#00000000" font="SansReg; 18" foregroundColor="#ffffff" halign="center" render="Label" source="global.CurrentTime" transparent="1" valign="center" zPosition="3">
					<convert type="ClockToText">Format:%H:%M</convert>
					</widget>
				<!-- Buttons -->
					<widget render="Label" font="SansReg;26" transparent="1" position="60,128" size="450,45" source="key_red" foregroundColor="#ff0000" halign="center" valign="center" zPosition="1"/>
					<widget render="Label" font="SansReg;26" transparent="1" position="510,128" size="450,45" source="key_green" foregroundColor="#00ff21" halign="center" valign="center" zPosition="1"/>
					<widget render="Label" font="SansReg;26" transparent="1" position="960,128" size="450,45" source="key_yellow" foregroundColor="#FFD800" halign="center" valign="center" zPosition="1"/>
					<widget render="Label" font="SansReg;26" transparent="1" position="1410,128" size="450,45" source="key_blue" foregroundColor="#3D8DFF" halign="center" valign="center" zPosition="1"/>			
				<widget name="headertext" position="165,6" size="1500,110" font="SansReg;24" foregroundColor="#ff7700" backgroundColor="#00000000" halign="center" valign="center" zPosition="1" />
				<ePixmap position="30,22" size="90,90" pixmap="~/sc-iconx60.png" alphatest="on" zPosition="2"/>
				<widget name="useravatar" position="1780,0" size="120,120" zPosition="2" />
				<!-- line -->
					<eLabel backgroundColor="#ff7700" position="0,120" size="1920,1" zPosition="1" />
			</screen>'''
		else:
			self.skin='''
			<screen name="SCMain" position="0,0" size="1280,720" flags="wfNoBorder" backgroundColor="#00000000" zPosition="0">
				<widget name="list" position="50,130" zPosition="2" size="1180,570" scrollbarMode="showOnDemand" backgroundColor="#00000000"/>
					
				<eLabel position="1120,20" size="80,18" text="MusicCenter" font="SansReg;13" transparent="1" foregroundColor="#ffffff" halign="center"  valign="center" zPosition="3"/>
				<!-- clock -->
					<widget position="1120,45" size="80,18" backgroundColor="#00000000" font="SansReg; 16" foregroundColor="#ffffff" halign="center" render="Label" source="global.CurrentTime" transparent="1" valign="center" zPosition="3">
					<convert type="ClockToText">Format:%H:%M</convert>
					</widget>
				<!-- Buttons -->
					<widget render="Label" font="SansReg;26" transparent="1" position="40,85" size="300,30" source="key_red" foregroundColor="#ff0000" halign="center" valign="center" zPosition="1"/>
					<widget render="Label" font="SansReg;26" transparent="1" position="340,85" size="300,30" source="key_green" foregroundColor="#00ff21" halign="center" valign="center" zPosition="1"/>
					<widget render="Label" font="SansReg;26" transparent="1" position="640,85" size="300,30" source="key_yellow" foregroundColor="#FFD800" halign="center" valign="center" zPosition="1"/>
					<widget render="Label" font="SansReg;26" transparent="1" position="940,85" size="300,30" source="key_blue" foregroundColor="#3D8DFF" halign="center" valign="center" zPosition="1"/>			
			
				<widget name="headertext" position="110,4" size="1000,73" font="SansReg;24" foregroundColor="#ff7700" backgroundColor="#00000000" halign="center" valign="center" zPosition="1" />
				<ePixmap position="20,15" size="60,60" pixmap="~/sc-iconx60.png" alphatest="on" zPosition="2"/>
				<widget name="useravatar" position="1195,0" size="80,80" zPosition="2" />
				<!-- line -->
					<eLabel backgroundColor="#ff7700" position="0,80" size="1280,1" zPosition="1" />
			</screen>'''

		#LOG('SCMain]buildSkin]->%s'%self.skin)
	
	def startRun(self, ischanged=False):
		logger.info('SCMain]buildSkin]startRun]')
		self['headertext'].startBlinking()
		if self.TOKEN is None or ischanged:
			self.getSoundCloudaccesstoken_mc_conn=getSoundCloudaccesstoken.MessagePump.recv_msg.connect(self.gotThreadMsg_getSoundCloudaccesstoken)
			logger.info('SCMain]startRun]')
			getSoundCloudaccesstoken.Start(ischanged)
		else:
			self.startBuildRoot()

	def gotThreadMsg_getSoundCloudaccesstoken(self, msg):
		msg=getSoundCloudaccesstoken.Message.pop()
		logger.info('SCMain]gotThreadMsg_getSoundCloudaccesstoken]msg: %s' %str(msg))
		if msg[0]!=None:
			self.TOKEN=msg[0]
			if msg[1]==0 or msg[1]==1 and self.mode=='buildMainmenu': # token from cache
				self.startBuildRoot()
		if msg[1]==1:
			self.getSoundCloudaccesstoken_mc_conn=None
		
	def startBuildRoot(self):
		if self.mode!='buildMainmenu':
			self.mode='buildMainmenu'
			self.redPressed()
		else:
			self.buildMainmenu()

	def checkModeandisappend(self):
		res = self.mode in (SEARCH, 551, FOLLOWINGUSERTRACKLIST, 502, 552, 505, 555, USERFOLLOWINGSLIST) or isinstance( self.mode, str ) and self.mode in (
			'buildMyRepostlist', 
			'buildMyActivityCollection',
			'buildTrendingAudio', 
			'buildTrendingMusic', 
			'buildGenreTracklist', 
			'buildMyFollowingsUserlist', 
			'buildMyFollowersUserlist', 
			'buildMeLikedTracklist',
			'buildMeLikedPlaylists',
			'getUserLikedTracklist',
			'userOwnTracklist',
			) and not self.isendoflist
		logger.info('SCMain]checkModeandisappend]isendoflist->%s  mode->%s return->%s'%(self.isendoflist, self.mode, str(res)))	
		return res

	def keyDown(self):
		index=self['list'].getCurrentIndex()
		count=self['list'].getItemCount()
		logger.info('SCMain]keyDown]index ->%d count ->%d' %(index, count))
		if index >= count-2:
			if self.checkModeandisappend():
				if config.plugins.musiccenter.sc_autoloadnextfeeds.value:
					self.session.openWithCallback(self.getNextEntries, MessageBox, _("Do you want to see more results?"))
				else:
					self.getNextEntries(True)
					if index < count:
						self['list'].down()
			else:
				if index <count:
					self['list'].down()
				else:
					self['list'].moveToIndex(0)
		else:
			self['list'].down()

	def keyRight(self):
		index=self['list'].getCurrentIndex()
		count=self['list'].getItemCount()
		if index == count:
			if self.checkModeandisappend():
				if config.plugins.musiccenter.sc_autoloadnextfeeds.value:
					self.session.openWithCallback(self.getNextEntries, MessageBox, _("Do you want to see more results?"))
				else:
					self.getNextEntries(True)
		else:
			self['list'].pageDown()

	def keyArrowLeft(self):
		if self.mode=='buildSoundCloudSearchhistory':
			if self.hlp.get('keylist')==1:
				self.setButtons(red="Tracks", green="Playlists", yellow="Users", blue="Groups")
				self.hlp['keylist']=0

	def keyArrowRight(self):
		if self.mode=='buildSoundCloudSearchhistory':
			if self.hlp.get('keylist')==0:
				self.setButtons(red="Genres", green="", yellow="", blue="")
				self.hlp['keylist']=1

	def getNextEntries(self, result):
		if not result:
			logger.info('SCMain]getNextEntries]stop get next entrys...')	
			return
		list=self['list'].getList()
		if self.mode in (FOLLOWINGUSERTRACKLIST,):
			self.buildUserTracklist(list, isappend=True)
		elif self.mode in (SEARCH, 551,):
			self.buildTrackslist(list, isappend=True)
		elif self.mode in (502, 552,):
			self.buildPlaylistslist( list, isappend=True)
		elif self.mode in (505, 555,):
			self.buildUserslist( list, isappend=True)
		elif not isinstance(self.mode, int): 
			s="self.%s(isappend=True)" %self.mode
			logger.info('''SCMain]getNextEntries]call->%s''' %s)
			eval(s)
			#exec"self.%s(%s)" %(self.mode, str(sel.cache_it))

		else:
			logger.error('''SCMain]getNextEntries]What is wrong? call -> "self.%s(%s)"''' %(self.mode, str(sel.cache_it)))

	def audioPressed(self):
		if self.player!=None and self.player.songList:
			self.session.execDialog(self.player)
			self.player.onShownAppend()

	def menuPressed(self):
		options=[(_("Configuration"), self.config),]
		options.append((_("Soundcloudauthentification"), self.openSCAuth),)
		options.append((_("Reload Authtoken"), self.afterSCAuthChanged, True),)
		if self.mode=='buildSoundCloudSearchhistory':
			options.append((_("Remove selected word from list"), self.removeItemFromList),)
		options.append((_("Help"), self.openHelp),)
		self.session.openWithCallback(self.genrerallyCallback, ChoiceBox,list=options)

	def openHelp(self):
		pass

	def infoPressed(self):
		logger.info('SCMain]infoPressed]')
		options=[]
		curr=sel=self.getCurrentSelection()
		if self.TOKEN.me is None:
			return
		if self.mode in (551, FOLLOWINGUSERTRACKLIST, 503, 553):
			if not curr.fullitem.user_favorite:
				options.append((_("Like selected song"), self.likeTrack, curr),)
			else:
				options.append((_("Unlike selected song"), self.unlikeTrack, curr),)
			if not curr.fullitem.user_id in self.TOKEN.myfollowing_ids:
				options.append((_("Follow %s" %curr.fullitem.artist), self.follow, curr.fullitem.user_id),)
			else:
				options.append((_("Unfollow %s" %curr.fullitem.artist), self.unfollow, curr.fullitem.user_id),)
		elif self.mode in (MYFOLLOWINGSLIST, MYFOLLOWERSLIST, 505, 555):
			if not curr.fullitem.id in self.TOKEN.myfollowing_ids:
				options.append((_("Follow %s" %myenCode(curr.fullitem.username)), self.follow, curr.fullitem.id),)
			else:
				options.append((_("Unfollow %s" %myenCode(curr.fullitem.username)), self.unfollow, curr.fullitem.id),)
		options.append((_("Create new set"), self.startCreatePlaylsit),)
		if self.mode in (SEARCH, 551, FOLLOWINGUSERTRACKLIST, 503, 553, MYLIKEDPLAYLISTTRACKLIST, USERLIKEDTRACKLIST) or isinstance( self.mode, str ) and self.mode in ('buildMyActivityCollection', 'buildMeLikedTracks'): # tracklists
			options.append((_("Add selected track to set"), self.startAddTracktoPlaylist, curr.fullitem.id),)
		if self.mode in (MYLIKEDPLAYLISTTRACKLIST,): # my sets
			options.append((_("Delete selected track from set"), self.deleteTrackfromSet, curr.fullitem.id),)
		if self.mode in (MYSETS,): # my sets
			options.append((_("Delete selected set"), self.deleteSet, curr.fullitem.id),)
		self.session.openWithCallback(self.genrerallyCallback, ChoiceBox, title=_("Trackoptions"), list=options, keys=MYKEYSORT, titlebartext=_("MusicCenter"))
# selectAction
	def selectAction(self, sel):
		logger.info('SCMain]selectAction]')
		options=[]
		mode='userOwnTracklist'
		options.append((_("List own tracks"), mode, sel),)
		mode='getUserOwnPlaylists'
		options.append((_("List own playlists"), mode, sel),)
		mode='getUserLikedTracklist'
		options.append((_("List liked tracks"), mode, sel),)
		mode='getUserLikedPlaylists'
		options.append((_("List liked playlists"), mode, sel),)
		'''
		sel.mode='buildFollowinglistUserInit'
		options.append((_("List Followings"), self.ok, sel),)
		sel.mode='buildFollowerlistUserInit'
		options.append((_("List Followers"), self.ok, sel),)
		'''
		text=' '.join((myenCode(sel.fullitem.username), 'Userinfo'))
		self.session.openWithCallback(self.selectActionCallback, ChoiceBox, title=_('Selections'), list=options, keys=MYKEYSORT, titlebartext=text)
		
	def selectActionCallback(self, ret):
		if ret is not None:
			if len(ret)==3:
				ret[2].mode=ret[1]
				logger.info('SCMain]selectActionCallback]->%s' %str(ret))
				self.hlp['sel']=ret[2]
				ret and self.ok()
			else:
				ret and ret[1]()
	
	def genrerallyCallback(self, ret):
		if ret is not None:
			if len(ret)==3:
				ret and ret[1](ret[2])
			else:
				ret and ret[1]()

	def buildPlaylistUserInit(self):
		self.mode=USERPLAYLIST
		self['list'].setMode(USERPLAYLIST)
		self.buildLikedPlaylistold(curr, lastmode)

	def buildLikedTracklistUserInit(self): # new 22.06
		self.mode=self.hlp('sel').mode
		self.userLikedTracklist(cache_it)

	def buildLikedPlaylistUserInit(self):
		self.mode=USERLIKEDPLAYLIST
		self['list'].setMode(USERLIKEDPLAYLIST)
		self.buildLikedPlaylistold(curr, lastmode)

	def buildFollowinglistUserInit(self):
		self.mode=USERFOLLOWINGSLIST
		self['list'].setMode(USERFOLLOWINGSLIST)
		self.buildFollowinglistInit(curr, lastmode)

	def buildFollowerlistUserInit(self):
		self.mode=USERFOLLOWERLIST
		self['list'].setMode(USERFOLLOWERLIST)
		self.buildFollowerlistInit(curr, lastmode)

	def follow(self, user_id):
		res=self.TOKEN.client.put('/users/%d/followings/%d' %(self.TOKEN.me.id, user_id))
		self.TOKEN.myfollowing_ids-append(user_id)
		saveToken(self.TOKEN)
		del res, user_id

	def unfollow(self, user_id):
		logger.info('SCMain]unfollow]%s' %str(user_id))
		res=self.TOKEN.client.delete('/users/%d/followings/%d' %(self.TOKEN.me.id, user_id))
		f=[ self.TOKEN.myfollowing_ids.pop(id) for id in self.TOKEN.myfollowing_ids if id==user_id ]

		saveToken(self.TOKEN)
		del res, user_id

	def likeTrack(self, curr):
		res=self.TOKEN.client.put('/users/%d/favorites/%d' %(self.TOKEN.me.id, curr.fullitem.id))
		if res.status==u'201 - Created':
			self["islike"].setPixmapNum(1)
			curr.islike=True
			self.TOKEN.me=self.TOKEN.client.get('/me')
			self.TOKEN.mylikedTracks_ids.append(curr.fullitem.id)
			saveToken(self.TOKEN)
			del curr

	def unlikeTrack(self, curr):
		res=self.TOKEN.client.delete('/users/%d/favorites/%d' %(self.TOKEN.me.id, curr.fullitem.id))
		if res.status==u'200 - OK':
			self["islike"].setPixmapNum(0)
			curr.islike=False
			self.TOKEN.me=self.TOKEN.client.get('/me')
			f=[ self.TOKEN.mylikedTracks_ids.pop(id) for id in self.TOKEN.mylikedTracks_ids if id==curr.fullitem.id ]
			saveToken(self.TOKEN)
			del curr

	def startCreatePlaylsit(self):
		self.session.openWithCallback(self.cbcreateNewPlaylist, vInputBox, title=_("Put in name for your set here..."), windowTitle=_("MusicCenter"), text="setname")

	def cbcreateNewPlaylist(self, answer):
		if answer is None:
			return
		try:
			res=self.TOKEN.client.post('/playlists', playlist={'title': answer, 'sharing': 'public', 'tracks': []})
			logger.info('SCMain]cbcreateNewPlaylist]res %s' %res)
			# new 26.06 ok?
			self.TOKEN.mylikedPlaylists_ids=getSoundCloudaccesstoken.getIds(self.TOKEN.client, '/e1/me/playlist_likes/ids?linked_partitioning=1')
			saveToken(self.TOKEN)
		except Exception, e:
			logger.error('SCMain]cbcreateNewPlaylist]error:%s' %e)
			self.session.open(MessageBox, _("Error: %s" %e), type=MessageBox.TYPE_ERROR, title="MusicCenter SoundCloud create set",timeout=6 )

	def startAddTracktoPlaylist(self, id):
		logger.info('SCMain]startAddTracktoPlaylist]')
		options=[]
		for playlist in self.TOKEN.myplaylists:
			options.append((_("%s (%d tracks)" %(myenCode(playlist.title), playlist.track_count)), self.addTracktoPlaylist, (playlist, id)),)
		text='Select playlist for append'
		self.session.openWithCallback(self.genrerallyCallback, ChoiceBox, title=_('Add track to Playlist'), list=options, keys=MYKEYSORT, titlebartext=text)

	def addTracktoPlaylist(self, entry):
		playlist, id=entry[0], entry[1]
		tracks=[ {'id':i['id']} for i in playlist.tracks]
		tracks.append({'id': id})
		logger.info('SCMain]addTracktoPlaylist]id %d, tracks %s' %(id, str(tracks)))
		try:
			res=self.TOKEN.client.put('/playlists/%d' %playlist.id, playlist={'tracks': tracks})
			logger.info('SCMain]addTracktoPlaylist]res %s' %res)
			self.TOKEN.myplaylists=self.TOKEN.client.get('/me/playlists')
			saveToken(self.TOKEN)
		except Exception, e:
			logger.error('SCMain]addTracktoPlaylist]error:%s' %e)
			self.session.open(MessageBox, _("Error: %s" %e), type=MessageBox.TYPE_ERROR, title="MusicCenter SoundCloud add track to set",timeout=6 )
		del entry, playlist, id

	def deleteTrackfromSet(self, todelid):
		tracks, newlist=[], []
		# { 'id' : i.fullitem.id } for i in list if i.fullitem.id!=todelid]
		for i in self['list'].getList():
			if i.fullitem.id!=todelid:
				newlist.append(i)
				tracks.append({ 'id' : i.fullitem.id })
		logger.info('SCMain]deleteTrackfromSet]todelid %d, tracks %s' %(todelid, str(tracks)))
		try:
			res=self.TOKEN.client.put('/playlists/%d' %playlist.id, playlist={'tracks': tracks})
			logger.info('SCMain]deleteTrackfromSet]res %s' %res)
			self.TOKEN.myplaylists=self.TOKEN.client.get('/me/playlists')
			saveToken(self.TOKEN)
		except Exception, e:
			logger.error('SCMain]deleteTrackfromSet]error:%s' %e)
			self.session.open(MessageBox, _("Error: %s" %e), type=MessageBox.TYPE_ERROR, title="MusicCenter SoundCloud delete track from set",timeout=6 )
		del entry, playlist, id
		self['list'].setList(newlist)

	def deleteSet(self, id):
		return # hmm doof..
		try:
			res=self.TOKEN.client.delete('/playlists/%d' %id)
			logger.info('SCMain]deleteSet]res %s' %res)
			self.TOKEN.myplaylists=self.TOKEN.client.get('/me/playlists')
			saveToken(self.TOKEN)
		except Exception, e:
			logger.error('SCMain]deleteSet]error:%s' %e)
			self.session.open(MessageBox, _("Error: %s" %e), type=MessageBox.TYPE_ERROR, title="MusicCenter SoundCloud add track to playlist",timeout=6 )
		self.buildMeLikedPlaylists('', 'buildMainmenu')

	def openSCAuth(self):
		self.session.openWithCallback(self.afterSCAuthChanged, SCAuth)

	def afterSCAuthChanged(self, ret):
		if ret is not None:
			logger.info('afterSCAuthChanged]user or pass is changed, get new token and go to ROOT')
			self['headertext'].setText(_('Reload Accesstoken !'))
			self.startRun(ischanged=True)

	def addToCache(self):
		mode=self['list'].getMode()
		index=self['list'].getCurrentIndex()
		headertext=self['headertext'].getText()
		buttons=self.getButtons()
		logger.info('SCMain]addToCache]self.mode->%s, index->%d, headertext->%s, buttons->%s, hlp->%s' %(str(mode), index, headertext, str(buttons), self.hlp))
		hlp=copy_copy(self.hlp)
		self.cachedict[self.mode]=CacheItem(mode=mode, index=index, listview=self['list'].getList(), headertext=headertext, buttons=buttons, hlp=hlp)
					
# --> ok
	def ok(self, from_colorkey=False):
		'''
		wenn cache_it->add to cache  
		selectAction -> kein cache_it
		'''
		logger.info('SCMain]ok]start, old mode is:%s' %str(self.mode))
		if from_colorkey:
			sel=from_colorkey
		else:
			sel=self.getCurrentSelection()
			if sel.cache_it:
				self.addToCache() # hier ok????
			else:
				logger.info('SCMain]ok]add no to cache!')
		if sel.mode=='selectAction':
			logger.info('SCMain]ok]open selectAction')
			self.selectAction(sel)
			return
			
		if sel is None or isinstance(self.mode, str) and self.mode in ('buildSoundCloudSearchhistory', 'buildMyCommentslist', 'exploreGenres') and sel.mode in (551,552,555, MYCOMMENTLISTAFTER) :#track-, user-, set- search
			if self.mode in ('buildSoundCloudSearchhistory',):
				self.session.open(MessageBox, _("Please use color key to select searchtype"), type=MessageBox.TYPE_INFO, title="MusicCenter SoundCloud Search",timeout=4 )
			return
			
		if sel.mode==STARTPLAYER:
			self.greenPressed(True)
		else:
			lastmode=self.mode
			self.hlp['lastmode']=lastmode
			self.hlp['sel']=sel
			self['list'].setMode(sel.mode)
			self.mode=sel.mode
			logger.info('SCMain]ok]new mode->%s cache_it->%s len_cache->%d' %(str(self.mode), str(sel.cache_it), len(self.cachedict)))
			cache=self.cachedict.get(sel.mode, None)
			if cache!=None:
				logger.info('SCMain]ok]getCache...')
				self['list'].setList(cache.listview)
				self['headertext'].setText(cache.headertext)
				self['list'].moveToIndex(cache.index)
				self.setButtons(*cache.buttons)
				self.hlp=cache.hlp
				return
				
			if not isinstance(self.mode, int): #
				logger.info('''SCMain]ok]call method:{} cache it:{}'''.format(self.mode, str(sel.cache_it)))
				exec"self.%s(%s)" %(self.mode, str(sel.cache_it))
			elif self.mode==FOLLOWINGUSERTRACKLIST: # userstracklist
				if not sel.cache_it:
					self.buildUsersTracklistInit(sel, lastmode)
			elif self.mode in (503, 553, MYLIKEDPLAYLISTTRACKLIST): # buildPlaylistTracklist
				self.buildPlaylistTracklist(sel, lastmode)
			elif self.mode in (507, 557,): # buildGroupSonglist
				if not sel.cache_it:
					self.buildGroupSonglist(list=[], isappend=False, sel=sel, lastmode=lastmode)
			elif self.mode==MYFOLLOWERSLIST:
				if not sel.cache_it:
					self.buildMyFollowerlist()
			else:
				if not sel.cache_it:
					self.redPressed() # back to main menu

	def openSearchScreen(self, cache_it):
		self.session.openWithCallback(self.cbSoundCloudSearch, SCEnterSearchScreen, self.TOKEN, self.skin_path)
	
# mainmenu
	def buildMainmenu(self, cache_it=True): 
		logger.info('buildMainmenu]Start')
		self.setButtons()
		if self.TOKEN.client is not None:
			self['list'].setMode(self.mode)
			list=[(SCItem(text=_("[back]"), mode='closing'),)]
			list.append((SCItem(text =_("Search Everything"), mode='openSearchScreen'),))
			list.append((SCItem(text =_("Searchhistory"), mode='buildSoundCloudSearchhistory'),))
			list.append((SCItem(text =_("Explore Trending Music"), cache_it=True, mode='buildTrendingMusic'),))
			list.append((SCItem(text =_("Explore Trending Audio"), cache_it=True, mode='buildTrendingAudio'),))
			list.append((SCItem(text =_("Explore by genre"), cache_it=True, mode='exploreGenres'),))
			if self.TOKEN.me is not None:
				text="Stream "
				list.append((SCItem(text =_(text), cache_it=True, mode='buildMyActivityCollection', thumb=drawImageJob(text[0])),))
				
				text="Reposted (%d)" %(len(self.TOKEN.myrepostedTracks_ids+self.TOKEN.myrepostedPlaylists_ids))
				list.append((SCItem(text =_(text), cache_it=True, mode='buildMyRepostlist', thumb=drawImageJob(text[0])),))
				
				text="Tracks liked (%d)" %(len(self.TOKEN.mylikedTracks_ids))
				list.append((SCItem(text =_(text), cache_it=True, mode='buildMeLikedTracklist', thumb=drawImageJob(text[0])),))
				
				text="Playlists liked (%d)" %len(self.TOKEN.mylikedPlaylists_ids)
				list.append((SCItem(text =_(text), cache_it=True, mode='buildMeLikedPlaylists', thumb=drawImageJob(text[0])),))
				
				text="Playlists created (%d)" %len(self.TOKEN.myplaylists.collection)
				list.append((SCItem(text =_(text), cache_it=True, mode='buildMeOwnPlaylists', thumb=drawImageJob(text[0])),))
				
				text="Followings (%d)" %len(self.TOKEN.myfollowing_ids)
				list.append((SCItem(text =_(text), cache_it=True, mode='buildMyFollowingsUserlist', thumb=drawImageJob(text[0])),))
				
				text="Followers (%d)" %len(self.TOKEN.myfollower_ids)
				list.append((SCItem(text =_(text), cache_it=True, mode='buildMyFollowersUserlist', thumb=drawImageJob(text[0])),))
				
				self['headertext'].setText(_("Welcome %s (%s) on Soundcloud" %(myenCode(self.TOKEN.me.username), myenCode(self.TOKEN.me.full_name))))
			else:
				self['headertext'].setText(_("Welcome on Soundcloud, please login."))
			self['list'].setList(list)
			self['list'].moveToIndex(1)
			if self.TOKEN.me is not None:
				self.getuseravatar()
		else:
			list=[(SCItem(text=_("[back]"), mode=0),)]
			list.append((SCItem(text =_("Error connecting Soundcloud"), mode=0),))
		self['headertext'].stopBlinking()
		self['headertext'].show()

	def openSCIntro(self): # unused
		url='https://on.soundcloud.com/'
		from Plugins.Extensions.Browser.plugin import Browser
		self.session.open(Browser, fullscreen = True, url = url, isHbbtv = False, isTransparent = False, hbbtvMenu = None)

	def explore(self):
		pass
		'''
		genrelist=[Alternative Rock, Ambient, Classical, Country, Dance, Deep House, Disco, Drum & Bass, Dubstep, Electro, Electronic, Folk, Hardcore Techno, Hip Hop, House, Indie Rock, Jazz, Latin,
		Metal, Minimal Techno, Piano, Pop, Progressive House, Punk, R&B, Rap, Reggae, Rock, Singer-Songwriter, Soul, Tech House, Techno, Trance, Trap, Trip Hop, World, Audiobooks, Business, Comedy,
		Entertainment, Learning, News & Politics, Religion & Spirituality, Science, Sports, Storytelling, Technology]
		'''
# helper artwork sqlite images
	def resolveArtistartwork(self, entry):
		artwork_url=None
		if entry.artwork_url!=None and len(entry.artwork_url):
			artwork_url=entry.artwork_url
		#elif entry.avatar_url!=None and len(entry.avatar_url):	
		#	artwork_url=entry.avatar_url
		#else:
		#	url=soundcloud_Resource(entry.user).avatar_url
		#	if url!=None and len(url):
		#		artwork_url=url

		if artwork_url!=None:
			artwork_url, artwork_fn=splitSoundcloudCoverurl(artwork_url, size='t300x300')
			if not os_path.exists(artwork_fn):
				downloadPage(artwork_url, artwork_fn).addCallback(self.finishedPicDownload, artwork_fn).addErrback(self.errorPicDownload, artwork_url)	
		else:
			artwork_fn=''.join((self.skin_path, 'sc_default-t500x500.jpg'))
		#LOG('SCMain]resolveArtistartwork]thumburl-->%s tumbfn-->%s'%(artwork_url ,artwork_fn))
		return artwork_url, artwork_fn

	def finishedPicDownload(self, result, artwork_fn):
		pass #LOG('SCMain]finishedPicDownload]->%s' %artwork_fn)

	def errorPicDownload(self, error, artwork_url):
		logger.info('SCMain]errorPicDownload]->%s ->%s' %(artwork_url, error))

# stream....
	def buildMyActivityCollection(self, cache_it=False, isappend=False):
		logger.info('SCMain]buildMyActivityCollection]Start')
		self.setButtons(red='Main menu', green=_('play'), yellow=_('Sort list'))
	
		piclist=[]
		if not isappend:
			list=[(SCItem(text=_("[back]"), cache_it=True, mode='buildMainmenu'),)]
			
			self['headertext'].setText(_("Get Activitys..."))
			self['headertext'].startBlinking()
			
			self.hlp['streamidsoutsorted']=[]
			self.hlp['streamids']=[]
			try:
				affiliated=self.TOKEN.client.get('https://api-v2.soundcloud.com/stream')#'/e1/me/stream'
				'''affiliated.keys()->[u'next_href', u'query_urn', u'collection']
					sorted(soundcloud_Resource(soundcloud_Resource(res2.collection[0]).track).keys())
					[u'artwork_url', u'comment_count', u'commentable', u'created_at', u'description', u'download_count', u'download_url', u'downloadable', u'duration', u'embeddable_by', u'full_duration', u'genre', u'has_downloads_left', u'id', u'kind', u'label_name', u'last_modified', u'license', u'likes_count', u'monetization_model', u'permalink', u'permalink_url', u'playback_count', u'policy', u'public', u'publisher_metadata', u'purchase_title', u'purchase_url', u'release_date', u'reposts_count', u'secret_token', u'sharing', u'state', u'streamable', u'tag_list', u'title', u'uri', u'urn', u'user', u'user_id', u'visuals', u'waveform_url']
				'''
			except Exception, e:
				logger.error('SCMain]buildMyActivityCollection]%s' %e)
				headertext="Error-->%s" %e
				self.setHeaderTextNow(headertext)
				self['list'].setList(list)
				return
		else:
			list=self['list'].getList()
			self['headertext'].setText(_("Get more Activitys..."))
			self['headertext'].startBlinking()
			try:
				affiliated=self.TOKEN.client.get(self.hlp.get('next_href'))
			except Exception, e:
				logger.error('SCMain]buildMyActivityCollection]%s' %e)
				headertext="Error-->%s" %e
				self.setHeaderTextNow(headertext)
				self['list'].setList(list)
				return
		
		nextpage=affiliated.next_href
		self.hlp['next_href']=nextpage
		logger.info('SCMain]buildMyActivityCollection]next_href->%s' %nextpage)
		if not nextpage.startswith('https://api-v2.soundcloud.com/stream'): # 'https://api.soundcloud.com/e1/me/stream'):
			self.isendoflist=True
		 	
		for item in affiliated.collection:
			item_resource=soundcloud_Resource(item)
			activity_type=myenCode(item_resource.type) # track-repost, track, playlist LOG('SCMain]buildMyActivityCollection]songtype ->%s' %myenCode(activity_type))
			if activity_type in ('track', 'track-repost'):
				fullitem=soundcloud_Resource(item_resource.track)
				islike=fullitem.id in self.TOKEN.mylikedTracks_ids
				mode=STARTPLAYER
				logger.info('SCMain]buildMyActivityCollection]track->%s' %str(fullitem.title))
			elif activity_type in ('playlist', 'playlist-repost'):
				fullitem=soundcloud_Resource(item_resource.playlist)
				islike=fullitem.id in self.TOKEN.mylikedPlaylists_ids
				mode='buildMyActivityPlaylistTracklist'
				logger.info('SCMain]buildMyActivityCollection]playlist found with %s tracks' %fullitem.track_count)
			else:
				logger.error('SCMain]buildMyActivityCollection]what is this??--> %s' %activity_type)
				continue
			
			if fullitem.id not in self.hlp.get('streamids', []): # sort out dublicates
				self.hlp['streamids'].append(fullitem.id)
			else:
				self.hlp['streamidsoutsorted'].append(fullitem.id)
				logger.info('SCMain]buildMyActivityCollection]skip id %d' %fullitem.id)
				continue
			
			if activity_type in ('playlist-repost','track-repost',):
				reposted_by=myenCode(soundcloud_Resource(item_resource.user).username)
			else:
				reposted_by=''
			
			artwork_url, artwork_fn=self.resolveArtistartwork(fullitem)
		
			list.append((SCItem(cache_it=True, fullitem=fullitem, mode=mode, thumb=artwork_fn, islike=islike, iscomment=fullitem.id in self.TOKEN.mycomment_ids, isfollower=fullitem.id in self.TOKEN.myfollower_ids, isfollowing=fullitem.id in self.TOKEN.myfollowing_ids, isplaylist_trackcount=fullitem.track_count, type=activity_type, reposted_by=reposted_by),))

		l=len(list)
		headertext=_("Activitys(%d) dublicates outsorted(%d)" %(l-1, len(self.hlp.get('streamidsoutsorted',[]))))
		self.setListAndHeadertext(list, isappend, headertext)

	def buildMyActivityPlaylistTracklist(self, cache_it):
		sel=self.hlp.get('sel')
		url='/playlists/%d/tracks' %sel.fullitem.id
		playlist_title=myenCode(sel.fullitem.title)
		length=myenCode(sel.length)
		create_time=myenCode(sel.fullitem.created_at.split(' ',1)[0])
		headertext="%s (%s %s)" %(playlist_title, length, create_time)
		self.buildallPlaylistsTracklist(cache_it, url, headertext)

# reposts....
	def buildMyRepostlist(self, cache_it=True, isappend=False):
		logger.info('SCMain]buildMyRepostlist]Start')
		self.setButtons(red='Main menu', green=_('play'), yellow=_('Sort list'))
		if not isappend:
			list=[(SCItem(text=_("[back]"), cache_it=True, mode='buildMainmenu'),)]
		else:
			list=self['list'].getList()

		self['list'].setMode(self.mode)
		
		if not isappend:# first run...
			self['headertext'].setText(_("Get Reposts..."))
			self['headertext'].startBlinking()
			try:
				#reposts=self.TOKEN.client.get('/e1/me/reposts', limit=10, offset=0, linked_partitioning=1)#[u'next_href', u'collection']
				reposts=self.TOKEN.client.get('https://api-v2.soundcloud.com/profile/soundcloud:users:%s?'  %self.TOKEN.me.id, limit=10, offset=0, linked_partitioning=1)
			except Exception, e:
				logger.error('SCMain]buildMyRepostlist]%s' %e)
				headertext="Error-->%s" %e
				self.setHeaderTextNow(headertext)
				self['list'].setList(list)
				return
		else:
			self['headertext'].setText(_("Get more Reposts..."))
			self['headertext'].startBlinking()
			try:
				reposts=self.TOKEN.client.get(self.hlp.get('next_href'))
				
			except Exception, e:
				logger.error('SCMain]buildMyRepostlist]%s' %e)
				headertext="Error-->%s" %e
				self.setHeaderTextNow(headertext)
				self['list'].setList(list)
				return
		if reposts.next_href:
			self.hlp['next_href']=reposts.next_href
		else:
			self.isendoflist=True # hmm....
		
		for repost in reposts.collection: #
			repostresource=soundcloud_Resource(repost) # [u'track', u'kind', u'playlist', u'created_at']
			if repostresource.track:
				fullitem=soundcloud_Resource(repostresource.track)
				activity_type='track'
				isplaylist_trackcount=0
			elif repostresource.playlist:
				fullitem=soundcloud_Resource(repostresource.playlist)
				activity_type='playlist'
				isplaylist_trackcount=fullitem.track_count					
				logger.info('SCMain]buildMyRepostlist]playlist found with %s tracks' %isplaylist_trackcount)
			else:
				logger.error('SCMain]buildMyRepostlist]what is this??')
				continue
				
			reposted_by=myenCode(self.TOKEN.me.username)

			artwork_url, artwork_fn=self.resolveArtistartwork(fullitem)
			if activity_type in ('playlist', 'playlist-repost'):
				islike=fullitem.id in self.TOKEN.mylikedPlaylists_ids
				mode='buildMyRepostPlaylistTracklist'
			elif activity_type in ('track', 'track-repost'):
				islike=fullitem.id in self.TOKEN.mylikedTracks_ids
				mode=STARTPLAYER
				 
			list.append((SCItem(cache_it=True, fullitem=fullitem, mode=mode, thumb=artwork_fn, islike=islike, 
				iscomment=fullitem.id in self.TOKEN.mycomment_ids, isfollower=fullitem.id in self.TOKEN.myfollower_ids, 
				isfollowing=fullitem.id in self.TOKEN.myfollowing_ids, isplaylist_trackcount=isplaylist_trackcount, type=activity_type, reposted_by=myenCode(self.TOKEN.me.username)),))

		l=len(list)
		headertext="Reposts (%d hits)" %(l-1)
		self.setListAndHeadertext(list, isappend, headertext)

	def buildMyRepostPlaylistTracklist(self, cache_it):
		sel=self.hlp.get('sel')
		url='/playlists/%d/tracks' %sel.fullitem.id
		playlist_title=myenCode(sel.fullitem.title)
		length=myenCode(sel.length)
		create_time=myenCode(sel.fullitem.created_at.split(' ',1)[0])
		headertext="%s (%s %s)" %(playlist_title, length, create_time)
		self.buildallPlaylistsTracklist(cache_it, url, headertext)

#  explore
	def buildTrendingAudio(self, cache_it=True, isappend=False):
		url='https://api-v2.soundcloud.com/explore/Popular+Audio?tag=out-of-experiment&limit=10&offset=0&linked_partitioning=1'
		self.buildTrendingAppend(cache_it=cache_it, isappend=isappend, url=url)
		
		
	def buildTrendingMusic(self, cache_it=True, isappend=False):
		call='https://api-v2.soundcloud.com/explore/Popular+Music?tag=out-of-experiment&limit=10&offset=0&linked_partitioning=1'
		self.buildTrendingAppend(cache_it, isappend, call)
		
	def buildTrendingAppend(self, cache_it, isappend, call):
		logger.info('SCMain]buildTrendingAppend]Start')
		self.setButtons(red='Main menu', green=_('play'), yellow=_('Sort list'))
	
		if not isappend:
			list=[(SCItem(text=_("[back]"), cache_it=True, mode='buildMainmenu'),)]
		else:
			list=self['list'].getList()

		self['list'].setMode(self.mode)
		
		try:
			if not isappend:# first run...
				self['headertext'].setText(_("Get Trendings..."))
				self['headertext'].startBlinking()
				explores=self.TOKEN.client.get(call) # 'https://api-v2.soundcloud.com/explore/Popular+Music?tag=out-of-experiment&limit=10&offset=0&linked_partitioning=1')
			else:
				self['headertext'].setText(_("Get more Trendings..."))
				self['headertext'].startBlinking()
				explores=self.TOKEN.client.get(self.hlp.get('next_href'))	
		except Exception, e:
			logger.error('SCMain]buildTrendingAppend]%s' %e)
			headertext="Trending Error-->%s" %e
			self.setHeaderTextNow(headertext)
			self['list'].setList(list)
			return
		if explores.next_href:
			self.hlp['next_href']=explores.next_href
		else:
			self.isendoflist=True # hmm....
		
		for explore in explores.tracks: #
			fullitem=soundcloud_Resource(explore)
			activity_type='track'					
			artwork_url, artwork_fn=self.resolveArtistartwork(fullitem)
			islike=fullitem.id in self.TOKEN.mylikedTracks_ids
			mode=STARTPLAYER
				 
			list.append((SCItem(cache_it=True, fullitem=fullitem, mode=mode, thumb=artwork_fn, islike=islike, 
				iscomment=fullitem.id in self.TOKEN.mycomment_ids, isfollower=fullitem.id in self.TOKEN.myfollower_ids, 
				isfollowing=fullitem.id in self.TOKEN.myfollowing_ids, isplaylist_trackcount=0, type=activity_type),))

		l=len(list)
		headertext="Trending...(%d)" %(l-1)
		self.setListAndHeadertext(list, isappend, headertext)
# genres...
	def exploreGenres(self, cache_it=True, isappend=False):
		logger.info('SCMain]exploreGenres]Start')
		self.setButtons(red='Main menu', green=_('play'), yellow=_('Sort list'))
		url='https://api-v2.soundcloud.com/explore/categories?limit=10&offset=0&linked_partitioning=1'# -> [u'audio', u'music']

		list=[(SCItem(text=_("[back]"), cache_it=True, mode='buildMainmenu'),)]
		self['list'].setMode(self.mode)
		try:
			self['headertext'].setText(_("Get Trendings..."))
			self['headertext'].startBlinking()
			categorys=self.TOKEN.client.get(url)	
		except Exception, e:
			logger.error('SCMain]exploreGenres]%s' %e)
			headertext="Trending Error-->%s" %e
			self.setHeaderTextNow(headertext)
			self['list'].setList(list)
			return
		for category in sorted(categorys.keys(), reverse=True):
			list.append((SCItem(text='===>  %s' %myenCode(category).title(), mode='',),))
			for genre in sorted(categorys.fields()[category]): #
				mode='buildGenreTracklist'
				list.append((SCItem(cache_it=True, text=myenCode(genre).replace('+%26+',' ').replace('+',' '), thumb=myenCode(genre), mode=mode,),))

		l=len(list)
		headertext="Genres (%d)" %(l-1)
		self.setListAndHeadertext(list, isappend, headertext)

	def buildGenreTracklist(self, cache_it=True, isappend=False):
		logger.info('SCMain]buildGenreTracklist]Start')
		self.setButtons(red='Main menu', green=_('play'), yellow=_('Sort list'))
		
		self['list'].setMode(self.mode)
		sel=self.hlp.get('sel')
		if not isappend:
			list=[(SCItem(text=_("[back]"), cache_it=False, mode='exploreGenres'),)]
			self['headertext'].setText(_("Get %s Tracks..." %sel.text))
			self['headertext'].startBlinking()
			try:
				url='https://api-v2.soundcloud.com/explore/%s?limit=10&offset=0&linked_partitioning=1' %sel.text # fake for genre
				result=self.TOKEN.client.get(url)
			except Exception, e:
				logger.error('SCMain]buildGenreTracklist]%s' %e)
				headertext="Genre %s Error-->%s" %(sel.text, e)
				self.setHeaderTextNow(headertext)
				self['list'].setList(list)
				return
		else:
			list=self['list'].getList()
			self['headertext'].setText(_("Get more %s Tracks..."  %sel.text))
			self['headertext'].startBlinking()
			try:
				result=self.TOKEN.client.get(self.hlp.get('next_href'))
				
			except Exception, e:
				logger.error('SCMain]buildGenreTracklist]%s' %e)
				headertext="Error-->%s" %e
				self.setHeaderTextNow(headertext)
				self['list'].setList(list)
				return
				
		if result.next_href:
			self.hlp['next_href']=result.next_href
		else:
			self.isendoflist=True # hmm....
		
		for track in result.tracks: #[u'tracks', u'tag', u'next_href']
			track=soundcloud_Resource(track)
			
			artwork_url, artwork_fn=self.resolveArtistartwork(track)
			islike=track.id in self.TOKEN.mylikedTracks_ids
			mode=STARTPLAYER
				 
			list.append((SCItem(cache_it=False, fullitem=track, mode=mode, thumb=artwork_fn, islike=islike, 
				iscomment=track.id in self.TOKEN.mycomment_ids, isfollower=track.id in self.TOKEN.myfollower_ids, 
				isfollowing=track.id in self.TOKEN.myfollowing_ids),))

		l=len(list)
		headertext="%s Tracks(%d hits)" %(sel.text, l-1)
		self.setListAndHeadertext(list, isappend, headertext)		

# follow
	def buildMyFollowingsUserlist(self, cache_it=True, isappend=False): #ok
		logger.info('SCMain]buildMyFollowingsUserlist]Start')
		self['list'].setMode(self.mode)
		username=myenCode(self.TOKEN.me.username)
		id=self.TOKEN.me.id
		call='https://api-v2.soundcloud.com/users/%s/followings?&limit=12&offset=0&linked_partitioning=1' %id
		headertext="%s`s Followings (%d)"
		self.buildUserlist(cache_it, isappend, username, id, call, headertext)

	def buildMyFollowersUserlist(self, cache_it=True, isappend=False): #ok
		logger.info('SCMain]buildMyFollowersUserlist]start, lastmode:%s')
		self['list'].setMode(self.mode)
		username=myenCode(self.TOKEN.me.username)
		id=self.TOKEN.me.id
		call='https://api-v2.soundcloud.com/users/%s/followers?&limit=12&offset=0&linked_partitioning=1' %id
		headertext="%s`s Followers (%d)"
		self.buildUserlist(cache_it, isappend, username, id, call, headertext)

	def buildFollowinglistInit(self, sel, lastmode):# unklar ob aktiv
	
		logger.info('SCMain]buildFollowinglistInit]start')
		username=myenCode(sel.fullitem.username)
		id=sel.fullitem.id
		call='https://api-v2.soundcloud.com/users/%s/followings?&limit=12&offset=0&linked_partitioning=1' %id
		self.buildUserlist(cache_it, list, isappend,username, id, call)

	def buildUserlist(self, cache_it, isappend, username, id, call, headertext):# ok
		logger.info('SCMain]buildUserlist]Start')
		self.setButtons(red='Main menu')
		if not isappend:
			list=[(SCItem(text=_("[back]"), cache_it=True, mode=self.hlp.get('lastmode')),)]
			#self['headertext'].setText(_("Get Followings for %s" %self.hlp.get('username','')))
			self.isendoflist=False
			result=self.TOKEN.client.get(call)

		else:
			list=self['list'].getList()
			#self['headertext'].setText(_("Extend Followings for %s" %self.hlp.get('username','')))
			result=self.TOKEN.client.get(self.hlp.get('next_href'))
		logger.info('SCMain]buildUserlist]userid=%s'%id)
		
		#result -> [u'next_href', u'collection']
		if result.next_href:
			self.hlp['next_href']=result.next_href
		else:
			self.isendoflist=True # hmm....

		if result:			
			followinglist=result.collection
			piclist=[]
			for fullitemresource in followinglist:
				fullitem=soundcloud_Resource(fullitemresource)
				thumb=''.join((self.skin_path, '/sc_default-t500x500.jpg'))
				if fullitem.avatar_url is not None:
					picurl, thumb=splitSoundcloudCoverurl(fullitem.avatar_url)
					if not fileExists(thumb):
						piclist.append(PicDownloadItem(url=picurl,filename=thumb,))
				list.append((SCAllItem(
					fullitem=fullitem, 
					mode='selectAction', 
					thumb=thumb, 
					isfollower=fullitem.id in self.TOKEN.myfollower_ids, 
					isfollowing=fullitem.id in self.TOKEN.myfollowing_ids),))
					
			l=len(list)-1
			if not isappend and l>1:
				self['list'].moveToIndex(1)
			headertext=headertext %(username, l)
			self.startAllPicDownloads(list, piclist, headertext, l, isappend)
		else:
			self.isendoflist=True
			headertext="No Followings found for %s" %username
			self['headertext'].setText(_(headertext))
			self['list'].setList(list)

	def buildFollowerlistInit(self, sel, lastmode):# USERFOLLOWINGSLIST
		logger.info('SCMain]buildFollowerlistInit]start')
		self.setButtons(red='Main menu')
		list=[(SCItem(text=_("[back]"), cache_it=True, mode=lastmode),)]
		self.buildFollowerslist(list, self.TOKEN.client.get('/users/%d/followers' %sel.fullitem.id), myenCode(sel.fullitem.username))


# my liked tracks 
	def buildMeLikedTracklist(self, cache_it=True, isappend=False):
		url='https://api-v2.soundcloud.com/users/%d/track_likes?representation=speedy&limit=10&offset=0&linked_partitioning=1' %self.TOKEN.me.id
		headertext="My liked tracks"
		self.buildTracklist(cache_it, isappend, url, headertext)
		
# user liked tracks
	def getUserLikedTracklist(self, cache_it=True, isappend=False): # "List liked tracks"), mode, sel
		sel=self.hlp.get('sel')
		url='https://api-v2.soundcloud.com/users/%d/track_likes?representation=speedy&limit=10&offset=0&linked_partitioning=1' %sel.fullitem.id
		headertext="%s liked tracks" %soundcloud_Resource(sel.fullitem.user).username
		self.buildTracklist(cache_it, isappend, url, headertext)
		
# user own tracks
	def userOwnTracklist(self, cache_it=True, isappend=False):# ok
		logger.info('SCMain]userOwnTracklist]Start')
		sel=self.hlp.get('sel')
		call='https://api-v2.soundcloud.com/users/%d/tracks?representation=&limit=20&offset=0&linked_partitioning=1' %sel.fullitem.id
		#call='https://api.soundcloud.com/users/%d/tracks?limit=14&offset=0&linked_partitioning=1' %sel.fullitem.id
		headertext="%s own tracks" %soundcloud_Resource(sel.fullitem.user).username
		self.buildTracklist(cache_it, isappend, call, headertext)

		
	def buildTracklist(self, cache_it, isappend, call, headertext):
		self.setButtons(red='Main menu', yellow=_('Sort list'))
		if not isappend:
			list=[(SCItem(text=_("[back]"), cache_it=cache_it, mode=self.hlp.get('lastmode', 'buildMainmenu')),)]
			self['headertext'].setText(_("Get Tracks..."))
			self['headertext'].startBlinking()
		else:
			list=self['list'].getList()
			self['headertext'].setText(_("Get more Tracks..."))
			self['headertext'].startBlinking()
		
		try:
			logger.info('SCMain]buildTracklist]isappend->%s call->%s' %(str(isappend), call))
			if not isappend:
				result=self.TOKEN.client.get(call)# [u'next_href', u'collection']
			else:
				result=self.TOKEN.client.get(self.hlp.get('next_href'))
		except Exception, e:
			logger.error('SCMain]buildTracklist]%s' %e)
			headertext="Error-->%s" %e
			self.setHeaderTextNow(headertext)
			self['list'].setList(list)
			return			
		
		if result.next_href:
			logger.info('SCMain]buildTracklist]result.next_href->%s' %result.next_href)
			self.hlp['next_href']=result.next_href
		else:
			logger.info('SCMain]buildTracklist]->isendoflist!')
			self.isendoflist=True
			
		if result.collection:
			for fullitem in result.collection:
				if fullitem.has_key('track'):
					track=soundcloud_Resource(soundcloud_Resource(fullitem).track)
				else:
					track=soundcloud_Resource(fullitem)
				#LOG('SCMain]buildTracklist]artwork_url->%s' %str(track.artwork_url))
				artwork_url, artwork_fn=self.resolveArtistartwork(track)
				mode=STARTPLAYER					
				list.append((SCItem(cache_it=cache_it, fullitem=track, mode=mode, thumb=artwork_fn, islike=track.id in self.TOKEN.mylikedTracks_ids, 
					iscomment=track.id in self.TOKEN.mycomment_ids, isfollower=track.id in self.TOKEN.myfollower_ids, 
					isfollowing=track.id in self.TOKEN.myfollowing_ids),))

			l=len(list)
			headertext=headertext+'(%d)' %(l-1)
			self.setListAndHeadertext(list, isappend, headertext)

		else:
			self['headertext'].setText(_("No Tracks found"))
			self['list'].setList(list)
	 
# user own playlists
	def userOwnPlaylists(self):	
		pass
		#qtracks = client.get('https://api-v2.soundcloud.com/tracks?urns=soundcloud%3Atracks%3A194823612%2Csoundcloud%3Atracks%3A196616038%2Csoundcloud%3Atracks%3A196783108%2Csoundcloud%3Atracks%3A196953200%2C')
		# 'https://api-v2.soundcloud.com/users/129490297/playlists?representation=speedy&limit=10&offset=0&linked_partitioning=1'

	def buildLikedTracklistold(self, sel, lastmode): #510, 522
		logger.info('SCMain]buildLikedTracklist]start, lastmode:%s, mode:%s' %(lastmode, self.mode))
		self.setButtons(red='Main menu', yellow=_('Sort list'))
		list=[(SCItem(text=_("[back]"), mode=lastmode),)]
		piclist=[]

		if self.mode==USERLIKEDTRACKLIST:# user liked tracks USERLIKEDTRACKLIST
			id=sel.fullitem.id
			likedtracks=self.TOKEN.client.get('/users/%d/favorites' %id, offset=0, limit=200)
		if likedtracks:
			for fullitem in likedtracks:
				iscomment, isfollowing, isfollower=False, False, False
				thumb=''.join((self.skin_path, '/cloud_300x300.jpg'))
				if fullitem.artwork_url is not None:
					picurl, thumb=splitSoundcloudCoverurl(fullitem.artwork_url)
					if not fileExists(thumb):
						piclist.append(PicDownloadItem(url=picurl,filename=thumb))
				if fullitem.id in self.TOKEN.mycomment_ids:
					iscomment=True
				if fullitem.id in self.TOKEN.myfollowing_ids:
					isfollowing=True
				if fullitem.id in self.TOKEN.myfollower_ids:
					isfollower=True
				list.append((SCItem(cache_it=True, fullitem=fullitem, mode=STARTPLAYER, thumb=thumb, islike=fullitem.user_favorite, iscomment=iscomment, isfollower=isfollower, isfollowing=isfollowing),))
			l=len(list)
			if self.mode==USERLIKEDTRACKLIST:# user liked tracks
				headertext="%s`s Liked Tracks(%d hits)" %(myenCode(sel.fullitem.username), l-1)
			if l>1:
				self['list'].moveToIndex(1)
			self['headertext'].setText(_(headertext))
			self.startAllPicDownloads(list, piclist, headertext, l)
		else:
			self['headertext'].setText(_("No Tracks found"))
			self['list'].setList(list)

	def cbSoundCloudSearch(self, retval=None, lastmode='buildMainmenu'): # 501 + 551
		logger.info('SCMain]cbSoundCloudSearch]retval%s lastmode%s' %(retval, lastmode))
		list=[(SCItem(text=_("[back]"), mode=lastmode),)]
		if retval is not None:
			if retval[1]=="Groups":
				logger.info('SCMain]cbSoundCloudSearch]start get Groups...')
				self.mode='buildGrouplist'
				self['list'].setMode(self.mode)
				self.hlp['retval']=retval
				self.buildGrouplist(list)
			elif retval[1]=="Tracks":
				self.mode='buildTrackslist'
				logger.info('SCMain]cbSoundCloudSearch]start get Tracks...')
				self['list'].setMode(self.mode)
				self.hlp['retval']=retval
				self.buildTrackslist(list)
			elif retval[1]=="Playlists":
				self.mode='buildPlaylistslist'
				logger.info('SCMain]cbSoundCloudSearch]start get Tracks...')
				self['list'].setMode(self.mode)
				self.hlp['retval']=retval
				self.buildPlaylistslist(list)

			elif retval[1]=="Users":
				self.mode='buildUserslist'
				logger.info('SCMain]cbSoundCloudSearch]start get Users...')
				self['list'].setMode(self.mode)
				self.hlp['retval']=retval
				self.hlp['lastmode']=lastmode
				self.buildUserslist()
			elif retval[1]=="Tags":
				self.mode='buildTrackslist'
				logger.info('SCMain]cbSoundCloudSearch]start get Genre...')
				self['list'].setMode(self.mode)
				self.hlp['retval']=retval
				self.buildTrackslist(list)
			else:
				logger.info('cbSoundCloudSearch]no match for %s' %retval[1])
		else:
			self['headertext'].setText(_("No result`s"))
			self['list'].setList(list)

# group
	def buildGrouplist(self, list, isappend=False):
		self.setButtons(red='Main menu')
		retval=self.hlp.get('retval')
		limit=20
		if not isappend:
			self['headertext'].setText(_("Start %s search for %s" %(retval[1], retval[0])))
			offset=0
			self.isendoflist=False
		else:
			self['headertext'].setText(_("Extend %s search for %s" %(retval[1], retval[0])))
			offset=self['list'].getItemCount()
		logger.info('buildGrouplist]offset=%d'%offset)
		try:
			groups=self.TOKEN.client.get('/groups', q=retval[0], offset=offset, limit=limit, filter='streamable')
		except Exception, e:
			logger.error('buildGrouplist]error:%s' %e)
			groups=[]
			self.session.open(MessageBox, _("Error: %s" %e), type=MessageBox.TYPE_ERROR, title="MusicCenter SoundCloud Search",timeout=6 )
		if groups:
			if len(groups) < limit:
				self.isendoflist=True
			piclist=[]
			
			newmode=self.mode +1
			for fullitem in groups:
				thumb=''.join((self.skin_path, '/sc_default-t500x500.jpg'))
				if fullitem.artwork_url is not None:
					picurl, thumb=splitSoundcloudCoverurl(fullitem.artwork_url)
					if not fileExists(thumb):
						piclist.append(PicDownloadItem(url=picurl,filename=thumb))
				iscomment, isfollowing, isfollower=False, False, False
				if fullitem.id in self.TOKEN.mycomment_ids:
					iscomment=True
				try:
					if fullitem.creator[u'id'] in self.TOKEN.myfollowing_ids:
						isfollowing=True
					if fullitem.creator[u'id'] is not None and fullitem.creator[u'id'] in myfollower_ids:
						isfollower=True
				except Exception, e:
					logger.info('SCMain]buildGrouplist]error->%s' %e)
				list.append((SCItem(cache_it=True, fullitem=fullitem, mode=newmode, thumb=thumb, islike=fullitem.user_favorite, iscomment=iscomment, isfollower=isfollower, isfollowing=isfollowing),)) #503,553
			self.saveSoundCloudSearchhistory(retval[0])
			l=len(list)
			headertext="%s for %s (%d hits)" %(retval[1], retval[0],(l-1))
			if not isappend and l>1:
				self['list'].moveToIndex(1)
			self.startAllPicDownloads(list, piclist, headertext, l)
		else:
			self['headertext'].setText(_("No Groups found for %s" %retval[0]))
			self['list'].setList(list)
		self.saveSoundCloudSearchhistory(retval[0])

	def buildGroupSonglist(self, list=[], isappend=False, sel=None, lastmode=None):# 508,558
		self['list'].setMode(self.mode)
		logger.info('SCMain]buildGroupSonglist]start')
		#####################################
		limit=30
		self.setButtons(red='Main menu', green='Play', yellow='Sort list')
		if not isappend:
			self.hlp['sel']=sel
			list=[(SCItem(text=_("[back]"), cache_it=True, mode=lastmode),)]
			self['headertext'].setText(_("Start build Group Songlist"))
			offset=0
			self.isendoflist=False
		else:
			sel=self.hlp.get('sel')
			self['headertext'].setText(_("Extend build Group Songlist"))
			offset=self['list'].getItemCount()
		logger.info('buildTrackslist]offset=%d'%offset)
		tracks=self.TOKEN.client.get('/groups/%d/tracks' %sel.fullitem.id, offset=offset, limit=limit, filter='streamable')
		if tracks:
			if len(tracks) < limit:
				self.isendoflist=True
			piclist=[]
			
			for fullitem in tracks:
				thumb=''.join((self.skin_path, '/sc_default-t500x500.jpg'))
				if fullitem.artwork_url is not None:
					picurl, thumb=splitSoundcloudCoverurl(fullitem.artwork_url)
					if not fileExists(thumb):
						piclist.append(PicDownloadItem(url=picurl,filename=thumb))
				iscomment, isfollowing, isfollower=False, False, False
				if fullitem.id in self.TOKEN.mycomment_ids:
					iscomment=True
				if fullitem.id in self.TOKEN.myfollowing_ids:
					isfollowing=True
				if fullitem.id in self.TOKEN.myfollower_ids:
					isfollower=True
				list.append((SCItem(cache_it=True, fullitem=fullitem, mode=STARTPLAYER, thumb=thumb, islike=fullitem.user_favorite, iscomment=iscomment, isfollower=isfollower, isfollowing=isfollowing),))
			l=len(list)
			headertext="Group %s (%d hits)" %(myenCode(sel.fullitem.name),(l-1))
			if not isappend and l>1:
				self['list'].moveToIndex(1)
			self.startAllPicDownloads(list, piclist, headertext, l)
		else:
			self['headertext'].setText(_("No Track found for %s" %retval[0]))
			self['list'].setList(list)

# tracks
	def buildTrackslist(self, list, isappend=False): #501, 551
		limit=30
		self.setButtons(red='Main menu', yellow=_('Sort list'))
		retval=self.hlp.get('retval')
		if not isappend:
			self['headertext'].setText(_("Start %s search for %s" %(retval[1], retval[0])))
			offset=0
			self.isendoflist=False
		else:
			self['headertext'].setText(_("Extend %s search for %s" %(retval[1], retval[0])))
			offset=self['list'].getItemCount()
		logger.info('buildTrackslist]offset=%d'%offset)
		if retval[1]=='Tracks':
			tracks=self.TOKEN.client.get('/tracks', q=retval[0], offset=offset, limit=limit, filter='streamable')
		elif retval[1]=='Tags':
			try:
				tracks=self.TOKEN.client.get('/tracks', tags=retval[0], offset=offset, limit=limit, filter='streamable')
				#tracks=self.TOKEN.client.get('/tracks', genres=retval[0], offset=offset, limit=limit, filter='streamable')
			except:
				tracks=[]
		if tracks:
			if len(tracks) < limit:
				self.isendoflist=True
			piclist=[]
			
			for fullitem in tracks:
				thumb=''.join((self.skin_path, '/sc_default-t500x500.jpg'))
				if fullitem.artwork_url is not None:
					picurl, thumb=splitSoundcloudCoverurl(fullitem.artwork_url)
					if not fileExists(thumb):
						piclist.append(PicDownloadItem(url=picurl,filename=thumb))
				iscomment, isfollowing, isfollower=False, False, False
				if fullitem.id in self.TOKEN.mycomment_ids:
					iscomment=True
				if fullitem.id in self.TOKEN.myfollowing_ids:
					isfollowing=True
				if fullitem.id in self.TOKEN.myfollower_ids:
					isfollower=True
				list.append((SCItem(cache_it=True, fullitem=fullitem, mode=STARTPLAYER, thumb=thumb, islike=fullitem.user_favorite, iscomment=iscomment, isfollower=isfollower, isfollowing=isfollowing),))
			self.saveSoundCloudSearchhistory(retval[0])
			l=len(list)
			headertext="%s for %s (%d hits)" %(retval[1], retval[0],(l-1))
			if not isappend and l>1:
				self['list'].moveToIndex(1)
			self.startAllPicDownloads(list, piclist, headertext, l)
		else:
			self['headertext'].setText(_("No Track found for %s" %retval[0]))
			self['list'].setList(list)
#me  liked playlists
	def buildMeLikedPlaylists(self, cache_it=True, list=[], isappend=False):
		self.setButtons(red='Main menu')

		list=[(SCItem(text=_("[back]"), cache_it=True, mode='buildMainmenu'),)]

		piclist=[]
		try:
			if not isappend:
				result=self.TOKEN.client.get('/e1/me/playlist_likes', limit=20 ,offset=0, linked_partitioning=1)# [u'next_href', u'collection']
			else:
				result=self.TOKEN.client.get(self.hlp.get('next_href'))
		except Exception, e:
			logger.error('SCMain]buildMeLikedPlaylists]%s' %e)
			headertext="Error-->%s" %e
			self.setHeaderTextNow(headertext)
			self['list'].setList(list)
			return			
		
		if result.next_href:
			logger.info('SCMain]buildMeLikedPlaylists]result.next_href->%s' %result.next_href)
			self.hlp['next_href']=result.next_href
		else:
			logger.info('SCMain]buildMeLikedPlaylists]->isendoflist!')
			self.isendoflist=True
			
		liked_playlists=result.collection

		if liked_playlists:
			for fullitem in liked_playlists:
				fullitem=soundcloud_Resource(soundcloud_Resource(fullitem).playlist)
				logger.info('SCMain]buildMeLikedPlaylists]artwork_url->%s' %str(fullitem.artwork_url))
				artwork_url, artwork_fn=self.resolveArtistartwork(fullitem)
				logger.info('SCMain]buildMyActivityCollection]playlist found with %s tracks' %fullitem.track_count)
				
				mode='buildMyActivityPlaylistTracklist'				
				list.append((SCItem(cache_it=True, fullitem=fullitem, mode=mode, thumb=artwork_fn, islike=fullitem.id in self.TOKEN.mylikedPlaylists_ids, 
				iscomment=fullitem.id in self.TOKEN.mycomment_ids, isfollower=fullitem.id in self.TOKEN.myfollower_ids, 
				isfollowing=fullitem.id in self.TOKEN.myfollowing_ids, isplaylist_trackcount=fullitem.track_count, type='playlist'),))

			l=len(list)
			headertext="Likes (%d hits)" %(l-1)
			self.setListAndHeadertext(list, isappend, headertext)

		else:
			self['headertext'].setText(_("No Tracks found"))
			self['list'].setList(list)

	def buildMeLikedPlaylistTracklist(self, cache_it):
		sel=self.hlp.get('sel')
		url='/playlists/%d/tracks' %sel.fullitem.id
		playlist_title=myenCode(sel.fullitem.title)
		length=myenCode(sel.length)
		create_time=myenCode(sel.fullitem.created_at.split(' ',1)[0])
		headertext="%s (%s %s)" %(playlist_title, length, create_time)
		self.buildallPlaylistsTracklist(cache_it, url, headertext)

#get user own playlists
	def getUserOwnPlaylists(self, cache_it=True, list=[], isappend=False):
		sel=self.hlp.get('sel')
		url='https://api.soundcloud.com/users/%d/playlists?limit=20&offset=0&linked_partitioning=1' %sel.fullitem.id
		headertext='%s own playlists' %soundcloud_Resource(sel.fullitem.user).username
		self.buildPlaylist(cache_it, list, isappend, url, headertext)

#get user liked playlists
	def getUserLikedPlaylists(self, cache_it=True, list=[], isappend=False):
		sel=self.hlp.get('sel')
		url='https://api.soundcloud.com/e1/users/%d/playlist_likes?limit=5&offset=0&linked_partitioning=1' %sel.fullitem.id
		headertext='%s liked playlists' %soundcloud_Resource(sel.fullitem.user).username
		self.buildPlaylist(cache_it, list, isappend, url, headertext)
	
#get my own playlists
	def buildMeOwnPlaylists(self, cache_it=True, list=[], isappend=False):
		sel=self.TOKEN.me
		url='https://api.soundcloud.com/users/%d/playlists?limit=5&offset=0&linked_partitioning=1' %sel.id
		headertext='My own playlists' 
		self.buildPlaylist(cache_it, list, isappend, url, headertext)

#build all Playlists		
	def buildPlaylist(self, cache_it, list, isappend, url, headertext):
		self.setButtons(red='Main menu')
		
		list=[(SCItem(text=_("[back]"), cache_it=False, mode=self.hlp.get('lastmode', 'buildMainmenu')),)]

		piclist=[]
		
		try:
			if not isappend:
				result=self.TOKEN.client.get(url)
			else:
				result=self.TOKEN.client.get(self.hlp.get('next_href'))
		except Exception, e:
			logger.error('SCMain]buildPlaylist]%s' %e)
			headertext="Error-->%s" %e
			self.setHeaderTextNow(headertext)
			self['list'].setList(list)
			return			
		
		if result.next_href:
			logger.info('SCMain]buildPlaylist]result.next_href->%s' %result.next_href)
			self.hlp['next_href']=result.next_href
		else:
			logger.info('SCMain]buildPlaylist]->isendoflist!')
			self.isendoflist=True
			
		playlists=result.collection

		if playlists:
			for fullitem in playlists:
				if fullitem.has_key('playlist'):
					playlist=soundcloud_Resource(soundcloud_Resource(fullitem).playlist)
				else:
					playlist=soundcloud_Resource(fullitem)
					
				artwork_url, artwork_fn=self.resolveArtistartwork(playlist)
				
				mode=self.mode+'Tracklist'
				logger.info('SCMain]buildPlaylist]new mode for next Tracklist->%s' %mode)
				list.append((SCItem(cache_it=True, fullitem=playlist, mode=mode, thumb=artwork_fn, islike=playlist.id in self.TOKEN.mylikedPlaylists_ids, 
				iscomment=playlist.id in self.TOKEN.mycomment_ids, isfollower=playlist.id in self.TOKEN.myfollower_ids, 
				isfollowing=playlist.id in self.TOKEN.myfollowing_ids, isplaylist_trackcount=playlist.track_count, type='playlist'),))

			l=len(list)
			headertext=headertext+'(%d)' %(l-1)
			self.setListAndHeadertext(list, isappend, headertext)

		else:
			self['headertext'].setText(_("No Playlists found"))
			self['list'].setList(list)

# tracklist for all playlistmodes
	def buildallPlaylistsTracklist(self, cache_it, url, headertext):
		logger.info('SCMain]buildallPlaylistsTracklist]url->%s' %url)
		self.setButtons(red='Main menu', green=_('play'), yellow=_('Sort list'))
		self['headertext'].setText(_("Build tracklist..."))		
		self['headertext'].startBlinking()
		list=[(SCItem(text=_("[back]"), cache_it=True, mode=self.hlp.get('lastmode')),)] # buildMyActivitylistPlaylists
		try:
			tracks=self.TOKEN.client.get(url)
		except Exception, e:
			logger.error('SCMain]buildallPlaylistsTracklist]%s' %e)
			headertext="Error-->%s" %e
			tracks=''
			
		if tracks:
			for track in tracks.data:
			
				artwork_url, artwork_fn=self.resolveArtistartwork(track)

				list.append((SCItem(cache_it=True, fullitem=track, 
					mode=STARTPLAYER, 
					thumb=artwork_fn, 
					islike=track.id in self.TOKEN.mylikedTracks_ids, 
					iscomment=track.id in self.TOKEN.mycomment_ids, 
					isfollower=track.id in self.TOKEN.myfollower_ids, 
					isfollowing=track.id in self.TOKEN.myfollowing_ids, 
					),))
				
			l=len(list)
			headertext=headertext+' (%d)' %(l-1)
			
		self.setListAndHeadertext(list=list, headertext=headertext)
		
	def buildPlaylistslist(self, list, isappend=False): # 502,552
		self.setButtons(red='Main menu')
		retval=self.hlp.get('retval')
		limit=10
		if not isappend:
			self['headertext'].setText(_("Start %s search for %s" %(retval[1], retval[0])))
			offset=0
			self.isendoflist=False
		else:
			self['headertext'].setText(_("Extend %s search for %s" %(retval[1], retval[0])))
			offset=self['list'].getItemCount()
		logger.info('buildPlaylistslist]offset=%d'%offset)
		try:
			e=''
			playlists=self.TOKEN.client.get('/playlists', q=retval[0], offset=offset, limit=limit, filter='streamable')
		except Exception, e:
			logger.error('buildPlaylistslist]error:%s' %e)
			playlists=[]
		if playlists:
			if len(playlists) < limit:
				self.isendoflist=True
			piclist=[]
			
			newmode='buildPlaylistTracklistInit' # old was mode +1
			for fullitem in playlists:
				thumb=''.join((self.skin_path, '/sc_default-t500x500.jpg'))
				if fullitem.artwork_url is not None:
					picurl, thumb=splitSoundcloudCoverurl(fullitem.artwork_url)
					if not fileExists(thumb):
						piclist.append(PicDownloadItem(url=picurl,filename=thumb))
				iscomment, isfollowing, isfollower=False, False, False
				if fullitem.id in self.TOKEN.mycomment_ids:
					iscomment=True
				if fullitem.id in self.TOKEN.myfollowing_ids:
					isfollowing=True
				if fullitem.id in self.TOKEN.myfollower_ids:
					isfollower=True
				list.append((SCItem(cache_it=True, fullitem=fullitem, mode=newmode, thumb=thumb, islike=fullitem.user_favorite, iscomment=iscomment, isfollower=isfollower, isfollowing=isfollowing),)) #503,553
			self.saveSoundCloudSearchhistory(retval[0])
			l=len(list)
			headertext="%s for %s (%d hits)" %(retval[1], retval[0],(l-1))
			if not isappend and l>1:
				self['list'].moveToIndex(1)
			self.startAllPicDownloads(list, piclist, headertext, l)
		else:
			if e:
				text="Error -->%s" %e
			else:
				text="No Track found for %s %s" %retval[0]		
			self['headertext'].setText(_(text))
			self['list'].setList(list)
		self.saveSoundCloudSearchhistory(retval[0])

	def buildPlaylistTracklistInit(self, cache_it):
		self.setButtons(red='Main menu', yellow=_('Sort list'))
		sel=self.hlp.get('sel')
		lastmode=self.hlp.get('lastmode')
		self.buildPlaylistTracklist( sel, lastmode)
	
	def buildPlaylistTracklist(self, sel, lastmode):# 503,553
		self['list'].setMode(self.mode)
		logger.info('SCMain]buildPlaylistTracklist]start')
		self.setButtons(red='Main menu', yellow=_('Sort list'))
		list=[(SCItem(text=_("[back]"), cache_it=True, mode=lastmode),)]
		tracks= sel.fullitem.tracks
		setid=sel.fullitem.id
		if tracks:
			piclist=[]
			for itemdict in tracks:
				fullitem=soundcloud_Resource(itemdict)
				islike, iscomment=False, False
				thumb=''.join((self.skin_path, '/sc_default-t500x500.jpg'))
				if fullitem.artwork_url is not None:
					picurl, thumb=splitSoundcloudCoverurl(fullitem.artwork_url)
					if not fileExists(thumb):
						piclist.append(PicDownloadItem(url=picurl,filename=thumb))
				iscomment, isfollowing, isfollower=False, False, False
				if fullitem.id in self.TOKEN.mycomment_ids:
					iscomment=True
				if fullitem.id in self.TOKEN.myfollowing_ids:
					isfollowing=True
				if fullitem.id in self.TOKEN.myfollower_ids:
					isfollower=True
				# text entry is to get id of playlist, is dirty here
				list.append((SCItem(cache_it=True, text=setid, fullitem=fullitem, mode=STARTPLAYER, thumb=thumb, islike=fullitem.user_favorite, iscomment=iscomment, isfollower=isfollower, isfollowing=isfollowing),))
			if self.hlp.get('retval') is not None:
				self.saveSoundCloudSearchhistory(self.hlp.get('retval')[0])
			l=len(list)
			headertext="Tracks for %s (%d hits)" %(myenCode(sel.fullitem.title),(l-1))
			if l>1:
				self['list'].moveToIndex(1)
			self.startAllPicDownloads(list, piclist, headertext, l)
		else:
			self['headertext'].setText(_("No Tracks found %s" %myenCode(sel.fullitem.title)))
			self['list'].setList(list)

	def buildUserslist(self, cache_it=False, list=[], isappend=False): # 505,555
		
		if not isappend:
			lastmode=self.hlp.get('lastmode', 'buildMainmenu')
			list=[(SCItem(text=_("[back]"), cache_it=True, mode=lastmode),)]
				
		limit=30
		retval=self.hlp.get('retval')
		self.setButtons(red='Main menu')
		logger.info('SCMain]buildUserslist]start')
		if not isappend:
			self['headertext'].setText(_("Start %s search for %s" %(retval[1], retval[0])))
			offset=0
			self.isendoflist=False
		else:
			self['headertext'].setText(_("Extend %s search for %s" %(retval[1], retval[0])))
			offset=self['list'].getItemCount()
		logger.info('buildUserslist]offset=%d'%offset)
		users=self.TOKEN.client.get('/users', q='%s' %retval[0], offset=offset, limit=limit)
		piclist=[]
		if users:
			if len(users) < limit:
				self.isendoflist=True
			for fullitem in users:
				thumb= ''.join((self.skin_path, '/useravatar_x100.png'))
				if fullitem.avatar_url is not None:
					picurl, thumb=splitSoundcloudCoverurl(fullitem.avatar_url)
					if not fileExists(thumb):
						piclist.append(PicDownloadItem(url=picurl,filename=thumb,))
				isfollowing, isfollower=False, False
				if fullitem.id in self.TOKEN.myfollowing_ids:
					isfollowing=True
				if fullitem.id in self.TOKEN.myfollower_ids:
					isfollower=True
				list.append((SCAllItem(fullitem=fullitem, mode='selectAction', thumb=thumb, isfollower=isfollower, isfollowing=isfollowing),)) # FOLLOWINGUSERTRACKLIST
			l=len(list)-1
			headertext="%s for %s (%d hits)" %(retval[1], retval[0],(l-1))
			if not isappend and l>1:
				self['list'].moveToIndex(1)
			self.startAllPicDownloads(list, piclist, headertext, l)
		else:
			self['headertext'].setText(_("No %s found %s" %(retval[1], retval[0])))
			self['list'].setList(list)
		self.saveSoundCloudSearchhistory(retval[0])

	def buildUsersTracklistInit(self, sel, lastmode): # FOLLOWINGUSERTRACKLIST
		logger.info('SCMain]buildUsersTracklistInit]id:%s' %sel.fullitem.id)
		list=[(SCItem(text=_("[back]"), cache_it=True, mode=lastmode),)]
		self.hlp['username']=myenCode(sel.fullitem.username)
		self.hlp['id']=sel.fullitem.id
		self.buildUserTracklist(list)

	def buildMyCommentslist(self):
		self.setButtons(red='Main menu')
		logger.info('buildMyCommentslist]Start')
		self['list'].setMode(self.mode)
		list=[(SCItem(text=_("[back]"), cache_it=True, mode='buildMainmenu'),)]
		piclist=[]
		commentslist=self.TOKEN.mycomments
		for fullitem in commentslist:
			thumb=''.join((self.skin_path, 'sc_default-t500x500.jpg'))
			if fullitem.user[u'avatar_url'] is not None:
				picurl, thumb=splitSoundcloudCoverurl(fullitem.user[u'avatar_url'])
				if not fileExists(thumb):
					piclist.append(PicDownloadItem(url=picurl, filename=thumb))
			list.append((SCItem(cache_it=True, fullitem=fullitem, mode=MYCOMMENTLISTAFTER, thumb=thumb),))
		l=len(list)
		headertext="%s`s comments(%d hits)" %(l-1)
		if l>1:
			self['list'].moveToIndex(1)
		self.startAllPicDownloads(list, piclist, headertext, l)

	def startAllPicDownloads(self, list, piclist, headertext, l, isappend=False):
		if piclist:
			ds=defer.DeferredSemaphore(tokens=2)
			#downloads=[ ds.run(downloadFunction, item) for item in piclist]
			downloads=[ ds.run(downloadFunction, item).addCallback(self.finishedPicDownload, item) for item in piclist ]
			finished=defer.DeferredList(downloads).addCallback(self.finishedAllPicDownloads, list, headertext, piclist).addErrback(self.errorAllPicDownloads, list, headertext)
		else:
			self.setHeaderTextNow(headertext)
		self['list'].setList(list)
		if not isappend and l>1:
			self['list'].moveToIndex(1)


	def setHeaderTextNow(self, headertext): # ---->  old?
		self['headertext'].stopBlinking()
		self['headertext'].show()
		self['headertext'].setText(_(headertext))

	def setListAndHeadertext(self, list=[], isappend=False, headertext='No text given...'):
		logger.info('SCMain]setListAndHeadertext]start...')
		self['list'].setList(list)
		if not isappend and len(list)>1:
			self['list'].moveToIndex(1)
		else:
			if self.player!=None:
				songList, selected_index=self.resolveSonglist()
				if self.player.songList!=songList:
					logger.info('SCMain]setListAndHeadertext]songList is changed -> set new songlist')
					self.player.songList=songList
		self['headertext'].stopBlinking()
		self['headertext'].show()
		self['headertext'].setText(_(headertext))


	def finishedAllPicDownloads(self, result, list, headertext, piclist=[]):
		logger.info('SCMain]finishedAllPicDownloads]start')
		self.setHeaderTextNow(headertext)
		self['list'].setList(list)

	def errorAllPicDownloads(self, error=None, list =[], headertext=''):
		if error is not None:
			logger.info('SCMain]errorAllPicDownloads]error %s' %(error.getErrorMessage()))
			result=None
			self.finishedAllPicDownloads(result, list, headertext + error.getErrorMessage())

	def buildSoundCloudSearchhistory(self, cache_it=False):
		self.hlp['keylist']=0
		self.setButtons(red="Tracks", green="Playlists", yellow="Users", blue="Groups")
		self.searchlist=0
		list=[(SCItem(text=_("[back]"), cache_it=True, mode='buildMainmenu'),)]
		for i in self.soundcloudsearchhist:
			list.append((SCItem(text=i.strip(), mode=551),))
		l=len(list)
		self['headertext'].setText(_("SoundCloud searchhistory %d entry`s")%(l-1))
		self['list'].setList(list)
		if l > 1:
			self['list'].moveToIndex(1)

	def saveSoundCloudSearchhistory(self, retval):
		for e in self.soundcloudsearchhist:
			if (retval + '\n')==e:
				logger.info('saveSoundCloudSearchhistory]searchword:%s is in list, return!' %retval)
				return
		logger.info('saveSoundCloudSearchhistory]add searchword to list:%s'%retval)
		self.soundcloudsearchhist.insert(0,retval + '\n')
		with open(SCSEARCHHIST, 'w') as newlst:
			for l in self.soundcloudsearchhist:
				newlst.write(l)

	def removeItemFromList(self):
		sel=self.getCurrentSelection()
		if sel is not None:
			self.removeSoundCloudSearchhistory(sel.text)
			self.buildSoundCloudSearchhistory()

	def removeSoundCloudSearchhistory(self, retval):
		retval=retval.strip()
		for i, e in enumerate(self.soundcloudsearchhist):
			logger.info('removeSoundCloudSearchhistory]retval:%s e:%s' %(retval, e))
			if (retval+'\n'.strip())==e.strip():
				logger.info('removeSoundCloudSearchhistory]remove:%s index:%d' %(retval, i))
				self.soundcloudsearchhist.pop(i)
		logger.info('removeSoundCloudSearchhistory]save new list')
		with open(SCSEARCHHIST, 'w') as newlst:
			for l in self.soundcloudsearchhist:
				newlst.write(l)
# buttons
	def setButtons(self, red='', green='', yellow='', blue=''):
		self["key_red"].setText(red)
		self["key_green"].setText(green)
		self["key_yellow"].setText(yellow)
		self["key_blue"].setText(blue)
	
	def getButtons(self):
		return (self["key_red"].getText(), self["key_green"].getText(), self["key_yellow"].getText(), self["key_blue"].getText())

	def resolveSonglist(self):
		selected_index=self['list'].getCurrentIndex() -1
		songList=[]
		
		for index, song in enumerate(self['list'].getList()[1:]):
			if song[0].type not in ('playlist','playlist-repost'):
				songList.append(song)
			else:
				if index<selected_index:
					selected_index-=1
		logger.info('SCMain]resolveSonglist]selected index->%d len songlist->%d'%(selected_index, len(songList)))
		return songList, selected_index

	def greenPressed(self, from_ok=False):
		logger.info('SCMain]greenPressed]mode is:%s'%self.mode)
		if not from_ok:
			if self.mode=='buildSoundCloudSearchhistory':
				#self.mode=551
				sel=self.getCurrentSelection().text
				logger.info('SCMain]redPressed]sel is %s' %sel)
				self.cbSoundCloudSearch(retval=(self.getCurrentSelection().text, 'Playlists'), lastmode='buildSoundCloudSearchhistory')
			return
		else:
			songList, selected_index=self.resolveSonglist()
			if self.player!=None:
				if self.player.playermode!=SOUNDCLOUDMODE:
					logger.info('SCMain]greenPressed]is player, but not Soundcloud, close Player')
					self.closePlayerNow()
				else:
					logger.info('SCMain]greenPressed]is playermode 2 and songList')
					if self.player.songList!=songList:
						logger.info('SCMain]greenPressed]songList is changed -> new songlist and track')
						#self.player.songList=[]
						self.player.songList=songList
					else:
						logger.info('SCMain]greenPressed]songList is unchanged -> only skip track')
					self.player.playSong(selected_index)

			if self.player is None: 
				import SoundCloudPlayer
				r=reload(SoundCloudPlayer)
				self.player=self.session.instantiateDialog(SoundCloudPlayer.SCPlayer, songList=songList, index=selected_index, sc_client=self.TOKEN, playermode=SOUNDCLOUDMODE, soundcloudInstance=self)
			self.session.execDialog(self.player)

	def redPressed(self, from_ok=False):
		logger.info('SCMain]redPressed]mode %s' %self.mode)
		#if not from_ok:
		if self.mode=='buildSoundCloudSearchhistory':
			self['list'].setMode(self.mode)
			sel=self.getCurrentSelection().text
			logger.info('SCMain]redPressed]sel is %s' %sel)
			if self.hlp.get('keylist')==0:
				self.cbSoundCloudSearch(retval=(self.getCurrentSelection().text, 'Tracks'), lastmode='buildSoundCloudSearchhistory')
			elif self.hlp.get('keylist')==1:
				self.cbSoundCloudSearch(retval=(self.getCurrentSelection().text, 'Tags'), lastmode='buildSoundCloudSearchhistory')
		else:
			self.cachedict=[]
			self.setButtons()
			self.mode='buildMainmenu'
			self['list'].setMode(self.mode)
			self.buildMainmenu()

	def yellowPressed(self, from_ok=False):
		logger.info('SCMain]yellowPressed]mode %s' %self.mode)
		if not from_ok:
			if self.mode=='buildSoundCloudSearchhistory':
				#self.mode=551
				sel=self.getCurrentSelection().text
				logger.info('SCMain]redPressed]sel is %s' %sel)
				self.cbSoundCloudSearch(retval=(self.getCurrentSelection().text, 'Users'), lastmode='buildSoundCloudSearchhistory')
			elif self.mode in (SEARCH, 551, FOLLOWINGUSERTRACKLIST, 503, 553, MYLIKEDPLAYLISTTRACKLIST, USERLIKEDTRACKLIST) or isinstance( self.mode, str ) and self.mode in ('buildMyActivityCollection', 'buildMeLikedTracklist'):
				self.buildSort()

	def bluePressed(self, from_ok=False):
		logger.info('SCMain]bluePressed]')
		if not from_ok:
			if self.mode=='buildSoundCloudSearchhistory':
				sel=self.getCurrentSelection().text
				logger.info('SCMain]redPressed]sel is %s' %sel)
				self.cbSoundCloudSearch(retval=(self.getCurrentSelection().text, 'Groups'), lastmode='buildSoundCloudSearchhistory')		

	def getCurrentSelection(self):
		try: sel=self['list'].l.getCurrentSelection()[0]
		except: sel=None
		return sel

	def buildSort(self):
		options=[]
		options.append((_("Sort by Createdate"), self.sortByCreatedate),)
		options.append((_("Sort by Plays"), self.sortByPlays),)
		options.append((_("Sort by Likes"), self.sortByLikes),)
		options.append((_("Sort by Comments"), self.sortByCComments),)
		options.append((_("Sort by Users"), self.sortByUsers),)
		options.append((_("Sort by Title"), self.sortByTitle),)
		self.session.openWithCallback(self.genrerallyCallback, ChoiceBox,list=options)

	def sortByCreatedate(self):
		l=self['list'].getList()
		self['list'].setList(l[:1] + sorted(l[1:], key=lambda a:a[0].date, reverse=True))
		self['headertext'].setText(self['headertext'].getText().split(' sort by')[0] + ' sort by Dates')
		self['list'].moveToIndex(1)

	def sortByTitle(self):
		l=self['list'].getList()
		self['list'].setList(l[:1] + sorted(l[1:], key=lambda a:a[0].title))
		self['headertext'].setText(self['headertext'].getText().split(' sort by')[0] + ' sort by Titles')
		self['list'].moveToIndex(1)

	def sortByUsers(self):
		l=self['list'].getList()
		self['list'].setList(l[:1] + sorted(l[1:], key=lambda a:a[0].artist))
		self['headertext'].setText(self['headertext'].getText().split(' sort by')[0] + ' sort by Users')
		self['list'].moveToIndex(1)

	def sortByPlays(self):
		l=self['list'].getList()
		self['list'].setList(l[:1] + sorted(l[1:], key=lambda a:int(a[0].playback_count), reverse=True))
		self['headertext'].setText(self['headertext'].getText().split(' sort by')[0] + ' sort by Plays')
		self['list'].moveToIndex(1)

	def sortByLikes(self):
		l=self['list'].getList()
		self['list'].setList(l[:1] + sorted(l[1:], key=lambda a:int(a[0].favoritings_count), reverse=True))
		self['headertext'].setText(self['headertext'].getText().split(' sort by')[0] + ' sort by Likes')
		self['list'].moveToIndex(1)

	def sortByCComments(self):
		l=self['list'].getList()
		self['list'].setList(l[:0] + sorted(l[1:], key=lambda a:int(a[0].comment_count), reverse=True))
		self['headertext'].setText(self['headertext'].getText().split(' sort by')[0] + ' sort by Comments')
		self['list'].moveToIndex(1)

	def config(self):
		self.session.open(MusicCenterSetup, 2)

	def getuseravatar(self):
		downloadPage(myenCode(self.TOKEN.me.avatar_url.replace('https://','http://').replace('large','t500x500')), '/tmp/mc/useravatar').addCallback(self.useravatarShow).addErrback(self.useravatarDlError)

	def useravatarShow(self, result):
		thumb='/tmp/mc/useravatar'
		self.TOKEN.useravatar=thumb
		self["useravatar"].doshow(thumb)
		logger.info('SCMain]userartShow]done...')

	def useravatarDlError(self, error):
		logger.error('SCMain]useravatarDlError]%s' %error)

	def keyNumberPressed(self, number):
		if number==0 and self.mode!='buildMainmenu':
			self['list'].moveToIndex(0)
			self.ok()

	def clearCache(self, key=None):
		logger.info('SCMain]clearCache]start')
		if key!=None:
			self.cachedict.pop(key)
		else:
			self.cachedict={}

	def closePlayerNow(self):
		logger.info('SCMain]closePlayerNow]')
		self.player.closePlayer()
		self.session.deleteDialog(self.player) #self.player.doClose()
		self.player=None

	def closing(self, cache_it=None):
		logger.info('SCMain]closing]mode is %s' %self.mode)
		if self.mode not in ('buildMainmenu', 'closing'):
			self.keyNumberPressed(0)
		else:
			self.clearCache()
			self.close(self.player, self.TOKEN)

	def __onClose(self):
		logger.info('SCMain]__onClose]')
		self.getSoundCloudaccesstoken_mc_conn=None


class SCList(MenuList):
		
	def __init__(self, list, enableWrapAround = True):
	
		logger.info('SCList]__init__]')
		MenuList.__init__(self, list, enableWrapAround, eListboxPythonMultiContent)
		
		if RESOLUTIONx==1920:
			self.rfactor=1.5
			self.l.setFont(0, gFont("SansReg", 35))
			self.l.setFont(1, gFont("SansReg", 26))
			self.l.setFont(2, gFont("SansReg", 23))
			self.picloader_92 = PicLoaderScale(138, 138, transparent=False, cached=False, name='SCList_92')
			self.picloader_100 = PicLoaderScale(150, 150, transparent=False, cached=False, name='SCList_100')
		else:
			self.rfactor=1
			self.l.setFont(0, gFont("SansReg", 24))
			self.l.setFont(1, gFont("SansReg", 18))
			self.l.setFont(2, gFont("SansReg", 17))
			self.picloader_92 = PicLoaderScale(92, 92, transparent=False, cached=False, name='SCList_92')
			self.picloader_100 = PicLoaderScale(100, 100, transparent=False, cached=False, name='SCList_100')

		self.l.setItemHeight(int(114*self.rfactor))
		self.l.setBuildFunc(self.buildSCTracksentry)

		self.onSelectionChanged = [ ]
		self.mode = MYLIKEDPLAYLISTTRACKLIST
		self.list = []

	def destroy(self):
		#LOG('SCList]destroy]')
		self.picloader_100.destroy()
		self.picloader_92.destroy()

	def getRes(self):
		esize = self.l.getItemSize()
		return esize.width(), esize.height()
		
	def connectSelChanged(self, fnc):
		if not fnc in self.onSelectionChanged:
			self.onSelectionChanged.append(fnc)

	def disconnectSelChanged(self, fnc):
		if fnc in self.onSelectionChanged:
			self.onSelectionChanged.remove(fnc)

	def selectionChanged(self):
		for x in self.onSelectionChanged:
			x()

	def getCurrent(self):
		cur = self.l.getCurrentSelection()
		return cur and cur[0]

	GUI_WIDGET = eListbox

	def postWidgetCreate(self, instance):
		instance.setContent(self.l)
		self.selectionChanged_conn = instance.selectionChanged.connect(self.selectionChanged)
		if self.enableWrapAround:
			self.instance.setWrapAround(True)

	def moveToIndex(self, index):
		self.instance.moveSelectionTo(index)

	def getCurrentIndex(self):
		return self.instance.getCurrentIndex()

	currentIndex = property(getCurrentIndex, moveToIndex)
	currentSelection = property(getCurrent)

	def pageUp(self):
		if self.instance is not None:
			self.instance.moveSelection(self.instance.pageUp)

	def pageDown(self):
		if self.instance is not None:
			self.instance.moveSelection(self.instance.pageDown)

	def up(self):
		if self.instance is not None:
			self.instance.moveSelection(self.instance.moveUp)

	def down(self):
		if self.instance is not None:
			self.instance.moveSelection(self.instance.moveDown)

	def setList(self, mylist):
		self.list = mylist
		self.l.setList(mylist)

	def getItemCount(self):
		return len(self.list)

	def getList(self):
		return self.list

	def removeItem(self, index):
		del self.list[index]
		self.l.entryRemoved(index)

	def setMode(self, mode):
		logger.info('SCList]setMode] mode %s' %mode)
		self.mode = mode
		if isinstance( mode, str ) and mode in ('buildUserslist', 'buildMyFollowingsUserlist','buildFollowerslist', 'buildMyFollowerlist', 'buildFollowerlistInit', 'buildMyFollowersUserlist'):
			self.l.setBuildFunc(self.buildSCUser)
			self.l.setItemHeight(int(114*self.rfactor))
		elif isinstance( mode, str ) and mode in ('buildMyCommentslist',):# comments
			self.l.setBuildFunc(self.buildSCCommententry)
			self.l.setItemHeight(int(101*self.rfactor))
		elif isinstance( mode, str ) and mode in ('buildGrouplist',):
			self.l.setBuildFunc(self.buildSCGrouplistsentry)
			self.l.setItemHeight(int(114*self.rfactor))
		elif isinstance( mode, str ) and mode in ('buildMainmenu', 'exploreGenres', 'buildSoundCloudSearchhistory'):
			self.l.setBuildFunc(self.buildEntryMini)
			self.l.setItemHeight(int(30*self.rfactor))
		else:
			self.l.setBuildFunc(self.buildSCTracksentry)
			self.l.setItemHeight(int(114*self.rfactor))
			
	def getMode(self):
		return self.mode

	def buildEntryMini(self, item):
		#LOG('SCList]buildEntryMini]__dict__->%s' %str(item.__dict__))
		width, height = self.getRes()
		if item.text in ("[back]", "[zurück]"):
			return [None, (eListboxPythonMultiContent.TYPE_TEXT, 20*self.rfactor, 0, width, height, 0, RT_HALIGN_CENTER|RT_VALIGN_CENTER, "%s" % item.text)]
		else:
			return [None, (eListboxPythonMultiContent.TYPE_TEXT, 20*self.rfactor, 0, width, height, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, "%s" % item.text) ]

	def buildSCTracksentry(self, item): # 114
		logger.info('SCList]buildSCTracksentry]__dict__->%s' %str(item.__dict__))
		width, height = self.getRes()
		rfactor=self.rfactor
		res = [ None ]
		p='/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/'
		if item.text in ("[back]", '[zur\xc3\xbcck]'):# item.cache_it or 
			res.append((eListboxPythonMultiContent.TYPE_TEXT, 0, 0, width, height, 0, RT_HALIGN_CENTER|RT_VALIGN_CENTER, "%s" % item.text))
		else:
			offset_title=0
			if item.type in ('track', 'track-repost'):
				if fileExists(item.thumb):
					ptr = self.picloader_100.load(item.thumb)
				else:
					ptr=LoadPixmap(cached=True, path=p+'cloud_x100.png')	
				res.append((eListboxPythonMultiContent.TYPE_PIXMAP, int(7*rfactor), int(7*rfactor), 100*rfactor, 100*rfactor, ptr))
				if item.type=='track':
					res.append((eListboxPythonMultiContent.TYPE_TEXT, 120*rfactor, 2*rfactor, 50*rfactor, 24*rfactor, 2, RT_HALIGN_LEFT|RT_VALIGN_CENTER, 'NEW'))
					offset_title=50*rfactor
			elif item.type in ('playlist','playlist-repost'):
				res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 1, 1, 112*rfactor, 112*rfactor, LoadPixmap(cached=True, path=p+'playlist_cover_112.png')))
				if fileExists(item.thumb):
					ptr = self.picloader_92.load(item.thumb)
				else:
					ptr=self.picloader_92.load(p+'cloud_x100.png')
				res.append((eListboxPythonMultiContent.TYPE_PIXMAP, 12*rfactor, 10*rfactor, 92*rfactor, 92*rfactor, ptr))
			res.append((eListboxPythonMultiContent.TYPE_TEXT,        120*rfactor+offset_title,  2*rfactor, width- 280*rfactor, 28*rfactor, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, item.title))
			res.append((eListboxPythonMultiContent.TYPE_TEXT, width-150*rfactor,  2*rfactor, 150*rfactor, 20*rfactor, 1, RT_HALIGN_CENTER|RT_VALIGN_CENTER, item.length))
			if item.isfollowing and not item.isfollower:
				res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 82*rfactor, 34*rfactor, 22*rfactor, 22*rfactor, LoadPixmap(cached=True, path=p+'following_x22.png')))
				offset = 26
			elif item.isfollower and not item.isfollowing:
				res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 82*rfactor, 34*rfactor, 22*rfactor, 22*rfactor, LoadPixmap(cached=True, path=p+'follower_x22.png')))
				offset = 26
			elif item.isfollower and item.isfollowing:
				res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 82*rfactor, 34*rfactor, 22*rfactor, 22*rfactor, LoadPixmap(cached=True, path=p+'following_x22.png')))
				res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, (82+26)*rfactor, 34*rfactor, 22*rfactor, 22*rfactor, LoadPixmap(cached=True, path=p+'follower_x22.png')))
				offset = 52
			else:
				offset = 0
			res.append((eListboxPythonMultiContent.TYPE_TEXT,        (120+offset)*rfactor, 34*rfactor, 500*rfactor, 20*rfactor, 1, RT_HALIGN_LEFT|RT_VALIGN_CENTER, item.artist))
			res.append((eListboxPythonMultiContent.TYPE_TEXT, width-400*rfactor, 34*rfactor, 150*rfactor, 20*rfactor, 1, RT_HALIGN_CENTER|RT_VALIGN_CENTER, item.genre))
			res.append((eListboxPythonMultiContent.TYPE_TEXT, width-150*rfactor, 34*rfactor, 150*rfactor, 20*rfactor, 1, RT_HALIGN_CENTER|RT_VALIGN_CENTER, item.date)) # upload date
			if item.type in ('track', 'track-repost'):
				res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 120*rfactor, 60*rfactor, 22*rfactor, 22*rfactor, LoadPixmap(cached=True, path=p+'play_22x22.png')))
				res.append((eListboxPythonMultiContent.TYPE_TEXT,	 150*rfactor, 60*rfactor, 150*rfactor, 16*rfactor, 2, RT_HALIGN_LEFT|RT_VALIGN_CENTER, (item.playback_count)))
				if item.iscomment:			
					res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 280*rfactor, 60*rfactor, 20*rfactor, 20*rfactor, LoadPixmap(cached=True, path=p+'comment20_orange.png')))
				else:
					res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 280*rfactor, 60*rfactor, 20*rfactor, 20*rfactor, LoadPixmap(cached=True, path=p+'comment20_white.png')))
				res.append((eListboxPythonMultiContent.TYPE_TEXT,	     310*rfactor, 60*rfactor, 150*rfactor, 16*rfactor, 2, RT_HALIGN_LEFT|RT_VALIGN_CENTER, (item.comment_count)))
			elif item.type in ('playlist','playlist-repost'):
				res.append((eListboxPythonMultiContent.TYPE_TEXT,	 150*rfactor, 60*rfactor, 300*rfactor, 16*rfactor, 2, RT_HALIGN_CENTER|RT_VALIGN_CENTER, ('Playlist %s Tracks' %item.isplaylist_trackcount)))
			else:
				logger.info('')
			if item.islike:
				res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 480*rfactor, 60*rfactor, 20*rfactor, 20*rfactor, LoadPixmap(cached=True, path=p+'heart20_orange.png')))
			else:
				res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 480*rfactor, 60*rfactor, 20*rfactor, 20*rfactor, LoadPixmap(cached=True, path=p+'heart20_white.png')))
			res.append((eListboxPythonMultiContent.TYPE_TEXT,	     510*rfactor, 60*rfactor, 150*rfactor, 16*rfactor, 2, RT_HALIGN_LEFT|RT_VALIGN_CENTER, (item.likes_count)))
			if item.downloadable:
				res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, width-200*rfactor, 60*rfactor, 20*rfactor, 20*rfactor, LoadPixmap(cached=True, path=p+'download_20x20.png')))
			if item.video_url:
				res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, width-355*rfactor, 60*rfactor, 50*rfactor, 24*rfactor, LoadPixmap(cached=True, path=p+'youtube_50x25.png')))
			if item.type=='track-repost':
				res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 120*rfactor, 86*rfactor, 18*rfactor, 16*rfactor, LoadPixmap(cached=True, path=p+'repost_x16.png')))
				res.append((eListboxPythonMultiContent.TYPE_TEXT, (120+5+18)*rfactor, 85*rfactor, 300*rfactor, 24*rfactor, 2, RT_HALIGN_LEFT|RT_VALIGN_CENTER, item.reposted_by))
				
		return res
		
	def buildSCPlaylistsentry(self, item): # 114
		res = [ None ]
		p='/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/'
		if item.cache_it or item.text in ("[back]", "[zurück]"):
			res.append((eListboxPythonMultiContent.TYPE_TEXT, 0, 22, 1180 , 28, 0, RT_HALIGN_CENTER|RT_VALIGN_CENTER, "%s" % item.text))
		else:
			res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 1, 1, 113, 113, LoadPixmap(cached=True, path=p+'playlist_cover_112.png')))
			if fileExists(item.thumb):
				fn=item.thumb
			else:
				fn=path=p+'cloud_x100.png'
			ptr = self.picloader_92.load(item.thumb)
			res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 12, 10, 93, 93, ptr))
			if item.isfollowing and not item.isfollower:
				res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 82, 35, 22, 22, LoadPixmap(cached=True, path=p+'following_x22.png')))
				offset = 26
			elif item.isfollower and not item.isfollowing:
				res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 82, 35, 22, 22, LoadPixmap(cached=True, path=p+'follower_x22.png')))
				offset = 26
			elif item.isfollower and item.isfollowing:
				res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 82, 35, 22, 22, LoadPixmap(cached=True, path=p+'following_x22.png')))
				res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 82+26, 35, 22, 22, LoadPixmap(cached=True, path=p+'follower_x22.png')))
				offset = 52
			else:
				offset = 0
			res.append((eListboxPythonMultiContent.TYPE_TEXT,   100+offset, 35, 900, 20, 1, RT_HALIGN_LEFT|RT_VALIGN_CENTER, item.artist))
			res.append((eListboxPythonMultiContent.TYPE_TEXT,   100,  4, 900, 28, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, item.title))
			res.append((eListboxPythonMultiContent.TYPE_TEXT, 1030,  4, 150, 20, 1, RT_HALIGN_CENTER|RT_VALIGN_CENTER, item.length))

			res.append((eListboxPythonMultiContent.TYPE_TEXT,  780, 35, 150, 20, 1, RT_HALIGN_CENTER|RT_VALIGN_CENTER, item.genre))
			res.append((eListboxPythonMultiContent.TYPE_TEXT, 1030, 35, 150, 20, 1, RT_HALIGN_CENTER|RT_VALIGN_CENTER, item.date)) # upload date
			if item.downloadable:
				res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 980, 60, 20, 20, LoadPixmap(cached=True, path=p+'download_20x20.png')))
			res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 620, 61, 28, 28, LoadPixmap(cached=True, path=p+'track_x28.png')))
			res.append((eListboxPythonMultiContent.TYPE_TEXT, 650,  65,  180, 20, 1, RT_HALIGN_CENTER|RT_VALIGN_CENTER, (str(item.fullitem.track_count)+' tracks')))
		return res

	def buildSCGrouplistsentry(self, item): # 114
		res = [ None ]
		p='/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/'
		if item.cache_it or item.text in ("[back]", "[zurück]"):
			res.append((eListboxPythonMultiContent.TYPE_TEXT, 0, 22, 1180 , 28, 0, RT_HALIGN_CENTER|RT_VALIGN_CENTER, "%s" % item.text))
		else:
			if fileExists(item.thumb):
				fn=item.thumb
			else:
				fn=path=p+'cloud_x100.png'
			ptr = self.picloader_92.load(item.thumb)
			res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 3, 10, 93, 93, ptr))
			if item.isfollowing and not item.isfollower:
				res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 82, 35, 22, 22, LoadPixmap(cached=True, path=p+'following_x22.png')))
				offset = 26
			elif item.isfollower and not item.isfollowing:
				res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 82, 35, 22, 22, LoadPixmap(cached=True, path=p+'follower_x22.png')))
				offset = 26
			elif item.isfollower and item.isfollowing:
				res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 82, 35, 22, 22, LoadPixmap(cached=True, path=p+'following_x22.png')))
				res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 82+26, 35, 22, 22, LoadPixmap(cached=True, path=p+'follower_x22.png')))
				offset = 52
			else:
				offset = 0
			#[u'permalink', u'members_count', u'name', u'track_count', u'creator', u'artwork_url', u'created_at', u'kind', u'uri', u'moderated', u'short_description', u'contributors_count',
			#u'permalink_url', u'id', u'description']
			res.append((eListboxPythonMultiContent.TYPE_TEXT,   100+offset, 35, 900, 20, 1, RT_HALIGN_LEFT|RT_VALIGN_CENTER, myenCode(str(item.fullitem.moderated))))
			res.append((eListboxPythonMultiContent.TYPE_TEXT,   100,  4, 900, 28, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, myenCode(item.fullitem.name)))
			res.append((eListboxPythonMultiContent.TYPE_TEXT, 1030,  4, 150, 20, 1, RT_HALIGN_CENTER|RT_VALIGN_CENTER, str(item.fullitem.members_count)))

			res.append((eListboxPythonMultiContent.TYPE_TEXT,  780, 35, 150, 20, 1, RT_HALIGN_CENTER|RT_VALIGN_CENTER, 'contrib:%d'%item.fullitem.contributors_count))
			res.append((eListboxPythonMultiContent.TYPE_TEXT, 1030, 35, 150, 20, 1, RT_HALIGN_CENTER|RT_VALIGN_CENTER, item.date)) # upload date
			if item.downloadable:
				res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 980, 60, 20, 20, LoadPixmap(cached=True, path=p+'download_20x20.png')))
			res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 620, 61, 28, 28, LoadPixmap(cached=True, path=p+'track_x28.png')))
			res.append((eListboxPythonMultiContent.TYPE_TEXT, 650,  65,  180, 20, 1, RT_HALIGN_CENTER|RT_VALIGN_CENTER, (str(item.fullitem.track_count)+' tracks')))
		return res
		
	def buildSCUser(self, item):#high 114
		res = [ None ]
		rfactor=self.rfactor
		p='/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/'
		if item.cache_it or item.text in ("[back]", "[zurück]"):
			res.append((eListboxPythonMultiContent.TYPE_TEXT, 0, 22*rfactor, 1180*rfactor , 28*rfactor, 0, RT_HALIGN_CENTER|RT_VALIGN_CENTER, "%s" % item.text))
		else:
			if fileExists(item.thumb):
				fn=item.thumb
			else:
				fn=path=p+'cloud_x100.png'
			ptr = self.picloader_100.load(item.thumb)
			res.append((eListboxPythonMultiContent.TYPE_PIXMAP, 7*rfactor, 7*rfactor, 100*rfactor, 100*rfactor, ptr))
			if item.isfollowing and not item.isfollower:
				res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 114*rfactor, 35*rfactor, 22*rfactor, 22*rfactor, LoadPixmap(cached=True, path=p+'following_x22.png')))
				offset = 26*rfactor
			elif item.isfollower and not item.isfollowing:
				res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 114*rfactor, 35*rfactor, 22*rfactor, 22*rfactor, LoadPixmap(cached=True, path=p+'follower_x22.png')))
				offset = 26*rfactor
			elif item.isfollower and item.isfollowing:
				res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 114*rfactor, 35*rfactor, 22*rfactor, 22*rfactor, LoadPixmap(cached=True, path=p+'following_x22.png')))
				res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, (114+26)*rfactor, 35*rfactor, 22*rfactor, 22*rfactor, LoadPixmap(cached=True, path=p+'follower_x22.png')))
				offset = 52*rfactor
			else:
				offset = 0
			res.append((eListboxPythonMultiContent.TYPE_TEXT,  (114+offset)*rfactor,  4*rfactor, 880*rfactor, 29*rfactor, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, myenCode(item.fullitem.username))) #username
			res.append((eListboxPythonMultiContent.TYPE_TEXT,  (114+offset)*rfactor, 40*rfactor,  600*rfactor, 20*rfactor, 1, RT_HALIGN_LEFT|RT_VALIGN_CENTER, myenCode(item.fullitem.full_name)))#  user fullname
			res.append((eListboxPythonMultiContent.TYPE_TEXT,  870*rfactor, 4*rfactor,  300*rfactor, 29*rfactor, 0, RT_HALIGN_CENTER|RT_VALIGN_CENTER, (myenCode(item.fullitem.country))))#country + city
			res.append((eListboxPythonMultiContent.TYPE_TEXT,  870*rfactor, 40*rfactor,  300*rfactor, 20*rfactor, 1, RT_HALIGN_CENTER|RT_VALIGN_CENTER, (myenCode(item.fullitem.city))))#country + city
			res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 120*rfactor, 70*rfactor, 22*rfactor, 22*rfactor, LoadPixmap(cached=True, path=p+'follow_x22.png')))
			res.append((eListboxPythonMultiContent.TYPE_TEXT,  150*rfactor, 71*rfactor,  200*rfactor, 20*rfactor, 1, RT_HALIGN_LEFT|RT_VALIGN_CENTER, (str(item.fullitem.followers_count)+' followers'))) # followers
			res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 370*rfactor, 70*rfactor, 22*rfactor, 22*rfactor, LoadPixmap(cached=True, path=p+'follow_x22.png')))
			res.append((eListboxPythonMultiContent.TYPE_TEXT,  400*rfactor, 71*rfactor,  250*rfactor, 20*rfactor, 1, RT_HALIGN_LEFT|RT_VALIGN_CENTER, (str(item.fullitem.followings_count)+' follows')))# followings
			res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 620*rfactor, 68*rfactor, 28*rfactor, 28*rfactor, LoadPixmap(cached=True, path=p+'tracks_x28.png')))
			res.append((eListboxPythonMultiContent.TYPE_TEXT, 650*rfactor,  71*rfactor,  180*rfactor, 20*rfactor, 1, RT_HALIGN_LEFT|RT_VALIGN_CENTER, (str(item.fullitem.track_count)+' tracks')))
			res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, 870*rfactor, 70*rfactor, 22*rfactor, 22*rfactor, LoadPixmap(cached=True, path=p+'playlist_x24.png')))
			res.append((eListboxPythonMultiContent.TYPE_TEXT,  900*rfactor, 71*rfactor,  250*rfactor, 20*rfactor, 1, RT_HALIGN_LEFT|RT_VALIGN_CENTER, (str(item.fullitem.playlist_count)+' playlists')))# followings
		return res
			
	def buildSCCommententry(comment):
		imagesize=100
		res = [ comment ]
		path='/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/default_avatar_badge.png'
		if fileExists(item.thumb):
			fn=item.thumb
		else:
			fn=path=p+'cloud_x100.png'
		ptr = self.picloader_100.load(item.thumb)
		res.append((eListboxPythonMultiContent.TYPE_PIXMAP, 10, 0, imagesize, imagesize, ptr))
		offset = 10 + imagesize + 10
		name = myenCode(comment.fullitem.user[u'username'])
		try:time = str(datetime_timedelta(0, comment.fullitem.timestamp/1000))
		except: time = '0:00:00'
		res.append((eListboxPythonMultiContent.TYPE_TEXT, offset,  3, 850-offset, 26, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, ''.join((name,' @ ',time)))) # user + timestamp 1160
		res.append((eListboxPythonMultiContent.TYPE_TEXT, offset,  32, 1180-offset, 44, 1, RT_HALIGN_LEFT|RT_VALIGN_TOP, myenCode(comment.fullitem.body))) # body
		res.append((eListboxPythonMultiContent.TYPE_TEXT, 850,  3, 300, 26, 0, RT_HALIGN_RIGHT|RT_VALIGN_CENTER, str(comment.fullitem.created_at.rsplit(' ',1)[0]))) # date
		return res


class SCEnterSearchScreen(Screen, ConfigListScreen):


	def __init__(self, session, TOKEN, skin_path):#, servicelist):
		logger.info('SCEnterSearchScreen]init...')
		self.session=session
		self.skin_path=skin_path
		self.buildSkin()
		Screen.__init__(self, session)

		self["actions"]=ActionMap(["WizardActions", "DirectionActions", "ColorActions", "EPGSelectActions", "InfobarAudioSelectionActions"],
		{
			"back": self.cancel,
			"red": self.keyRed,
			"green": self.keyGreeen,
			"yellow": self.keyYellow,
			"blue": self.keyBlue,
			"ok": self.keyOk,
			"audioSelection": self.keyAudio
		}, -1)

		logger.info('SCEnterSearchScreen]skin->%s' %self.skin)
		self["key_red"]=StaticText("Tracks")
		self["key_green"]=StaticText("Playlists")
		self["key_yellow"]=StaticText("Users")
		self["key_blue"]=StaticText("Groups")
		self['headertext']=Label()
		self["useravatar"]=PicLoaderScale(70,70, name='SCEnterSearchScreen_useravatar')

		self.config=[]
		self.config.append(getConfigListEntry(_("Enter Searchword here"), config.plugins.musiccenter.sc_search))
		ConfigListScreen.__init__(self, self.config, session)
		self['headertext'].setText(_('Press Audio for Genre Search'))
		self.TOKEN=TOKEN


	def buildSkin(self):
		self.skin="""
			<screen name="SCEnterSearchScreen" position="center,180" size="1280,280" backgroundColor="#00000000" title="MusicCenter SoundCloud Search" zPosition="0">
				<widget name="config" position="100,190" size="1080,40" scrollbarMode="showOnDemand"/>
				"""+SCSKINHEAD+"""
			</screen>"""


	def __onShown(self):
		self["useravatar"].doshow(self.TOKEN.useravatar)

	def keyOk(self):
		self.session.open(MessageBox, _("Please use color key to select searchtype"), type=MessageBox.TYPE_INFO, title="MusicCenter SoundCloud Search",timeout=4 )

	def keyRed(self):
		self.close([config.plugins.musiccenter.sc_search.value, "Tracks"])

	def keyGreeen(self):
		self.close([config.plugins.musiccenter.sc_search.value, "Playlists"])

	def keyYellow(self):
		self.close([config.plugins.musiccenter.sc_search.value, "Users"])

	def keyBlue(self):
		self.close([config.plugins.musiccenter.sc_search.value, "Groups"])

	def keyAudio(self):
		self.close([config.plugins.musiccenter.sc_search.value, "Tags"])


	def cancel(self):
		self.close()


class SCAuth(ConfigListScreen, Screen):

	skin="""
	<screen position="center,center" size="560,150" title="SoundCloud Authentification">
		<widget name="config" position="0,0" size="560,150" scrollbarMode="showOnDemand" />
	</screen>"""

	def __init__(self, session):
		self.session=session
		Screen.__init__(self, session)

		ConfigListScreen.__init__(self, [
			getConfigListEntry(_("Username:"), config.plugins.musiccenter.sc_username),
			getConfigListEntry(_("Password:"), config.plugins.musiccenter.sc_password)], session)

		self["actions"]=ActionMap(["WizardActions"],
		{
			"ok": self.okClicked,
			"cancel": self.exit
		}, -2)

	def okClicked(self):
		for x in self["config"].list:
			x[1].save()
		configfile.save()
		self.close(True)

	def exit(self):
		self.close(None)


class GetSoundCloudAccesstoken(Thread):

	def __init__(self):
		Thread.__init__(self)
		self.__running=False
		self.__messages=ThreadQueue()
		self.__messagePump=ePythonMessagePump()

	def __getMessagePump(self):
		return self.__messagePump
	MessagePump=property(__getMessagePump)

	def __getMessageQueue(self):
		return self.__messages
	Message=property(__getMessageQueue)

	def __getRunning(self):
		return self.__running
	isRunning=property(__getRunning)

	def Start(self, ischanged=False):
		if not self.__running:
			logger.info('GetSoundCloudAccesstoken]Start')
			self.__ischanged=ischanged
			self.start()

	def run(self):
		logger.info('GetSoundCloudAccesstoken]start run')
		#try:
		self.__running=True
		token=None
		error=''
		f='/etc/enigma2/sctoken'
		ttl=3600*1
		timeout=int(time_time())-ttl
		if os_path.exists(f) and not self.__ischanged:
			try:
				logger.info('GetSoundCloudAccesstoken]fileExists and not ischanged]read picklefile')
				with open(f, 'rb') as ptoken:
					token=pickle.load(ptoken)
			except Exception, e:
				token=None
				logger.error('GetSoundCloudAccesstoken]read picklefile error remove picklefile:%s' %e)
				os_remove(f)
			# push old token to get starting...
			self.__messages.push((token, 0))
			self.__messagePump.send(0)

		if os_path.exists(f) and os_path.getmtime(f)<timeout:
			logger.info('GetSoundCloudAccesstoken]token is outdated]refresh token')
			os_remove(f)
			token=None

		if token is None:
			logger.info('GetSoundCloudAccesstoken]start get token')
			username=config.plugins.musiccenter.sc_username.value
			password=config.plugins.musiccenter.sc_password.value
			if username != 'username' or password != 'password':
				logger.info('GetSoundCloudAccesstoken]->username != username or password != password')
				try:
					client=soundcloud_Client(
						grant_type='password',
						client_id='e864b0ca76a367275a991e55234adbd8',
						client_secret='789c2ce864251dfd0bb39aab28e93601',
						username=username,
						password=password,
						scope='non-expiring'
					)
					# ich
					me=client.get('/me')
					# meine comments
					mycomments=client.get('/users/%d/comments'%me.id)
					mycomment_ids=[ i.id for i in mycomments ]

					# meine Followings
					logger.info('GetSoundCloudAccesstoken]run]get meine Followings')
					myfollowing_ids=self.getIds(client, '/me/followings/ids?linked_partitioning=1')

					# meine Followers
					logger.info('GetSoundCloudAccesstoken]run]get meine Followers')
					myfollower_ids=self.getIds(client, '/me/followers/ids?linked_partitioning=1')

					# meine gelikten tracks
					logger.info('GetSoundCloudAccesstoken]run]get meine gelikten tracks')
					mylikedTracks_ids=self.getIds(client, '/e1/me/track_likes/ids?linked_partitioning=1')

					# meine gelikten playLists
					logger.info('GetSoundCloudAccesstoken]run]get meine gelikten Playlists')
					mylikedPlaylists_ids=self.getIds(client, '/e1/me/playlist_likes/ids?linked_partitioning=1')

					# meine reposted tracks
					logger.info('GetSoundCloudAccesstoken]run]get meine reposted tracks')
					myrepostedTracks_ids=self.getIds(client, '/e1/me/track_reposts/ids?linked_partitioning=1')

					# meine reposted playLists
					logger.info('GetSoundCloudAccesstoken]run]get meine reposted playLists')
					myrepostedPlaylists_ids=self.getIds(client, '/e1/me/playlist_reposts/ids?linked_partitioning=1')

					# meine selbst erstellten playlists
					logger.info('GetSoundCloudAccesstoken]run]get meine selbst erstellten playlists')
					myplaylists=client.get('https://api-v2.soundcloud.com/users/%d/playlists?representation=speedy&limit=10&offset=0&linked_partitioning=1' %me.id)
					logger.info('GetSoundCloudAccesstoken]run]create token')

					token=SCToken(client=client, me=me, mycomments=mycomments, mylikedTracks_ids=mylikedTracks_ids, mylikedPlaylists_ids=mylikedPlaylists_ids, mycomment_ids=mycomment_ids,
					myfollowing_ids=myfollowing_ids, myfollower_ids=myfollower_ids, myrepostedTracks_ids=myrepostedTracks_ids, myrepostedPlaylists_ids=myrepostedPlaylists_ids, myplaylists=myplaylists)

				except Exception,error:
					logger.error('GetSoundCloudAccesstoken->%s'%error)
					token=SCToken(error=str(error))
			else:
				logger.info('GetSoundCloudAccesstoken]run]No user and pass given, Login without auth!')
				token=None

		if token is None:
			try:
				logger.info('GetSoundCloudAccesstoken]without user/pass')
				client=soundcloud_Client(client_id='e864b0ca76a367275a991e55234adbd8',)
				token=SCToken(client=client)
			except Exception, error:
				logger.error('GetSoundCloudAccesstoken]without user/pass->%s' %error)
				token=SCToken(error=str(error))
		if self.__ischanged or not os_path.exists(f):
			saveToken(token)
			logger.info('GetSoundCloudAccesstoken]ischanged or not fileExists]create picklefile')

		self.__messages.push((token, 1))
		self.__messagePump.send(0)
		logger.info('GetSoundCloudAccesstoken]push now token to player...')

		self.__running=False
		Thread.__init__(self)
		logger.info('GetSoundCloudAccesstoken]done')

	def getIds(self, client, call):
		res=client.get(call)
		ids=res.collection
		while res.next_href:
			res=client.get(res.next_href)
			ids+=res.collection
		return ids

getSoundCloudaccesstoken=GetSoundCloudAccesstoken()


def saveToken(token=None):
	f='/etc/enigma2/sctoken'
	if token is not None:
		token.useravatar=None
		logger.info('saveToken]ischanged or not fileExists]create picklefile')
		with open(f, 'wb') as ptoken:
			pickle.dump(token, ptoken)
	return
