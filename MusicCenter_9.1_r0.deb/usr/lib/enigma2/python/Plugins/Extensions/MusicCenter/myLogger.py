# -*- coding: UTF-8 -*-

#  Music Center E2
#
#  Coded by bobo71 (c) 2014
#  Support: www.dreambox-tools.info
#
#  All Files of this Software are licensed under the Creative Commons
#  Attribution-NonCommercial-ShareAlike 3.0 Unported
#  License if not stated otherwise in a Files Head. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.

#  Additionally, this plugin may only be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.

#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially
#  distributed other than under the conditions noted above.
#  This applies to the source code as a whole as well as to parts of it, unless
#  explicitely stated otherwise.

	
from Components.config import config
from logging import getLogger as logging_getLogger, ERROR as logging_ERROR, INFO as logging_INFO, DEBUG as logging_DEBUG, Formatter as logging_Formatter, CRITICAL as logging_CRITICAL
from logging.handlers import RotatingFileHandler
from time import time as time_time

'''
Level		When it’s used

DEBUG		Detailed information, typically of interest only when diagnosing problems.
INFO		Confirmation that things are working as expected.
WARNING		An indication that something unexpected happened, or indicative of some problem in the near future (e.g. ‘disk space low’). The software is still working as expected.
ERROR		Due to a more serious problem, the software has not been able to perform some function.
CRITICAL	A serious error, indicating that the program itself may be unable to continue running.
 
The default level is WARNING, which means that only events of this level and above will be tracked, unless the logging package is configured to do otherwise.
'''

logger = logging_getLogger(__name__)		
filename='/var/log/musiccenter-{}.log'.format(str(time_time()).split('.')[0])
maxBytes=1024*1024
backupCount=3
# create a rotating file handler
handler = RotatingFileHandler(filename, "a", maxBytes, backupCount)
formatter = logging_Formatter('%(asctime)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)



def setLogLevel(logger): # "off""error""info""debug"
	logger.debug('myLogger]setLogLevel]now...')
	loglevel=None
	if config.plugins.musiccenter.setdebug.value == 'off':
		loglevel=logging_CRITICAL
	elif config.plugins.musiccenter.setdebug.value == 'error':
		loglevel=logging_ERROR
	elif config.plugins.musiccenter.setdebug.value == 'info':
		loglevel=logging_INFO
	elif config.plugins.musiccenter.setdebug.value == 'debug':
		loglevel=logging_DEBUG
	if loglevel is not None:
		logger.debug('MusicCenterSetup]setLogLevel]:{}'.format(loglevel))
		logger.setLevel(loglevel)
