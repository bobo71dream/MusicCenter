# -*- coding: UTF-8 -*-

#  Music Center E2
#
#  Coded by bobo71 (c) 2014
#  Support: www.dreambox-tools.info
#
#  All Files of this Software are licensed under the Creative Commons
#  Attribution-NonCommercial-ShareAlike 3.0 Unported
#  License if not stated otherwise in a Files Head. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.

#  Additionally, this plugin may only be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.

#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially
#  distributed other than under the conditions noted above.
#  This applies to the source code as a whole as well as to parts of it, unless
#  explicitely stated otherwise.


from Globals import *

# local plugin
from EditID3 import EditId3
from JobCenter import *
from myLogger import logger
from ItemClasses import *

from SelectPath import SelectPath
import Player

from Setup import MusicCenterSetup
import  EditStreamFavorite
from JobCenter2 import *
from LogScreen import *


def save_obj(obj, filename):
    with open(filename, 'wb') as f:
        pickle.dump(obj, f)

def load_obj(filename):
    with open(filename, 'rb') as f:
        return pickle.load(f)

		
class RadiobrowserMain(Screen):

	if RESOLUTIONx>1800:

		skin='''<screen name="RadioBrowserMain" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#00000000" zPosition="0">
			<!-- Header -->
				<eLabel backgroundColor="#191919" position="20,20" size="1900,100" zPosition="1" />
				<widget name="headertext" position="140,39" size="1760,42" font="SansReg;35" foregroundColor="#ffffff" backgroundColor="#191919" halign="center" valign="center" zPosition="3" />
				<ePixmap position="20,20" size="100,100" pixmap="~/radiobrowser.png" scale="1" zPosition="2"/>
			<!-- Buttons -->
				<eLabel position="20,135" size="1900,40" backgroundColor="#191919" zPosition="1" />
				<!-- arrow left -->
					<widget render="Label" font="SansReg;40" position="30,135" size="40,40" source="key_arrow_left" foregroundColor="#ffffff" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
				<!-- red -->
					<widget render="Label" font="SansReg;34" position="100,135" size="450,40" source="key_red" foregroundColor="#ff0000" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
					<widget name="line_red" position="105,170" size="440,6" zPosition="3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/white450x3.png" />
				<!-- green -->
					<widget render="Label" font="SansReg;34" position="510,135" size="450,40" source="key_green" foregroundColor="#00ff21" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
					<widget name="line_green" position="515,170" size="440,6" zPosition="3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/white450x3.png" />
				<!-- yellow -->
					<widget render="Label" font="SansReg;34" position="960,135" size="450,40" source="key_yellow" foregroundColor="#FFD800" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
					<widget name="line_yellow" position="965,170" size="440,6" zPosition="3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/white450x3.png" />
				<!-- blue -->
					<widget render="Label" font="SansReg;34" position="1410,135" size="450,40" source="key_blue" foregroundColor="#3D8DFF" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
					<widget name="line_blue" position="1415,170" size="440,6" zPosition="3" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/white450x3.png" />
				<!-- arrow right -->
					<widget render="Label" font="SansReg;40" position="1870,135" size="40,40" source="key_arrow_right" foregroundColor="#ffffff" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
			<widget name="list" position="35,190" zPosition="1" size="1850,855" scrollbarMode="showOnDemand" backgroundColor="#00000000"/>
		</screen>'''

	else:
		skin='''<screen name="RadioBrowserMain" position="0,0" size="1280,720" flags="wfNoBorder" backgroundColor="#00000000" zPosition="0">
			<!-- Header -->
				<eLabel backgroundColor="#191919" position="13,13" size="1266,66" zPosition="1" />
				<widget name="headertext" position="93,26" size="1173,28" font="SansReg;23" foregroundColor="#ffffff" backgroundColor="#191919" halign="center" valign="center" zPosition="3" />
				<ePixmap position="13,13" size="66,66" pixmap="~/radiobrowser.png" scale="1" zPosition="2"/>
			<!-- Buttons -->
				<eLabel position="13,90" size="1266,33" backgroundColor="#191919" zPosition="1" />
				<!-- arrow left -->
					<widget render="Label" font="SansReg;29" position="20,92" size="26,29" source="key_arrow_left" foregroundColor="#ffffff" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
				<!-- red -->
					<widget render="Label" font="SansReg;25" position="66,92" size="300,28" source="key_red" foregroundColor="#ff0000" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
					<widget name="line_red" position="70,120" size="293,2" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/white450x3.png" />
				<!-- green -->
					<widget render="Label" font="SansReg;25" position="340,92" size="300,28" source="key_green" foregroundColor="#00ff21" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
					<widget name="line_green" position="343,120" size="293,2" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/white450x3.png" />
				<!-- yellow -->
					<widget render="Label" font="SansReg;25" position="640,93" size="300,28" source="key_yellow" foregroundColor="#FFD800" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
					<widget name="line_yellow" position="643,120" size="293,2" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/white450x3.png" />
				<!-- blue -->
					<widget render="Label" font="SansReg;25" position="940,92" size="300,28" source="key_blue" foregroundColor="#3D8DFF" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
					<widget name="line_blue" position="943,120" size="293,2" zPosition="2" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/white450x3.png" />
				<!-- arrow right -->
					<widget render="Label" font="SansReg;29" position="1246,92" size="26,29" source="key_arrow_right" foregroundColor="#ffffff" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
			<widget name="list" position="23,130" zPosition="1" size="1233,570" scrollbarMode="showOnDemand" backgroundColor="#00000000"/>
		</screen>'''
		
	def __init__(self, session, player, currentService, serviceList):

		logger.info('Radiobrowser]init...')
		self.session=session
		self.currentService=currentService
		self.serviceList=serviceList
		self.skin_path='/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images'

		Screen.__init__(self, session)
		self['list']=RadioBrowserList([])

		self["actions"]=ActionMap(["WizardActions", "DirectionActions", "ColorActions", "EPGSelectActions", "InfobarAudioSelectionActions", "HelpActions"],
		{
			"input_date_time": self.menuPressed,
			"ok": self.okPressed,
			"back": self.closing,
			"red": self.redPressed,
			"green": self.greenPressed,
			"yellow": self.yellowPressed,
			"blue": self.bluePressed,
			"prevService": self.keyLeft,
			"nextService": self.keyRight,
			"audioSelection": self.audioPressed,
		}, -1)
		'''
			"info" : self.infoPressed,
		'''
		self.onLayoutFinish.append(self.__startRun)
		self.onClose.append(self.__onClose)

		self.player=player
		self["key_arrow_left"]=StaticText("")
		self["key_red"]=StaticText("")
		self["line_red"] = Pixmap()
		self["line_red"].hide()
		self["key_green"]=StaticText("")
		self["line_green"] = Pixmap()
		self["line_green"].hide()
		self["key_yellow"]=StaticText("")
		self["line_yellow"] = Pixmap()
		self["line_yellow"].hide()
		self["key_blue"]=StaticText("")
		self["line_blue"] = Pixmap()
		self["line_blue"].hide()
		self["key_arrow_right"]=StaticText(">")
		self.bottomlineindex=0

		self['headertext']=Label()
		self.toconvertlist=[]
		self.picdir=self.initPicDir()
		self.mode='MainMenu'
		self.headerpos=0
		self.hl=[]
		self.hlp={}
		self.tagselected=''
		self.tagfavoritenliste=[]

		if fileExists(resolveFilename(SCOPE_CONFIG ,"mc_radiobrowser_tag_favoriten")):
			self.tagfavoritenliste=load_obj(resolveFilename(SCOPE_CONFIG ,"mc_radiobrowser_tag_favoriten"))
		self.landselected=''
		self.laenderfavoritenliste=[]
		if fileExists(resolveFilename(SCOPE_CONFIG ,"mc_radiobrowser_laender_favoriten")):
			self.laenderfavoritenliste=load_obj(resolveFilename(SCOPE_CONFIG ,"mc_radiobrowser_laender_favoriten"))
		self.spracheselected=''
		self.sprachenfavoritenliste=[]
		if fileExists(resolveFilename(SCOPE_CONFIG ,"mc_radiobrowser_sprachen_favoriten")):
			self.sprachenfavoritenliste=load_obj(resolveFilename(SCOPE_CONFIG ,"mc_radiobrowser_sprachen_favoriten"))

	def initPicDir(self):
		picdir=''.join((config.plugins.musiccenter.downloadcache.value, 'Radiobrowser/'))
		if not pathExists(picdir):
			if not createDir(picdir, makeParents=True):
				picdir='/tmp/mc/'
		return picdir

	def __startRun(self):
		self.MainMenu()
		#self['list'].connectSelChanged(self.updateLCTText)

	def MainMenu(self):
		url='json/stats'
		rb_getPage(url).addCallback(self.MainMenuAppend).addErrback(self.MainMenuAppendError,)

	def MainMenuAppend(self, result):
		#{u'tags': u'1474', u'clicks_last_day': u'5716', u'stations': u'6243', u'languages': u'90', u'stations_broken': u'238', u'countries': u'100', u'clicks_last_hour': u'287'}
		res=json_loads(result)
		sprache="%s Sprachen" %res[u'languages'].encode()
		tags="%s Tags" %res[u'tags'].encode()
		laender="%s Länder" %res[u'countries'].encode()
		self.hl=['Favoriten', tags, laender, sprache, 'Andere hören', 'Top 100 Clicks','Top 100 Vote', 'Neu/Geändert', 'Suche', '','','']
		header='{} Stationen | {} Clicks letzter Tag | {} Clicks letzte Stunde | {} defekte Stationen'.format(res[u'stations'].encode(), res[u'clicks_last_day'].encode(), res[u'clicks_last_hour'].encode(), res[u'stations_broken'].encode())
		self.setListNow(list=[], header=header, red=self.hl[0], green=self.hl[1], yellow=self.hl[2], blue=self.hl[3])

	def MainMenuAppendError(self, error):
		logger.error('Radiobrowser]MainMenuAppendError]->%s' %(error))
		self.setListNow(list=[], header='Error->%s' %error, red='', green='', yellow='', blue='')

	def getPageError(self, error, key):
		logger.error('Radiobrowser]getPageError]->%s ->%s' %(key,error))

	def buildStationlistEntrys(self, stationen):
		dllist=[]
		'''[{"id":"59591","name":"Deutschlandfunk (MP3 HQ stereo 128 kBit/s)","url":"http://www.dradio.de/streaming/dlf.m3u",
		"homepage":"http://www.deutschlandfunk.de/","favicon":"http://www.deutschlandradio.de/media/thumbs/7/722b476e81c7ad558780f1800f572888v1_max_144x144_b3535db83dc50e27c1bb1392364c95a2.jpg",
		"tags":"news,information",
		"country":"Germany",
		"state":"",
		"language":"German",
		"votes":"491",
		"negativevotes":"0",
		"codec":"MP3",
		"bitrate":"128",
		"lastcheckok":"1","lastchecktime":"2016-10-23 02:00:31","lastcheckoktime":"2016-10-23 02:00:31","clicktimestamp":"2016-10-23 20:10:19",
		"clickcount":"184",
		"clicktrend":"5",
		"lastchangetime":"2016-08-25 22:42:00"},....
		'''
		stationen=json_loads(stationen)
		list=[]
		aussortiert=0
		counter=0
		for station in stationen:
			codec=station['codec'].encode()
			stationname=station['name'].encode()
			bitrate=station['bitrate'].encode()
			if (codec == 'MP3' and int(bitrate) >= int(config.plugins.musiccenter.minmp3streamingrate.value)) or (codec in('OGG', 'AAC', 'AAC+') and int(bitrate) >= int(config.plugins.musiccenter.minaacstreamingrate.value)) or (codec == 'WMA' and int(bitrate) >= int(config.plugins.musiccenter.minwmastreamingrate.value)) or int(bitrate)==0 or codec == 'UNKNOWN':
				songID=counter
				counter+=1
				streamID=station['id'].encode()
				streamurl=station['url'].encode()
				tags=station['tags'].encode().title()
				location='{} | {}'.format(station['country'].encode(), station['state'].encode())
				clickcount=station['clickcount'].encode()
				votes=station['votes'].encode()
				homepage=station['homepage'].encode()
				stationiconfilename=self.buildStationIconsDownload(station)
				if not fileExists(stationiconfilename):
					dllist.append(station)
				if codec=='UNKNOWN':
					codec='n/a'
				list.append((Item(songID=songID, streamID=streamID, text=stationname, stationname=stationname, genre=tags, location=location, bitrate=bitrate, codec=codec, streamurl=streamurl, join=True, filetype='RADIOBROWSER', audio=True, stationicon=stationiconfilename, playcount=clickcount, votes=votes),))
			else:
				aussortiert+=1
				logger.debug('RadioBrowser]buildStationlistEntrys] aussortiert->%s codec->%s bitrate->%s minmp3streamingrate->%s minaacstreamingrate->%s minwmastreamingrate->%s' %(stationname, codec, bitrate, config.plugins.musiccenter.minmp3streamingrate.value, config.plugins.musiccenter.minaacstreamingrate.value, config.plugins.musiccenter.minwmastreamingrate.value))
		return list, aussortiert, dllist

	def buildStationIconsDownload(self, station):
		stationname=station['name'].encode()
		stationiconurl=station['favicon'].encode()
		
		if stationiconurl.startswith('data:image/jpeg;base64'):
			filename=''.join((cleanName(stationname), '.jpeg'))
			stationiconfilename=os_path.join(self.picdir, filename)
				
		elif stationiconurl.startswith('data:image/png;base64'):
			filename=''.join((cleanName(stationname), '.png'))
			stationiconfilename=os_path.join(self.picdir, filename)
				
		else:
			endswithbase=stationiconurl.rsplit('/',1)[-1].lower()
			endswith=None
			for e in ('.jpg', '.png', '.jpeg', '.bmp', '.gif', '.svg'):
				if e in endswithbase:
					endswith=e
					break

			if endswith is not None:
				filename=''.join((cleanName(stationname), endswith))
				stationiconfilename=os_path.join(self.picdir, filename)
			else:
				filename=cleanName(stationname)
				stationiconfilename=os_path.join(self.picdir, filename)
		return stationiconfilename

	def buildLists(self, list, favorites):
		entrylist=[]
		favlist=[]
		for entry in list:
			name=entry['name'].encode()
			stationcount=entry['stationcount'].encode()
			if name in favorites:
				favlist.append((_("* %s(%s) *" %(name.title(), stationcount)), name),)
			else:
				entrylist.append((_("%s(%s)" %(name.title(), stationcount)), name),)
		return favlist+entrylist

	def getStationsAppend(self, stationen, header):
		logger.debug('RadioBrowser]getStationsAppend->%s' %header)
		list, aussortiert, dllist=self.buildStationlistEntrys(stationen)
		self.setListNow(list=list, header=header, aussortiert=aussortiert, dllist=dllist)

	def setBottomline(self, key=-1):
		logger.debug('RadioBrowser]setBottomline]key->%d' %key)
		if key>-1:
			self.bottomlineindex=key
		self["line_red"].hide()
		self["line_green"].hide()
		self["line_yellow"].hide()
		self["line_blue"].hide()
		if key in range(0,12,4):
			self["line_red"].show()
		elif key in  range(1,12,4):
			self["line_green"].show()
		elif key in  range(2,12,4):
			self["line_yellow"].show()
		elif key in  range(3,12,4):
			self["line_blue"].show()

	def redPressed(self):
		self.selectMode(0)

	def greenPressed(self):
		self.selectMode(1)

	def yellowPressed(self):
		self.selectMode(2)

	def bluePressed(self):
		self.selectMode(3)

	def selectMode(self, mode):
		mode=self.headerpos+mode
		logger.debug('RadioBrowser]setMode {}'.format(mode))
		self.setBottomline(mode)
		self.setListNow([], header='')
		#'0 Favoriten',1 tags,2 laender,3 sprache,4 'Andere hören',5 'Top 100 Clicks',6 'Top 100 Vote',7 'Neu/Geändert',8 'Suche'
		if mode!=8: #Suche
			self.hlp['suchname']=None
		if mode==0:
			self.listeFavoriten()
			self.mode='listeFavoriten'
		elif mode==1:
			self.TagsListe()
			self.mode='TagsListe'
		elif mode==2:
			self.LaenderListe()
			self.mode='LaenderListe'
		elif mode==3:
			self.SprachenListe()
			self.mode='SprachenListe'
		elif mode==4:
			self.LetztGespielt()
			self.mode='LetztGespielt'
		elif mode==5:
			self.Top_100_Clicks()
			self.mode='Top_100_Clicks'
		elif mode==6:
			self.Top_100_Vote()
			self.mode='Top_100_Vote'
		elif mode==7:
			self.LetztGeaendert()
			self.mode='LetztGeaendert'
		elif mode==8:
			self.startSuche()
			self.mode='startSuche'
		logger.debug('RadioBrowser]selectMode->%s' %self.mode)
# favoriten
	def listeFavoriten(self, index=0):
		sql='''
		SELECT * FROM Stream_Favorites ORDER BY stationname;'''
		cursor=sqlCommand_Streaming_WithReturn(sql, dbname='musiccenter_stream_favorites.db')
		list=[]
		for row in cursor.fetchall():
			stationname=row['stationname']
			stationicon=row['stationicon']
			codec=row['codec']
			if codec=='UNKNOWN':
					codec='n/a'
			list.append((Item(songID=row['station_id'], streamID=row['streamID'], text=row['stationname'], stationname=stationname, genre=row['genre'], location=row['location'], bitrate=row['bitrate'], codec=codec, streamurl=row['streamurl'], join=True, filetype=row['filetype'], audio=True, stationicon=stationicon, playcount=row['clicks'], rating=10, votes=row['votes']),))
		self.setListNow(list=list, header='Favoriten ')

	def Top_100_Clicks(self):
		self.clearListNow()
		url='json/stations/topclick/100'
		header='Top100 nach Click '
		rb_getPage(url).addCallback(self.getStationsAppend, header).addErrback(self.getPageError, 'Top_100_Clicks')

	def Top_100_Vote(self):#0
		self.clearListNow()
		url='json/stations/topvote/100'
		header='Top100 nach Vote '
		rb_getPage(url).addCallback(self.getStationsAppend, header).addErrback(self.getPageError, 'Top_100_Vote')

	def LetztGeaendert(self):
		self.clearListNow()
		url='json/stations/lastchange/100'
		header='Letzt geänderte Stationen '
		rb_getPage(url).addCallback(self.getStationsAppend, header).addErrback(self.getPageError, 'LetztGeändert')

	def LetztGespielt(self):
		self.clearListNow()
		url='json/stations/lastclick/100'
		header='Andere hören '
		rb_getPage(url).addCallback(self.getStationsAppend, header).addErrback(self.getPageError, 'LetztGespielt')
#suche
	def startSuche(self):
		self.session.openWithCallback(self.sucheJetzt, vInputBox, title=_('Suchbegriff eingeben!'), windowTitle=_("Radiobrowser Suche"), text=LAST_STREAM_SEARCH)

	def sucheJetzt(self, suchname):
		logger.info('RadioBrowser]sucheJetzt]suchname:{}'.format(suchname))
		if suchname is not None:
			LAST_STREAM_SEARCH=suchname
			global LAST_STREAM_SEARCH
			url='json/stations/{}'.format(quote(suchname))
			rb_getPage(url).addCallback(self.getSucheAppend, suchname).addErrback(self.getPageError, 'sucheJetzt')
		else:
			self.setListNow(list=[], header='kein Suchwort!')

	def getSucheAppend(self, stationen, suchname):
		self.hlp['suchname']=suchname
		logger.debug('RadioBrowser]getSucheAppend]suchname:{}'.format(suchname))
		list, aussortiert, dllist=self.buildStationlistEntrys(stationen)
		self.setListNow(list=list, header='Suchergebnis für {}'.format(suchname), aussortiert=aussortiert, dllist=dllist)

	def SprachenListe(self):# green
		logger.info('RadioBrowser]SprachenListe]')
		url='json/languages'
		rb_getPage(url).addCallback(self.SprachenListeAppend).addErrback(self.getPageError, 'SprachenListe')

	def SprachenListeAppend(self, sprachenliste):
		#[{"name":"Albanian","value":"Albanian","stationcount":"8"},...
		logger.debug('RADIOBROWSER]TagsListeAppend]sprachenfavoritenliste->%s' %self.sprachenfavoritenliste)
		list=self.buildLists(json_loads(sprachenliste), self.sprachenfavoritenliste)
		self.session.openWithCallback(self.selectedSprache, ChoiceBox, title=_('Bitte Sprache auswählen'), list=list, keys=MYKEYSORT, titlebartext='MusicCenter Sprachenliste')

	def selectedSprache(self, sprache):
		if sprache != None:
			sprache=sprache[1]
			logger.debug('RadioBrowser]selectedSprache]->%s' %sprache)
			url='json/stations/bylanguageexact/'+sprache
			logger.debug('RadioBrowser]selectedSprache]url->%s' %url)
			rb_getPage(url).addCallback(self.selectedSpracheAppend, sprache).addErrback(self.getPageError, 'selectedSpracheAppend')

	def selectedSpracheAppend(self, stationen, sprache):
		self.spracheselected=sprache
		list, aussortiert, dllist=self.buildStationlistEntrys(stationen)
		self.setListNow(list=list, header='Sprache %s (%s)' %(sprache, len(list)), aussortiert=aussortiert, dllist=dllist)

	def TagsListe(self):
		logger.info('RadioBrowser]TagsListe]')
		url='json/tags'
		rb_getPage(url).addCallback(self.TagsListeAppend).addErrback(self.getPageError, 'TagsListe')

	def TagsListeAppend(self, tagsliste):
		#{"name":"100.6","value":"100.6","stationcount":"1"},...
		logger.debug('RADIOBROWSER]TagsListeAppend]tagfavoritenliste->%s' %self.tagfavoritenliste)
		list=self.buildLists(json_loads(tagsliste), self.tagfavoritenliste)
		self.session.openWithCallback(self.selectedTag, ChoiceBox, title=_('Bitte Tag auswählen'), list=list, keys=MYKEYSORT, titlebartext=_('MusicCenter Tagliste'))

	def selectedTag(self, tag):
		if tag != None:
			tag=tag[1]
			logger.debug('RadioBrowser]selectedTag]->%s' %tag)
			url='json/stations/bytagexact/'+tag
			logger.info('RadioBrowser]selectedTag]url->%s' %url)
			rb_getPage(url).addCallback(self.selectedTagAppend, tag).addErrback(self.getPageError, 'selectedTagAppend')

	def selectedTagAppend(self, stationen, tag):
		self.tagselected=tag
		list, aussortiert, dllist=self.buildStationlistEntrys(stationen)
		self.setListNow(list=list, header='Tag %s (%s)' %(tag.title(), len(list)), aussortiert=aussortiert, dllist=dllist)

	def LaenderListe(self):# blau
		logger.info('RadioBrowser]LaenderListe]')
		url='json/countries'
		rb_getPage(url).addCallback(self.LaenderListeAppend).addErrback(self.getPageError, 'LaenderListe')

	def LaenderListeAppend(self, laenderliste):
		#[{"name":"Albania","value":"Albania","stationcount":"8"},,...
		logger.debug('RADIOBROWSER]LaenderListeAppend]laenderfavoritenliste->%s' %self.laenderfavoritenliste)
		list=self.buildLists(json_loads(laenderliste), self.laenderfavoritenliste)
		self.session.openWithCallback(self.selectedLand, ChoiceBox, title=_('Bitte Land auswählen'), list=list, keys=MYKEYSORT, titlebartext='MusicCenter Länderliste')

	def selectedLand(self, land):
		if land != None:
			land=land[1]
			logger.debug('RadioBrowser]selectedLand]->%s' %land)
			url='json/stations/bycountryexact/'+land
			rb_getPage(url).addCallback(self.selectedLandAppend, land).addErrback(self.getPageError, 'selectedLandAppend')

	def selectedLandAppend(self, stationen, land):
		self.landselected=land
		list, aussortiert, dllist=self.buildStationlistEntrys(stationen)
		self.setListNow(list=list, header='Land %s (%s)' %(land, len(list)), aussortiert=aussortiert, dllist=dllist)

	def okPressed(self):
		logger.info('Radiobrowser]ok]start')
		if self.player is not None:
			if self.player.hlp.get('currIndex')!=-2:
				self.player.stopPlay()
			logger.debug('Radiobrowser]scanFinished]is player instance, delete now...')
			self.session.deleteDialog(self.player)
			self.player=None			
		try:
			if JCcheckModuleIsUpdated('Player'):
				reload(Player)
		except Exception, e:
			self.session.open(MessageBox, _("Error reload Player\n%s" %e), type=MessageBox.TYPE_ERROR, timeout=10 )
	
		logger.debug('Radiobrowser]scanFinished]instantiate new player dialog')
		self.player=self.session.instantiateDialog(Player.Player, songList=self['list'].getList(), index=self['list'].getSelectedIndex(), playermode=RADIOBROWSER, currentService=self.currentService, serviceList=self.serviceList, radiobrowserinstance=self)
		self.player.setShowHideAnimation("quick_fade")
		self.session.execDialog(self.player)

	def setListNow(self, list=[], index=0, header=None, red=None, green=None, yellow=None, blue=None, aussortiert=0, dllist=[]):
		logger.info('Radiobrowser]setListNow]')
		self['list'].setList(list)
		self['list'].moveToIndex(index)
		if header !=None:
			itemcount=self['list'].getItemCount()
			if aussortiert==0:
				self['headertext'].setText(_('{}({})'.format(header, itemcount)))
			else:
				self['headertext'].setText(_('{}({}) aussortiert({})'.format(header, itemcount, aussortiert)))
		self.setButtons(red, green, yellow, blue)
		if len(dllist):
			stationiconDownloader.Start(dllist,	self.picdir, 'RADIOBROWSER')
		
	def clearListNow(self):
		self['list'].setList([])
		self['list'].moveToIndex(0)

	def setButtons(self, red=None, green=None, yellow=None, blue=None):
		if red!=None:
			self["key_red"].setText(red)
		if green!=None:
			self["key_green"].setText(green)
		if yellow!=None:
			self["key_yellow"].setText(yellow)
		if blue!=None:
			self["key_blue"].setText(blue)

	def menuPressed(self):
		options=[]
		options.append((_("Globale Konfiguration"), self.startConfig),)
		if self.mode!='listeFavoriten':
			options.append((_("Füge ausgewählten Stream zu Favoriten hinzu"), self.startAddStreamToFavoriteList),)
		if self.hlp.get('suchname', None) is not None:
			options.append((_("Füge ausgewähltes Suchwort den Favoriten hinzu"), self.startAddStreamToFavoriteList),)			
		if self.mode=='TagsListe':
			if self.tagselected in self.tagfavoritenliste:
				options.append((_("Entferne ausgewählten Tag von den Favoriten der Länderliste"), self.entferneTagAusFavoritenliste),)
			else:
				options.append((_("Füge ausgewählten Tag zu den Favoriten der Tagliste hinzu"), self.fuegeTagZurFavoritenliste),)
		elif self.mode=='LaenderListe':
			if self.landselected in self.laenderfavoritenliste:
				options.append((_("Entferne ausgewähltes Land von den Favoriten der Länderliste"), self.entferneLandAusFavoritenliste),)
			else:
				options.append((_("Füge ausgewähltes Land zu den Favoriten der Länderliste hinzu"), self.fuegeLandZurFavoritenliste),)
		elif self.mode=='SprachenListe':
			if self.spracheselected in self.sprachenfavoritenliste:
				options.append((_("Entferne ausgewählte Sprache von den Favoriten der Sprachenliste"), self.entferneSpracheAusFavoritenliste),)
			else:
				options.append((_("Füge ausgewählte Sprache zu den Favoriten der Sprachnliste hinzu"), self.fuegeSpracheZurFavoritenliste),)
		else:
			options.append((_("Editiere ausgewählten FavoritenStream"), self.startEditiereSelektieretenStream),)
			options.append((_("Lösche ausgewählten FavoritenStream"), self.startLoescheSelektieretenStream),)
		options.append((_("öffne Logfile"), self.startLog ),)
		self.session.openWithCallback(self.menuCallback, ChoiceBox, title=_("Mainscreen Options"), list=options, keys=MYKEYSORT, titlebartext=_("MusicCenter"))

	def menuCallback(self, ret):
		if ret is not None:
			if len(ret) == 3:
				ret and ret[1](ret[2])
			else:
				ret and ret[1]()

	def startAddStreamToFavoriteList(self):
		sel=self.getCurrentSelection()
		if sel is not None:
			addStreamToFavoriteList(sel)
# tag
	def fuegeTagZurFavoritenliste(self):
		self.tagfavoritenliste.append(self.tagselected)
		save_obj(self.tagfavoritenliste, resolveFilename(SCOPE_CONFIG ,"mc_radiobrowser_tag_favoriten"))

	def entferneTagAusFavoritenliste(self):
		if self.tagselected in self.tagfavoritenliste:
			self.tagfavoritenliste.remove(self.tagselected)
			save_obj(self.tagfavoritenliste, resolveFilename(SCOPE_CONFIG ,"mc_radiobrowser_tag_favoriten"))
# laender
	def fuegeLandZurFavoritenliste(self):
		self.laenderfavoritenliste.append(self.landselected)
		save_obj(self.laenderfavoritenliste, resolveFilename(SCOPE_CONFIG ,"mc_radiobrowser_laender_favoriten"))

	def entferneLandAusFavoritenliste(self):
		if self.landselected in self.laenderfavoritenliste:
			self.laenderfavoritenliste.remove(self.landselected)
			save_obj(self.laenderfavoritenliste, resolveFilename(SCOPE_CONFIG ,"mc_radiobrowser_laender_favoriten"))
# sprache
	def fuegeSpracheZurFavoritenliste(self):
		self.sprachenfavoritenliste.append(self.spracheselected)
		save_obj(self.sprachenfavoritenliste, resolveFilename(SCOPE_CONFIG ,"mc_radiobrowser_sprachen_favoriten"))

	def entferneSpracheAusFavoritenliste(self):
		if self.spracheselected in self.sprachenfavoritenliste:
			self.sprachenfavoritenliste.remove(self.spracheselected)
			save_obj(self.sprachenfavoritenliste, resolveFilename(SCOPE_CONFIG ,"mc_radiobrowser_sprachen_favoriten"))

	def startEditiereSelektieretenStream(self):
		sel=self.getCurrentSelection()
		if sel is not None:
			if JCcheckModuleIsUpdated:
				reload(EditStreamFavorite)
			self.session.openWithCallback(self.afterEditdSelectedStream, EditStreamFavorite.EditFavoriteStreamDB, sel.stationname)

	def afterEditdSelectedStream(self, res):
		logger.info('RadioBrowser]afterEditdSelectedStream]update Favoritelist, is chnaged->%s' %str(res))
		if res!=None:# stationname
			index=self['list'].getSelectedIndex()
			logger.info('RadioBrowser]afterEditdSelectedStream]update Favoritelist now index->%d' %index)
			self.listeFavoriten(index=index)

	def startLoescheSelektieretenStream(self, sel=None):#also called from player
		if sel is None:
			sel=self.getCurrentSelection()
		if sel is not None:
			removeStreamFromFavoriteList(sel)
			logger.info('RadioBrowser]startLoescheSelektieretenStream]remove station->%s' %sel.stationname)
			i=self['list'].getCurrentIndex()
			self['list'].removeItem(i)
			self['list'].refreshList()

	def startConfig(self):
		self.session.open(MusicCenterSetup)

	def startLog(self):
		self.session.open(LogScreen)

	def keyLeft(self):
		if self.headerpos>0:
			self.headerpos-=4
			self['key_arrow_left'].setText('<')
			self.setButtons(red=self.hl[self.headerpos+0], green=self.hl[self.headerpos+1], yellow=self.hl[self.headerpos+2], blue=self.hl[self.headerpos+3])
			if not self.headerpos>0:
				self['key_arrow_left'].setText('')

		if self.headerpos>0:
			self['key_arrow_right'].setText('>')
		self.updateBottomline()

	def keyRight(self):
		if self.headerpos < len(self.hl)-4:
			self.headerpos+=4
			self['key_arrow_right'].setText('>')
			self.setButtons(red=self.hl[self.headerpos+0], green=self.hl[self.headerpos+1], yellow=self.hl[self.headerpos+2], blue=self.hl[self.headerpos+3])
			if not self.headerpos < len(self.hl)-4:
				self['key_arrow_right'].setText('')

		if self.headerpos>0:
			self['key_arrow_left'].setText('<')
		self.updateBottomline()

	def updateBottomline(self):
		if self.bottomlineindex not in range(self.headerpos, self.headerpos+4):
			self.setBottomline(-1)
		else:
			self.setBottomline(self.bottomlineindex)

	def audioPressed(self):
		logger.info('Radiobrowser]audioPressed]')
		if self.player is not None and self.player.songList:
			self.session.execDialog(self.player)

	def getCurrentSelection(self):
		try: sel=self['list'].l.getCurrentSelection()[0]
		except: sel=None
		return sel

	def updateLCTText(self):
		entry=self['list'].getCurrent()
		if entry is not None:
			self.summaries.setText(entry.artist, 1)
			self.summaries.setText(entry.title, 2)
			self.summaries.setText(entry.stationname, 3)
		
	def createSummary(self):
		return RadioBrowserLCD

	def closePlayerNow(self):
		logger.info('Radiobrowser]closePlayerNow]')
		self.player.closePlayer()
		self.session.deleteDialog(self.player)
		self.player=None

	def closing(self):
		logger.info('RadioBrowser]closing]')
		if stationiconDownloader.isRunning:
			stationiconDownloader.cancel()
		self.close(self.player)

	def __onClose(self):
		logger.info('RadioBrowser]__onClose]...')


class RadioBrowserList(MenuList):

	def __init__(self, list, enableWrapAround = True):
		logger.info('RadioBrowserList]__init__]')
		MenuList.__init__(self, list, enableWrapAround, eListboxPythonMultiContent)
		if RESOLUTIONx==1920:
			self.rfactor=1.5
			self.l.setFont(0, gFont("SansReg", 38))
			self.l.setFont(1, gFont("SansReg", 32))
			self.l.setFont(2, gFont("SansReg", 25))
			self.thbsze=150
		else:
			self.rfactor=1
			self.l.setFont(0, gFont("SansReg", 26))
			self.l.setFont(1, gFont("SansReg", 21))
			self.l.setFont(2, gFont("SansReg", 17))
			self.thbsze=100
		self.l.setItemHeight(int(114*self.rfactor))
		self.l.setBuildFunc(self.buildEntryStation)
		self.onSelectionChanged = [ ]
		self.list = list
		self.nocoverptr=LoadPixmap(cached=False, path=drawImageJobWithLongMultilineText(text=_('No Stationicon'), size=(200,200), fontsize=30, round=20, out='/tmp/mc/radiobrowser_no_icon.png', force=True))
		
	def buildEntryStation(self, item): # stationname, stationicon, url
		f=self.rfactor
		res = [ None ]
		width=self.l.getItemSize().width()
		title, album, mypath, color, selcolor=item.slhelper
		ptr=None
		if fileExists(item.stationicon):
			#logger.debug('RadioBrowserList]buildEntryStation]:{}'.format(item.stationicon))
			ptr=LoadPixmap(cached=False, path=item.stationicon)
		if ptr is None:
			ptr = self.nocoverptr
		bitrate='{} | {}'.format(item.bitrate, item.codec)
		res.append((eListboxPythonMultiContent.TYPE_PIXMAP,	7*f,  7*f, self.thbsze, self.thbsze, ptr))
		res.append((eListboxPythonMultiContent.TYPE_TEXT,       120*f,  2*f, 720*f, 30*f, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, item.stationname, selcolor)) #stationname
		res.append((eListboxPythonMultiContent.TYPE_TEXT, 		120*f, 38*f, 720*f, 24*f, 1, RT_HALIGN_LEFT|RT_VALIGN_CENTER, item.genre, selcolor)) # tags
		res.append((eListboxPythonMultiContent.TYPE_TEXT,       120*f, 68*f, 720*f, 24*f, 1, RT_HALIGN_LEFT|RT_VALIGN_CENTER, item.location, selcolor)) #location
		res.append((eListboxPythonMultiContent.TYPE_TEXT, 		850*f,  5*f, 300*f, 24*f, 1, RT_HALIGN_CENTER|RT_VALIGN_CENTER, bitrate, selcolor)) # bitrate
		if item.filetype=='RADIOBROWSER':
			res.append((eListboxPythonMultiContent.TYPE_TEXT,       120*f, 68*f, 720*f, 24*f, 1, RT_HALIGN_LEFT|RT_VALIGN_CENTER, item.location+' | radio-browser.info', selcolor)) #location
			res.append((eListboxPythonMultiContent.TYPE_TEXT,		850*f, 38*f, 300*f, 24*f, 1, RT_HALIGN_CENTER|RT_VALIGN_CENTER, 'Clicks(%s)' %item.playcount, selcolor))
			res.append((eListboxPythonMultiContent.TYPE_TEXT,		850*f, 68*f, 300*f, 24*f, 1, RT_HALIGN_CENTER|RT_VALIGN_CENTER, 'Votes(%s)' %item.votes, selcolor))
		elif item.filetype=='RADIODE':
			res.append((eListboxPythonMultiContent.TYPE_TEXT,       120*f, 68*f, 720*f, 24*f, 1, RT_HALIGN_LEFT|RT_VALIGN_CENTER, item.location+' | Radio.de', selcolor)) #location
			res.append((eListboxPythonMultiContent.TYPE_TEXT,		850*f, 38*f, 300*f, 24*f, 1, RT_HALIGN_CENTER|RT_VALIGN_CENTER, 'Rang:{}'.format(item.playcount), selcolor))
			res.append((eListboxPythonMultiContent.TYPE_TEXT,		850*f, 68*f, 300*f, 24*f, 1, RT_HALIGN_CENTER|RT_VALIGN_CENTER, 'Rating:{}'.format(item.votes), selcolor))
		return res

	def getCurrentIndex(self):
		return self.getSelectedIndex()
		
	#def getRes(self):
	#	esize = self.l.getItemSize()
	#	return esize.width(), esize.height()
	
	def getCurrent(self):
		cur = self.l.getCurrentSelection()
		return cur and cur[0]

	def connectSelChanged(self, fnc):
		if not fnc in self.onSelectionChanged:
			self.onSelectionChanged.append(fnc)

	def getItemCount(self):
		return  len(self.list)

	def getList(self):
		return self.list

	def refreshList(self):
		i=self.getSelectedIndex()
		self.setList(self.list)
		self.moveToIndex(i)

	def removeItem(self, index):
		del self.list[index]
		self.l.entryRemoved(index)


class RadioBrowserLCD(Screen):

	skin="""
		<screen position="0,0" size="132,64">
			<widget name="screenname" position="2,2" size="128,14" font="SansReg;12"/>
			<widget name="text1" position="2,17" size="128,14" font="SansReg;12"/>
			<widget name="text2" position="2,32" size="128,14" font="SansReg;12"/>
			<widget name="text3" position="2,47" size="128,14" font="SansReg;12"/>
		</screen>"""

	def __init__(self, session, parent):
		Screen.__init__(self, session)
		self["screenname"] = Label(_('MusicCenter Radiobrowser'))
		self["text1"]=Label()
		self["text2"]=Label()
		self["text3"]=Label()

	def setText(self, text, line):
		if line == 1:
			self["text1"].setText(text)
		elif line == 2:
			self["text2"].setText(text)
		elif line == 3:
			self["text3"].setText(text)
		else:
			pass

