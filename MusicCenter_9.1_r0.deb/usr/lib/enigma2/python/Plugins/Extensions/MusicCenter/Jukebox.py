﻿# -*- coding: UTF-8 -*-

#  Music Center E2
#
#  Coded by bobo71 (c) 2014
#  Support: www.dreambox-tools.info
#
#  All Files of this Software are licensed under the Creative Commons
#  Attribution-NonCommercial-ShareAlike 3.0 Unported
#  License if not stated otherwise in a Files Head. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.

#  Additionally, this plugin may only be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.

#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially
#  distributed other than under the conditions noted above
#  This applies to the source code as a whole as well as to parts of it, unless
#  explicitely stated otherwise.


		
from sys import getsizeof, stderr
from itertools import chain
from collections import deque
try:
	from reprlib import repr
except ImportError:
	pass

from Globals import *

# local plugin
from JobCenter import *
from JobCenter2 import *						
from myLogger import logger
from ItemClasses import Item
from SelectPath import SelectPath
import Player
from Setup import MusicCenterSetup
from TaskViewScreen import MusicCenterTasksScreen

def save_obj(obj, filename):
	with open(filename, 'wb') as f:
		pickle.dump(obj, f)


def load_obj(filename):
	with open(filename, 'rb') as f:
		return pickle.load(f)


class Jukebox(Screen, ConfigListScreen):

	if RESOLUTIONx>1800:
		skin='''
			<screen name="Jukebox" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#00000000" zPosition="0">
			<!-- Header -->
				<eLabel backgroundColor="#191919" position="20,20" size="1900,100" zPosition="1" /> 
				<widget name="headertext" position="140,39" size="1760,42" font="SansReg;35" foregroundColor="#ffffff" backgroundColor="#191919" halign="center" valign="center" zPosition="3" />
				<ePixmap position="20,20" size="100,100" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/Jukebox.png" scale="1" zPosition="2"/>
			<!-- Buttons -->
				<eLabel position="20,135" size="1880,40" backgroundColor="#191919" zPosition="1" /> 
				<widget render="Label" font="SansReg;40" position="30,135" size="40,40" source="key_arrow_left" foregroundColor="#ffffff" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
				<widget render="Label" font="SansReg;34" position="100,135" size="450,40" source="key_red" foregroundColor="#ff0000" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
				<widget render="Label" font="SansReg;34" position="510,135" size="450,40" source="key_green" foregroundColor="#00ff21" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
				<widget render="Label" font="SansReg;34" position="960,135" size="450,40" source="key_yellow" foregroundColor="#FFD800" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
				<widget render="Label" font="SansReg;34" position="1410,135" size="450,40" source="key_blue" foregroundColor="#3D8DFF" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>	
				<widget render="Label" font="SansReg;40" position="1870,135" size="40,40" source="key_arrow_right" foregroundColor="#ffffff" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
			<!-- lists -->
				<widget name="list" position="75,200" zPosition="1" size="1770,855" scrollbarMode="showOnDemand" backgroundColor="#00000000"/>
				<widget name="config" position="150,180" zPosition="-2" size="1620,68" itemHeight="55" scrollbarMode="showNever" transparent="1"/>
			</screen>'''
	else:
		skin='''
			<screen name="Jukebox" position="0,0" size="1280,720" flags="wfNoBorder" backgroundColor="#00000000" zPosition="0">
			<!-- Header -->
				<eLabel backgroundColor="#191919" position="13,13" size="1267,67" zPosition="1" /> 
				<widget name="headertext" position="96,26" size="1173,28" font="SansReg;25" foregroundColor="#ffffff" backgroundColor="#191919" halign="center" valign="center" zPosition="3" />
				<ePixmap position="13,13" size="67,67" pixmap="/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/Jukebox.png" scale="1" zPosition="2"/>
			<!-- Buttons -->
				<eLabel position="13,90" size="1267,34" backgroundColor="#191919" zPosition="1" /> 
				<widget render="Label" font="SansReg;24" position="20,96" size="26,24" source="key_arrow_left" foregroundColor="#ffffff" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
				<widget render="Label" font="SansReg;20" position="67,96" size="300,24" source="key_red" foregroundColor="#ff0000" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
				<widget render="Label" font="SansReg;20" position="340,96" size="300,24" source="key_green" foregroundColor="#00ff21" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
				<widget render="Label" font="SansReg;20" position="640,96" size="300,24" source="key_yellow" foregroundColor="#FFD800" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
				<widget render="Label" font="SansReg;20" position="940,956" size="300,24" source="key_blue" foregroundColor="#3D8DFF" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>	
				<widget render="Label" font="SansReg;20" position="1247,96" size="40,24" source="key_arrow_right" foregroundColor="#ffffff" backgroundColor="#191919" halign="center" valign="center" zPosition="2"/>
			<!-- lists -->
				<widget name="list" position="50,130" zPosition="1" size="1180,570" scrollbarMode="showOnDemand" backgroundColor="#00000000"/>
				<widget name="config" position="100,120" zPosition="-2" size="1080,46" itemHeight="39" scrollbarMode="showNever" transparent="1"/>
			</screen>'''

	def __init__(self, session, player, currentService, serviceList):

		logger.info('Jukebox]init...')
		self.session=session
		self.currentService=currentService
		self.serviceList=serviceList
		self.skin_path='/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images'
		
		Screen.__init__(self, session)
		
		# suggestion
		config.plugins.musiccenter.db_search =  NoSave(ConfigText(default = '', fixed_size = False))
		self.config = [] 
		self.config.append(getConfigListEntry(_("Enter Searchword here"), config.plugins.musiccenter.db_search))
		self['config'] = self.config
		
		ConfigListScreen.__init__(self, self.config, session)
				
		self['list']=JukeboxList([])
		self["actions"]=ActionMap(["WizardActions", "DirectionActions", "ColorActions", "EPGSelectActions", "InfobarAudioSelectionActions"],
		{
			"ok": self.okPressed,
			"back": self.closing,
			"red": self.redPressed,
			"green": self.greenPressed,
			"yellow": self.yellowPressed,
			"blue": self.bluePressed,
			"input_date_time": self.menuPressed,
			"info" : self.infoPressed,
			"audioSelection": self.audioPressed,
			"down": self.keyDown,
			"right": self.keyRight,
		}, -1)

		self["actions2"]=NumberActionMap(["InputActions"],
		{
			"8": self.startSearch,
			"0": self.goToIndexNull,
		}, -1)
	
		# search suggestion
		self["config_actions"] = NumberActionMap(["SetupActions", "InputAsciiActions", "KeyboardInputActions", "WizardActions"],
		{
			"gotAsciiCode": self.keyGotAscii,
			"ok": self.keyOK,
			"up": self.up,
			"down": self.keyDown,
			"left": self.keyLeft,
			"right": self.keyRight,
			"home": self.keyHome,
			"end": self.keyEnd,
			"deleteForward": self.keyDelete,
			"deleteBackward": self.keyBackspace,
			"toggleOverwrite": self.keyToggleOW,
			"1": self.keyNumberGlobal,
			"2": self.keyNumberGlobal,
			"3": self.keyNumberGlobal,
			"4": self.keyNumberGlobal,
			"5": self.keyNumberGlobal,
			"6": self.keyNumberGlobal,
			"7": self.keyNumberGlobal,
			"8": self.keyNumberGlobal,
			"9": self.keyNumberGlobal,
			"0": self.keyNumberGlobal	
		}, -1) # to prevent left/right overriding the listbox


		self.onLayoutFinish.append(self.__startRun)
		self.onClose.append(self.__onClose)

		self.player=player
		self.mode='mainmenusonglist'
		self.cacheList=[]
		self.hlp={}
		self.__dbpool = OpenDatabasePool()
 
		self["key_arrow_left"]=StaticText("<")
		self["key_red"]=StaticText("")
		self["key_green"]=StaticText("")
		self["key_yellow"]=StaticText("")
		self["key_blue"]=StaticText("")
		self["key_arrow_right"]=StaticText(">")
		self['headertext']=BlinkingLabel()
		self.headerTextList=[]
		self.songListtmp=[]
		self.scanPath_mc_conn=None
		self.jukeboxfavoriten=[]
		self.len_songlist_all=0
		self.chunksize=20
		self.songlist_all=[]
		if fileExists(resolveFilename(SCOPE_CONFIG ,"mc_jukeboxfavoriten")):
			self.jukeboxfavoriten=load_obj(resolveFilename(SCOPE_CONFIG ,"mc_jukeboxfavoriten"))
		#suggestion
		self.suggestlen=0
		self.suggestword=''
		self.searchvalueTimer=eTimer()
		self.searchvalueTimer_mc_conn=self.searchvalueTimer.timeout.connect(self.searchvalueTimerAppend)
		self.suggestionsThread_mc_conn=suggestionsThread.MessagePump.recv_msg.connect(self.suggestionsThreadgotThreadMsg)
			
	def __startRun(self):
		logger.info('Jukebox]__startRun]')
		self['list'].connectSelChanged(self.updateLCTText)		
		self.setListView()
		self.buildMainmenu()
	
	def setListView(self):
		logger.info('Jukebox]setListView]')
		self["config"].hide()
		self["actions"].setEnabled(True)
		self["actions2"].setEnabled(True)
		self["config_actions"].setEnabled(False)
		current = self["config"].getCurrent()
		if current[1].help_window.instance is not None:
			current[1].help_window.instance.hide()
		self['list'].selectionEnabled(1)

	def buildMainmenu(self):
		self.setListNow([], header='Bitte warten, hole daten von deiner Datenbank...', red='-', green='-', yellow='-', blue='-')
		sql='''SELECT DISTINCT genre, date, count(*) FROM Songs GROUP BY genre,date ORDER BY genre;'''
		logger.info('Jukebox]buildMainmenu]get sql now:{}'.format(sql))
		self.__dbpool.runQuery(sql,).addCallback(self.buildMainMenuCallback).addErrback(self.errorSQLCommand, 'buildMainmenu')

	def buildMainMenuCallback(self, result):
		logger.info('Jukebox]buildMainMenuCallback]:{}'.format(str(result)[:120]))
		self.cacheList=result # [(Electronic, 2017, 3),...]
		jahrecount=len(set([entry[1] for entry in result]))
		genrecount=len(set([entry[0] for entry in result]))
		self.headerTextList=['Zufallsgenerator', 'Filter Jahr({})'.format(jahrecount), 'Filter Genre({})'.format(genrecount), 'Filter Favoriten', 'Suche','','','']
		self.setListNow([], header='Jukebox, treffe Deine Auswahl', red=self.headerTextList[0], green=self.headerTextList[1], yellow=self.headerTextList[2], blue=self.headerTextList[3])
# random songs
	def getRandomSongs(self):
		self.mode='jukeboxrandomsonglist'
		self.setListNow([], header='Einen Moment Geduld, lade zufällige Songs')
		sql='''SELECT * FROM songs ORDER BY RANDOM() LIMIT 500;''' #SELECT * FROM songs WHERE song_id IN (SELECT song_id FROM songs ORDER BY RANDOM() LIMIT 100);'''
		logger.info('Jukebox]getRandomSongs]get sql now:{}'.format(sql))
		self.__dbpool.runQuery(sql,).addCallback(self.buildJukeboxSonglistCallback).addErrback(self.errorSQLCommand, 'getRandomSongs')
# jahr
	def startJahrAusgewaehlt(self):
		self.mode='jukeboxsonglist'
		self['headertext'].setText('Suche Jahre in Datenbank...')
		jukeboxselectedgenres=self.hlp.get('jukeboxselectedgenres',[])
		if jukeboxselectedgenres:
			jahre=sorted(list(set([ entry[1] for entry in self.cacheList if entry[0] in jukeboxselectedgenres])))
		else:
			jahre=sorted(list(set([entry[1] for entry in self.cacheList])))
		jahrliste=[]
		jahrlistekopf=[]
		jukeboxselectedjahre=self.hlp.get('jukeboxselectedjahre',[])
		if jukeboxselectedjahre:
			jahrliste.append((("Selektion loeschen"), 'clear'))
		for jahr in jahre:
			if jukeboxselectedgenres:
				count=sum([entry[2] for entry in self.cacheList if jahr == entry[1] and entry[0] in jukeboxselectedgenres])
			else:
				count=sum([entry[2] for entry in self.cacheList if jahr == entry[1]])
			if jahr in jukeboxselectedjahre:	
				jahrlistekopf.append(('>>>>>{} ({})<<<<<'.format(jahr.encode(), count), jahr.encode()),)
			else:
				jahrliste.append((' {} ({}) '.format(jahr.encode(), count), jahr.encode()),)
		self.session.openWithCallback(self.jahrAusgewaehlt, ChoiceBox, title=_("Markiere ein Jahr"), list=jahrlistekopf+sorted(jahrliste,reverse=True), keys=MYKEYSORT, titlebartext=_("MusicCenter Jukebox"))
		
	def jahrAusgewaehlt(self, jahrgewaehlt):
		logger.info('Jukebox]jahrAusgewaehlt]jahrgewaehlt:{}'.format(jahrgewaehlt))
		if jahrgewaehlt is not None:
			jahrgewaehlt=jahrgewaehlt[1]
			jukeboxselectedgenres=self.hlp.get('jukeboxselectedgenres',[])
			if jahrgewaehlt=='fromyear':
				jukeboxselectedjahre=self.hlp.get('jukeboxselectedjahre',[])
			elif jahrgewaehlt=='clear':
				todelete=self.hlp.pop('jukeboxselectedjahre')
				logger.info('Jukebox]jahrAusgewaehlt]clear jukeboxselectedjahre->%s' %str(todelete))
				if jukeboxselectedgenres:
					self.genreAusgewaehlt(('','fromyear'))
				else:
					header='Jukebox, treffe Deine Auswahl!'
					self.setButtons(red='Zufallsgenerator', green='Jahr Filter', yellow='Genre Filter', blue='Favorite Filter')
					self.setListNow([], header=header)
				return

			else:
				jukeboxselectedjahre=self.hlp.get('jukeboxselectedjahre',[])
				if jahrgewaehlt not in jukeboxselectedjahre:
					jukeboxselectedjahre.append(jahrgewaehlt)
				else:
					jukeboxselectedjahre.pop(jukeboxselectedjahre.index(jahrgewaehlt))
				self.hlp['jukeboxselectedjahre']=jukeboxselectedjahre
			self.buildJukeboxSonglist(jukeboxselectedgenres, jukeboxselectedjahre)		

	def makesqlitelist(self, list):
		if len(list)==1:
			return str(tuple(list)).replace(',','')
		else:
			return str(tuple(list))

	def startGenreAusgeaehlt(self):
		self.mode='jukeboxsonglist'
		logger.info('Jukebox]startGenreAusgeaehlt]')
		self['headertext'].setText('Suche Genre in Datenbank...')
		jukeboxselectedjahre=self.hlp.get('jukeboxselectedjahre',[])
		if jukeboxselectedjahre:
			genres=sorted(list(set([ entry[0] for entry in self.cacheList if entry[1] in jukeboxselectedjahre])))
		else:
			genres=sorted(list(set([entry[0] for entry in self.cacheList])))
		genreliste=[]
		genrelistekopf=[]
		jukeboxselectedgenres=self.hlp.get('jukeboxselectedgenres',[])
		if jukeboxselectedgenres:
			genreliste.append((("Selektion loeschen"), 'clear'))
		for genre in genres:
			if jukeboxselectedjahre:
				count=sum([entry[2] for entry in self.cacheList if genre in entry[0] and entry[1] in jukeboxselectedjahre ])
			else:
				count=sum([entry[2] for entry in self.cacheList if genre in entry[0] ])
			if genre in jukeboxselectedgenres:	
				genrelistekopf.append(('>>>>>{} ({})<<<<<'.format(genre, count), genre),)
			else:
				genreliste.append((' {} ({}) '.format(genre, count), genre),)
		self.session.openWithCallback(self.genreAusgewaehlt, ChoiceBox, title=_("Markiere ein Genre"), list=genrelistekopf+genreliste, keys=MYKEYSORT, titlebartext=_("MusicCenter Jukebox"))
		
	def genreAusgewaehlt(self, genregewaehlt=None): # angepasst
		logger.info('Jukebox]genreAusgewaehlt]genregewaehlt:{}'.format(genregewaehlt))
		if genregewaehlt is not None:
			genregewaehlt=genregewaehlt[1]
			jukeboxselectedjahre=self.hlp.get('jukeboxselectedjahre',[])
			if genregewaehlt=='fromyear':
				jukeboxselectedgenres=self.hlp.get('jukeboxselectedgenres',[])
			elif genregewaehlt=='clear':
				todelete=self.hlp.pop('jukeboxselectedgenres')
				logger.info('Jukebox]genreAusgewaehlt]clear jukeboxselectedgenres->%s' %str(todelete))
				if jukeboxselectedjahre:
					self.jahrAusgewaehlt(('','fromyear'))
				else:
					header='Jukebox, treffe Deine Auswahl!'
					self.setListNow([], header=header, red='Zufallsgenerator', green='Jahr Filter', yellow='Genre Filter', blue='Favorite Filter')
				return
			else:
				jukeboxselectedgenres=self.hlp.get('jukeboxselectedgenres',[])
				if genregewaehlt not in jukeboxselectedgenres:
					jukeboxselectedgenres.append(genregewaehlt)
				else:
					jukeboxselectedgenres.pop(jukeboxselectedgenres.index(genregewaehlt))
				self.hlp['jukeboxselectedgenres']=jukeboxselectedgenres
			
			self.buildJukeboxSonglist(jukeboxselectedgenres, jukeboxselectedjahre)		
			
	def buildJukeboxSonglist(self, jukeboxselectedgenres, jukeboxselectedjahre):
		logger.info('Jukebox]buildJukeboxSonglist]jukeboxselectedgenres:{} jukeboxselectedjahre:{}'.format(jukeboxselectedgenres, jukeboxselectedjahre))
		if jukeboxselectedjahre and not jukeboxselectedgenres:
			sql='''SELECT * FROM Songs WHERE date in %s ORDER by artist, title, filename;''' %self.makesqlitelist(jukeboxselectedjahre)
		elif not jukeboxselectedjahre and jukeboxselectedgenres:
			sql='''SELECT * FROM Songs WHERE genre in %s ORDER by artist, title, filename;''' %self.makesqlitelist(jukeboxselectedgenres)
		elif jukeboxselectedjahre and jukeboxselectedgenres:
			sql='''SELECT * FROM Songs WHERE genre in %s AND date in %s ORDER by artist, title, filename;''' %(self.makesqlitelist(jukeboxselectedgenres), self.makesqlitelist(jukeboxselectedjahre))
		else:
			header='Jukebox, treffe Deine Auswahl!????'
			self.setListNow([], header=header, red='Zufallsgenerator', green='Jahr Filter', yellow='Genre Filter', blue='Favorite Filter')
			return
		self.setListNow([], header='Hole Songs aus der Datenbank...')

		logger.info('Jukebox]buildJukeboxSonglist]get sql now:{}'.format(sql))
		self.hlp['lastselectedgenresundjahre']=(jukeboxselectedgenres, jukeboxselectedjahre)
		self.__dbpool.runQuery(sql,).addCallback(self.buildJukeboxSonglistCallback).addErrback(self.errorSQLCommand, 'buildJukeboxSonglist')
	
	def buildJukeboxSonglistCallback(self, result):
		self.scanPath_mc_conn=scanPath.MessagePump.recv_msg.connect(self.gotThreadMsg)
		self.scaned_count=0
		self.songListtmp=[]
		songlist_all = [ config.plugins.musiccenter.defaultfilebrowserpath.value+row['filename'] for row in result if fileExists(config.plugins.musiccenter.defaultfilebrowserpath.value+row['filename'])]
		self.len_songlist_all=len(songlist_all)
		self.songlist_all=[songlist_all[i:i + self.chunksize] for i in xrange(0, len(songlist_all), self.chunksize)]
		if self.songlist_all:
			scanPath.Start(self.songlist_all.pop(0))
		else:
			self.clearThreadmessage()
			self.scanFinished()					
						
	def getNextEntries(self, getallentrys):
		if self.songlist_all:
			self.scanPath_mc_conn=scanPath.MessagePump.recv_msg.connect(self.gotThreadMsg)			
			logger.info('Jukebox]getNextEntries]start scanPath!')
			if getallentrys:
				l=[]
				for i in self.songlist_all:
					l=l+i
				self.songlist_all=[]
				scanPath.Start(l)
			else:
				scanPath.Start(self.songlist_all.pop(0))
		else:
			logger.info('Jukebox]getNextEntries]end of list...')
			self.scanFinished()
		
	def gotThreadMsg(self, msg):
		msg=scanPath.Message.pop()
		logger.debug('Jukebox]gotThreadMsg]msg:{}'.format(msg))

		if msg[0] in ('THREAD_WORKING', 'THREAD_SCAN_FINISHED'):
			self.scaned_count +=1
			self.songListtmp.append((msg[1],))
			self['headertext'].setText(_('Lese song {} von {}'.format(self.scaned_count, self.len_songlist_all)))
			if msg[0]=='THREAD_SCAN_FINISHED':
				logger.info('Jukebox]gotThreadMsg]msg:{}'.format(msg))
				self.scanFinished()
		elif msg[0]=='THREAD_FINISHED': # database updated
			logger.info('Jukebox]gotThreadMsg]THREAD_FINISHED database updated')
			self.clearThreadmessage()
		elif msg[0]=='THREAD_EXCEPTED':
			t='Error read songlist->%s' %msg[1]
			logger.error('Jukebox]gotThreadMsg]THREAD_EXCEPTED set waittext->%s' %t)
			self['headertext'].setText(_(t))
			self.clearThreadmessage()
		else:
			t='Read %d/%s Error read file!!!' %(self.scaned_count, self.len_songlist_all)
			logger.error('Jukebox]gotThreadMsg]set waittext->%s' %t)

	def scanFinished(self):
		logger.info('Jukebox ]scanFinished]set list')
		if self.mode=='jukeboxrandomsonglist':
			header='Zufaellig ausgewaehlte Songs '
		else:
			jukeboxselectedgenres=self.hlp.get('jukeboxselectedgenres',[])
			jukeboxselectedjahre=self.hlp.get('jukeboxselectedjahre',[])
			header='{} Songs '.format('|'.join(jukeboxselectedjahre+jukeboxselectedgenres))
		self.setListNow(self.songListtmp, header=header)

	def clearThreadmessage(self):
		logger.info('Jukebox]clearThreadmessage]Start')
		self.scanPath_mc_conn=None

	def startgetJukeboxFavoriten(self):
		self.mode='favoritensonglist'
		choicelist=[]
		favorites=self.jukeboxfavoriten
		for favorit in favorites:
			choicelist.append(('Genre:%s Jahr:%s' %(' | '.join(favorit[0]), ' | '.join(favorit[1])), favorit),)
		self.session.openWithCallback(self.favoritausgewaehlt, ChoiceBox, title=_("Markiere einen Favoriten"), list=choicelist, keys=MYKEYSORT, titlebartext=_("MusicCenter Jukebox"))
		
	def favoritausgewaehlt(self, ret):
		if ret:
			logger.info('Jukebox]favoritausgewaehlt]->%s' %str(ret))
			self.hlp['jukeboxselectedgenres']=ret[1][0]
			self.hlp['jukeboxselectedjahre']=ret[1][1]
			self.buildJukeboxSonglist(ret[1][0], ret[1][1])
			
	def errorSQLCommand(self, error, functionname='n/a'):
		logger.error('Jukebox]errorSQLCommand]error-->%s' %error) 
		header='Oh, was ist los->%s' %error
		self.setListNow(list=[], header=header)

	def menuPressed(self):
		menuentrys=[(_("Configuration"), self.openConfig)]
		if self.mode=='favoritensonglist':
			menuentrys.append((_("Delete current filter from Favoritelist"), self.deleteCurrentSonglistToFavoritelist),)
		elif self.mode=='jukeboxsonglist':
			menuentrys.append((_("Add current filter to Favoritelist"), self.addCurrentSonglistToFavoritelist),)
		self.session.openWithCallback(self.menuCallback, ChoiceBox, title=_("Jukebox options:"), list=menuentrys, keys=MYKEYSORT, titlebartext=_("MusicCenter"))

	def menuCallback(self, ret):
		ret and ret[1]()

	def infoPressed(self):
		return

	def infoCallback(self, ret):
		ret and ret[1]()

	def goToIndexNull(self, number):
		logger.info('Jukebox]goToIndexNull]number:{}'.format(number))
		self['list'].moveToIndex(0)

	def addCurrentSonglistToFavoritelist(self):
		logger.info('Jukebox]addCurrentSonglistToFavoritelist]start,')
		selectedgenres, selectedjahre=self.hlp.get('lastselectedgenresundjahre')
		self.jukeboxfavoriten.append((selectedgenres, selectedjahre))
		save_obj(self.jukeboxfavoriten, resolveFilename(SCOPE_CONFIG ,"mc_jukeboxfavoriten"))

	def deleteCurrentSonglistToFavoritelist(self):
		selectedgenres, selectedjahre=self.hlp.get('lastselectedgenresundjahre')
		logger.info('Jukebox]deleteCurrentSonglistToFavoritelist]start:{}-{}'.format(selectedgenres, selectedjahre))
		for index, entry in enumerate(self.jukeboxfavoriten):
			if (selectedgenres, selectedjahre)==entry:
				self.jukeboxfavoriten.pop(index)
		save_obj(self.jukeboxfavoriten, resolveFilename(SCOPE_CONFIG ,"mc_jukeboxfavoriten"))
# ## Ok
	def okPressed(self):
		logger.info('Jukebox]okPressed]start')
		try:
			sel=self['list'].l.getCurrentSelection()[0]
		except:
			sel=None
		if sel is None:
			return
		if sel.songID==-10000:# extend list entry!
			self.getNextEntries(True)
			logger.info('Jukebox]okPressed]gatall items start now.')
			return
		if self.player is not None:
			if self.player.hlp.get('currIndex')!=-2:
				self.player.stopPlay()
			logger.info('Jukebox]scanFinished]is player instance, delete now...')
			self.session.deleteDialog(self.player)
			self.player=None			
		try:
			if JCcheckModuleIsUpdated('Player'):
				reload(Player)
		except Exception, e:
			self.session.open(MessageBox, _("Error reload Player\n%s" %e), type=MessageBox.TYPE_ERROR, timeout=10 )
	
		logger.info('Jukebox]scanFinished]instantiate new player dialog')
		self.player=self.session.instantiateDialog(Player.Player, songList=self['list'].getList(), index=self['list'].getCurrentIndex(), playermode=DBMODE, currentService=self.currentService, serviceList=self.serviceList, jukeboxinstance=self)
		self.player.setShowHideAnimation("quick_fade")
		self.session.execDialog(self.player)

# buttons
	def setListNow(self, list=[], header='', red=None, green=None, yellow=None, blue=None):
		logger.info('Jukebox]setListNow]set list.mode:{}'.format(self.mode))
		index=self['list'].getCurrentIndex()	
		itemcount=len(list)#self['list'].getItemCount()
		if itemcount:
			if self.songlist_all:
				logger.debug('Jukebox]setListNow]is songlist_all, append extend entry!')
				list=list[:]
				list.append((Item(songID=-10000, text='Druecke OK, und lade alle {} Ergebnisse'.format(self.len_songlist_all)),))
				self['list'].setList(list)	
				self['list'].moveToIndex(index)
				self['headertext'].setText(_('{}(>{})'.format(header, itemcount)))
			else:
				logger.debug('Jukebox]setListNow]not songlist_all')
				self['list'].setList(list)	
				self['list'].moveToIndex(index)
				self['headertext'].setText(_('{}({})'.format(header, itemcount)))
		else:
			logger.debug('Jukebox]setListNow]no entrys given')
			self['headertext'].setText(_('{} keine Eintrag'.format(header)))
		self.setButtons(red, green, yellow, blue)

	def setButtons(self, red=None, green=None, yellow=None, blue=None):
		if red!=None:
			self["key_red"].setText(red)
		if green!=None:	
			self["key_green"].setText(green)
		if yellow!=None:
			self["key_yellow"].setText(yellow)
		if blue!=None:
			self["key_blue"].setText(blue)

	def audioPressed(self):
		logger.info('Jukebox]audioPressed]')
		if self.player is not None and self.player.songList:
			self.session.execDialog(self.player)

	def closePlayerNow(self):
		logger.info('Jukebox]closePlayerNow]')
		self.player.closePlayer()
		self.session.deleteDialog(self.player) 
		self.player=None

	def redPressed(self):
		if scanPath.isRunning:
			self.session.toastManager.showToast(_('Ich bin beschäftigt, ein wenig Geduld...'), 2)
			return
		logger.info('Jukebox]redPressed]mode:{}'.format(self.mode))
		self.getRandomSongs()

	def greenPressed(self):
		if scanPath.isRunning:
			self.session.toastManager.showToast(_('Ich bin beschäftigt, ein wenig Geduld...'), 2)
			return		
		logger.info('Jukebox]greenPressed]mode:{}'.format(self.mode))
		self.startJahrAusgewaehlt()

	def yellowPressed(self):
		if scanPath.isRunning:
			self.session.toastManager.showToast(_('Ich bin beschäftigt, ein wenig Geduld...'), 2)
			return		
		logger.info('Jukebox]yellowPressed]mode:{}'.format(self.mode))
		self.startGenreAusgeaehlt()

	def bluePressed(self):
		if scanPath.isRunning:
			self.session.toastManager.showToast(_('Ich bin beschäftigt, ein wenig Geduld...'), 2)
			return
		logger.info('Jukebox]bluePressed]mode:{}'.format(self.mode))
		self.startgetJukeboxFavoriten()

	def openConfig(self):
		self.session.open(MusicCenterSetup)
# search suggestion
	
	def startSearch(self, number):
		if scanPath.isRunning:
			self.session.toastManager.showToast(_('Ich bin beschäftigt, ein wenig Geduld...'), 2)
			return
		logger.info('Jukebox]startSearch]mode:{}'.format(self.mode))
		self.mode='searchsonglist'
		self.hlp['searchsuggestiontype']='ALL'
		self.switchListView2()
		self.searchvalueTimer.start(200)	
	
	def switchListView2(self):
		splitListview=self.hlp.get('splitListview2', False)
		if RESOLUTIONx>1800:
			f=1.5
		else:
			f=1.0
		if not splitListview: # set configlist
			logger.info('Jukebox]switchListView2]->config activ')
			list=self['list']
			list.resize(int(1180*f),int(530*f))
			list.move(int(50*f),int(170*f))
			list.selectionEnabled(0)
			
			sub0=self['config']
			sub0.instance.setZPosition(6)
			sub0.show()
			
			self["actions"].setEnabled(False)
			self["actions2"].setEnabled(False)
			self["config_actions"].setEnabled(True)
			current = self["config"].getCurrent()
			if current[1].help_window.instance is not None:
				current[1].help_window.instance.show()
			self.hlp['splitListview2']=True	
		else:
			logger.info('Jukebox]switchListView2]->reslut activ')
			list=self['list']
			list.resize(int(1180*f),int(570*f))
			list.move(int(50*f),int(130*f))
			list.selectionEnabled(1)
			
			sub0=self['config']
			sub0.instance.setZPosition(-2)
			sub0.hide()
			
			self["actions"].setEnabled(True)
			self["actions2"].setEnabled(True)
			self["config_actions"].setEnabled(False)
			current = self["config"].getCurrent()
			if current[1].help_window.instance is not None:
				current[1].help_window.instance.hide()
			self.hlp['splitListview2']=False

	def searchvalueTimerAppend(self):
		l=len(config.plugins.musiccenter.db_search.value)
		#logger.info('Jukebox]searchvalueTimerAppend]suggestword->%s config.plugins.musiccenter.db_search.value->%s' %(self.suggestword, config.plugins.musiccenter.db_search.value))
		if config.plugins.musiccenter.db_search.value !=self.suggestword:# and l!=self.suggestlen:
			searchsuggestiontype=self.hlp.get('searchsuggestiontype')
			suggestionsThread.Start(searchword=config.plugins.musiccenter.db_search.value, searchsuggestiontype=searchsuggestiontype)
			self.suggestlen=l
			self.suggestword=config.plugins.musiccenter.db_search.value
			logger.info('Jukebox]searchvalueTimerAppend]suggestword->%s searchsuggestiontype->%s' %(self.suggestword, searchsuggestiontype))

	def suggestionsThreadgotThreadMsg(self, msg):
		msg=suggestionsThread.Message.pop()
		self.setListNow(msg[0])
		self['headertext'].setText(_(str(msg[1])))

	def keyOK(self): # from ['config_actions']
		self.searchvalueTimer.stop()
		self["config"].invalidateCurrent()
		self.switchListView2()
		logger.info('Jukebox]keyOK]suggestiontext->%s' %config.plugins.musiccenter.db_search.value)
		
	def up(self):
		self['list'].up()

	def keyDown(self):
		if scanPath.isRunning:
			self.session.toastManager.showToast(_('Ich bin beschäftigt, ein wenig Geduld...'), 2)
			return
		if self.hlp.get('splitListview2', False):
			self.keyOK()
		else:
			index=self['list'].getCurrentIndex()
			count=self['list'].getItemCount()
			logger.info('Jukebox]keyDown]index:{} count:{}'.format(index, count))
			if index >= count-2:
				self.getNextEntries(False)
				if index < count:
					self['list'].down()
			else:
				self['list'].down()
		
	def left(self):
		self['list'].pageUp()

	def keyRight(self):
		if scanPath.isRunning:
			self.session.toastManager.showToast(_('Ich bin beschäftigt, ein wenig Geduld...'), 2)
			return
		index=self['list'].getCurrentIndex()
		count=self['list'].getItemCount()-1
		logger.info('Jukebox]keyRight]index:{} count-1:{}'.format(index, count))
		if index == count:
			self.getNextEntries(False)
		else:
			self['list'].pageDown()

	def updateLCTText(self):
		try:
			entry=self['list'].getCurrent()
		except:
			entry=None
		if entry is not None:
			self.summaries.setText(entry.artist, 1)
			self.summaries.setText(entry.title, 2)
			self.summaries.setText(entry.album, 3)
		
	def createSummary(self):
		return JukeboxLCD

	def closing(self):
		logger.info('Jukebox]closing]Start')
		if scanPath.isRunning:
			logger.info('Jukebox]__onClose]scanPath remove')
			scanPath.Cancel()
			self.clearThreadmessage()
		self.__dbpool.close()
		self.close(self.player)

	def __onClose(self):
		logger.info('Jukebox]__onClose]...')


class JukeboxList(MenuList):

	def __init__(self, list= [], enableWrapAround = True):
		
		logger.info('JukeboxList]__init__]')
		MenuList.__init__(self, list, enableWrapAround, eListboxPythonMultiContent)
		
		if RESOLUTIONx==1920:
			self.rfactor=1.5
			self.l.setFont(0, gFont("SansReg", 39))
			self.l.setFont(1, gFont("SansReg", 30))
			self.l.setFont(2, gFont("SansReg", 25))
			self.l.setFont(3, gFont("SansReg", 60))
			self.thbsze=150
		else:
			self.rfactor=1
			self.l.setFont(0, gFont("SansReg", 26))
			self.l.setFont(1, gFont("SansReg", 20))
			self.l.setFont(2, gFont("SansReg", 17))
			self.thbsze=100
			
		self.l.setItemHeight(int(114*self.rfactor))
		self.l.setBuildFunc(self.buildEntrySonglist)
		self.onSelectionChanged = [ ]
		self.mode = 0
		self.list = list
		self.nocoverptr=LoadPixmap(cached=False, path=drawImageJobWithLongMultilineText(text='no            cover', size=(200,200), fontsize=50))
		self.__picloader=PicLoader()

	def buildEntrySonglist(self, item):
		f=self.rfactor
		res = [ None ]
		dir='/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/'
		width=self.l.getItemSize().width()
		title, album, mypath, color, selcolor=item.slhelper
		if item.songID==-10000: # extend entry
			res.append((eListboxPythonMultiContent.TYPE_TEXT, 0,  0, width, int(114*f) , 0, RT_HALIGN_CENTER|RT_VALIGN_CENTER|RT_VALIGN_CENTER, item.text, color, selcolor)) #
			return res		
		ptr=None
		if fileExists(item.coverfn):
			logger.info('JukeboxList]buildEntrySonglist]cover found load:{}'.format(item.coverfn))
			ptr=LoadPixmap(cached=False, path=item.coverfn)
		if ptr is None:
			logger.info('JukeboxList]buildEntrySonglist]no ptr found:{}'.format(item.coverfn))
			ptr=self.nocoverptr
		res.append((eListboxPythonMultiContent.TYPE_PIXMAP,	10,  10, self.thbsze, self.thbsze, ptr))
		res.append((eListboxPythonMultiContent.TYPE_TEXT,       129*f,  4*f, (width-(150+129)*f), 28*f, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, title, color, selcolor)) # artist + title
		res.append((eListboxPythonMultiContent.TYPE_TEXT, width-150*f,  4*f, 150*f, 28*f, 1, RT_HALIGN_CENTER|RT_VALIGN_CENTER, 'Track '+item.track, color, selcolor)) #track?? or tracknr
		res.append((eListboxPythonMultiContent.TYPE_TEXT, (width-150*f), 38*f, 150*f, 22*f, 1, RT_HALIGN_CENTER|RT_VALIGN_CENTER, item.length, color, selcolor)) # length
		res.append((eListboxPythonMultiContent.TYPE_TEXT,       129*f, 38*f, (width-(400+129)*f), 22*f, 1, RT_HALIGN_LEFT|RT_VALIGN_CENTER, album, color, selcolor)) #album
		res.append((eListboxPythonMultiContent.TYPE_TEXT, (width-400*f), 38*f, 230*f, 22*f, 1, RT_HALIGN_CENTER|RT_VALIGN_CENTER, item.genre, color, selcolor)) # genre
		res.append((eListboxPythonMultiContent.TYPE_TEXT,    129*f, ((68+2)*f), (width-(355+129)*f), 19*f, 2, RT_HALIGN_LEFT|RT_VALIGN_CENTER, mypath, color, selcolor)) #Pfad zum Song
		gradientlength=200*f
		ptr=LoadPixmap(cached=True, path=dir+'gradientmypathalpha%d_32.png' %gradientlength) # verlauf mypath am Ende
		res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, (width-(355+gradientlength/f)*f), ((68+2)*f), gradientlength, 20*f, ptr))
		res.append((eListboxPythonMultiContent.TYPE_TEXT, (width-150*f), 68*f, 150*f, 22*f, 1, RT_HALIGN_CENTER|RT_VALIGN_CENTER, item.bitrate, color, selcolor)) # bitrate
		res.append((eListboxPythonMultiContent.TYPE_TEXT, (width-235*f), 68*f, 80*f, 22*f, 1, RT_HALIGN_RIGHT|RT_VALIGN_CENTER, 'Plays %d' %item.playcount, color, selcolor)) # playcount
		ptr=LoadPixmap(cached=True, path=dir+'rating'+str(calcRating(item.rating))+'.png')
		res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, (width-355*f), 68*f, 120*f, 23*f, ptr)) # rating
		return res

	def connectSelChanged(self, fnc):
		if not fnc in self.onSelectionChanged:
			self.onSelectionChanged.append(fnc)

	def disconnectSelChanged(self, fnc):
		if fnc in self.onSelectionChanged:
			self.onSelectionChanged.remove(fnc)

	def selectionChanged(self):
		for x in self.onSelectionChanged:
			x()

	def getCurrent(self):
		cur = self.l.getCurrentSelection()
		return cur and cur[0]

	def postWidgetCreate(self, instance):
		instance.setContent(self.l)
		self.selectionChanged_conn = instance.selectionChanged.connect(self.selectionChanged)
		if self.enableWrapAround:
			self.instance.setWrapAround(True)

	def moveToIndex(self, index):
		self.instance.moveSelectionTo(index)

	def getCurrentIndex(self):
		return self.instance.getCurrentIndex()

	currentIndex = property(getCurrentIndex, moveToIndex)
	currentSelection = property(getCurrent)

	def setList(self, mylist):
		self.list = mylist
		self.l.setList(mylist)

	def getEntryByIndex(self, index):
		return self.list[index]
	
	def getItemCount(self):
		return len(self.list)

	def getList(self):
		return self.list

	def refreshList(self):
		self.l.setList(self.list)
		
	def removeItem(self, index):
		del self.list[index]
		self.l.entryRemoved(index)

	def selectionEnabled(self, enabled):
		if self.instance is not None:
			self.instance.setSelectionEnable(enabled)


class JukeboxLCD(Screen):

	skin="""
		<screen position="0,0" size="132,64">
			<widget name="screenname" position="2,2" size="128,14" font="SansReg;12"/>
			<widget name="text1" position="2,17" size="128,14" font="SansReg;12"/>
			<widget name="text2" position="2,32" size="128,14" font="SansReg;12"/>
			<widget name="text3" position="2,47" size="128,14" font="SansReg;12"/>
		</screen>"""

	def __init__(self, session, parent):
		Screen.__init__(self, session)
		self["screenname"] = Label(_('MusicCenter Jukebox'))
		self["text1"]=Label()
		self["text2"]=Label()
		self["text3"]=Label()

	def setText(self, text, line):
		if line == 1:
			self["text1"].setText(text)
		elif line == 2:
			self["text2"].setText(text)
		elif line == 3:
			self["text3"].setText(text)
		else:
			pass
		
def total_size(o, handlers={}, verbose=False):
	""" Returns the approximate memory footprint an object and all of its contents.
	Automatically finds the contents of the following builtin containers and
	their subclasses:  tuple, list, deque, dict, set and frozenset.
	To search other containers, add handlers to iterate over their contents:
		handlers = {SomeContainerClass: iter,
					OtherContainerClass: OtherContainerClass.get_elements}
	"""
	dict_handler = lambda d: chain.from_iterable(d.items())
	all_handlers = {tuple: iter,
					list: iter,
					deque: iter,
					dict: dict_handler,
					set: iter,
					frozenset: iter,
				   }
	all_handlers.update(handlers)	 # user handlers take precedence
	seen = set()					  # track which object id's have already been seen
	default_size = getsizeof(0)	   # estimate sizeof object without __sizeof__

	def sizeof(o):
		if id(o) in seen:	   # do not double count the same object
			return 0
		seen.add(id(o))
		s = getsizeof(o, default_size)
		for typ, handler in all_handlers.items():
			if isinstance(o, typ):
				s += sum(map(sizeof, handler(o)))
				break
		return s

	return sizeof(o)
