# -*- coding: UTF-8 -*-

#  Music Center E2
#
#  Coded by bobo71 (c) 2014
#  Support: www.dreambox-tools.info
#
#  All Files of this Software are licensed under the Creative Commons
#  Attribution-NonCommercial-ShareAlike 3.0 Unported
#  License if not stated otherwise in a Files Head. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.

#  Additionally, this plugin may only be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.

#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially
#  distributed other than under the conditions noted above.
#  This applies to the source code as a whole as well as to parts of it, unless
#  explicitely stated otherwise.
'''
import sys
sys.path.append('/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter')
import JobCenter2
'''

from random import randrange as random_randrange
from textwrap import wrap as textwrap_wrap
from PIL import ImageFont, ImageDraw, Image, ImageOps
from pydub import AudioSegment
from mutagen.id3 import ID3, WXXX
from datetime import timedelta as datetime_timedelta
from time import strptime as time_strptime

try:
	from myLogger import logger
	from Globals import *#time_time, os_path, StringIO, os_system, os_remove, sp_call, WAVETHREADID, calcRating, sp_Popen, time_sleep, sp_PIPE, Thread

except Exception, e: # not running in enigma2
	
	from time import time as time_time
	from os import path as os_path, system as os_system, remove as os_remove, utime as os_utime
	from subprocess import call as sp_call, Popen as sp_Popen, PIPE as sp_PIPE
	from time import sleep as time_sleep
	from threading import Thread
	import logging
	from logging.handlers import RotatingFileHandler

	logger = logging.getLogger(__name__)		
	filename='/var/log/musiccenter.log'
	maxBytes=1024*1024
	backupCount=3
	# create a rotating file handler
	handler = RotatingFileHandler(filename, "a", maxBytes, backupCount)
	logger.setLevel(logging.INFO)
	formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
	handler.setFormatter(formatter)
	logger.addHandler(handler)
	
	logger.error('JobCenter2]running not on enigma2... %s' %e)


colorlist=[(0, 0, 0), (0, 0, 139), (0, 0, 255), (0, 128, 0), (0, 139, 139), (0, 206, 209), (0, 255, 0), (0, 255, 255), (30, 144, 255), (34, 139, 34), (47, 79, 79),
(60, 179, 113), (65, 105, 225), (72, 61, 139), (75, 0, 130), (95, 158, 160), (102, 205, 170), (106, 90, 205), (112, 128, 144), (123, 104, 238), (127, 255, 0), (128, 0, 0), (128, 128, 0), (135, 206, 235),
(138, 43, 226), (139, 0, 139), (143, 188, 143), (147, 112, 219), (152, 251, 152), (154, 205, 50), (165, 42, 42), (173, 216, 230), (175, 238, 238), (176, 224, 230), (184, 134, 11), (188, 143, 143), (192, 192, 192), (205, 92, 92),
(210, 105, 30), (211, 211, 211), (218, 112, 214),(220, 20, 60), (224, 255, 255), (233, 150, 122), (240, 230, 140), (240, 255, 255), (245, 222, 179), (245, 245, 245), (250, 235, 215), (250, 250, 210), (255, 0, 0), (255, 20, 147), (255, 99, 71),
(255, 127, 80), (255, 160, 122), (255, 182, 193), (255, 215, 0), (255, 222, 173), (255, 228, 196), (255, 235, 205), (255, 240, 245), (255, 248, 220), (255, 250, 240), (255, 255, 0), (255, 255, 255)]


def writeToFile(fn,data):
	with open(fn, 'wb') as f:
		f.write(data)
	
def readFromFile(fn):
	with open(fn, 'rb') as f:
		return f.read()

def drawImageJob( text='-', size=(200,200), out=None, backcolor=None, round=0):
	# zeichne pic mit text einzeilig
	# choose color
	text=text.replace('/','-')
	index=random_randrange(len(colorlist))
	if backcolor==None:
		backcolor=colorlist[index]

	if backcolor[0]+backcolor[1]+backcolor[2]<378:
		textcolor1=(255,255,255) # (255-backcolor[0], 255-backcolor[1], 255-backcolor[2])
	else:
		textcolor1=(0,0,0)

	if out==None:
		#out='/tmp/mc/%s_%d_%d_%d.png' %(text, backcolor[0], backcolor[1], backcolor[2])
		out='/tmp/mc/%s_%d.png' %(text, round)
	if not os_path.exists(out):
		im = Image.new('RGB',size, backcolor)
		draw = ImageDraw.Draw(im)
		text_size=size[1]/10*6
		font = ImageFont.truetype("/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/fonts/sans.ttf", text_size) #Light, Thin

		w, h = draw.textsize(text, font=font)
		draw.text(((size[0]-w)/2,(size[1]-h)/2), text, fill=textcolor1, font=font)
		del draw

		if round!=None:
			im = _add_corners(im, round)


		im.save(out, "PNG")

	return out

def drawTransparentImage( text='-', size=(200,200), out=None, textcolor='white', textsize=35):
	# zeichne pic mit text einzeilig
	# transparent
	text=text.replace('/','-')

	if out==None:
		out='/tmp/mc/%s_transparent.png' %(text)
	
	im = Image.new("RGBA", size, (0,0,0,0))
	draw = ImageDraw.Draw(im)
	font = ImageFont.truetype("/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/fonts/sans.ttf", textsize) #Light, Thin

	w, h = draw.textsize(text, font=font)
	draw.text(((size[0]-w)/2,(size[1]-h)/2), text, fill=textcolor, font=font)
	del draw

	im.save(out, "PNG")

	return out


def _add_corners(im, rad):
	circle = Image.new('L', (rad * 2, rad * 2), 0)
	draw = ImageDraw.Draw(circle)
	draw.ellipse((0, 0, rad * 2, rad * 2), fill=255)
	alpha = Image.new('L', im.size, 255)
	w, h = im.size
	alpha.paste(circle.crop((0, 0, rad, rad)), (0, 0))
	alpha.paste(circle.crop((0, rad, rad, rad * 2)), (0, h - rad))
	alpha.paste(circle.crop((rad, 0, rad * 2, rad)), (w - rad, 0))
	alpha.paste(circle.crop((rad, rad, rad * 2, rad * 2)), (w - rad, h - rad))
	im.putalpha(alpha)

	del draw

	return im


def drawImageJobWithLongText(text='-', size=(200,200), fontsize=None):
	#choose color
	text=text.replace('/','-')
	index=random_randrange(len(colorlist))
	backcolor=colorlist[index]
	if backcolor[0]+backcolor[1]+backcolor[2]<378:
		textcolor1=(255,255,255) # (255-backcolor[0], 255-backcolor[1], 255-backcolor[2])
	else:
		textcolor1=(0,0,0)
	out='/tmp/mc/%s_%d_%d_%d.png' %(text, backcolor[0], backcolor[1], backcolor[2])
	im = Image.new('RGB',size, backcolor)
	draw = ImageDraw.Draw(im)
	img_fraction = 0.9
	if fontsize==None:
		fontsize = 19  # starting font size
		font = ImageFont.truetype("/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/fonts/sans.ttf", fontsize)
		while font.getsize(text)[0] < img_fraction*im.size[0]:
			# iterate until the text size is just larger than the criteria
			fontsize += 1
			font = ImageFont.truetype("/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/fonts/sans.ttf", fontsize)
	else:
		font = ImageFont.truetype("/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/fonts/sans.ttf", fontsize)

	logger.info('drawImageJobWithLongText]final font size %d' %fontsize)
	w, h = draw.textsize(text, font=font)
	#if w > img_fraction+0.05*im.size[0]:
	#	while font.getsize(text)[0] > img_fraction*im.size[0]:
	#		# iterate until the text is just larger than the criteria
	#		text=text[:-1]
	#		#font = ImageFont.truetype("/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/fonts/sans.ttf", fontsize)
	#	w, h = draw.textsize(text, font=font)
	draw.text(((size[0]-w)/2,(size[1]-h)/2), text, fill=textcolor1, font=font)
	del draw
	im.save(out, "PNG")
	return out


def paintTextToImageJob(pic, text1,text2):

	try:
		#logger.info('paintText]pic-->%s text1-->%s text2-->%s' %(pic, text1,text2))
		path,fn=os_path.split(pic)
		fn=fn.replace('/','-')
		out=''.join(('/tmp/mc/wt_', fn))
		if os_path.exists(pic):

			if not out.lower().endswith(('.jpg','.jpeg','.png')):
				im1=Image.open(pic)
				out+='.%s' %im1.tile[0][0]

			if not os_path.exists(out):
				im1=Image.open(pic)
				if im1.mode not in('RGB', 'RGBA'):
					im1=im1.convert("RGB")
				x,y=im1.size
				z=y/300.0
				im2 = Image.new('RGBA',(x,int(z*75)),(0, 0, 0,130))
				im1.paste(im2,(0,y-int(z*75)), im2)
				draw = ImageDraw.Draw(im1)
				fontsize=int(24*z)
				#logger.info('paintText]fontsize-->%s ' %str(fontsize))
				font = ImageFont.truetype("/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/fonts/sans.ttf", fontsize)
				draw.text((5, y-int(z*66)), text1, fill=(255,255,255), font=font)
				#logger.info('paintText]text2-->%s' %text2)
				draw.text((5, y-int(z*35)), text2, fill=(255,255,255), font=font)
				im1.save(out)

		return out
	except Exception, e:
		logger.error('paintTextToImageJob]-->%s' %e)
		return pic

def paintTextToImageJobResize(filename, pic, title='', artist='', album='', length='', rating=None):
	'''
	create new image with embeded thumb or stationicon
	paste text on images...
	'''
	try:
		#logger.info('paintTextToImageJobResize]start filename-->%s pic-->%s title-->%s artist-->%s album-->%s	length-->%s rating-->%s' %(filename, pic, title, artist, album, length, str(rating)))
		directory, filename=os_path.split(pic)
		filename=filename.replace('/','-')
		if '.fl.' in pic:
			out=pic.replace('.fl.','.wt.')
		elif rating==-1: # islike
			out='/wt_islike_'.join((directory, filename))
		elif rating==-2: # nolike
			out='/wt_nolike_'.join((directory, filename))
		else:
			out='/wt_'.join((directory, filename))
		logger.info('paintTextToImageJobResize]out-->%s' %out)
		if os_path.exists(pic):

			if not out.lower().endswith(('.jpg','.jpeg','.png')):
				im1=Image.open(pic)
				out+='.%s' %im1.tile[0][0]
			else:
				im1=None
			if filename==None or not os_path.exists(filename) :
				filename_mtime=time_time()
			else:
				filename_mtime=os_path.getmtime(filename)

			if not os_path.exists(out) or os_path.getmtime(out) < os_path.getmtime(pic) or os_path.getmtime(out) < filename_mtime: # os_path.getmtime(filename):# out �lter als pic oder das songfile
				#logger.info('paintTextToImageJobResize]start build pic...')
				if im1==None:
					im1=Image.open(pic)
				if im1.mode != "RGB":
					im1=im1.convert("RGB")

				im1_x, im1_y=im1.size
				x,y=300, 300

				y_all=450
				im2=Image.open('/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/background_300x450.png')
				#im2 = Image.new('RGB',(x, y_all),(45,45,45)) #0, 0, 0

				if (im1_x or im1_y)>300:
					logger.info('Image is bigger as 300 resize to 300')
				else:
					logger.info('Image is tinny as 300 resize to 300')
				basewidth = 300
				wpercent = (basewidth/float(im1_x))
				hsize = int((float(im1_y)*float(wpercent)))
				im1 = im1.resize((basewidth,hsize), Image.NEAREST) # ANTIALIAS)
				im1_x, im1_y= x, y

				offset = ((300 - im1_x) / 2, (450 - im1_y) / 2)
				#logger.info('Image paste offset is %s' %str(offset))
				im2.paste(im1,offset,)
				draw = ImageDraw.Draw(im2)
				fontsize=22 # 24
				font = ImageFont.truetype("/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/fonts/sans.ttf", fontsize)

				x_start=int((x-draw.textsize(title.decode('utf-8'), font=font)[0])/2)
				if x_start<5:
					x_start=5
				draw.text((x_start, y_all-66), title.decode('utf-8'), fill=(255,255,255), font=font)

				x_start=int((x-draw.textsize(artist.decode('utf-8'), font=font)[0])/2)
				if x_start<5:
					x_start=5
				draw.text((x_start, y_all-33), artist.decode('utf-8'), fill=(255,255,255), font=font)

				x_start=int((x-draw.textsize(album.decode('utf-8'), font=font)[0])/2)
				if x_start<5:
					x_start=5
				draw.text((x_start, 35), album.decode('utf-8'), fill=(255,255,255), font=font)

				text_len=font.getsize(length)[0]
				draw.text(( x-5-text_len, 5), length, fill=(255,255,255), font=font)


				if rating!=None:#rating
					if rating==-1:# sc like
						im3=Image.open('/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/heart32_orange.png')
						im2.paste(im3,(50,4),)
					elif rating>-1:
						im3=Image.open('/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/rating%d.png'%calcRating(rating))
						im2.paste(im3,(5,7),)
				im2.save(out)
				del draw
			else:
				logger.info('paintText]file is ok not recreate is nessesarry...')
		else:
			out=pic
		return out

	except Exception, e:
		logger.error('paintTextToImageJobResize]-->%s' %e)
		return pic

def createGradientPNG(size, bgcolor):
	im=Image.new('RGB', size, bgcolor)
	if im.mode != 'RGBA':
		im = im.convert('RGBA')
	# create a vertical gradient...
	gradient = Image.new('L', (256,1))
	for y in range(256):
		if y<256:
			gradient.putpixel((0+y,0),y)
		else:
			gradient.putpixel((y,0),255)
	# resize the gradient to the size of im...
	alpha = gradient.resize(im.size)
	im.putalpha(alpha)
	return im
	#im.save(os_path.splitext(picfn)[0] + 'alpha.png', 'PNG')

# -----------
def drawImageJobWithLongMultilineText(text='-', size=(200,200), fontsize=33, round=0, out=None, force=False): # size=(300,300), fontsize=40
	if out is None:
		out='/tmp/mc/%s_%d.png' %(text.replace('/','-'), round)
	logger.info('drawImageJobWithLongMultilineText]start->%s' %out)
	if not os_path.exists(out) or force :
		#logger.info('drawImageJobWithLongMultilineText]paint image->%s' %out)
		
		#choose color
		index=random_randrange(len(colorlist))
		backcolor=colorlist[index]
		
		if backcolor[0]+backcolor[1]+backcolor[2]<378:
			textcolor1=(255,255,255) # (255-backcolor[0], 255-backcolor[1], 255-backcolor[2])
		else:
			textcolor1=(0,0,0)
			
		im = Image.new('RGB',size, backcolor)
		draw = ImageDraw.Draw(im)
		font = ImageFont.truetype("/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/fonts/sans.ttf", fontsize)
		textlines, max_text_width, heigth =IntelliDraw(draw,text,font, int(size[0]*0.9))
		
		if max_text_width > int(size[0]*0.9):
			old_size_0=int(size[0]*0.9)
			size=(max_text_width/9*10, max_text_width/9*10)
			#logger.info('drawImageJobWithLongMultilineText]max_text_width:{} > image width*0.9:{}, repaint image to size:{}'.format(max_text_width, old_size_0, (size[0],size[1])))
			im = Image.new('RGB',size, backcolor)
			draw = ImageDraw.Draw(im)
		linecount=len(textlines)
		
		#heigth = draw.textsize(text, font=font)[1]*1.3
		hsum=int(linecount*heigth)
		h_text=(size[1]-hsum)/2
		for text in textlines:
			text_line=' '.join(text).decode()# fix utf errors
			w=draw.textsize(text_line, font=font)[0]
			draw.text(((size[0]-w)/2, h_text), text_line, fill=textcolor1, font=font)
			h_text+=heigth
		del draw

		if round!=None and isinstance(round, int):
			im = _add_corners(im, round)

		im.save(out, "PNG")
	else:
		logger.info('drawImageJobWithLongMultilineText]image allready exists, abort!')
	return out

def IntelliDraw(drawer, text, font, max_text_len):
	# split text to words
	for character in('''"-/.&%`�$�!'([{?\\'''):
		if character in text:
			if character in ('([{'):
				#logger.info('IntelliDraw]replace:{}'.format(character))
				text=text.replace(character,' {}'.format(character))
			else:
				#logger.info('IntelliDraw]replace:{}'.format(character))
				text=text.replace(character,' ')
	words=text.split()
	#logger.info('IntelliDraw]splitted text to words:{}'.format(words))

	# now construct textlines parsed to pic width
	line_count = 0
	widths=[]
	text_in_lines=[]
	while words:
		newline = [words.pop(0)]
		innerFinished = False
		while not innerFinished:
			#logger.info('IntelliDraw]newline test:{}'.format(newline))
			curr_line_width, heigth=drawer.textsize(' '.join(newline), font)
			
			if curr_line_width < max_text_len and len(words)>0:
				newline.append(words[0])
				if drawer.textsize(' '.join(newline), font)[0] > max_text_len and len(newline)>1:
					newline.pop()
					text_in_lines.append(newline)
					widths.append(curr_line_width)
					innerFinished = True
					line_count+=1
				else:
					words.pop(0)
			else:
				text_in_lines.append(newline)
				widths.append(curr_line_width)
				innerFinished = True
				line_count+=1
	width=max(widths)
	#logger.info('IntelliDraw]text_in_lines:{} width:{} heigth:{}'.format(text_in_lines, width, heigth))
	return (text_in_lines, width, heigth)


def convertImageToRGB(pic):
	try:
		im=Image.open(pic)
		logger.info('convertImageToRGB]mode is-->%s' %im.mode)
		if im.mode=='CMYK':
			logger.info('convertImageToRGB]convert-->%s to RGB' %im.mode)
			a=im.convert('RGB')
			a.save(pic)
	except Exception, e:
		logger.error('convertImageToRGB]exception-->%s -->%s' %(pic,e))

def jobFixAspectRatioXequalY(picpath): # fix wrong aspectratio VideoDBPictureBox
	try:
		im=Image.open(picpath)
		x,y=im.size
		if x!=y:
			logger.info('jobFixAspectRatio]x>%s y>%s'%(x,y))
			res=max(x,y)
			im1=Image.new('RGB',(res,res), 'black')
			im1.paste(im,((res-x)/2,(res-y)/2))
			im1.save(picpath, 'JPEG')
		return (True, picpath)
		
	except Exception, e:
		logger.error('jobFixAspectRatio]error ->%s'%e)
		if picpath!='usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/no-cover.png':
			if os_path.exists(picpath):
				logger.error('jobFixAspectRatio]remove fauft pic ->%s'%picpath)
				os_remove(picpath)
			else:
				logger.error('jobFixAspectRatio]no valid picpath->%s'%picpath)
		return (False, 'usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/no-cover.png')

def parsePictoCovercollection(pic,out):
	#logger.info('parsePictoCovercollection]start build pic...')
	im1=Image.open(pic)
	#if im1.mode not in("RGB", "RGBA"):
	#	im1=im1
	im1_x, im1_y=im1.size
	basewidth = 300
	im2=Image.open('/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/transparent_300_450.png')
	wpercent = (basewidth/float(im1_x))
	hsize = int((float(im1_y)*float(wpercent)))
	#if (im1_x or im1_y)>300:
	#	#logger.info('parsePictoCovercollection]Image is bigger, resize to 300')
	#	im1.thumbnail((basewidth,hsize), Image.NEAREST) # ANTIALIAS)
	#else:
	#	#logger.info('parsePictoCovercollection]Image is tinny, resize to 300')
	#	im1=im1.resize((basewidth,hsize), Image.NEAREST) # ANTIALIAS)
	im1=im1.resize((basewidth,hsize),) 
	#logger.info('parsePictoCovercollection]Image paste offset is %s' %str(offset))
	im2.paste(im1,(0,75),)
	im2.save(out)
	return out

def parseImageInBackgroundbase(pic, size=200, im=None):
	logger.info('parseImageInBackgroundbase]->%s'%pic)
	if im is None:
		im=Image.open(pic)
	#if im1.mode not in("RGB", "RGBA"):
	#	im1=im1
	im1_x, im1_y=im.size
	im2=Image.new("RGB", (size, size), "white")
	if (im1_x or im1_y)>size:
		logger.info('parseImageInBackgroundbase]Image is bigger, skip')
	else:
		logger.info('parseImageInBackgroundbase]Image is tinny, parse')
		im2.paste(im,(size/2-im1_x/2, size/2-im1_y/2),)
		im2.save(pic)


class CalcWaveValusThread(Thread):

	def __init__(self):
		
		Thread.__init__(self)
		self.__running=False
		self.__songfileentry=[] 
		self.canceled=False
		self.deferred = defer.Deferred()
		self.__messages=ThreadQueue()
		self.__messagePump=ePythonMessagePump()
	
	def cancel(self):
		self.canceled=True
		
	def __getMessagePump(self):
		return self.__messagePump

		
	def __getMessageQueue(self):
		return self.__messages

		
	def __getRunning(self):
		return self.__running
		
		
	def Start(self, songfilename, lengthofsong, song_id, index):
		if not self.__running:
			logger.info('CalcWaveValusThread]Start]new thread')
			self.__running=True
		else:
			logger.info('CalcWaveValusThread]Start]old thread is running, check is songfile the same?')
			if self.__songfileentry[2]!=song_id:
				logger.info('CalcWaveValusThread]Start]songfile changed, abort old thread')
				self.cancel()
				while self.__running:
					time_sleep(0.1)
					logger.info('CalcWaveValusThread]Start]wait for canceling Thread...')
				else:
					logger.info('CalcWaveValusThread]Start]Thread canceled, start new...')
					time_sleep(0.1)
					self.__running=True
			else:
				logger.info('CalcWaveValusThread]Start]songfile not chanded, do nothing...')
				return
				
		self.__songfileentry=(songfilename, lengthofsong, song_id, index)
		logger.info('CalcWaveValusThread]Start]__songfileentry:{}'.format(self.__songfileentry))
		self.start()

	MessagePump=property(__getMessagePump)
	Message=property(__getMessageQueue)
	isRunning=property(__getRunning)
	
	def run(self):
		
		#logger.info('CalcWaveValusThread]run]start')
		tmpfn='/tmp/.wave.wav'
		try:
			if not os_path.exists('/usr/bin/ffmpeg'):
				t='CalcWaveValusThread]run]raise no ffmpeg found!'
				logger.info(t)
				raise Exception(t)
				self.canceled=False
				
			songfilename, lengthofsong, song_id, index=self.__songfileentry

			# b�se b�se... :-)
			#logger.info('CalcWaveValusThread]run]start song-->%s' %(songfilename))
			if self.canceled:
				t='CalcWaveValusThread]run]raise Thread'
				pkillcmd=['pkill', 'ffmpeg']
				sp_call(pkillcmd)
				logger.info(t)
				raise Exception(t)
				self.canceled=False

			#logger.info('CalcWaveValusThread]run]convert song')
			pixel_x=1920 # Full HD wide
			songfn=songfilename.replace("'","\\'").replace(" ","\ ").replace("(","\(").replace(")","\)").replace("&","\&").replace("$","\$")
			#cmd="exec ffmpeg -i %s -y  -v quiet -acodec pcm_u8 -ac 1 -ar 11025 %s" %(songfn, tmpfn)
			cmd="exec nice -n 15 ffmpeg -i %s -y  -v quiet -acodec pcm_u8 -ac 1 -ar 11025 %s" %(songfn, tmpfn)# nice to reduce load
			logger.info('CalcWaveValusThread]run]convert song cmd->%s' %str(cmd))
			p=sp_Popen(cmd, shell=True)
			start=time_time()
			delay=time_time()
			count=1
			h, m, s = lengthofsong.split(':')
			maxruntime=int(h) * 3600 + int(m) * 60 + int(s)/14
			logger.info('CalcWaveValusThread]run]start now convert, break after->%d' %maxruntime)
			while 1: #p.poll()!=0
				if self.canceled or time_time()-start > maxruntime:
					t='CalcWaveValusThread]run]kill ffmpeg now, self.canceled or maxruntime reached:{}'.format(maxruntime)
					logger.info(t)
					p.kill()
					raise Exception(t)
					self.canceled=False
					break
				elif p.poll()==0:
					logger.info('CalcWaveValusThread]run]ffmpeg finished, break loop!')
					break
				if time_time()-delay>1:
					#logger.info('CalcWaveValusThread]run]is running->%d' %count)
					count+=1
					delay=time_time()
				time_sleep(0.2)
				
			logger.info('CalcWaveValusThread]run]Time for wavebuild-->%d'  %(time_time()-start))
			if self.canceled:
				t='CalcWaveValusThread]run]raise Thread after ffmpeg'
				logger.info(t)
				raise Exception(t)
				self.canceled=False
			
			logger.info('CalcWaveValusThread]run]read song-->%s' %tmpfn)
			sound = AudioSegment.from_wav(tmpfn)
			logger.info('CalcWaveValusThread]run]create wave now...')
			chunk_length = len(sound) / pixel_x
			loudness_of_chunks = [ sound[ i*chunk_length : (i+1)*chunk_length ].rms for i in xrange(pixel_x)]
			os_remove(tmpfn)
			sound=None 
			if self.canceled:
				t='CalcWaveValusThread]run]raise Thread after create wave'
				logger.info(t)
				raise Exception(t)
				self.canceled=False
				
			logger.info('CalcWaveValusThread]run]done push song:{} song_id:{} index:{}'.format(songfilename, song_id, index))
			self.__messages.push((songfilename, loudness_of_chunks, song_id, index))
				
		except Exception, error:
			logger.error('CalcWaveValusThread]run]error->%s' %error)
			if os_path.exists(tmpfn):
				os_remove(tmpfn)
			
			self.__messages.push((error, [], 'canceled', index))
		finally:
			self.__messagePump.send(0)
			
		Thread.__init__(self)
		self.__songfileentry=[] 
		self.canceled=False
		self.__running=False
		#logger.info('CalcWaveValusThread]run]done')


def JCpaintWaveformpngThread(songfile, lengthofsong):
	# b�se b�se... :-)
	logger.info('JCpaintWaveformpngThread]start song-->%s' %(songfile))
	try:
		if readFromFile('/tmp/mc/.wavename')!=songfile:
			logger.info('JCpaintWaveformpngThread]raise Thread')
			pkillcmd=['pkill', 'ffmpeg']
			sp_call(pkillcmd)
			raise Exception('JCpaintWaveformpngThread instance changed!')

		logger.info('JCpaintWaveformpngThread]convert song')
		pixel_x=1920 # Full HD wide

		tmpfn='/tmp/.wave.wav'# %str(time_time()).split('.')[0]	
		cmd="exec ffmpeg -i \'\'\'%s\'\'\' -y -v quiet -acodec pcm_u8 -ac 1 -ar 11025 %s" %(songfile, tmpfn)
		p = sp_Popen(cmd, stdout=sp_PIPE, shell=True)
		start=time_time()
		maxruntime=int(lengthofsong.split('.')[0])/16
		logger.info('JCpaintWaveformpngThread]start now convert, break after->%d' %maxruntime)
		while p.poll()!=0 or time_time()-start < maxruntime:
			if readFromFile('/tmp/mc/.wavename')!=songfile:
				logger.info('JCpaintWaveformpngThread]is running, file changed, abort!')
				p.kill()
				break
			logger.info('JCpaintWaveformpngThread]is running, sleep 1')
			time_sleep(1)
			
		logger.info('JCpaintWaveformpngThread]Time for wavebuild-->%d'  %(time_time()-start))
		if readFromFile('/tmp/mc/.wavename')!=songfile:
			logger.info('JCpaintWaveformpngThread]raise Thread after ffmpeg')
			raise Exception('JCpaintWaveformpngThread instance changed!')
		
		logger.info('JCpaintWaveformpngThread]read song-->%s' %tmpfn)
		sound = AudioSegment.from_wav(tmpfn)
		logger.info('JCpaintWaveformpngThread]create wave now...')
		chunk_length = len(sound) / pixel_x
		loudness_of_chunks = [ sound[ i*chunk_length : (i+1)*chunk_length ].rms for i in xrange(pixel_x)]
		os_remove(tmpfn)
		sound=None 
		logger.info('JCpaintWaveformpngThread]done  song-->%s' %(songfile))
		if readFromFile('/tmp/mc/.wavename')!=songfile:
			logger.info('JCpaintWaveformpngThread]raise Thread after create wave')
			raise Exception('JCpaintWaveformpngThread instance changed!')
			
		return songfile, loudness_of_chunks
		
	except Exception, e:
		logger.error('JCpaintWaveformpngThread]excepted->%s' %e)
		if os_path.exists(tmpfn):
			os_remove(tmpfn)
		return 'raised', []
		

def calcPointerColors(coverfn):
	#logger.info('calcPointerColors]start')
	try:
		im=Image.open(coverfn)
		if im.mode!='RGB':
			#logger.info('calcPointerColors]no rgb, convert to RGB')
			im=im.convert('RGB')
	except Exception, e:
		logger.error('calcPointerColors]pic->%s  Error->%s' %(coverfn, e))
		return (189,156,24),(255,255,255)
	im900=im.resize((30,30),)
	pixellist=im900.getcolors(900)
	pixellist=sorted(pixellist, key=lambda a:a[0], reverse=True)[:300]
	bgcolor=pixellist.pop(0)
	bgcolor=bgcolor[1]
	if sum(list(bgcolor))<120:
		d=(120-sum(list(bgcolor)))/3
		r=bgcolor[0]+d
		g=bgcolor[1]+d
		b=bgcolor[2]+d
		bgcolor=(r,g,b)
		#logger.info('calcPointerColors]bgcolor fixed->%s' %str(bgcolor))
		
	match=False 
	colordistance=90
	isblack=False
	for pixel in pixellist:
		possible_fg_color=pixel[1]
		if sum(list(possible_fg_color))<120:# to dark
			isblack=True
			continue
		if abs(possible_fg_color[0]-bgcolor[0])>colordistance and abs(possible_fg_color[1]-bgcolor[1])-colordistance and abs(possible_fg_color[2]-bgcolor[2])>colordistance:
			match=True
			break
	if not match:
		#logger.info('calcPointerColors]No matching color found pic->%s' %coverfn)
		if isblack:
			#logger.info('calcPointerColors]set to black')
			possible_fg_color=(255,255,255)
		else:
			#logger.info('calcPointerColors]set to white')
			possible_fg_color=(45,45,45)

	return bgcolor, possible_fg_color

def tint_image(src, color="#000000"):
	src.load()
	src=src.convert("RGBA")
	r, g, b, alpha=src.split()
	gray=ImageOps.grayscale(src)
	result=ImageOps.colorize(gray, (0, 0, 0, 0), color) 
	result.putalpha(alpha)
	return result
	
def ImageZerren(wavefn, waveout, color=(0,0,0)):
	im=Image.open(wavefn)
	im_x, im_y=im.size
	# spiegeln
	mirror_img = ImageOps.flip(im)
	# halbieren y
	mirror_img=mirror_img.resize((im_x,im_y/3))
	w,h=mirror_img.size
	# neues Image
	wave_new = Image.new('RGBA', (im_x+h, im_y+h))
	wave_new.paste(im,(0,0))
	# neuer Pointer
	pointer_new = Image.new('RGBA', (im_x+h, im_y+h))
	pointer_new.paste(color,(0, 0, im_x, im_y))
	
	pixels = mirror_img.load()
	putpixel_x, putpixel_y=0,0
	offset=-1
	# einf�gen
	for y in xrange(h):
		offset+=1
		pointer_new.paste(color,(0, im_y+offset,im_x+offset, im_y+offset+1))
		
		for x in xrange(w):
			pixel = pixels[x, y]
			putpixel_x=x+offset
			putpixel_y=im_y+y
			wave_new.putpixel((putpixel_x, putpixel_y),(pixel))
	wave_new.save(waveout)
	pointer_new.save('/tmp/pointer.png')
	return '/tmp/pointer.png'
	
	
class WaveonID3():
	
	def __init__(self, fn):
		logger.info('WaveonID3]__init__')
		self.audio=ID3(fn)
		
	def getWave(self):
		logger.info('WaveonID3]getWave')
		#WXXX(encoding=3, desc=u'wave', url=u'[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]')
		if self.audio.has_key('WXXX:wave'):
			wave=eval(self.audio.get('WXXX:wave').url)
			return wave#[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
		else:
			return[]
		
	def addWave(self, wave):
		logger.info('WaveonID3]addWave')
		self.audio.add(WXXX(encoding=3, desc=u'wave', url=u'%s' %repr(wave)))
		self.audio.save()

	def __del__(self):
		logger.info('WaveonID3]__del__')
		self.audio=None
		
