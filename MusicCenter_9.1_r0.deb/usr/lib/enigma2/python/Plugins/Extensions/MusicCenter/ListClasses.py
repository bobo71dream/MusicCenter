# -*- coding: UTF-8 -*-

#  Music Center E2
#
#  Coded by bobo71 (c) 2014
#  Support: www.dreambox-tools.info
#
#  All Files of this Software are licensed under the Creative Commons
#  Attribution-NonCommercial-ShareAlike 3.0 Unported
#  License if not stated otherwise in a Files Head. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.

#  Additionally, this plugin may only be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.

#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially
#  distributed other than under the conditions noted above.
#  This applies to the source code as a whole as well as to parts of it, unless
#  explicitely stated otherwise.

# local plugin
from Globals import *
from JobCenter import *
from JobCenter2 import calcRating
from myLogger import logger


class CentralList(MenuList):

	def __init__(self, list, enableWrapAround = True):
		logger.info('CentralList]__init__]')
		MenuList.__init__(self, list, enableWrapAround, eListboxPythonMultiContent)
		if RESOLUTIONx==1920:
			self.rfactor=1.5
			self.l.setFont(0, gFont("SansReg", 39))
			self.l.setFont(1, gFont("SansReg", 30))
			self.l.setFont(2, gFont("SansReg", 25))
			self.thbsze=150
		else:
			self.rfactor=1
			self.l.setFont(0, gFont("SansReg", 26))
			self.l.setFont(1, gFont("SansReg", 20))
			self.l.setFont(2, gFont("SansReg", 17))
			self.thbsze=100
		self.l.setItemHeight(int(114*self.rfactor))
		self.l.setBuildFunc(self.buildEntryBig)
		self.onSelectionChanged = [ ]
		self.mode = 0
		self.list = list
		self.nocoverptr=LoadPixmap(cached=False, path=drawImageJobWithLongMultilineText(text='no            cover', size=(200,200), fontsize=50))
	
	def buildEntryBig(self, item):
		f=self.rfactor
		res = [ None ]
		dir='/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/'
		width=self.l.getItemSize().width()
		title, album, mypath, color, selcolor=item.slhelper
		ptr=None
		if fileExists(item.coverfn):
			ptr=LoadPixmap(cached=False, path=item.coverfn)
		if ptr is None:
			ptr=self.nocoverptr
		res.append((eListboxPythonMultiContent.TYPE_PIXMAP,	10,  10, self.thbsze, self.thbsze, ptr))
		res.append((eListboxPythonMultiContent.TYPE_TEXT,       129*f,  4*f, (width-(150+129)*f), 28*f, 0, RT_HALIGN_LEFT|RT_VALIGN_CENTER, title, color, selcolor)) # artist + title
		res.append((eListboxPythonMultiContent.TYPE_TEXT, width-150*f,  4*f, 150*f, 28*f, 1, RT_HALIGN_CENTER|RT_VALIGN_CENTER, 'Track '+item.track, color, selcolor)) #track?? or tracknr
		res.append((eListboxPythonMultiContent.TYPE_TEXT, (width-150*f), 38*f, 150*f, 22*f, 1, RT_HALIGN_CENTER|RT_VALIGN_CENTER, item.length, color, selcolor)) # length
		res.append((eListboxPythonMultiContent.TYPE_TEXT,       129*f, 38*f, (width-(400+129)*f), 22*f, 1, RT_HALIGN_LEFT|RT_VALIGN_CENTER, album, color, selcolor)) #album
		res.append((eListboxPythonMultiContent.TYPE_TEXT, (width-400*f), 38*f, 230*f, 22*f, 1, RT_HALIGN_CENTER|RT_VALIGN_CENTER, item.genre, color, selcolor)) # genre
		res.append((eListboxPythonMultiContent.TYPE_TEXT,    129*f, ((68+2)*f), (width-(355+129)*f), 19*f, 2, RT_HALIGN_LEFT|RT_VALIGN_CENTER, mypath, color, selcolor)) #Pfad zum Song
		
		gradientlength=200*f
		ptr=LoadPixmap(cached=True, path=dir+'gradientmypathalpha%d_32.png' %gradientlength) # verlauf mypath am Ende
		res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, (width-(355+gradientlength/f)*f), ((68+2)*f), gradientlength, 20*f, ptr))
		res.append((eListboxPythonMultiContent.TYPE_TEXT, (width-150*f), 68*f, 150*f, 22*f, 1, RT_HALIGN_CENTER|RT_VALIGN_CENTER, item.bitrate, color, selcolor)) # bitrate
		res.append((eListboxPythonMultiContent.TYPE_TEXT, (width-235*f), 68*f, 80*f, 22*f, 1, RT_HALIGN_RIGHT|RT_VALIGN_CENTER, 'Plays %d' %item.playcount, color, selcolor)) # playcount
		res.append((eListboxPythonMultiContent.TYPE_PIXMAP_ALPHATEST, (width-355*f), 68*f, 120*f, 23*f, 	LoadPixmap(cached=True, path=dir+'rating'+str(calcRating(item.rating))+'.png'))) # rating
		return res

	def connectSelChanged(self, fnc):
		if not fnc in self.onSelectionChanged:
			self.onSelectionChanged.append(fnc)

	def disconnectSelChanged(self, fnc):
		if fnc in self.onSelectionChanged:
			self.onSelectionChanged.remove(fnc)

	def selectionChanged(self):
		for x in self.onSelectionChanged:
			x()

	def getCurrent(self):
		cur = self.l.getCurrentSelection()
		return cur and cur[0]

	def postWidgetCreate(self, instance):
		instance.setContent(self.l)
		self.selectionChanged_conn = instance.selectionChanged.connect(self.selectionChanged)
		if self.enableWrapAround:
			self.instance.setWrapAround(True)

	def moveToIndex(self, index):
		self.instance.moveSelectionTo(index)

	def getCurrentIndex(self):
		return self.instance.getCurrentIndex()

	currentIndex = property(getCurrentIndex, moveToIndex)
	currentSelection = property(getCurrent)

	def setList(self, mylist):
		self.list = mylist
		self.l.setList(mylist)

	def getItemCount(self):
		return  self.itemCount

	def getList(self):
		return self.list

	def refreshList(self):
		self.l.setList(self.list)
		
	def removeItem(self, index):
		del self.list[index]
		self.l.entryRemoved(index)

	def selectionEnabled(self, enabled):
		if self.instance is not None:
			self.instance.setSelectionEnable(enabled)
			#logger.info('CentralList]selectionEnabled]->%s'%str(enabled))
