# -*- coding: UTF-8 -*-

#  Music Center E2
#
#  Coded by bobo71 (c) 2014
#  Support: www.dreambox-tools.info
#
#  All Files of this Software are licensed under the Creative Commons
#  Attribution-NonCommercial-ShareAlike 3.0 Unported
#  License if not stated otherwise in a Files Head. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.

#  Additionally, this plugin may only be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.

#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially
#  distributed other than under the conditions noted above.
#  This applies to the source code as a whole as well as to parts of it, unless
#  explicitely stated otherwise.


from Plugins.Plugin import PluginDescriptor
from Components.config import config, ConfigYesNo, ConfigSubsection, ConfigInteger, ConfigDirectory, ConfigSelection, ConfigText, ConfigLocations, NoSave,ConfigNothing
from os import path as os_path, listdir as os_listdir
from myLogger import logger, setLogLevel
from Tools.HardwareInfo import HardwareInfo



config.plugins.musiccenter=ConfigSubsection()
config.plugins.musiccenter.useartistart=ConfigYesNo(default=True)
config.plugins.musiccenter.artistartpicsmaxcount=ConfigInteger(6,limits=(1, 20))
config.plugins.musiccenter.addcoverautotosong=ConfigYesNo(default=False)
config.plugins.musiccenter.musiccenterextendedpluginlist=ConfigYesNo(default=True)
config.plugins.musiccenter.defaultfilebrowserpath=ConfigDirectory(default="/hdd/")
config.plugins.musiccenter.rememberlastfilebrowserpath=ConfigYesNo(default=True)
config.plugins.musiccenter.musiccentermainmenu=ConfigYesNo(default=True)
config.plugins.musiccenter.filedeletefunction=ConfigYesNo(default=False)
config.plugins.musiccenter.screensaverstarttime=ConfigInteger(5,limits=(0, 60))
config.plugins.musiccenter.setdebug=ConfigSelection(default="error", choices=[("off",_("off")), ("error",_("error")), ("info",_("info")), ("debug",_("debug"))])
config.plugins.musiccenter.copydestin=ConfigText(default="/")
config.plugins.musiccenter.bookmarks=ConfigLocations(default="/hdd/")
config.plugins.musiccenter.lastusedpath=ConfigText(default="/")
# streamripper
config.plugins.musiccenter.minmp3streamingrate=ConfigSelection(default="0", choices=[("0",_("All")), ("64",_(">= 64 kbps")), ("96",_(">= 96 kbps")), ("128",_(">= 128 kbps")), ("160",_(">= 160 kbps")), ("192",_(">= 192 kbps")), ("256",_(">= 256 kbps"))])
config.plugins.musiccenter.minaacstreamingrate=ConfigSelection(default="0", choices=[("0",_("All")), ("64",_(">= 64 kbps")), ("96",_(">= 96 kbps")), ("128",_(">= 128 kbps")), ("160",_(">= 160 kbps")), ("192",_(">= 192 kbps")), ("256",_(">= 256 kbps"))])
config.plugins.musiccenter.minwmastreamingrate=ConfigSelection(default="0", choices=[("0",_("All")), ("64",_(">= 64 kbps")), ("96",_(">= 96 kbps")), ("128",_(">= 128 kbps")), ("160",_(">= 160 kbps")), ("192",_(">= 192 kbps")), ("256",_(">= 256 kbps"))])
config.plugins.musiccenter.streamripper_base_directory=ConfigDirectory(default="/hdd/streamripper/")
config.plugins.musiccenter.streamripper_addsequencenumber_on_outputfile=ConfigSelection(default="no", choices=[("no",_("No")), ("counter",_("Counter")), ("date_and_counter",_("Date and counter"))])
config.plugins.musiccenter.use_different_streamripper_useragent_for_rip=ConfigYesNo(default=False)
config.plugins.musiccenter.different_streamripper_useragent=ConfigText(default='SimplePlayer/1.x', fixed_size=False)
config.plugins.musiccenter.streamripper_check_for_dublicates=ConfigYesNo(default=True)
config.plugins.musiccenter.streamripper_save_dublicates=ConfigYesNo(default=False)
#soundcloud
config.plugins.musiccenter.sc_downloadfolder=ConfigDirectory(default="/hdd/")
config.plugins.musiccenter.sc_search= NoSave(ConfigText(default='Searchword', fixed_size=False))
config.plugins.musiccenter.sc_username=ConfigText(default="username", fixed_size=False)
config.plugins.musiccenter.sc_password=ConfigText(default="password", fixed_size=False)
config.plugins.musiccenter.sc_autoloadnextfeeds=ConfigYesNo(default=True)

config.plugins.musiccenter.downloadcache=ConfigDirectory(default="/hdd/")
config.plugins.musiccenter.downloadcachesize=ConfigInteger(256,limits=(16, 1024))
config.plugins.musiccenter.picrefreshtime=ConfigSelection(default="315360000", choices=[("315360000",_("Never")), ("0",_("Every session")), ("86400",_("Older one day")), ("172800",_("Older two days")), ("259200",_("Older three days")), ("604800",_("Older one week"))])

config.plugins.musiccenter.playcountertriggerprozent=ConfigSelection(default="0", choices=[("0",_("Off")), ("25",_("25%")), ("33",_("33%")), ("50",_("50%")), ("66",_("66%")), ("75",_("75%")), ("90",_("90%")), ("100",_("100%"))])
config.plugins.musiccenter.playcountertriggertime=ConfigInteger(5,limits=(1, 20))
config.plugins.musiccenter.openHelp=ConfigNothing()
config.plugins.musiccenter.ytSearchmax_results=ConfigInteger(5,limits=(3, 20))
config.plugins.musiccenter.databasepath=ConfigDirectory(default="/etc/enigma2/")
config.plugins.musiccenter.songliststyle=ConfigSelection(choices = [("list", _("list")), ("2dlist", _("2D Coverflow")), ("coverwall", _("Coverwall"))], default = "list")
config.plugins.musiccenter.fake=NoSave(ConfigText(default=''))
config.plugins.musiccenter.visualization = ConfigSelection(choices = [("With Peakhold", _("With Peakhold")), ("No Peakhold", _("No Peakhold")), ("Off", _("Off"))], default = "No Peakhold")


from JobCenter import JCcheckModuleIsUpdated
from Globals import FILESSIZE

from enigma import addFont
from StreamRipper import streamripperinstance

try:
	#logger.info('plugin.py]addFont]try first...')
	addFont('/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/fonts/sans.ttf', 'SansReg', 100, False) #

except Exception as ex:
	#logger.info( 'plugin.py]addFont]exception...')
	addFont('/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/fonts/sans.ttf', 'SansReg', 100, False, 0)

import MusicCenter, JobCenter # , JobCenter2, StreamRipper # , LogScreen, GoogleImageSearch, TaskViewScreen, SoundCloudPlayer, ListClasses, Player, RadioDe

def MusicCenterstart(session, **kwargs):
	session1=session
	try:
		if JCcheckModuleIsUpdated('MusicCenter'):
			logger.info('plugin.py]MusicCenterStart]reload MusicCenter Module')
			reload(MusicCenter)

		if kwargs.has_key("servicelist"):
			servicelist = kwargs["servicelist"]
		else:
			from Screens.InfoBar import InfoBar
			servicelist = InfoBar.instance.servicelist

		logger.info('plugin.py]MusicCenterStart]call MusicCenterStart')
		d = MusicCenter.MusicCenterStart(session, servicelist)
		d.open()
		#session.open(MusicCenter.MusicCenterMain)#, self.servicelist)
	except Exception, e:
		print 'MusicCenterstart]plugin] Function Error:{}'.format(e)
		logger.error('MusicCenterstart]plugin] Function Error:{}'.format(e))
		from Screens.MessageBox import MessageBox
		session1.open(MessageBox, _("Error MusicCenter\n{}".format(e)), type=MessageBox.TYPE_ERROR)


def menu_musiccenter(menuid, **kwargs):
	if menuid == "mainmenu":
		return [(_("Music Center"),
		MusicCenterstart, "Dreambox Music Player", 30)]
	return []

# Autostart
def autostart(reason, **kwargs):
	print 'MusicCenter set loggerlevel:{}'.format(config.plugins.musiccenter.setdebug.value)
	setLogLevel(logger)

	from StreamRipper import streamripperinstance

	if reason == 0:
		logger.info('autostart]reason 0 -> start')

	elif reason == 1:
		logger.info('autostart]reason 1 -> check for streamripperinstance')
		if streamripperinstance.isRunning:
			logger.info('autostart]streamripperinstance kill...')
			streamripperinstance.shutdown()
		streamripperinstance = None


def Plugins(**kwargs):
	list=[PluginDescriptor(name="Music Center",description=_("Dreambox Music Player"), where=[PluginDescriptor.WHERE_PLUGINMENU], icon="images/MusicCenter.png", fnc=MusicCenterstart)]
	list.append(PluginDescriptor(name = "Music Center", where = [PluginDescriptor.WHERE_AUTOSTART], fnc = autostart))
	if config.plugins.musiccenter.musiccenterextendedpluginlist.value:
		list.append(PluginDescriptor(name="Music Center", description=_("Dreambox Music Player"), where=[PluginDescriptor.WHERE_EXTENSIONSMENU], fnc=MusicCenterstart))
	if config.plugins.musiccenter.musiccentermainmenu.value:
		list.append(PluginDescriptor(name="Music Center", description=_("Dreambox Music Player"), where=[PluginDescriptor.WHERE_MENU], fnc=menu_musiccenter))
	return list
