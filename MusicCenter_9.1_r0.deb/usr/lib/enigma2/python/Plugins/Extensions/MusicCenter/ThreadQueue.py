# -*- coding: UTF-8 -*-

#  Music Center E2
#
#  Coded by bobo71 (c) 2014
#  Support: www.dreambox-tools.info
#
#  All Files of this Software are licensed under the Creative Commons
#  Attribution-NonCommercial-ShareAlike 3.0 Unported
#  License if not stated otherwise in a Files Head. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.

#  Additionally, this plugin may only be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.

#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially
#  distributed other than under the conditions noted above.
#  This applies to the source code as a whole as well as to parts of it, unless
#  explicitely stated otherwise.

from myLogger import logger
from threading import BoundedSemaphore

class ThreadQueue:
	# semaphore
	def __init__(self):
		self.__list = [ ]
		max_connections = 10
		self.__semaphore_pool = BoundedSemaphore(max_connections)

	def push(self, val):
		with self.__semaphore_pool:
			self.__list.append(val)
			#logger.debug('ThreadQueue]push]{}'.format(str(val)[:100]))

	def pop(self):
		with self.__semaphore_pool:
			if self.__list:
				ret = self.__list.pop(0)
			else:
				ret = ('Nothing in Threadquere!', None, None)
		#logger.debug('ThreadQueue]pop]{}'.format(str(ret)[:100]))
		return ret
