# -*- coding: UTF-8 -*-

#  Music Center E2
#
#  Coded by bobo71 (c) 2014
#  Support: www.dreambox-tools.info
#
#  All Files of this Software are licensed under the Creative Commons
#  Attribution-NonCommercial-ShareAlike 3.0 Unported
#  License if not stated otherwise in a Files Head. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.

#  Additionally, this plugin may only be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.

#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially
#  distributed other than under the conditions noted above.
#  This applies to the source code as a whole as well as to parts of it, unless
#  explicitely stated otherwise.


from Globals import *
from SelectPath import SelectPath
from myLogger import logger
from JobCenter import sqlCommand_Streaming_WithReturn, OpenDB_Streaming, JCcheckModuleIsUpdated
import GoogleImageSearch


class EditFavoriteStreamDB(Screen,ConfigListScreen):

	if RESOLUTIONx > 1800:
		skin="""
			<screen position="210,180" size="1500,540" title="MusicCenter Edit FavoriteStreamDB Screen" >
			<widget name="config" position="15,60" size="1425,480" scrollbarMode="showOnDemand" />
			<widget name="buttonred" position="15,480" size="380,60" backgroundColor="red" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;30"/>
			<widget name="buttongreen" position="415,480" size="380,60" backgroundColor="green" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;30"/>
			<widget name="buttonyellow" position="815,480" size="380,60" backgroundColor="yellow" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;30"/>
			</screen>"""
	else:
		skin="""
			<screen                     position="140,120" size="1000,360" title="MusicCenter Edit FavoriteStreamDB Screen" >
			<widget name="config"       position="10,40"   size="950,320" scrollbarMode="showOnDemand" />
			<widget name="buttonred"    position="10,320"  size="253,40" backgroundColor="red" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;20"/>
			<widget name="buttongreen"  position="276,320" size="253,40" backgroundColor="green" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;20"/>
			<widget name="buttonyellow" position="543,320" size="253,40" backgroundColor="yellow" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;20"/>
			</screen>"""
	def __init__(self, session,stationname=None):

		self.session=session
		Screen.__init__(self, session)

		self.is_changed=False

		sql='''SELECT stationname, genre, location, bitrate, codec, streamurl, stationicon, station_id
		FROM Stream_Favorites 
		WHERE stationname="%s";''' % stationname
		cursor=sqlCommand_Streaming_WithReturn(sql, dbname='musiccenter_stream_favorites.db')	
		row=cursor.fetchone()

		self.stationname=row[0]
		self.genre=row[1].replace('Genre:','')
		self.location=row[2].replace('Location:','')
		try:
			self.bitrate=int(row[3].lower().split('k',1)[0])
		except:
			self.bitrate=0

		codecchoices=['None','MP3','OGG','AAC','WMA']
		if len(row[4]) > 0:
			self.codec=row[4]
		else:
			self.codec='None'
		self.streamurl=row[5]
		self.stationicon=row[6]

		config.plugins.musiccenter.stream_stationname= NoSave(ConfigText(default=self.stationname , fixed_size=False))
		config.plugins.musiccenter.stream_genre= NoSave(ConfigText(default=self.genre , fixed_size=False))
		config.plugins.musiccenter.stream_location= NoSave(ConfigText(default=self.location , fixed_size=False))
		config.plugins.musiccenter.stream_bitrate= NoSave(ConfigNumber(default=self.bitrate))
		config.plugins.musiccenter.stream_codec= NoSave(ConfigSelection(default=self.codec , choices=codecchoices))
		config.plugins.musiccenter.stream_streamurl= NoSave(ConfigText(default=self.streamurl , fixed_size=False))
		if self.stationicon==None:
			config.plugins.musiccenter.stationiconpath= NoSave(ConfigDirectory(default=config.plugins.musiccenter.downloadcache.value))
		else:
			config.plugins.musiccenter.stationiconpath= NoSave(ConfigDirectory(default=self.stationicon))

		self.list=[]
		self.list.append(getConfigListEntry(_("Stationname:"), config.plugins.musiccenter.stream_stationname))
		self.list.append(getConfigListEntry(_("Genre:"), config.plugins.musiccenter.stream_genre))
		self.list.append(getConfigListEntry(_("Location:"), config.plugins.musiccenter.stream_location))
		self.list.append(getConfigListEntry(_("Bitrate:"), config.plugins.musiccenter.stream_bitrate))
		self.list.append(getConfigListEntry(_("Codec:"), config.plugins.musiccenter.stream_codec))
		self.list.append(getConfigListEntry(_("Stationstreamurl:"), config.plugins.musiccenter.stream_streamurl))
		self.stationIconPath=getConfigListEntry(_("Stationicon path"), config.plugins.musiccenter.stationiconpath)
		self.list.append(self.stationIconPath)

		ConfigListScreen.__init__(self, self.list, session)

		self["buttonred"]=Label(_("Back"))
		self["buttongreen"]=Label(_("Save changes"))
		self["buttonyellow"]=Label(_("Update Stationicon"))
		self["setupActions"]=ActionMap(["ColorActions"],
		{
			"green": self.save,
			"red": self.cancel,
			"yellow": self.updateStationicon,
			"cancel": self.cancel,
			"ok": self.keySelect,
			"save": self.save,
		}, -2)

	def keySelect(self):
		cur=self["config"].getCurrent()
		if cur == self.stationIconPath:
			self.session.openWithCallback(self.pathSelectedStationIcon, SelectPath, config.plugins.musiccenter.stationiconpath.value, mediaPattern="^.*\.(jpg|jpeg|png)", showFiles = True)

	def updateStationicon(self):
		logger.info('EditFavoriteStreamDB]updateStationicon]')
		if JCcheckModuleIsUpdated('GoogleImageSearch'):
			reload(GoogleImageSearch)
		stationname=config.plugins.musiccenter.stream_stationname.value + ' logo'
		logger.info('EditFavoriteStreamDB]updateStationicon]stationname->%s self.stationIconPath->%s' %(stationname, config.plugins.musiccenter.stationiconpath.value))
		self.session.openWithCallback(self.closedArtistGoogleSearch, GoogleImageSearch.GoogleImageSearchScreen, currenPlayingSongfFilename=stationname, picname=config.plugins.musiccenter.stationiconpath.value, searchterm=stationname, res=(-1, -1, False))	
		
	def closedArtistGoogleSearch(self, result):# currenPlayingSongfFilename, picname, error
		currenPlayingSongfFilename, picname, error=result
		if picname is not None:
			logger.info('EditFavoriteStreamDB]closedArtistGoogleSearch]new stationpic->%s' %picname)
		else:
			logger.info('EditFavoriteStreamDB]closedArtistGoogleSearch]no stationicon found')
		
	def pathSelectedStationIcon(self, res):
		if res is not None:
			logger.info('EditFavoriteStreamDB]pathSelectedStationIcon]res-->%s' %str(res))
			picdir='/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/stationicons/'
			stationicon=''.join((res[1], res[0]))
			if not stationicon.startswith(picdir):
				iconpath=''.join((picdir, res[0]))
				sh_copy2(stationicon, iconpath)
			else:
				iconpath=stationicon
			config.plugins.musiccenter.stationiconpath.value=iconpath

	def saveChangedTags(self):
		sql='''UPDATE Stream_Favorites SET '''
		# stationname
		if self.stationname!=config.plugins.musiccenter.stream_stationname.value:
			self.is_changed=True
			logger.info('EditFavoriteStreamDB]saveChangedTags]new stationname:%s' % (config.plugins.musiccenter.stream_stationname.value))
		sql=sql + '''stationname="%s", ''' % config.plugins.musiccenter.stream_stationname.value

		# genre
		if self.genre!=config.plugins.musiccenter.stream_genre.value:
			self.is_changed=True
			logger.info('EditFavoriteStreamDB]saveChangedTags]new genre:%s' % (config.plugins.musiccenter.stream_genre.value))
		sql=sql + '''genre="%s", ''' % config.plugins.musiccenter.stream_genre.value

		# location
		if self.location!=config.plugins.musiccenter.stream_location.value:
			self.is_changed=True
			logger.info('EditFavoriteStreamDB]saveChangedTags]new location:%s' % (config.plugins.musiccenter.stream_location.value))
		sql=sql + '''location="%s", ''' % config.plugins.musiccenter.stream_location.value

		#bitrate
		if self.bitrate!=config.plugins.musiccenter.stream_bitrate.value:
			if config.plugins.musiccenter.stream_bitrate.value!=0:
				self.is_changed=True
				logger.info('EditFavoriteStreamDB]saveChangedTags]new bitrate:%s' % (config.plugins.musiccenter.stream_bitrate.value))
		sql=sql + '''bitrate="%sK", ''' % config.plugins.musiccenter.stream_bitrate.value

		#codec
		if self.codec!=config.plugins.musiccenter.stream_codec.value and self.codec!='None':
			self.is_changed=True
			logger.info('EditFavoriteStreamDB]saveChangedTags]new codec:%s' % (config.plugins.musiccenter.stream_codec.value))
		sql=sql + '''codec="%s", ''' % config.plugins.musiccenter.stream_codec.value

		# streamurl
		if self.streamurl!=config.plugins.musiccenter.stream_streamurl.value:
			self.is_changed=True
			logger.info('EditFavoriteStreamDB]saveChangedTags]new streamurl:%s' % (config.plugins.musiccenter.stream_streamurl.value))
		sql=sql + '''streamurl="%s", ''' % config.plugins.musiccenter.stream_streamurl.value

		#stationicon
		if self.stationicon!=config.plugins.musiccenter.stationiconpath.value:
			self.is_changed=True
			logger.info('EditFavoriteStreamDB]saveChangedTags]new stationicon:%s' % (config.plugins.musiccenter.stream_streamurl.value))
			sql=sql + '''stationicon="%s", ''' % config.plugins.musiccenter.stationiconpath.value
			
		# wenn Aenderung dann schreibe neu
		if self.is_changed:
			logger.info('EditFavoriteStreamDB]saveChangedTags]New Tags, save now!')
			sql= sql[:-2] + ''' WHERE station_id="%d";''' % station_id
			logger.info('EditFavoriteStreamDB]saveChangedTags]sql %s' %sql)
			cursor=sqlCommand_Streaming_WithReturn(sql, dbname='musiccenter_stream_favorites.db')

	def save(self):
		for x in self["config"].list:
			x[1].save()
		self.saveChangedTags()
		self.close(True)

	def cancel(self):
		self.close(None)

