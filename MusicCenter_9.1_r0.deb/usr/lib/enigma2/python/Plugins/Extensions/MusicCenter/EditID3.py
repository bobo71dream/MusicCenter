# -*- coding: UTF-8 -*-

#  Music Center E2
#
#  Coded by bobo71 (c) 2014
#  Support: www.dreambox-tools.info
#
#  All Files of this Software are licensed under the Creative Commons
#  Attribution-NonCommercial-ShareAlike 3.0 Unported
#  License if not stated otherwise in a Files Head. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.

#  Additionally, this plugin may only be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.

#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially
#  distributed other than under the conditions noted above.
#  This applies to the source code as a whole as well as to parts of it, unless
#  explicitely stated otherwise.

from myLogger import logger
from JobCenter import *
from Globals import *
from tagger import myenCode, getID3raw
from mutagen.id3 import ID3, TIT2, TALB, TPE1, TPE2, COMM, USLT, TCOM, TCON, TDRC, POPM, TRCK

class myConfigNumber(ConfigNumber):
			
	def __init__(self, default = 0):
		ConfigText.__init__(self, str(default), fixed_size = False)
		logger.info('myConfigNumber]__init__...')
		NUMBERS='-1'
		global NUMBERS
		
	def conform(self):
		pos = len(self.text) - self.marked_pos
		if self.text == "":
			self.text = "0"
		if pos > len(self.text):
			self.marked_pos = 0
		else:
			self.marked_pos = len(self.text) - pos
		logger.info('myConfigNumber]conform text->%s' %self.text)
		NUMBERS=self.text
		global NUMBERS


class EditId3(Screen, ConfigListScreen):

	if RESOLUTIONx>1800:
		skin="""
			<screen position="210,180" size="1500,540" title="MusicCenter_Edit_ID3" >
			<widget name="filetype" position="15,15" zPosition="1" size="1350,30" font="SansReg;30" transparent="1"	backgroundColor="#00000000"/>
			<widget name="config" position="15,60" size="1275,480" scrollbarMode="showOnDemand" />
			<widget name="buttonred" position="15,480" size="380,60" backgroundColor="red" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="SansReg;39"/>
			<widget name="buttongreen" position="405,480" size="380,60" backgroundColor="green" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="SansReg;39"/>
			<widget name="buttonyellow" position="795,480" size="380,60" backgroundColor="yellow" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="SansReg;39"/>
			</screen>"""
	else:
		skin="""
			<screen                     position="140,120" size="1000,360" title="MusicCenter_Edit_ID3" >
			<widget name="filetype"     position="10,10"   size="900,20" zPosition="1" font="SansReg;20" transparent="1"	backgroundColor="#00000000"/>
			<widget name="config"       position="10,640"  size="850,320" scrollbarMode="showOnDemand" />
			<widget name="buttonred"    position="10,320"  size="253,40" backgroundColor="red" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="SansReg;26"/>
			<widget name="buttongreen"  position="270,320" size="253,40" backgroundColor="green" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="SansReg;26"/>
			<widget name="buttonyellow" position="530,320" size="253,40" backgroundColor="yellow" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="SansReg;26"/>
			</screen>"""


	def __init__(self, session, slentry, currentSonglistindex):
	
		self.session=session
		Screen.__init__(self, session)

		self.date="0000"
		self.track="0000"
		self.is_changed=False
		self.artist_is_changed=False
		self.titl_is_changed=False
		currentFilename=slentry.filename
		self.root, self.filename=os_path.split(os_path.realpath(currentFilename))
		self.currentSonglistindex=currentSonglistindex
		self.slentry=slentry
		basefilename=self.filename.strip().rsplit('.',1)[0]
		logger.info('EditID3]init basefilename->%s'%basefilename)

		# tracknr
		tracknr=''
		for char in iter(basefilename):
			if char.isdigit():
				tracknr+=char
			else:
				break
		if tracknr:
			self.track=tracknr
			
		# artist, title
		tmp=basefilename.rsplit('.',1)[0].strip()
		artistandtitle=[ i for i in tmp[len(tracknr):].replace('_','-').strip().split('-') if len(i)]
				
		self.artist=myenCode(re_sub('\A | \Z','',(artistandtitle[0])))
		if len(artistandtitle)>1:
			self.title=myenCode(re_sub('\A | \Z','',(artistandtitle[1])))
		else:
			self.title=self.artist
		logger.info('EditID3]init names after resolve filename self.track->%s self.artist->%s self.title->%s'%(self.track, self.artist, self.title))

		# getID3Tags now...
		ID3=slentry
		self.genre=ID3.genre
		self.album=ID3.album
		self.albumartist=ID3.albumartist
		self.filetype=ID3.filetype
		self.playcount=ID3.playcount
		self.rating=ID3.rating
		self.wave=ID3.wave
		
		self["filetype"]=Label('is %s' % (self.filetype))

		if len(ID3.tracknr) > 0 and not ID3.tracknr=='n/a':
			self.track=ID3.tracknr
		if len(ID3.artist) > 0 and not ID3.artist == "n/a":
			self.artist=myenCode(ID3.artist).title() #myenCode(ID3.artist.decode('utf8').title())
			self.artist_is_changed=True
		if len(ID3.title) > 0 and not ID3.title == 'n/a' and ID3.title!=basefilename:
			self.title=myenCode(ID3.title).title() #myenCode(ID3.title.decode('utf8').title())
			self.titl_is_changed=True	
		logger.info('EditID3]init names after getId3 self.track->%s self.artist->%s self.title->%s'%(self.track, self.artist, self.title))
		
		if self.album == "n/a":
			self.album=''

		if self.albumartist == "n/a":
			self.albumartist=''
			
		actualdate=datetime_date.today().year
		self.choicesdate=[str(f) for f in range(actualdate-40, actualdate+1)]
		logger.info('EditID3]init id3_date %s'%ID3.date)
		if ID3.date!='-1' and len(ID3.date) > 0 :
			self.date=ID3.date
			self.choicesdate.append(self.date)# kein Datum und das von ID3 an
		# genre
		if self.genre == 'n/a' or len(self.genre) == 0:
			self.genre='No genre'
			
		sql='''SELECT genre_text FROM Genres ORDER BY genre_text;''' # SELECT genre_text FROM Genres ORDER BY(SUBSTR(genre_text, 1, 1))||SUBSTR(genre_text, 2);'''
		res=execSQLCommandWithReturn(sql).fetchall()
		self.genre_choices=[ x[0] for x in res if len(x[0])!=0 ] # fix crash ValueError: '' is not in list

		self.genre_choices.append(self.genre)
		logger.info('EditID3]init]genre_choices:{}'.format(self.genre_choices))
		
		self.list=[]
		logger.info('EditID3]init]buildconfigList')
		self.buildConfigList()

		logger.info('EditID3]init]ConfigListScreen')
		ConfigListScreen.__init__(self, self.list, session)

		logger.info('EditID3]init]buttons...')
		self["buttonred"]=Label(_("Back"))
		self["buttongreen"]=Label(_("Save changed Tags"))
		self["buttonyellow"]=Label(_("Toggle artist with title"))

		logger.info('EditID3]init]ActionMap...')
		self["setupActions"]=ActionMap(['ColorActions', 'SetupActions'],
		{
			"red": self.cancel,
			"green": self.save,
			"yellow": self.yellowPressed,
			"save": self.save,
			"cancel": self.cancel,
			"ok": self.save,
		}, -2)

	def buildConfigList(self):
		config.plugins.musiccenter.newfilename= NoSave(ConfigText(default=self.filename , fixed_size=False))
		config.plugins.musiccenter.newartist= NoSave(ConfigText(default=self.artist , fixed_size=False))
		config.plugins.musiccenter.newtitl= NoSave(ConfigText(default=self.title , fixed_size=False))
		config.plugins.musiccenter.newalbum= NoSave(ConfigText(default=self.album , fixed_size=False))
		config.plugins.musiccenter.newalbumartist= NoSave(ConfigText(default=self.albumartist , fixed_size=False))
		config.plugins.musiccenter.newgenrelist=NoSave(ConfigSelection(default= self.genre, choices=self.genre_choices))
		config.plugins.musiccenter.newgenre= NoSave(ConfigText(default=self.genre , fixed_size=False))
		config.plugins.musiccenter.newdate=NoSave(ConfigSelection(default= self.date, choices=self.choicesdate))
		config.plugins.musiccenter.newtrack= NoSave(myConfigNumber(default=str(self.track)))
		config.plugins.musiccenter.newplaycount= NoSave(myConfigNumber(default=str(self.playcount)))
		
		self.list.append(getConfigListEntry(_("Filename:"), config.plugins.musiccenter.newfilename))
		self.list.append(getConfigListEntry(_("Artist:"), config.plugins.musiccenter.newartist))
		self.list.append(getConfigListEntry(_("Title:"), config.plugins.musiccenter.newtitl))
		self.list.append(getConfigListEntry(_("Album:"), config.plugins.musiccenter.newalbum))
		self.list.append(getConfigListEntry(_("Albumartist:"), config.plugins.musiccenter.newalbumartist))
		self.list.append(getConfigListEntry(("Genres in database:"), config.plugins.musiccenter.newgenrelist))
		self.list.append(getConfigListEntry(_("Add new Genre:"), config.plugins.musiccenter.newgenre))
		self.list.append(getConfigListEntry(_("Year:"), config.plugins.musiccenter.newdate))
		self.list.append(getConfigListEntry(_("Tracknr:"), config.plugins.musiccenter.newtrack))
		self.list.append(getConfigListEntry(_("Playcount:"), config.plugins.musiccenter.newplaycount))

		
	def saveChangedId3(self):
	
		audio, filetype=getID3raw(os_path.join(self.root, self.filename), will_write=True)

		if audio!=None:
			# artist
			if self.artist!=config.plugins.musiccenter.newartist.value or self.artist_is_changed:
				self.is_changed=True
				logger.info('EditID3]saveChangedId3]New Artist:%s' % (config.plugins.musiccenter.newartist.value))
			#audio.update(artist=unicode(config.plugins.musiccenter.newartist.value, "utf-8")) #audio['artist']=(config.plugins.musiccenter.newartist.value.encode('ascii', 'xmlcharrefreplace'))
			audio["TPE1"] = TPE1(encoding=3, text=unicode(config.plugins.musiccenter.newartist.value, "utf-8"))

			# title
			if self.title!=config.plugins.musiccenter.newtitl.value or self.titl_is_changed:
				self.is_changed=True
				logger.info('EditID3]saveChangedId3]New Title:%s' % (config.plugins.musiccenter.newtitl.value))
			#audio.update(title=unicode(config.plugins.musiccenter.newtitl.value, "utf-8")) #audio['title']=(config.plugins.musiccenter.newtitl.value.encode('ascii', 'xmlcharrefreplace'))
			audio["TIT2"] = TIT2(encoding=3, text=unicode(config.plugins.musiccenter.newtitl.value, "utf-8"))
			
			# album
			if self.album!=config.plugins.musiccenter.newalbum.value:
				self.is_changed=True
				logger.info('EditID3]saveChangedId3]New Album:%s' % (config.plugins.musiccenter.newalbum.value))
			#audio.update(album=unicode(config.plugins.musiccenter.newalbum.value, "utf-8")) #audio['album']=(config.plugins.musiccenter.newalbum.value.encode('ascii', 'xmlcharrefreplace'))
			audio["TALB"] = TALB(encoding=3, text=unicode(config.plugins.musiccenter.newalbum.value, "utf-8"))

			#albumartist
			if self.albumartist!=config.plugins.musiccenter.newalbumartist.value:
				self.is_changed=True
				logger.info('EditID3]saveChangedId3]New Albumartist:%s' % (config.plugins.musiccenter.newalbumartist.value))
			#audio.update(performer=unicode(config.plugins.musiccenter.newalbumartist.value, "utf-8"))
			audio["TPE2"] = TPE2(encoding=3, text=unicode(config.plugins.musiccenter.newalbumartist.value, "utf-8"))

			#genre
			if self.genre!=config.plugins.musiccenter.newgenre.value:
				self.is_changed=True
				self.genre=config.plugins.musiccenter.newgenre.value
				logger.info('EditID3]saveChangedId3]New Genre from key entry:%s' % (config.plugins.musiccenter.newgenre.value))
				#audio.update(genre=unicode(config.plugins.musiccenter.newgenre.value, "utf-8")) 
				audio["TCON"] = TCON(encoding=3, text=unicode(config.plugins.musiccenter.newgenre.value, "utf-8"))
			elif self.genre!=config.plugins.musiccenter.newgenrelist.value:
				self.is_changed=True
				self.genre=config.plugins.musiccenter.newgenrelist.value
				logger.info('EditID3]saveChangedId3]New Genre from choicelist:%s' % (config.plugins.musiccenter.newgenrelist.value))
				#audio.update(genre=unicode(config.plugins.musiccenter.newgenrelist.value, "utf-8"))
				audio["TCON"] = TCON(encoding=3, text=unicode(config.plugins.musiccenter.newgenrelist.value, "utf-8"))
			if config.plugins.musiccenter.newgenrelist.value == 'No genre' and config.plugins.musiccenter.newgenre.value == 'No genre':
				logger.info('EditID3]saveChangedId3]Genre is unchanged')

			#date
			if self.date!=config.plugins.musiccenter.newdate.value:
				self.is_changed=True
				logger.info('EditID3]saveChangedId3]New Date:%s' % (config.plugins.musiccenter.newdate.value))
			#audio.update(date=unicode(str(config.plugins.musiccenter.newdate.value), "utf-8")) #audio['date']=str(config.plugins.musiccenter.newdate.value) #= str(co...
			audio["TDRC"] = TDRC(encoding=3, text=unicode(str(config.plugins.musiccenter.newdate.value), "utf-8"))

			#tracknr	
			logger.info('EditID3]saveChangedId3]config.plugins.musiccenter.newdate.value->%s NUMBERS->%s' %(config.plugins.musiccenter.newdate.value, NUMBERS))
			if config.plugins.musiccenter.newdate.value == '0000':
				audio["TRCK"] = TRCK(encoding=3, text=unicode('', "utf-8"))
			else:
				if str(NUMBERS)=='-1': # unchanged
					tracknr=self.track
				else:
					tracknr=str(NUMBERS)
					logger.info('EditID3]saveChangedId3]Tracknr->%s' %tracknr)
				#	if self.track!=tracknr:
					self.is_changed=True
					logger.info('EditID3]saveChangedId3]New Tracknr:%s old was ->%s' % (tracknr, config.plugins.musiccenter.newtrack.value))
				audio["TRCK"] = TRCK(encoding=3, text=unicode(str(tracknr), "utf-8"))
			# playcount
			if self.playcount!=config.plugins.musiccenter.newplaycount.value:
				self.is_changed=True
				self.playcount=config.plugins.musiccenter.newplaycount.value
				logger.info('EditID3]saveChangedId3]New playcount from key entry:%s' % (config.plugins.musiccenter.newplaycount.value))
				if filetype=='MP3':
					logger.info('EditID3]saveChangedId3]update playcount MP3')
					audio['PCNT']=PCNT(encoding=3, count=self.playcount)
				elif filetype in ('FLAC','OGG'):
					logger.info('EditID3]saveChangedId3]update playcount FLAC OGG')
					audio['PCNT']='{}'.format(self.playcount)

			# wenn keine Aenderung dann lösche audio
			if not self.is_changed:
				logger.info('EditID3]saveChangedId3]no tag changed, remove audio...')
				audio=None
		else:
			logger.info('EditID3]saveChangedId3]Error get audioID3 from file!')

		# filename
		if self.filename!=config.plugins.musiccenter.newfilename.value:
			old_fullfn=os_path.join(self.root, self.filename)
			new_fullfn=os_path.join(self.root, config.plugins.musiccenter.newfilename.value)
			logger.info('EditID3]saveChanged Filename]rename old->%s  new->%s' % (old_fullfn, new_fullfn))
			os_rename(old_fullfn, new_fullfn)
			self.filename=config.plugins.musiccenter.newfilename.value
			
			if new_fullfn.startswith(config.plugins.musiccenter.defaultfilebrowserpath.value):
				pathoffset=len(config.plugins.musiccenter.defaultfilebrowserpath.value)
				new_fullfnindb=new_fullfn[pathoffset:]
				old_fullfnindb=old_fullfn[pathoffset:]
				logger.info('EditID3]saveChanged Filename]is in DB, update entry old->%s  new->%s' % (old_fullfnindb, new_fullfnindb))
				execSQLCommand('''UPDATE Songs SET filename=? WHERE filename=?;''', (old_fullfnindb, new_fullfnindb))
			else:
				logger.info('EditID3]saveChanged Filename]is not in DB, skip update db')
		
		# insert missing n/a
		title=config.plugins.musiccenter.newtitl.value
		if title=='':
			title='n/a'
		artist=config.plugins.musiccenter.newartist.value
		if artist=='':
			artist='n/a'
		genre=self.genre
		if genre=='':
			genre='n/a'
		track=str(tracknr)	
		if track=='':
			track='n/a'
		date=str(config.plugins.musiccenter.newdate.value)
		if date=='':
			date='n/a'
		album=config.plugins.musiccenter.newalbum.value
		if album=='':
			album='n/a'
		albumartist=config.plugins.musiccenter.newalbumartist.value
		if albumartist=='':
			albumartist='n/a'
			
		# ersetze songlistentry ................
		slentry_new=self.slentry
		slentry_new.title=title
		slentry_new.artist=artist
		slentry_new.genre=genre
		slentry_new.track=track
		slentry_new.date=date
		slentry_new.album=album
		slentry_new.albumartist=albumartist
		slentry_new.filename=self.filename
		slentry_new.playcount=self.playcount
		return audio, slentry_new

	def save(self):
		audio, slentry=self.saveChangedId3()
		res=[self.currentSonglistindex, os_path.join(self.root, self.filename), audio, slentry]
		self.close(res)

	def yellowPressed(self):
		temp=self.title
		self.title=self.artist
		self.artist=temp
		self.buildconfigList()
		#ConfigListScreen.config.setList( self.list)
		self["config"].setList( self.list)
	
	def cancel(self):
		#for x in self["config"].list:
		#	x[1].cancel()
		self.close(None)
