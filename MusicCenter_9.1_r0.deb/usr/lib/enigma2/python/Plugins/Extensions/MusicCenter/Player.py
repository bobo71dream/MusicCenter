# -*- coding: UTF-8 -*-

#  Music Center E2
#
#  Coded by bobo71 (c) 2014
#  Support: www.dreambox-tools.info
#
#  All Files of this Software are licensed under the Creative Commons
#  Attribution-NonCommercial-ShareAlike 3.0 Unported
#  License if not stated otherwise in a Files Head. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.

#  Additionally, this plugin may only be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.

#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially
#  distributed other than under the conditions noted above.
#  This applies to the source code as a whole as well as to parts of it, unless
#  explicitely stated otherwise.

from Globals import *
import EditID3
from ItemClasses import Item
from JobCenter import *
from JobCenter2 import *
from ListClasses import CentralList
from myLogger import logger
import GoogleImageSearch
from LogScreen import *
from RadioBrowser import RadioBrowserList
from tagger import getID3raw
import SimplePicbrowser
import SelectPath
from Setup import *
from StreamRipper import streamripperinstance
import TaskViewScreen

from  SoundVisualization import SoundVisualization
from enigma import eMusicPlayer
from pipes import quote as pipes_quote
from random import choice as random_choice

from . import _
#  select * from songs where artist='Rita Ora' and title='your song' COLLATE NOCASE;

# artist - title(39)-------------------------------------- Track 0236
# album [year] albumartist(30)----------------- genre ------ 0:02:56
# filename(20)----------------------------- ***** - plays -- bitrate
#- added some options for ePixmap.setScale(...) and scale= in skins, fix code-bugs related to setScale, too (it's no immediate, some broken things have been removed)
#-- ePixmap.SCALE_TYPE_NONE: "off" / "none" in skins
#-- ePixmap.SCALE_TYPE_ASPECT: "on" / "aspect" in skins
#-- ePixmap.SCALE_TYPE_CENTER: "center" in skins
#-- ePixmap.SCALE_TYPE_WIDTH: "width" in skins
#-- ePixmap.SCALE_TYPE_HEIGHT: "height" in skins
#-- ePixmap.SCALE_TYPE_StRETCH: "fill full" in skins

class Player(Screen, InfoBarBase, InfoBarSeek, InfoBarNotifications, SoundVisualization):

	if RESOLUTIONx>1800:
		skin="""
			<screen name="MusicCenterPlayer" position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#00000000" title="MC Player" zPosition="0">
			<!-- headerfield  -->
				<eLabel backgroundColor="#191919" position="20,20" size="1880,132" zPosition="1" />
				<!-- 1 zeile  -->
					<widget name="artistandtitle" position="60,26" size="1610,42" font="SansReg;35" halign="left" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" transparent="1" zPosition="2"/>
					<widget name="artistandtitlewithminicov" position="190,26" size="1480,42" font="SansReg;35" halign="left" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" transparent="1" zPosition="3"/>
					<widget name="track" position="1675,26" size="225,42" font="SansReg;35" halign="center" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" zPosition="2"/>
				<!-- 2 zeile  -->
					<widget name="albumyearalbartist" position="60,76" size="1315,34" font="SansReg;28" halign="left" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" transparent="1" zPosition="2"/>
					<widget name="albumyearalbartistwithminicov" position="190,76" size="1185,34" font="SansReg;28" halign="left" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" transparent="1" zPosition="3"/>
					<widget name="genre" position="1375,76" size="300,34" font="SansReg;28" halign="left" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" zPosition="2"/>
					<widget name="length" position="1675,76" size="225,34" font="SansReg;28" halign="center" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" zPosition="2"/>
				<!-- 3 zeile  -->
					<widget name="filename" position="60,117" size="1115,28" font="SansReg;23" halign="left" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" transparent="1" zPosition="2"/>
					<widget name="filenamewithminicov" position="190,117" size="985,28" font="SansReg;23" halign="left" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" transparent="1" zPosition="3"/>
					<widget name="rating" position="1175,116" size="300,32" alphatest="on" zPosition="3"  pixmaps="~/rating0.png,~/rating1.png,~/rating2.png,~/rating3.png,~/rating4.png,~/rating5.png,~/rating6.png,~/rating7.png,~/rating8.png,~/rating9.png,~/rating10.png,~/rating11.png"/>
					<widget name="plays" position="1475,117" size="200,28" font="SansReg;23" halign="center" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" zPosition="2"/>
					<widget name="bitrate" position="1675,117" size="225,28" font="SansReg;23" halign="center" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" zPosition="2"/>
				<!-- Buttons  -->
					<widget name="console" position="20,167" zPosition="2" size="1880,40" font="SansReg;20" backgroundColor="#191919"/>
					<widget render="Label" font="SansReg;33" transparent="1" position="60,167" size="450,40" source="key_red" foregroundColor="#ff0000" halign="center" valign="center" zPosition="3"/>
					<widget render="Label" font="SansReg;33" transparent="1" position="510,167" size="450,40" source="key_green" foregroundColor="#00ff21" halign="center" valign="center" zPosition="3"/>
					<widget render="Label" font="SansReg;33" transparent="1" position="960,167" size="450,40" source="key_yellow" foregroundColor="#FFD800" halign="center" valign="center" zPosition="3"/>
					<widget render="Label" font="SansReg;33" transparent="1" position="1410,167" size="450,40" source="key_blue" foregroundColor="#3D8DFF" halign="center" valign="center" zPosition="3"/>
					<widget name="slpage" font="SansReg;24" transparent="1" position="960,212" size="300,28" zPosition="3" halign="left" foregroundColor="#ffffff" />
			<!-- artistart  -->
				<widget name="artistArt" position="660,230" size="1120,630" zPosition="2" scale="width"/>
			<!-- wave  -->
				<widget name="wave" position="30,935" size="1860,120" alphatest="on" zPosition="5"/>
				<widget name="PositionGauge" position="30,935" size="1860,120" zPosition="4" pointer="~/SC_progressbar.png:1920,120" backgroundColor="#ff000000"/>
			<!-- playstate  -->
				<widget name="playstate" position="-12,1054" size="84,24" zPosition="6" transparent="0" font="SansReg;23" halign="center" valign="center" backgroundColor="#00000000"/>
			<!-- coverart  -->
				<widget name="coverArtmini" position="21,21" size="130,130" zPosition="3" />
				<widget name="coverArt" position="55,340" size="450,450" zPosition="2" scale="width"/>
				<widget name="coverArtBg" position="55,340" size="450,50" transparent="1" scale="fill full" alphatest="blend" pixmaps="~/placeholder1.png,~/coverttexttop300_24.png" zPosition="4"/>
				<widget name="covertext" position="55,340" size="450,50" zPosition="5" transparent="1" font="SansReg;30" foregroundColor="#ffffff" halign="center" valign="center"/>
			<!-- stationicon  -->
				<widget name="stationicon" position="350,925" size="145,145" zPosition="3"/>
				<widget name="shuffle" position="70,290" size="50,30" pixmaps="~/placeholder1.png,~/shuffle.png" transparent="1" alphatest="on" zPosition="4"/>
				<widget name="repeat" position="350,290" size="50,30" pixmaps="~/placeholder1.png,~/repeat.png" transparent="1" alphatest="on" zPosition="4"/>
			<!-- embeded songlist  -->
					<widget name="embededSonglistSimplelist" position="75,230" size="1770,684" zPosition="2" scrollbarMode="showOnDemand" backgroundColor="#00000000"/>
					<widget name="embededSonglist2DFlow" position="0,255" size="1920,420" transparent="0" backgroundColor="#00000000" zPosition="2" coverSize="200,200" selectedCoverScale="1.35" unselectedCoverDimm="0.7"  coverflowCurrentPosition="960,220" coverflowCurrentXDistance="30" coverflowCurrentCenterDistance="30" style="1" noCoverAvailablePic="/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/no-cover.png" />
					<widget name="embededSonglistCoverwall" position="0,255" size="1920,480" transparent="0" backgroundColor="#00000000" zPosition="2" coverSize="200,200" selectedCoverScale="1.25" unselectedCoverDimm="0.7"  coverBeginPosition="180,120" coverDistance="30,30" style="0" noCoverAvailablePic="/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/no-cover.png" />
			<!-- entrys 2dlist  -->
				<widget name="slbackground" position="20,750" size="1880,132" zPosition="2"/>
					<!-- 1 zeile  -->
						<widget name="slartistandtitle" position="60,756" size="1610,42" font="SansReg;36" halign="left" valign="bottom"  foregroundColor="#ffffff"  backgroundColor="#FF000000" transparent="1" zPosition="3"/>
						<widget name="sltrack" position="1675,756" size="200,42" font="SansReg;36" halign="center" valign="bottom"  foregroundColor="#ffffff"  backgroundColor="#FF000000" transparent="1" zPosition="3"/>
					<!-- 2 zeile  -->
						<widget name="slalbumyearalbartist" position="60,807" size="1315,34" font="SansReg;28" halign="left" valign="bottom"  foregroundColor="#ffffff"  backgroundColor="#FF000000" transparent="1" zPosition="3"/>
						<widget name="slgenre" position="1375,807" size="300,32" font="SansReg;28" halign="center" valign="bottom"  foregroundColor="#ffffff"  backgroundColor="#FF000000" transparent="1" zPosition="3"/>
						<widget name="sllength" position="1675,807" size="200,32" font="SansReg;28" halign="center" valign="bottom"  foregroundColor="#ffffff"  backgroundColor="#FF000000" transparent="1" zPosition="3"/>
					<!-- 3 zeile  -->
						<widget name="slfilename" position="60,849" size="1115,28" font="SansReg;23" halign="left" valign="center"  foregroundColor="#ffffff"  backgroundColor="#FF000000" transparent="1" zPosition="3"/>
						<widget name="slrating" position="1175,846" size="300,32" alphatest="on" zPosition="4"  pixmaps="~/rating0.png,~/rating1.png,~/rating2.png,~/rating3.png,~/rating4.png,~/rating5.png,~/rating6.png,~/rating7.png,~/rating8.png,~/rating9.png,~/rating10.png,~/rating11.png"/>
						<widget name="slplays" position="1475,849" size="200,28" font="SansReg;23" halign="center" valign="center"  foregroundColor="#ffffff"  backgroundColor="#FF000000" transparent="1" zPosition="3"/>
						<widget name="slbitrate" position="1675,849" size="200,28" font="SansReg;23" halign="center" valign="center"  foregroundColor="#ffffff"  backgroundColor="#FF000000" transparent="1" zPosition="3"/>
			<!-- spectrumanalyser  -->
				<widget name="progress_0" zPosition="7" position="674,930" size="42,140" backgroundColor="#00000000" orientation="orBottomToTop" pixmap="~/bar_white_40x145.png" />
				<widget name="progress_1" zPosition="7" position="744,930" size="42,140" backgroundColor="#00000000" orientation="orBottomToTop" pixmap="~/bar_white_40x145.png" />
				<widget name="progress_2" zPosition="7" position="814,930" size="42,140" backgroundColor="#00000000" orientation="orBottomToTop" pixmap="~/bar_white_40x145.png" />
				<widget name="progress_3" zPosition="7" position="884,930" size="42,140" backgroundColor="#00000000" orientation="orBottomToTop" pixmap="~/bar_white_40x145.png" />
				<widget name="progress_4" zPosition="7" position="954,930" size="42,140" backgroundColor="#00000000" orientation="orBottomToTop" pixmap="~/bar_white_40x145.png" />
				<widget name="progress_5" zPosition="7" position="1024,930" size="42,140" backgroundColor="#00000000" orientation="orBottomToTop" pixmap="~/bar_white_40x145.png" />
				<widget name="progress_6" zPosition="7" position="1094,930" size="42,140" backgroundColor="#00000000" orientation="orBottomToTop" pixmap="~/bar_white_40x145.png" />
				<widget name="progress_7" zPosition="7" position="1164,930" size="42,140" backgroundColor="#00000000" orientation="orBottomToTop" pixmap="~/bar_white_40x145.png" />
				<widget name="progress_8" zPosition="7" position="1234,930" size="42,140" backgroundColor="#00000000" orientation="orBottomToTop" pixmap="~/bar_white_40x145.png" />
				<widget name="progress_9" zPosition="7" position="1304,930" size="42,140" backgroundColor="#00000000" orientation="orBottomToTop" pixmap="~/bar_white_40x145.png" />
				<widget name="progress_10" zPosition="7" position="1374,930" size="42,140" backgroundColor="#00000000" orientation="orBottomToTop" pixmap="~/bar_white_40x145.png" />
				<widget name="progress_11" zPosition="7" position="1444,930" size="42,140" backgroundColor="#00000000" orientation="orBottomToTop" pixmap="~/bar_white_40x145.png" />
				<widget name="progress_12" zPosition="7" position="1514,930" size="42,140" backgroundColor="#00000000" orientation="orBottomToTop" pixmap="~/bar_white_40x145.png" />
				<widget name="progress_13" zPosition="7" position="1584,930" size="42,140" backgroundColor="#00000000" orientation="orBottomToTop" pixmap="~/bar_white_40x145.png" />
				<widget name="progress_14" zPosition="7" position="1654,930" size="42,140" backgroundColor="#00000000" orientation="orBottomToTop" pixmap="~/bar_white_40x145.png" />
				<widget name="progress_15" zPosition="7" position="1724,930" size="42,140" backgroundColor="#00000000" orientation="orBottomToTop" pixmap="~/bar_white_40x145.png" />
				<widget name="top_0" position="674,930" zPosition="9" size="42,1" pixmap="~/top_orange_50x1.png" />
				<widget name="top_1" position="744,930" zPosition="9" size="42,1" pixmap="~/top_orange_50x1.png" />
				<widget name="top_2" position="814,930" zPosition="9" size="42,1" pixmap="~/top_orange_50x1.png" />
				<widget name="top_3" position="884,930" zPosition="9" size="42,1" pixmap="~/top_orange_50x1.png" />
				<widget name="top_4" position="954,930" zPosition="9" size="42,2" pixmap="~/top_orange_50x1.png" />
				<widget name="top_5" position="1024,930" zPosition="9" size="42,2" pixmap="~/top_orange_50x1.png" />
				<widget name="top_6" position="1094,930" zPosition="9" size="42,2" pixmap="~/top_orange_50x1.png" />
				<widget name="top_7" position="1164,930" zPosition="9" size="42,2" pixmap="~/top_orange_50x1.png" />
				<widget name="top_8" position="1234,930" zPosition="9" size="42,2" pixmap="~/top_orange_50x1.png" />
				<widget name="top_9" position="1304,930" zPosition="9" size="42,2" pixmap="~/top_orange_50x1.png" />
				<widget name="top_10" position="1374,930" zPosition="9" size="42,2" pixmap="~/top_orange_50x1.png" />
				<widget name="top_11" position="1444,930" zPosition="9" size="42,2" pixmap="~/top_orange_50x1.png" />
				<widget name="top_12" position="1514,930" zPosition="9" size="42,2" pixmap="~/top_orange_50x1.png" />
				<widget name="top_13" position="1584,930" zPosition="9" size="42,2" pixmap="~/top_orange_50x1.png" />
				<widget name="top_14" position="1654,930" zPosition="9" size="42,2" pixmap="~/top_orange_50x1.png" />
				<widget name="top_15" position="1724,930" zPosition="9" size="42,1" pixmap="~/top_orange_50x1.png" />
			</screen>"""
	else:
		skin="""
			<screen name="MusicCenterPlayer" position="0,0" size="1280,720" flags="wfNoBorder" backgroundColor="#00000000" title="MC Player" zPosition="0">
			<!-- headerfield  -->
				<eLabel backgroundColor="#191919" position="13,13" size="1253,88" zPosition="1" />
				<!-- 1 zeile  -->
					<widget name="artistandtitle"            position=  "40,17" size="488,29" font="SansReg;23" halign="left" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" zPosition="2"/>
					<widget name="artistandtitlewithminicov" position= "126,17" size="986,29" font="SansReg;23" halign="left" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" zPosition="2"/>
					<widget name="track"                     position="1116,17" size="170,29" font="SansReg;23" halign="center" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" zPosition="2"/>
				<!-- 2 zeile  -->
					<widget name="albumyearalbartist" position= "40,51" size="877,23" font="SansReg;18" halign="left" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" zPosition="2"/>
					<widget name="albumyearalbartistwithminicov" position= "127,51" size="790,23" font="SansReg;18" halign="left" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" zPosition="2"/>
					<widget name="genre" position="917,51" size= "200,23" font="SansReg;18" halign="left" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" zPosition="2"/>
					<widget name="length" position="1117,51" size= "150,23" font="SansReg;18" halign="center" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" zPosition="3"/>
				<!-- 3 zeile  -->
					<widget name="filename" position=  "40,78" size="743,18" font="SansReg;15" halign="left" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" zPosition="2"/>
					<widget name="filenamewithminicov" position= "126,78" size="656,18" font="SansReg;15" halign="left" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" zPosition="2"/>
					<widget name="rating" position= "783,78" size="200,21" alphatest="on" zPosition="3"  pixmaps="~/rating0.png,~/rating1.png,~/rating2.png,~/rating3.png,~/rating4.png,~/rating5.png,~/rating6.png,~/rating7.png,~/rating8.png,~/rating9.png,~/rating10.png,~/rating11.png"/>
					<widget name="plays" position= "983,78" size="133,18" font="SansReg;15" halign="center" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" zPosition="2"/>
					<widget name="bitrate" position="1116,78" size="150,18" font="SansReg;15" halign="center" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" zPosition="2"/>
				<!-- Buttons -->
					<widget name="console" position="10,106" zPosition="2" size="1260,26" font="SansReg;20" backgroundColor="#191919"/>
					<widget render="Label" font="SansReg;22" transparent="1" position= "40,106" size="300,26" source="key_red" foregroundColor="#ff0000" halign="center" valign="center" zPosition="3"/>
					<widget render="Label" font="SansReg;22" transparent="1" position="340,106" size="300,26" source="key_green" foregroundColor="#00ff21" halign="center" valign="center" zPosition="3"/>
					<widget render="Label" font="SansReg;22" transparent="1" position="640,106" size="300,26" source="key_yellow" foregroundColor="#FFD800" halign="center" valign="center" zPosition="3"/>
					<widget render="Label" font="SansReg;22" transparent="1" position="940,106" size="300,26" source="key_blue" foregroundColor="#3D8DFF" halign="center" valign="center" zPosition="3"/>
				    <widget name="slpage" font="SansReg;16" transparent="1" position="640,128" size="200,19" zPosition="3" halign="left" foregroundColor="#ffffff" />
			<!-- artistart  -->
				<widget name="artistArt" position="374,113"  size="880,494" zPosition="2"/>
			<!-- wave  -->
				<widget name="wave"           position="20,623"  size="1240,80" alphatest="on" zPosition="5"/>
				<widget name="PositionGauge" position="20,623"  size="1240,80" zPosition="4" pointer="~/SC_progressbar.png:1920,120" backgroundColor="#ff000000"/>
			<!-- playstate  -->
				<widget name="playstate"      position="-8,702" size="56,16" zPosition="6" transparent="0" font="SansReg;15" halign="center" valign="center" backgroundColor="#00000000"/>
			<!-- coverart  -->
				<widget name="coverArtmini"   position="14, 14"   size="86,86" zPosition="3" />
				<widget name="coverArt"       position="20,210"   size="333,333" zPosition="2" />
				<widget name="coverArtBg"     position="20,210"   size="333,24" transparent="1" scale="fill full" alphatest="blend" pixmaps="~/placeholder1.png,~/coverttexttop300_24.png" zPosition="4"/>
				<widget name="covertext"      position="20,210"   size="333,21" zPosition="5" transparent="1" font="SansReg;20" foregroundColor="#ffffff" halign="center" valign="center"/>
			<!-- stationicon  -->
				<widget name="stationicon" position="233,616" size= "96,96" zPosition="3"/>
				<widget name="shuffle"     position="26,186"  size=  "33,20" pixmaps="~/placeholder1.png,~/shuffle.png" transparent="1" alphatest="on" zPosition="4"/>
				<widget name="repeat"      position="100,186" size=  "33,20" pixmaps="~/placeholder1.png,~/repeat.png" transparent="1" alphatest="on" zPosition="4"/>
			<!-- embeded songlist  -->
					<widget name="embededSonglistSimplelist" position="50,132" size="1180,456" zPosition="2" scrollbarMode="showOnDemand" backgroundColor="#00000000"/>
					<widget name="embededSonglist2DFlow"     position= "0,153" size="1280,280" transparent="0" backgroundColor="#00000000" zPosition="2" coverSize="133,133" selectedCoverScale="1.35" unselectedCoverDimm="0.7"  coverflowCurrentPosition="640,133" coverflowCurrentXDistance="20" coverflowCurrentCenterDistance="13" style="1" noCoverAvailablePic="/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/no-cover.png" />
					<widget name="embededSonglistCoverwall"  position= "0,146" size="1280,320" transparent="0" backgroundColor="#00000000" zPosition="2" coverSize="133,133" selectedCoverScale="1.35" unselectedCoverDimm="0.7"  coverBeginPosition="120,80" coverDistance="20,20" style="0" noCoverAvailablePic="/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/no-cover.png" />
			<!-- entrys 2dlist  -->
				<widget name="slbackground" position="20,690" size="1880,132" zPosition="2"/>
				<!-- 1 zeile  -->
					<widget name="slartistandtitle" position=  "20,464" size="1073,28" font="SansReg;24" halign="left" valign="bottom"  foregroundColor="#ffffff"  backgroundColor="#FF000000" transparent="1" zPosition="3"/>
					<widget name="sltrack"          position="1116,464" size= "133,28" font="SansReg;24" halign="center" valign="bottom"  foregroundColor="#ffffff"  backgroundColor="#FF000000" transparent="1" zPosition="3"/>
				<!-- 2 zeile  -->
					<widget name="slalbumyearalbartist" position=  "40,504" size="876,22" font="SansReg;18" halign="left" valign="bottom"  foregroundColor="#ffffff"  backgroundColor="#FF000000" transparent="1" zPosition="3"/>
					<widget name="slgenre"              position= "916,504" size="200,22" font="SansReg;18" halign="center" valign="bottom"  foregroundColor="#ffffff"  backgroundColor="#FF000000" transparent="1" zPosition="3"/>
					<widget name="sllength"             position="1116,504" size="133,22" font="SansReg;18" halign="center" valign="bottom"  foregroundColor="#ffffff"  backgroundColor="#FF000000" transparent="1" zPosition="3"/>
				<!-- 3 zeile  -->
					<widget name="slfilename" position=  "60,526" size="743,18" font="SansReg;15" halign="left" valign="center"  foregroundColor="#ffffff"  backgroundColor="#FF000000" transparent="1" zPosition="3"/>
					<widget name="slrating"   position= "783,524" size="200,21" alphatest="on" zPosition="4"  pixmaps="~/rating0.png,~/rating1.png,~/rating2.png,~/rating3.png,~/rating4.png,~/rating5.png,~/rating6.png,~/rating7.png,~/rating8.png,~/rating9.png,~/rating10.png,~/rating11.png"/>
					<widget name="slplays"    position= "983,526" size="133,18" font="SansReg;15" halign="center" valign="center"  foregroundColor="#ffffff"  backgroundColor="#FF000000" transparent="1" zPosition="3"/>
					<widget name="slbitrate"  position="1116,524" size="133,18" font="SansReg;15" halign="center" valign="center"  foregroundColor="#ffffff"  backgroundColor="#FF000000" transparent="1" zPosition="3"/>
			<!-- spectrumanalyser  -->
				<widget name="progress_0" zPosition="7"  position= "376,616" size="48,96" backgroundColor="#00000000" orientation="orBottomToTop" pixmap="~/bar_white_40x145.png" />
				<widget name="progress_1" zPosition="7"  position= "430,616" size="48,96" backgroundColor="#00000000" orientation="orBottomToTop" pixmap="~/bar_white_40x145.png" />
				<widget name="progress_2" zPosition="7"  position= "486,616" size="48,96" backgroundColor="#00000000" orientation="orBottomToTop" pixmap="~/bar_white_40x145.png" />
				<widget name="progress_3" zPosition="7"  position= "540,616" size="48,96" backgroundColor="#00000000" orientation="orBottomToTop" pixmap="~/bar_white_40x145.png" />
				<widget name="progress_4" zPosition="7"  position= "594,616" size="48,96" backgroundColor="#00000000" orientation="orBottomToTop" pixmap="~/bar_white_40x145.png" />
				<widget name="progress_5" zPosition="7"  position= "649,616" size="48,96" backgroundColor="#00000000" orientation="orBottomToTop" pixmap="~/bar_white_40x145.png" />
				<widget name="progress_6" zPosition="7"  position= "704,616" size="48,96" backgroundColor="#00000000" orientation="orBottomToTop" pixmap="~/bar_white_40x145.png" />
				<widget name="progress_7" zPosition="7"  position= "758,616" size="48,96" backgroundColor="#00000000" orientation="orBottomToTop" pixmap="~/bar_white_40x145.png" />
				<widget name="progress_8" zPosition="7"  position= "813,616" size="48,96" backgroundColor="#00000000" orientation="orBottomToTop" pixmap="~/bar_white_40x145.png" />
				<widget name="progress_9" zPosition="7"  position= "868,616" size="48,96" backgroundColor="#00000000" orientation="orBottomToTop" pixmap="~/bar_white_40x145.png" />
				<widget name="progress_10" zPosition="7" position= "922,616" size="48,96" backgroundColor="#00000000" orientation="orBottomToTop" pixmap="~/bar_white_40x145.png" />
				<widget name="progress_11" zPosition="7" position= "977,616" size="48,96" backgroundColor="#00000000" orientation="orBottomToTop" pixmap="~/bar_white_40x145.png" />
				<widget name="progress_12" zPosition="7" position="1032,616" size="48,96" backgroundColor="#00000000" orientation="orBottomToTop" pixmap="~/bar_white_40x145.png" />
				<widget name="progress_13" zPosition="7" position="1086,616" size="48,96" backgroundColor="#00000000" orientation="orBottomToTop" pixmap="~/bar_white_40x145.png" />
				<widget name="progress_14" zPosition="7" position="1141,616" size="48,96" backgroundColor="#00000000" orientation="orBottomToTop" pixmap="~/bar_white_40x145.png" />
				<widget name="progress_15" zPosition="7" position="1196,616" size="48,96" backgroundColor="#00000000" orientation="orBottomToTop" pixmap="~/bar_white_40x145.png" />
				<widget name="top_0"  position= "376,616" zPosition="9" size="48,1" pixmap="~/top_orange_50x1.png" />
				<widget name="top_1"  position= "430,616" zPosition="9" size="48,1" pixmap="~/top_orange_50x1.png" />
				<widget name="top_2"  position= "486,616" zPosition="9" size="48,1" pixmap="~/top_orange_50x1.png" />
				<widget name="top_3"  position= "540,616" zPosition="9" size="48,1" pixmap="~/top_orange_50x1.png" />
				<widget name="top_4"  position= "594,616" zPosition="9" size="48,1" pixmap="~/top_orange_50x1.png" />
				<widget name="top_5"  position= "649,616" zPosition="9" size="48,1" pixmap="~/top_orange_50x1.png" />
				<widget name="top_6"  position= "704,616" zPosition="9" size="48,1" pixmap="~/top_orange_50x1.png" />
				<widget name="top_7"  position= "758,616" zPosition="9" size="48,1" pixmap="~/top_orange_50x1.png" />
				<widget name="top_8"  position= "813,616" zPosition="9" size="48,1" pixmap="~/top_orange_50x1.png" />
				<widget name="top_9"  position= "868,616" zPosition="9" size="48,1" pixmap="~/top_orange_50x1.png" />
				<widget name="top_10" position= "922,616" zPosition="9" size="48,1" pixmap="~/top_orange_50x1.png" />
				<widget name="top_11" position= "977,616" zPosition="9" size="48,1" pixmap="~/top_orange_50x1.png" />
				<widget name="top_12" position="1032,616" zPosition="9" size="48,1" pixmap="~/top_orange_50x1.png" />
				<widget name="top_13" position="1086,616" zPosition="9" size="48,1" pixmap="~/top_orange_50x1.png" />
				<widget name="top_14" position="1141,616" zPosition="9" size="48,1" pixmap="~/top_orange_50x1.png" />
				<widget name="top_15" position="1196,616" zPosition="9" size="48,1" pixmap="~/top_orange_50x1.png" />
			</screen>"""

	def __init__(self, session, songList=[], index=0, playermode=FILEMODE, radiode_api=None, currentService=None, serviceList=None, jukeboxinstance=None, radiodeinstance=None, radiobrowserinstance=None):

		logger.info('Player]__init__ ]RESOLUTIONx->%s' %RESOLUTIONx)
		self.playermode=playermode
		self.radiode_api=radiode_api
		self.jukeboxinstance=jukeboxinstance
		self.radiodeinstance=radiodeinstance
		self.radiobrowserinstance=radiobrowserinstance
		self.msgBox=None

		self.skin_path='/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images'
		self.session=session
		self.currentService=currentService
		self.serviceList=serviceList
		Screen.__init__(self, session)
		InfoBarNotifications.__init__(self)
		InfoBarBase.__init__(self)
		SoundVisualization.__init__(self, BANDS=16)

		self.songList=songList
		self['actions']=ActionMap(["ColorActions", "WizardActions", "EPGSelectActions", "MediaPlayerActions", "InfobarAudioSelectionActions", "InfobarActions"],
		{
			"input_date_time": self.menuPressed,
			"back": self.closePlayer,
			"pause": self.pauseEntry,
			"stop": self.stopPlay,
			"right": self.rightPressed,
			"left": self.leftPressed,
			"up": self.showSongListUp,
			"down" : self.showSongListDown,
			"prevBouquet": self.shuffleList,
			"nextBouquet": self.repeatSong,
			"info" : self.infoPressed,
			"red": self.redPressed,
			"green": self.greenPressed,
			"yellow": self.yellowPressed,
			"blue": self.bluePressed,
			"ok": self.okPressed,
			"audioSelection": self.audioPressed,
			"showMovies": self.pvrPressed,
			"previous": self.ratingDown,
			"next": self.ratingUp,
		}, -1)
		self.onClose.append(self.__onClose)
		self['covertext']=Label()
		self['playstate']=Label("0:00:00")
		self['repeat']=MultiPixmap()
		self['shuffle']=MultiPixmap()
		self['coverArtBg']=MultiPixmap()
		self['rating']=MultiPixmap()

		self['artistandtitle']=BlinkingLabel()
		self['albumyearalbartist']=BlinkingLabel()
		self['genre']=BlinkingLabel()
		self['filename']=BlinkingLabel()
		self['filenamewithminicov']=BlinkingLabel()
		self['plays']=BlinkingLabel()
		self['track']=BlinkingLabel()
		self['bitrate']=BlinkingLabel()
		self['length']=BlinkingLabel()
		self['artistandtitlewithminicov']=BlinkingLabel()
		self['albumyearalbartistwithminicov']=BlinkingLabel()
		self['console']=Label()
		self['console'].hide()
		
		self.__event_tracker=ServiceEventTracker(screen=self, eventmap=
			{
				iPlayableService.evUser+10: self.__evAudioDecodeError,
				iPlayableService.evUser+12: self.__evPluginError,
				iPlayableService.evStart: self.__serviceStarted,
			}) #				iPlayableService.evUser+13: self.embeddedCover,

		InfoBarSeek.__init__(self, actionmap="MediaPlayerSeekActions")
		self.APIKEY='9868c4ccb94342d2671b8f960b1516e2'
		self.hlp={}
		self.play_next=True
		self.songListOrig=[]
		self.hlp['currIndex']=index
		self.currentPlayingSongfFilename=""
		self.artistforart=''
		self.currartistdirforart=''
		self.coverLoader=CoverLoader()
		self.mcdownloaddir=os_path.join(config.plugins.musiccenter.downloadcache.value, "covers/" )
		if not pathExists(self.mcdownloaddir):
			if not createDir(self.mcdownloaddir):
				logger.error('Player]__init__]error create mcdownloaddir:{} use temporary:/tmp/mc/'.format(self.mcdownloaddir))
				self.mcdownloaddir="/tmp/mc/"
		self.artistpicsroot=os_path.join(config.plugins.musiccenter.downloadcache.value, "artistpics/" )
		if not pathExists(self.artistpicsroot):
			if not createDir(self.artistpicsroot):
				logger.error('Player]__init__]error create artistpicsroot:{} use temporary:/tmp/mc/'.format(self.artistpicsroot))
				self.artistpicsroot="/tmp/mc/"
		if not pathExists(os_path.join(self.artistpicsroot, 'Default/')):
			createDir(os_path.join(self.artistpicsroot, 'Default/'))
		self.init=True
		self.onShown.append(self.onShownAppend)
		self.onLayoutFinish.append(self.__startRun)

		self.skinelements=("artistandtitle","albumyearalbartist","filename","artistandtitlewithminicov","albumyearalbartistwithminicov","genre","filenamewithminicov","plays","track",'bitrate',"length", 'coverArt', 'stationicon', 'artistArt', 'coverArtmini', 'wave')
		# playstate
		self.isgstreamer=True
		self.playtime_station=0
		self.playtime_song=0
		# wave
		self.playstate=[-1, 0]
		self['PositionGauge']=myServicePositionGauge(self.session.nav)
		self['wave']=Pixmap()
		self.calcWaveValusThreadInstance=CalcWaveValusThread()
		self.TVScreen=None
		# Timer
		self.covertextTimer=None
		self.covertextTimer_mc_conn=None
		self.screenSaverTimer=eTimer()
		self.screenSaverTimer_mc_conn=self.screenSaverTimer.timeout.connect(self.startScreenSaver)
		self.songChangeTimer=eTimer()
		self.songChangeTimer_mc_conn=self.songChangeTimer.timeout.connect(self.changeSongOnTimeout)
		if playermode in (FILEMODE,DBMODE):
			# wave
			self.wg_conn=self.calcWaveValusThreadInstance.MessagePump.recv_msg.connect(self.eWaveformGeneratorCallBack)
			# mp3gain
			self.mp3gaincontainer=eConsoleAppContainer()
			self.mp3gaincontainer_dataAvail = self.mp3gaincontainer.dataAvail.connect(self.mp3gaindataAvail)
			self.mp3gaincontainer_stderrAvail = self.mp3gaincontainer.stderrAvail.connect(self.mp3gainstderrAvail)
		elif playermode in (RADIODE, RADIOBROWSER):
			self.visuCleanerTimer=None # eTimer()
			self.visuCleanerTimer_conn=None # self.visuCleanerTimer.timeout.connect(self.visuCleanerTimerCallback)
			self.radioPollTimer=eTimer()
			self.radioPollTimer_mc_conn=self.radioPollTimer.timeout.connect(self.updatePlaystate)
			self.eventUpdateTimer=None # eTimer()
			self.eventUpdateTimer_mc_conn=None # self.eventUpdateTimer.timeout.connect(self.eventUpdateTimerCallback)
			self.streamPlayer=eMusicPlayer(self.BANDS)
			self.streamPlayer_mc_conn =self.streamPlayer.callback.connect(self.streamPlayerCallBack)
			
		self.currentService=currentService
		self.serviceList=serviceList

		# coverart
		self.paraforcoveradd=None
		self.currentCoverFilename=''
		self.externalurlliste=[]

		# songlist
		if self.playermode in (RADIODE, RADIOBROWSER):
			self['embededSonglistSimplelist']=RadioBrowserList([])
			self['embededSonglistSimplelist'].hide()
		else:
			self['embededSonglistSimplelist']=CentralList([])
			self['embededSonglistSimplelist'].hide()
		self['embededSonglist2DFlow']=CoverCollection()
		self['embededSonglist2DFlow'].hide()
		self['embededSonglistCoverwall']=CoverCollection()
		self['embededSonglistCoverwall'].hide()

		self.currembededlist=None
		self.embededsonglistisshown=False
		self['key_red']=StaticText("")
		self['key_green']=StaticText("")
		self['key_yellow']=StaticText("")
		self['key_blue']=StaticText("")
		self['slartistandtitle']=Label()
		self['slalbumyearalbartist']=Label()
		self['slgenre']=Label()
		self['slplays']=Label()
		self['sltrack']=Label()
		self['slbitrate']=Label()
		self['slfilename']=Label()
		self['sllength']=Label()
		self['slpage']=Label()
		self['slpage'].hide()
		self['slrating']=MultiPixmap()
		self['slbackground']=Pixmap()
		self.streamripper_conn=streamripperinstance.MessagePump.recv_msg.connect(self.streamripperDataAvail)

		self['coverArt']=PicLoaderScale(transparent=False, cached=False, name='Player coverArt')
		self['coverArtmini']=PicLoaderScale(transparent=False, cached=False, name='Player coverArtmini')
		self['artistArt']=PicLoaderScale(transparent=False, cached=False, name='Player artistArt')
		self['stationicon']=PicLoaderScale(transparent=False, cached=False, name='Player stationicon')
		self.nocoverfn=drawImageJobWithLongMultilineText(text='NO-COVER', size=(400,400), fontsize=100, round=0, out='no_cover.png', force=True)
	def visualizationConfigOnChange(self, configentry=None): #"With Peakhold","No Peakhold","Off"
		logger.info('Player]visualizationConfigOnChange]set spectrumanalyser {}'.format(config.plugins.musiccenter.visualization.value))
		if config.plugins.musiccenter.visualization.value in ("With Peakhold","No Peakhold"):
			self.streamPlayer.setBands(self.BANDS)
		elif config.plugins.musiccenter.visualization.value in ("Off",):
			self.hideControls()

	def setPosState(self, data=(0,0)):
		length, state=data[0], data[1]
		if self.shown:
			if length!=0:
				wavepos=self.hlp.get('wavelen')*state/length
			else:
				wavepos=0
			# state
			state=str(datetime_timedelta(seconds=state/90000))
			if self.playstate[0]!=state:
				self['playstate'].setText(state)
				self.playstate[0]=state
			# pos
			if self.playstate[1]!=wavepos:
				pos_x_base, pos_y_base =self.hlp.get('statepos')
				posx=pos_x_base+wavepos
				self['playstate'].move(posx, pos_y_base)
				self.playstate[1]=wavepos

	def ratingUp(self):
		if self.playermode in (FILEMODE, DBMODE):
			ratingnum=calcRating(self.getCurrSonglistEntry().rating)
			if ratingnum==11:
				ratingnum=-1
			if ratingnum<10:
				ratingnum+=1
			self.updateRating(ratingnum)

	def ratingDown(self):
		if self.playermode in (FILEMODE, DBMODE):
			ratingnum=calcRating(self.getCurrSonglistEntry().rating)
			if ratingnum==11:
				ratingnum=-1
			if ratingnum>-1:
				ratingnum-=1
			self.updateRating(ratingnum)

	def updateRating(self, ratingnum):
		self.songList[self.hlp['currIndex']][0].rating=calcRating(ratingnum, tobyte=True)
		r=self.setRatingStars(ratingnum)
		self.hlp['rating_changed']=True

	def stopCovertextTimer(self, restart=False):
		logger.debug('Player]stopCovertextTimer]restart:{}'.format(restart))
		self['covertext'].setText("")
		self['coverArtBg'].setPixmapNum(0)
		if self.covertextTimer is not None and self.covertextTimer.isActive():
			self.covertextTimer.stop()
		if restart:
			if self.covertextTimer_mc_conn is None:
				self.covertextTimer=eTimer()
				self.covertextTimer_mc_conn=self.covertextTimer.timeout.connect(self.stopCovertextTimer)
			self.covertextTimer.start(30000, 1)

	def resetScreenSaverTimer(self,restart=True):
		logger.debug('Player]resetScreenSaverTimer]restart value is:{}'.format(restart))
		if self.screenSaverTimer.isActive():
			self.screenSaverTimer.stop()
		if restart:
			logger.debug('Player]resetScreenSaverTimer]start timer for {} minutes'.format(config.plugins.musiccenter.screensaverstarttime.value))
			if config.plugins.musiccenter.screensaverstarttime.value>0:
				self.screenSaverTimer.start(60000*config.plugins.musiccenter.screensaverstarttime.value, 1)

	def startScreenSaver(self):
		logger.error('Player]startScreenSaver]')
		if self.TVScreen:
			logger.error('Player]startScreenSaver]TVScreen is allready running, abort')
		else:
			self.showTV(isScreenSaverMode=True)	
	
	def __startRun(self):
		logger.debug('Player]__startRun]init:{}'.format(self.init))
		self['stationicon'].dohide()
		self._setDurationandAnimation()
		self['rating'].setPixmapNum(11)
		self['slrating'].setPixmapNum(11)
		self.showFullSkinparts([])
		self['embededSonglistSimplelist'].connectSelChanged(self.songlistSimpleSelChanged)
		self['embededSonglist2DFlow'].connectSelChanged(self.songlist2DSelChanged)
		self['embededSonglistCoverwall'].connectSelChanged(self.songlist2DSelChanged)
		if streamripperinstance.isRunning:
			self['console'].show()

		# backup skinvalues
		if self.playermode in (FILEMODE, DBMODE):
			logger.debug('Player]__startRun]File or Database: prepare wavepos values')
			x,y=self['PositionGauge'].getPosition()
			self.hlp['PositionGauge_pos_x']=x
			self.hlp['PositionGauge_pos_y']=y
			PG2_size=self['PositionGauge'].getSize()
			self.hlp['PositionGauge_size_x']=PG2_size.width()
			self.hlp['PositionGauge_size_y']=PG2_size.height()
			self['PositionGauge'].hide()
			#wavepos...
			self.hlp['wavelen']=self['wave'].getSize().width()
			self.hlp['waveheigth']=self['wave'].getSize().height()
			self.hlp['statepos']=self['playstate'].getPosition()
			self['PositionGauge'].connectPollAppend(self.setPosState)
			self.hideProgressbars()

		elif self.playermode in (RADIODE, RADIOBROWSER):
			config.plugins.musiccenter.visualization.addNotifier(self.visualizationConfigOnChange, initial_call = True)
			x,y=self['playstate'].getPosition()
			x_offset,y_offset=self['playstate'].getSize()
			logger.debug('Player]__startRun]Radiomode: move playstate->%s x->%d y->%d' %(str(x_offset), x,y))
			self['playstate'].move(10, y)
			self['playstate'].resize(x_offset+140,y_offset)
			self['PositionGauge'].hide()
			self.setPBtoNull()
			self.setProperties()
			if self.visuCleanerTimer_conn is None:
				self.visuCleanerTimer=eTimer()
				self.visuCleanerTimer_conn=self.visuCleanerTimer.timeout.connect(self.visuCleanerTimerCallback)
			self.visuCleanerTimer.start(1000)

		self.hideControls()
		self['wave'].hide()

	def _setDurationandAnimation(self):
		logger.debug('Player]_setDurationandAnimation]start animation')
		try:
			sf="quick_fade" #'quick_fade'
			for element in self.skinelements:
				self[element].instance.setShowHideAnimation(sf)
			sf="quick_fade" #'slide_zoom_left_to_right'
			for element in ('PositionGauge',): 
				self[element].instance.setShowHideAnimation(sf)
		except:
			logger.exception('Player]_setDurationandAnimation]Hmm, klappt  nicht...')
		self['coverArtmini'].hide()
		ptr=LoadPixmap('/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/1880x132x8bit.png')
		self['slbackground'].instance.setPixmap(ptr)
		self['slbackground'].hide()

	def onShownAppend(self):
		logger.debug('Player]onShownAppend]init:{}'.format(self.init))
		self.resetScreenSaverTimer(restart=True)
		if self.init:
			self.init=False
			self.session.nav.stopService()
			self.playSong(self.hlp.get('currIndex'))
		else:
			# LCD
			entry=self.songList[self.hlp.get('currIndex')][0]
			if self.playermode in (RADIOBROWSER, RADIODE):
				albumyearalbartist, bitrateandcodec, plays, radiotype=self.joinDisplaytextStream(entry.stationname, entry.location, entry.bitrate, entry.codec, entry.playcount, entry.rating, entry.filetype)
				self.summaries.setText('{} - {}'.format(entry.artist, entry.title),1)
				self.summaries.setText(albumyearalbartist, 2)
				self.summaries.setText('{}|{}'.format(entry.genre, bitrateandcodec), 3)
				self.summaries.setText(plays, 4)		
			elif self.playermode in (FILEMODE, DBMODE):
				logger.debug('Player]onShownAppend]entry.filename:{}'.format(entry.filename))
				artistandtitle, albumyearalbartist, filename, track, playcount=self.joinDisplaytextFiles(entry.artist, entry.title, entry.album, entry.date, entry.albumartist, entry.track, entry.playcount, entry.filename)
				self.summaries.setText(entry.artist, 1)
				self.summaries.setText(entry.title, 2)
				self.summaries.setText(albumyearalbartist, 3)
				self.summaries.setText('{} | {}'.format(entry.genre, entry.bitrate), 4)			
			if self.TVScreen:
				self.session.deleteDialog(self.TVScreen)
				self.TVScreen=None

	def __onShowna(self):
		logger.debug('Player]__onShowna]')
		if self.TVScreen:
			logger.debug('Player]__onShowna]TVScreen.doClose')
			self.session.deleteDialog(self.TVScreen)
			self.TVScreen=None

	def pvrPressed(self):
		self.resetScreenSaverTimer(restart=False)
		options=[]
		options.append((_("Browse current Artistpic directory"), self.brosweArtistPics),)
		options.append((_("New search for current Artist on artistdb`s"), self.regetExternalArtistPics),)
		options.append((_("Search for current Artist on google"), self.openArtistGoogleSearch),)
		options.append((_("New search for Default Artistpics"), self.regetDefaultArtistPics),)
		self.session.openWithCallback(self.pvrCallback, ChoiceBox, title=_("Artistpicoptions"), list=options, keys=MYKEYSORT, titlebartext=_("MusicCenter"))

	def pvrCallback(self, ret):
		ret and ret[1]()

	def openArtistGoogleSearch(self):
		if JCcheckModuleIsUpdated('GoogleImageSearch'):
			reload(GoogleImageSearch)
		logger.debug('Player]openArtistGoogleSearch]currentPlayingSongfFilename:{} currartistdirforart:{} artistforart:{}'.format(self.currentPlayingSongfFilename, self.currartistdirforart, self.artistforart))
		self.session.openWithCallback(self.closedArtistGoogleSearch, GoogleImageSearch.GoogleImageSearchScreen, self.currentPlayingSongfFilename, self.currartistdirforart, self.artistforart,  sizeX=1280, sizeY=720, face=True)

	def closedArtistGoogleSearch(self, result):# currentPlayingSongfFilename, picname, error
		currentPlayingSongfFilename, picname, error=result
		if picname is not None and currentPlayingSongfFilename==self.currentPlayingSongfFilename:
			logger.debug('Player]closedArtistGoogleSearch]show new artistpic:{}'.format(picname))
			i=self.hlp.get('currIndex',0)
			self.songList[i][0].artistpic=picname
			self.artistShow(picpath=picname, startwave=False)
		else:
			logger.debug('Player]closedArtistGoogleSearch]no artistpic given,or sonfile changed')
		self.resetScreenSaverTimer(restart=True)

	def audioPressed(self):
		self.resetScreenSaverTimer(restart=False)
		options=[]
		if not self.embededsonglistisshown:
			if self.playermode in (FILEMODE, DBMODE):
				options.append((_("Edit ID3 from current playing song"), self.startEditId3),)
				options.append((_("Update showing Cover from current songfile"), self.updateShowedCoverFromCurrentFile),)
				options.append((_("Add showing Cover to all songs in current songlist"), self.startEmbedShowingCoverToAllFilesInSonglist),)
				options.append((_("Update wave from playing songfile"), self.startUpdateWave),)
				options.append((_("Adjust loudness from playing song with mp3gain"), self.adjustLoudness),)
				#options.append((_("Adjust loudness from all songs in the playlist"), self.adjustLoudnessFromPlaylist),)
			else:
				options.append((_("Update stationicon from current station"), self.updateStationicon),)
		self.session.openWithCallback(self.audioCallback, ChoiceBox, title=_(" Audiofileoptions"), list=options, keys=MYKEYSORT, titlebartext=_("MusicCenter"))

	def audioCallback(self, ret):
		ret and ret[1]()

	def startUpdateWave(self):
		logger.debug('Player]startUpdateWave]clear old wave, restart wavebuild')
		self.songList[self.hlp['currIndex']][0].wave=0
		self.checkWave() 
		self.resetScreenSaverTimer(restart=True)

	def adjustLoudness(self):
		fn=self.currentPlayingSongfFilename
		comand=pipes_quote('mp3gain -d 4 -r -k -p -q {}'.format(fn))
		logger.debug('Player]adjustLoudness]comand:{}'.format(comand))
		self.mp3gaincontainer.execute(comand)
		#  mp3gain  -d 4 -r -k -p -q *.mp3
		self.resetScreenSaverTimer(restart=True)
		
	def adjustLoudnessFromPlaylist(self):
		filelist=[]
		for entry in self.songList:
			filelist.append(entry[0].filename)
		comand=pipes_quote('mp3gain  -d 4 -r -k -p -q '+' '.join(filelist))
		logger.debug('Player]adjustLoudnessFromPlaylist]comand:{}'.format(comand))
		#self.mp3gaincontainer.execute(comand)
		self.resetScreenSaverTimer(restart=True)

	def mp3gaindataAvail(self, data):
		if data and data!='                                                 ':
			logger.debug('Player]mp3gaindataAvail]data:{}'.format(data))
			self.session.toastManager.showToast(_('dataAvail: '+data), 1)
		
	def mp3gainstderrAvail(self, error):
		if error:
			logger.error('Player]mp3gainstderrAvail]error:{}'.format(error))

	def brosweArtistPics(self):
		if pathExists(self.currartistdirforart) and os_listdir(self.currartistdirforart):
			artistdir=self.currartistdirforart
		else:
			artistdir=os_path.join(self.artistpicsroot,'Default/')
		if JCcheckModuleIsUpdated('SimplePicbrowser'):
			reload(SimplePicbrowser)
		self.session.openWithCallback(self.brosweArtistPicsCB, SimplePicbrowser.Picbrowser, artistdir)

	def brosweArtistPicsCB(self):
		self.resetScreenSaverTimer(restart=True)

	def regetDefaultArtistPics(self):
		self.resetScreenSaverTimer(restart=True)
		logger.debug('Player]regetDefaultArtistPics]...')
		self.getDefaultPics(True)

	def regetExternalArtistPics(self):
		self.resetScreenSaverTimer(restart=True)
		logger.debug('Player]regetExternalArtistPics')
		self.getTheAudiodb(self.currartistdirforart, self.artistforart)

	def updateShowedCoverFromCurrentFile(self):
		logger.debug('Player]updateShowedCoverFromCurrentFile]start')
		self['covertext'].setText("Try now update cover!")
		self['coverArtBg'].setPixmapNum(1)
		current=self.getCurrSonglistEntry()
		nameforcoverfile, fake=buildCoverfilename(current.artist,current.title,current.album,current.albumartist, cleannames=False)
		logger.debug('Player]updateShowedCoverFromCurrentFile]nameforcoverfile->%s' %nameforcoverfile)
		if nameforcoverfile!=None:
			picfilename=buildCoverpath(self.mcdownloaddir, nameforcoverfile)
			if JCcheckModuleIsUpdated('GoogleImageSearch'):
				reload(GoogleImageSearch)
			self.session.openWithCallback(self.coverupdated, GoogleImageSearch.GoogleImageSearchScreen, current.filename, picfilename, nameforcoverfile,  sizeX=500, sizeY=500, face=False)
			
	def coverupdated(self, res):
		currentPlayingSongfFilename, coverfn, error=res
		if error is None:
			if currentPlayingSongfFilename==self.currentPlayingSongfFilename:
				logger.debug('Player]coverupdated]coverfn is %s'%coverfn)
				self.coverShow(isfilecover=True, picpath=coverfn, filename=currentPlayingSongfFilename, covertext='Google Cover')
		else:
			logger.debug('Player]coverupdated]Error:%s' %error)
			self.stopCovertextTimer(restart=True)
			self['covertext'].setText("Error update %s" %error)
			self['coverArtBg'].setPixmapNum(1)
		self.resetScreenSaverTimer(restart=True)

	def updateStationicon(self):
		logger.debug('Player]updateStationicon]start')
		slentry=self.getCurrSonglistEntry()
		logger.debug('Player]updateStationicon]stationname:{}'.format(slentry.stationname))
		picdir=os_path.join(config.plugins.musiccenter.downloadcache.value, 'favoritestationicons')
		if not pathExists(picdir):
			if not createDir(picdir):
				logger.error('Player]updateStationicon]error create picdir:{} use temporary:/tmp/mc/'.format(picdir))
				picdir="/tmp/mc/"
		stationfilename=os_path.join(picdir, cleanName(slentry.stationname))		
		if JCcheckModuleIsUpdated('GoogleImageSearch'):
			reload(GoogleImageSearch)
		station_id=slentry.songID # mapped in favorites
		self.session.openWithCallback(self.stationiconUpdated, GoogleImageSearch.GoogleImageSearchScreen, station_id, stationfilename, slentry.stationname,  sizeX=-1, sizeY=-1, face=False)

	def stationiconUpdated(self, res):
		station_id, stationicon, error=res
		if error is None:
			logger.debug('Player]stationiconUpdated]stationicon:{}, rename now'.format(stationicon))
			try:
				im=Image.open(stationicon)
				endswith=im.format.lower()
				if im.size[0]>175 or im.size[1]>175:
					logger.info('Player]stationiconUpdated]thumnail image x:{} to x:175 y:{} to y:175'.format(im.size[0], im.size[1]))
					im.thumbnail((175, 175), Image.ANTIALIAS)
				im.save(stationicon, endswith)
				del im
				newfn='{}.{}'.format(stationicon, endswith)
				os_rename(stationicon, newfn)
				stationicon=newfn
				logger.debug('Player]stationiconUpdated]stationicon renamed:{}, show now'.format(stationicon))
				self['stationicon'].doshow(stationicon)		
				self.songList[self.hlp.get('currIndex',None)][0].stationicon=stationicon
				sql='''UPDATE Stream_Favorites SET stationicon="%s" WHERE station_id="%d";''' %(stationicon, station_id)
				cursor=sqlCommand_Streaming_WithReturn(sql, dbname='musiccenter_stream_favorites.db')
			except:
				logger.exception('Player]stationiconUpdated]stationicon imagetype getter or rename failed')
		else:
			logger.error('Player]stationiconUpdated]error:{}'.format(error))
		self.resetScreenSaverTimer(restart=True)

	def autoSearchCoverForAllFilesInSonglist(self):
		if len(self.songList):
			logger.debug('Player]autoSearchCoverForAllFilesInSonglist] start embed songlist with  %s songs!' %len(self.songList))
			for item in self.songList:
				pass

	def	startEmbedShowingCoverToAllFilesInSonglist(self):
		logger.debug('Player]startEmbedShowingCoverToAllFilesInSonglist]start')
		if len(self.songList):
			logger.debug('Player]startEmbedShowingCoverToAllFilesInSonglist]is songList')
			cntmp='/tmp/coverartforcoveradd'
			if self.paraforcoveradd is not None:
				sh_copy2(self.paraforcoveradd['coverfn'], cntmp)
				self.paraforcoveradd=None
				logger.debug('Player]startEmbedShowingCoverToAllFilesInSonglist]cover from file')
			elif fileExists('/tmp/.id3coverart'):
				sh_copy2('/tmp/.id3coverart', cntmp)
				logger.debug('Player]startEmbedShowingCoverToAllFilesInSonglist]cover from tag')
			else:
				self.session.open(MessageBox, _("Error embed cover!\nNo cover found for embeding."), type=MessageBox.TYPE_ERROR, title="MusicCenter",timeout=20)
				return
			logger.debug('Player]startEmbedShowingCoverToAllFilesInSonglist]all nessesary parts found, embed songlist with  %s songs!' %len(self.songList))
			self['covertext'].setText("Embed cover on all songs...")
			self['coverArtBg'].setPixmapNum(1)
			for item in self.songList:
				job_manager.AddJob(Audio_ID3_Actions_Job(jobtype='embedcoverandID3Tags', coverfn=cntmp, item=item[0]))
		self.resetScreenSaverTimer(restart=True)

	def startEditId3(self):
		if JCcheckModuleIsUpdated('EditID3'):
			reload(EditID3)
		if self.embededsonglistisshown:
			index=self.embededSonglist.getCurrentIndex()
			entry=self.SongList[index][0]
		else:
			index=self.hlp.get('currIndex')
			entry=self.getCurrSonglistEntry()

		if not tagWriter.isLocked(entry.filename):
			self.session.openWithCallback(self.editId3Closed, EditID3.EditId3, entry, index)
		else:
			logger.debug('Player]startEditId3]audio isLocked, block edit file-->%s'%entry.filename)
			self.session.open(MessageBox, _("Song is locked"), type=MessageBox.TYPE_ERROR, title="MusicCenter",timeout=5)

	def editId3Closed(self, res):
		if res is not None: # [0] currentSonglistindex  [1] filename [2]audioID3 [3]slentry
			index, filename, audio, slentry=res
			logger.debug('Player]editId3Closed]update Songlist Index->%d for filename->%s editid3filename->%s' %(index, filename, slentry.filename))
			self.updateSongListEntry(index, artist=slentry.artist, title=slentry.title, album=slentry.album, genre=slentry.genre, albumartist=slentry.albumartist, date=slentry.date, track=slentry.track, filename=filename, playcount=slentry.playcount)
			if audio!=None:
				if self.hlp.get('currIndex')==index:					
					logger.debug('Player]editId3Closed]index is current song, set id3')
					self.hlp['id3']=audio
					self.hlp['id3_editid3_slentry']=slentry
				else:
					logger.debug('Player]editId3Closed]index is not current song, start embed job now...')
					job_manager.AddJob(Audio_ID3_Actions_Job(jobtype='saveID3Tags', item=slentry, audio=audio))
		else:
			logger.debug('Player]editId3Closed]nothing changed on EditID3 Screen')
		self.resetScreenSaverTimer(restart=True)

	def menuPressed(self):
		self.resetScreenSaverTimer(restart=True)
		options=[]
		options.append((_("Global Configuration"), self.config),)
		if self.embededsonglistisshown:
			options.append((_("Remove selected Song from songlist"), self.removeSongFromList),)
			if config.plugins.musiccenter.filedeletefunction.value and self.playermode in (FILEMODE, DBMODE):
				options.append((_("Remove selected song from songlist, Database and Disc"), self.removeSongFromListAndDisc),)
		else:
			if self.playermode in(FILEMODE, DBMODE):
				if config.plugins.musiccenter.filedeletefunction.value:
					options.append((_("Delete current played song"), self.delSelSong),)
			else:
				if self.getCurrSonglistEntry().rating==10: # is favorite station!
					options.append((_("Remove current stream from favorite list"), self.removeStreamFromFavoriteList),)
				else:
					options.append((_("Add current stream to favorite list"), self.addCurrentStreamToFavorite),)
		options.append((_("Current running jobs"), self.jobView),)
		options.append((_("Logfile"), self.startLog),)
		options.append((_("Version"), self.startChangelog),)
		self.session.openWithCallback(self.menuCallback, ChoiceBox, title=_("Mainscreen Options"), list=options, keys=MYKEYSORT, titlebartext=_("MusicCenter"))

	def menuCallback(self, ret):
		ret and ret[1]()

	def config(self):
		self.session.openWithCallback(self.setupFinished, MusicCenterSetup)

	def help(self):
		pass # self.session.open(MCHelp, PLAYERSCREEN)

	def startLog(self):
		self.session.open(LogScreen)
	
	def startChangelog(self):
		if fileExists('/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/change.log'):
			self.session.open(LogScreen, filename='/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/change.log', title='Version:{}'.format(MC_VERSION))

	def jobView(self):
		self.tasklist=[]
		for job in job_manager.getPendingJobs():
			#self.tasklist.append((job,job.name,job.getStatustext()))
			self.tasklist.append((job,job.name,job.getStatustext(),int(100*job.progress/float(job.end)) ,str(100*job.progress/float(job.end)) + "%" ))
		try:
			if JCcheckModuleIsUpdated('TaskViewScreen'):
				reload(TaskViewScreen)
			self.session.open(TaskViewScreen.MusicCenterTasksScreen, self.tasklist)
		except Exception, e:
			self.session.open(MessageBox, _("Error:%s") % str(e), type=MessageBox.TYPE_ERROR, title="MusicCenter",timeout=5 )

	def delSelSong(self):
		logger.info('Player]delselSong]...')
		i=self.hlp.get('currIndex')
		l=len(self.songList)
		self.paraforcoveradd=None
		songID=self.songList[i][0].songID
		fn=os_path.realpath(self.songList[i][0].filename)
		if l > 1:
			del self.songList[i]
			self.hlp['rating_changed']=False
			self.hlp['wave_changed']=False
			logger.debug('Player]delselSong]index:{} len songlist:{}'.format(i,l))
			if i+1<l: #delselSong]index:87 len songlist:88
				self.playSong(i)
			else:
				self.playSong(0)
		elif l==1:
			del self.songList[i]
			self.hlp['rating_changed']=False
			self.hlp['wave_changed']=False
			self.stopPlay()
		logger.debug('Player]delselSong]%s' %fn)
		deferToThread(JCdeleteSongfileonThread, fn, songID).addCallback(self.finishedJCdeleteSongfileonThread,).addErrback(self.errorJCdeleteSongfileonThread,)

	def finishedJCdeleteSongfileonThread(self, result):
		logger.debug('Player]finishedJCdeleteSongfileonThread]->%s' %result)

	def errorJCdeleteSongfileonThread(self, error):
		logger.error('Player]errorJCdeleteSongfileonThread]->%s' %error)

	def okPressed(self):
		if self.embededsonglistisshown:
			self.showhideEmbededSonglist()
			self.updateRatingPlaycounterWaveCover()
			self.hlp['currIndex']=self.currembededlist.getCurrentIndex()
			self.playNextAppend()
		else:
			options=[]
			options.append((_("Start TV Screensaver"), self.showTV),)
			options.append((_("Start Picture Screensaver"), self.startScreenSaver),)
			if self.songList[self.hlp.get('currIndex')][0].filetype in ('RADIOBROWSER',):
				options.append((_("Vote für die Station wenn Du sie magst!"), self.voteStation),)
			if streamripperinstance.isRunning:
				options.append((_("Stop record stream"), self.stopStreamRipper),)
			else:
				if self.songList[self.hlp.get('currIndex')][0].filetype in ('RADIOBROWSER', 'RADIODE'):
					options.append((_("Start record current stream"), self.startStreamRipperDialog),)
			self.session.openWithCallback(self.menuCallback, ChoiceBox, title=_("Mainscreen Options"), list=options, keys=MYKEYSORT, titlebartext=_("MusicCenter"))
		
	def voteStation(self):
		stationname=self.songList[self.hlp.get('currIndex')][0].stationname
		logger.debug('Player]voteStation]->%s'%self.songList[self.hlp.get('currIndex')][0].stationname)
		url='json/vote/%s' %self.songList[self.hlp.get('currIndex')][0].streamID
		rb_getPage(url).addCallback(self.afterVote, 'vote ok', stationname).addErrback(self.afterVote, 'vote error', stationname)
		
	def afterVote(self, result, text, stationname):
		#{"ok":"true","message":"voted for station successfully"}
		result=json_loads(result)
		message=result['message'].encode()
		logger.debug('Player]afterVote]text->%s result->%s'%(text, str(result)))
		self.session.open(MessageBox, _("{} {}".format(stationname, message)), type=MessageBox.TYPE_INFO, title="MusicCenter Player",timeout=5)
		
	def setupFinished(self, result):
		if result:
			self.mcdownloaddir=os_path.join(config.plugins.musiccenter.downloadcache.value, "covers/" )
			if not pathExists(self.mcdownloaddir):
				if not createDir(self.mcdownloaddir):
					self.mcdownloaddir="/tmp/mc/"

	def playSong(self, currentIndex):
		logger.debug('Player]playSong]start currentIndex:{}'.format(currentIndex))
		try:# end of list
			slentry=self.songList[currentIndex][0]
		except:
			logger.exception('Player]playSong]...?')
			if len(self.songList):
				currentIndex=0
				slentry=self.songList[currentIndex][0]
			else:
				self.updateMusicInformation(title="Fehler-->Leere Songliste :-(")
				return
		self.hlp['skiptime']=0
		self.hlp['currIndex']=currentIndex
		self.hlp['embededcoverisshown']=False
		self.currentPlayingSongfFilename=slentry.filename # new song
		if self.isgstreamer:
			self.session.nav.stopService()
		else:
			self.streamPlayer.play("")
		logger.debug('Player]playSong]playermode->%s filetype->%s ->filename->%s' %(self.playermode, slentry.filetype, slentry.filename))
		if self.playermode in (FILEMODE, DBMODE):
			if slentry.audio:
				logger.debug('Player]playSong]session.nav.playService')
				ref=eServiceReference(4097, 0, self.currentPlayingSongfFilename)
				self.session.nav.playService(ref)
				self.isgstreamer=True
				self.showWaveNow(slentry, currentIndex)
				self.updateEvent(slentry)
				# test seeking..
				#pos=90000*60
				#seek=self.getSeek()
				#if seek is not None:
				#	seek.seekTo(pos)
				#else:
				#	logger.debug('Player]playSong]no seek...')
			else:				
				logger.error('Player]playSong]file is not audio!!!???')
				error=slentry.album='File or Stream not found!'
				self.updateMusicInformation(artist=slentry.artist, title=slentry.title ,album=slentry.album, genre=slentry.genre, year=slentry.date, albumartist=slentry.albumartist,  bitrate=slentry.bitrate, track=slentry.track, filetype=slentry.filetype, playcount=slentry.playcount, filename=slentry.filename)

		elif self.playermode in (RADIODE, RADIOBROWSER):
			# kill old station
			self.radioPollTimer.stop()
			self.hlp['stationstate']=0
			logger.debug('Player]playSong]streamurl->%s' %slentry.streamurl)
			
			self.setPBtoNull()
			self.hideControls()
			
			if self.embededsonglistisshown:
				self['albumyearalbartistwithminicov'].setText(('Resolve Station: %s(%s)' %(slentry.stationname, slentry.location)))
			else:
				self['albumyearalbartist'].setText(('Resolve Station: %s(%s)' %(slentry.stationname, slentry.location)))
			
			if slentry.filetype=='RADIOBROWSER': # set clickcount...
				url='v2/json/url/{}'.format(slentry.streamID)
				logger.debug('Player]playSong]RADIOBROWSER click and resolve->%s' %url)
				rb_getPage(url).addCallback(self.playRadioBrowserAppend, slentry).addErrback(self.playRadioBrowserError)
							
			elif slentry.filename.lower().startswith(("http",)):
				logger.debug('Player]playSong]replay resolved url from songlist')
				self.playServiceStream(slentry.filename, slentry)
				return
				
			elif slentry.filetype=='RADIODE':
				if self.radiode_api==None:
					self.radiode_api=self.initRadioDEApi()					
				logger.debug('Player]playSong]resolve streamID:{}'.format(slentry.streamID))
				res=self.radiode_api.resolve_playlist(slentry.streamID)
				logger.debug('Player]playSong]resolve_playlist:{}'.format(res))
				if res and len(res) and res[0].get( u'stream') is not None:
					url=res[0].get(u'stream').encode()
					slentry.filename=url
					self.playServiceStream(url, slentry)
				else:
					url=''
					title='File or Stream not found!'
					self.updateMusicInformation(album=title, filename=slentry.filename)

			elif slentry.streamurl.lower().endswith((".pls",".m3u",".asx")) or ('func/dynampls.asp?' in slentry.streamurl):
				logger.debug('Player]playSong]resolve url...')
				mygetPage(slentry.streamurl, TWISTED_TIMEOUT).addCallback(self.callbackPlayList, slentry).addErrback(self.callbackStationListError)
			else:
				logger.error('Player]playSong]wrong here....')
			self.showStationicon(slentry)
			
	def showStationicon(self, slentry):
		if slentry.stationicon!=None and pathExists(slentry.stationicon):
			self['stationicon'].doshow(slentry.stationicon)
		else:
			self['stationicon'].doshow(drawImageJobWithLongMultilineText(text=slentry.stationname, size=(200,200), fontsize=30, round=20, out='/tmp/mc/stationicon.png', force=True))

	def initRadioDEApi(self):
		logger.debug('Player]initRadioDEApi]No radiode_api Instance, create Instance')
		from radiodeApi import RadioDeApi
		radiode_api=RadioDeApi()
		radiode_api.__init__('german')
		return radiode_api

	def playRadioBrowserAppend(self, result, slentry):
		#{"ok":"true","message":"retrieved station url successfully","id":"78167","name":"Antenne Bayern - Chillout","url":"http://mp3channels.webradio.antenne.de/chillout"}		
		res=json_loads(result)
		logger.debug('Player]playRadioBrowserAppend]->%s' %str(res))
		if res['ok'].encode()=='true':
			streamurl=res['url'].encode()
			self.playServiceStream(streamurl, slentry)
			self.updateClickVotesCounter(res['id'].encode())

	def updateClickVotesCounter(self, id):
		url='json/stations/byid/%s' %id
		logger.debug('Player]updateClickVotesCounter]')
		rb_getPage(url).addCallback(self.updateClickVotesCounterAppend, id).addErrback(self.playRadioBrowserError)		
		
	def updateClickVotesCounterAppend(self, result, id):
		deferToThread(self.updateClickVotesCounterDefered, result, id).addErrback(self.updateClickVotesCounterDeferedError)
	
	def updateClickVotesCounterDefered(self, result, id):
		#[{"id":"76079","name":"100 FM","url":"http://213.8.143.168/100fmAudio","homepage":"http://100fm.co.il/","favicon":"http://www.100fm.co.il/images/logo.png","tags":"","country":"Israel","state":"Tel Aviv","language":"Hebrew","votes":"6","negativevotes":"0","codec":"MP3","bitrate":"64","lastcheckok":"1","lastchecktime":"2017-01-02 20:50:06","lastcheckoktime":"2017-01-02 20:50:06","clicktimestamp":"2017-01-03 17:10:22","clickcount":"0","clicktrend":"0","lastchangetime":"2016-05-15 20:24:31"}]
		res=json_loads(result)
		logger.debug('Player]playRadioBrowserAppend]->%s' %str(res))
		res=res[0]
		sql='''UPDATE Stream_Favorites SET clicks=?, votes=? WHERE streamID=?;'''
		args=(res['clickcount'].encode(), res['votes'].encode(), id)
		cursor=sqlCommand_Streaming_WithReturn(sql, args, dbname='musiccenter_stream_favorites.db')
		logger.debug('Player]updateClickVotesCounterAppend]%s' %cursor)

	def updateClickVotesCounterDeferedError(self, error):
		logger.error('Player]updateClickVotesCounterDeferedError]error:{}'.format(error))
		
	def playRadioBrowserError(self, error):
		logger.error('Player]playRadioBrowserError]error->%s' %error)

	def addCurrentStreamToFavorite(self):
		logger.debug('Player]addCurrentStreamToFavorite]start')
		sel=self.getCurrSonglistEntry()
		if sel:
			addStreamToFavoriteList(sel)

	def removeStreamFromFavoriteList(self):
		sel=self.getCurrSonglistEntry()
		if sel is not None:
			if self.radiodeinstance is not None:
				self.radiodeinstance.removeStreamFromFavoriteList(sel)
			elif self.radiobrowserinstance is not None:
				self.radiobrowserinstance.startLoescheSelektieretenStream(sel)
			else:
				logger.error('Player]removeStreamFromFavoriteList]no valid instance...')
				return
			self.playNext()

	def addStreamToLastPlayedStationList(self, sel):
		'''
		time=self['playstate'].getText()
		h,m,s=time.rsplit('|',1)[-1].split(':')
		tnew=timedelta(hours=int(h), minutes=int(m), seconds=int(s))
		told=timedelta(hours=int(h), minutes=int(15), seconds=int(45))
		str(told+tnew)
		logger.debug('Player]addStreamToLastPlayedStationList]->%s'%time)
		'''
		if sel.filetype in ('RADIOBROWSER','RADIODE'):
			logger.debug('Player]addStreamToLastPlayedStationList]{}'.format(sel.stationname))
			connection=OpenDB_Streaming('musiccenter_stream_favorites.db')
			if connection is not None:
				with connection:
					connection.text_factory=str
					cursor=connection.cursor()
					cursor.execute('''DELETE FROM Stream_Recent WHERE stationname="%s";''' %sel.stationname)
					cursor.execute('''INSERT INTO Stream_Recent(stationname, genre, location, bitrate, codec, streamurl, stationicon, streamID, filetype) VALUES(?,?,?,?,?,?,?,?,?);''' , (sel.stationname, sel.genre, sel.location, sel.bitrate, sel.codec, sel.streamurl, sel.stationicon, sel.streamID, sel.filetype))
					cursor.execute('''DELETE FROM Stream_Recent where rowid NOT IN (Select rowid FROM Stream_Recent ORDER BY station_id DESC LIMIT 100);''')
		else:
			logger.debug('Player]addStreamToLastPlayedStationList]{}'.format(sel.filetype))
	
	def callbackPlayList(self, result, currentry):
		logger.debug('Player]callbackPlayList] result-> %s'%result[:500])
		found=False
		parts=string.split(result,"\n")
		if parts[0].lower().startswith("http://") or parts[0].lower().startswith("mms://"):
			url=parts[0]
			found=True
			self.playServiceStream(url.rstrip().strip(), currentry)
		elif parts[0].lower().find("[playlist]")!=-1:
			for lines in parts:
				if lines.find("file1=")!=-1:
					line=string.split(lines,"file1=")
					found=True
					self.playServiceStream(line[-1].rstrip().strip(), currentry)
					break
		elif parts[0].lower().find("#extm3u")!=-1:
			for lines in parts:
				if lines.startswith("http://"):
					found=True
					self.playServiceStream(lines.rstrip().strip(), currentry)
					break
		elif parts[0].lower().find("asx version")!=-1:
			stationList=[]
			try:
				root=ET_fromstring(result.lower())
			except:
				logger.exception('Player]callbackPlayList]...?')
				root=None
			if root:
				for childs in root.findall("entry"):
					for childs2 in childs.findall("ref"):
						url=childs2.get("href")
						if len(url):
							found=True
							self.playServiceStream(url.rstrip().strip(), currentry)
							break
					if found:
						break
		elif parts[0].lower().find("reference")!=-1:
			for lines in parts:
				if lines.lower().find('http://')!=-1:
					url='mms' + lines[lines.lower().find('http://')+4:]
					#url=lines[lines.lower().find('http://'):]
					found=True
					self.playServiceStream(url.rstrip().strip(), currentry)
					break
		if not found:
			logger.debug('Player]callbackPlayList]no match for -> %s' %parts[0][:500])
			self['title'].setText(_("No streaming data found..."))

	def callbackStationListError(self, error=None):
		if error is not None:
			try:
				e=str(error.getErrorMessage())
				self['title'].setText(_("%s ...") %e)
				logger.debug('Player]callbackStationListError]Error:'%e)
			except: 
				logger.exception('Player]callbackStationListError]...?')

	def playServiceStream(self, url, currentry):
		logger.debug('Player]playServiceStream]url:{} codec:{}'.format(url,currentry.codec.lower()))
		self.streamPlayer.play(url)
		self.isgstreamer=False
		self.streamPlayerCallBack(code=1, v=('n/a',), cleanup=False)
		self.currentPlayingSongfFilename=url # new song
		self.songList[self.hlp.get('currIndex')][0].filename=url

	def visuCleanerTimerCallback(self):
		logger.debug('Player]visuCleanerTimerCallback]start')
		self.visuCleanerTimer.stop()
		if self.needCleanup() == True:
			code=0
			v=(-80,) * self.BANDS
			self.streamPlayerCallBack(code, v, True)

	def streamPlayerCallBack(self, code=None, v=None, cleanup=False):
		if code == 0 and len(v): # > 0
			if config.plugins.musiccenter.visualization.value=="With Peakhold":
				self.setValues(v)
			elif config.plugins.musiccenter.visualization.value=="No Peakhold":
				self.setValuesnoTop(v)
		else:
			if self.visuCleanerTimer.isActive():
				self.visuCleanerTimer.stop()
			logger.debug('Player]streamPlayerCallBack]code-->%s streaminfo-->%s' %(str(code), str(v)))
			slentry=self.getCurrSonglistEntry()
			if code==1 and len(v[0]): # new event
				if self.eventUpdateTimer_mc_conn is not None:
					if self.eventUpdateTimer.isActive:
						self.eventUpdateTimer.stop()
						logger.debug('Player]streamPlayerCallBack]eventUpdateTimer is running, kill now!')
				#cleanup=True
				self.radioPollTimer.start(1000, 0)
				self.playtime_song=0
				artist, title='n/a', 'n/a'
				sTitle=v[0]
				logger.debug('Player]streamPlayerCallBack]New event:{}'.format(sTitle))
				if len(sTitle) and sTitle!='n/a':
					sTitle=sTitle.rsplit('|',1)[0].strip()
					artist, title='n/a', sTitle
					for sep in ('-','/',): #,'::'
						if sep in sTitle:
							try:
								artist, title=sTitle.split(sep,1)
								break
							except:
								logger.exception('Player]streamPlayerCallBack]split error Title->%s' %sTitle)
					artist, title=self.cleanStreamentry(artist, title, slentry.stationname)
					self.songList[self.hlp.get('currIndex')][0].artist=artist
					self.songList[self.hlp.get('currIndex')][0].title=title
					nameforcoverfile=self.createCoverfilename('n/a', sTitle, 'n/a', 'n/a')
					self.getLocalCover(nameforcoverfile)
				else:
					self.showNoCover(text='no event')
				self.updateMusicInformationStream(sTitle=sTitle, station=slentry.stationname, location=slentry.location, genre=slentry.genre, bitrate=slentry.bitrate, codec=slentry.codec, stationicon=slentry.stationicon, clicks=slentry.playcount, filetype=slentry.filetype, rating=slentry.rating, votes=slentry.votes)

				
			elif code==-2: #->Cannot connect to destination
				logger.debug('Player]streamPlayerCallBack]Cannot connect to destination')
				cleanup=True
				self.coverArtHide()
				self.updateMusicInformationStream(sTitle='Error %s'%str(v), station=slentry.stationname, location=slentry.location, genre=slentry.genre, bitrate=slentry.bitrate, codec=slentry.codec, stationicon=slentry.stationicon, filetype=slentry.filetype, rating=slentry.rating, votes=slentry.votes)
				
			elif code==-5 and v[0]==0: # 1,): # new station is tuned?
				logger.debug('Player]streamPlayerCallBack]new station is tuned')
				cleanup=True
				self.radioPollTimer.start(1000,0)
				self.playtime_song=0
				self.playtime_station=0
				deferToThread(self.addStreamToLastPlayedStationList, slentry).addErrback(self.errorAddStationToLastPlayedStation,)

				if self.eventUpdateTimer_mc_conn is None:
					self.eventUpdateTimer=eTimer()
					self.eventUpdateTimer_mc_conn=self.eventUpdateTimer.timeout.connect(self.eventUpdateTimerCallback)
				else:
					if self.eventUpdateTimer.isActive:
						self.eventUpdateTimer.stop()
						logger.debug('Player]streamPlayerCallBack]eventUpdateTimer is running, kill now!')
				self.eventUpdateTimer.start(2000, 1)
			else:
				cleanup=True
				logger.debug('Player]streamPlayerCallBack]Invalid Info, code:{} streaminfo:{}'.format(code, v))

			if cleanup == True:
				if self.visuCleanerTimer_conn is None:
					self.visuCleanerTimer=eTimer()
					self.visuCleanerTimer_conn=self.visuCleanerTimer.timeout.connect(self.visuCleanerTimerCallback)
				self.visuCleanerTimer.start(120)

	def eventUpdateTimerCallback(self):
		logger.debug('Player]eventUpdateTimerCallback]set no cover!')
		self.showNoCover(text='no event')
		intervall=randrange(90,300)
		logger.debug('Player]eventUpdateTimerCallback]set update intervall:{}'.format(intervall))
		if self.eventUpdateTimer_mc_conn is None:
			self.eventUpdateTimer=eTimer()
		self.eventUpdateTimer.start(1000*intervall)
		
	def errorAddStationToLastPlayedStation(self, error):
		logger.error('Player]errorAddStationToLastPlayedStation]{}'.format(error))

	def loadDefaultsArtistAndCover(self):
		self.showNoCover()
		self.getDefaultArtistPic()

	def coverArtHide(self):
		self['coverArt'].dohide()
		self['coverArtmini'].dohide()

	def updateEvent(self, slentry):
		logger.debug('Player]updateEvent]filename:{}'.format(slentry.filename))
		if slentry.audio:
			self.updateMusicInformation(slentry.artist, slentry.title, slentry.album, slentry.genre, slentry.date, slentry.albumartist, slentry.bitrate, slentry.track, slentry.filetype, slentry.playcount, length=slentry.length, filename=slentry.filename)
			self.getCover(slentry)
		else:
			logger.debug('Player]updateEvent]not Audio')
			self.updateMusicInformation(title="No music found...", filename=slentry.filename)

	def cleanStreamentry(self, artist, title, stationname):
		artist=artist.replace('www.antennemv.de | Antenne MV', '').strip()
		title=title.replace('| Antenne MV','').strip()
		return artist, title

	def __serviceStarted(self):
		logger.debug('Player]__serviceStarted]')

	def joinDisplaytextStream(self, station, location, bitrate, codec, clicks, votes, filetype):
		albumyearalbartist='{} | {}'.format(station, location)
		bitrateandcodec='{} | {}'.format(bitrate, codec)
		if filetype=='RADIOBROWSER':
			plays='Click{} | Vote{}'.format(clicks, votes)
			radiotype='www.radio-browser.info'
		elif filetype=='RADIODE':
			plays='Rang{} | Rating{}'.format(clicks, votes)
			radiotype='www.Radio.de'
		return albumyearalbartist, bitrateandcodec, plays, radiotype
	
	def updateMusicInformationStream(self, sTitle='n/a', station='n/a', location='n/a', genre='n/a', bitrate='n/a', codec='', stationicon='', clicks=0, votes=0, filetype='', rating=11):
		logger.debug('Player]updateMusicInformationStream]')
		if self.embededsonglistisshown:
			self['albumyearalbartistwithminicov'].show()
		else:
			self['albumyearalbartist'].show()
		albumyearalbartist, bitrateandcodec, plays, radiotype=self.joinDisplaytextStream(station, location, bitrate, codec, clicks, votes, filetype)
		self['artistandtitle'].setText(sTitle)
		self['albumyearalbartist'].setText('Station:'+albumyearalbartist)
		self['genre'].setText(genre)
		self['length'].setText(bitrateandcodec)
		self['plays'].setText(plays)
		self['artistandtitlewithminicov'].setText(sTitle)
		self['albumyearalbartistwithminicov'].setText('Station:'+albumyearalbartist)
		self['filename'].setText(radiotype)
		self['filenamewithminicov'].setText(radiotype)		
		self['rating'].setPixmapNum(rating)
		#lcd
		self.summaries.setText(sTitle,1)
		self.summaries.setText(albumyearalbartist, 2)
		self.summaries.setText('{}|{}'.format(genre, bitrateandcodec), 3)
		self.summaries.setText(plays, 4)
		# tv screen
		if self.TVScreen:
			self.TVScreen.updateDisplayText(sTitle, station, radiotype, '', genre, '', '', bitrate, rating)
			self.TVScreen.updateLCD(sTitle,3)
			self.TVScreen.updateLCD(station[8:],2)
			self.TVScreen.updateLCD('%s %s'%(genre, bitrate),1)

	def joinDisplaytextFiles(self, artist, title, album, year, albumartist, track, playcount, filename):
		artistandtitle='%s - %s' %(artist, title)
		if album in ('n/a',''):
			logger.debug('Player]updateMusicInformation]set directory name as album')
			if len(filename.rsplit('/',2)) > 1:
				showed_album=filename.rsplit('/',2)[1] #
			else:
				showed_album=album
		else:
			showed_album=album	
		albumyearalbartist='%s [%s] %s' %(showed_album, year, albumartist)
		filename=filename.rsplit('/',1)[-1]
		track='Tr.{}'.format(track)
		playcount='Plays {}'.format(playcount)	
		return artistandtitle, albumyearalbartist, filename, track, playcount
		
	def updateMusicInformation(self, artist="", title="", album="", genre="", year="", albumartist="", bitrate="",track="", filetype="", playcount=-1, length='0:00:00', filename='n/a'):
		logger.debug('Player]updateMusicInformation]...')
		artistandtitle, albumyearalbartist, filename, track, playcount=self.joinDisplaytextFiles(artist, title, album, year, albumartist, track, playcount, filename)
		self['artistandtitle'].setText(artistandtitle)		
		self['artistandtitlewithminicov'].setText(artistandtitle)
		self['albumyearalbartist'].setText(albumyearalbartist)
		self['albumyearalbartistwithminicov'].setText(albumyearalbartist)
		self['filename'].setText(filename)
		self['filenamewithminicov'].setText(filename)
		self['track'].setText(track)
		self['genre'].setText(genre)
		self['plays'].setText(playcount)
		self['bitrate'].setText(bitrate)
		self['length'].setText(length)
		
		ratingnum=self.setRatingStars()
		#lcd
		self.summaries.setText(artist, 1)
		self.summaries.setText(title, 2)
		self.summaries.setText(albumyearalbartist, 3)
		self.summaries.setText('{} | {}'.format(genre, bitrate), 4)
		# tv screen
		if self.TVScreen:
			logger.debug('Player]updateMusicInformation]ratingnum:{}'.format(ratingnum))
			self.TVScreen.updateDisplayText(artistandtitle, albumyearalbartist, filename, track, genre, playcount, bitrate, length, ratingnum)
			self.TVScreen.updateLCD(artist,2)
			self.TVScreen.updateLCD(title,1)
			self.TVScreen.updateLCD(albumyearalbartist,3)

	def getCover(self, slentry):
		if not slentry.cover:
			nameforcoverfile=self.createCoverfilename(slentry.artist, slentry.title, slentry.album, slentry.albumartist)
			self.getLocalCover(nameforcoverfile)
		else:
			self.coverShow(picpath=slentry.coverfn, covertext="Embeded cover")

	def setRatingStars(self, ratingnum=None):
		if ratingnum is None:
			ratingnum=calcRating(self.getCurrSonglistEntry().rating)
		self['rating'].setPixmapNum(ratingnum)
		return ratingnum

	def getUnixErrorString(self, s):# unicode error fix dirty....
		return re_sub('\xe9','e',s)

	def getLocalArtistPic(self, artistfolder):
		f=glob_glob(artistfolder + '*.jpg')
		if f:
			#fn=os_path.join(artistfolder, f[randrange(len(f))])
			self.artistShow(picpath=f[randrange(len(f))]) # artistfolder.rsplit('/',2)[1], fn)
		elif pathExists(artistfolder) or self.songList[self.hlp.get('currIndex')][0].filetype in('RADIOBROWSER','RADIODE'): # allready a search or stream
			logger.debug('Player]getLocalArtistPic] Artistdir is, but empty show default covers')
			self.getDefaultArtistPic()
		else:
			logger.debug('Player]getLocalArtistPic]no local artistpic and is not Streaming, get ExternalArtistPics')
			createDir(artistfolder, makeParents=True)
			self.getTheAudiodb(artistfolder, self.artistforart)

	def getDefaultArtistPic(self):
		artistfolder=os_path.join(self.artistpicsroot,'Default/')
		haspics=glob_glob(artistfolder + '*.jpg')
		haspics.extend(glob_glob('*.png'))
		if haspics:
			logger.debug('Player]getDefaultArtistPic]%s' %artistfolder)
			self.artistShow(picpath=haspics[randrange(len(haspics))])
		else:
			logger.debug('Player]getDefaultArtistPic]no default covers, start assistent')
			self.startGetDefaultArtistPics()

	def getTheAudiodb(self, artistdirforart, artistforart):
		self.externalurlliste=[]
		artistforart=self.getUnixErrorString(artistforart)
		apikey='137641636b2d653453323h'
		url='http://www.theaudiodb.com/api/v1/json/{}/search.php?s={}'.format(apikey, quote(artistforart))
		logger.debug('Player]getTheAudiodb]url:{}'.format(url))
		getPage(url, timeout=TWISTED_TIMEOUT).addCallback(self.gotTheAudiodb, artistdirforart, artistforart).addErrback(self.errorTheAudiodb, artistdirforart, artistforart)

	def gotTheAudiodb(self, res, artistdirforart, artistforart):
		result=json_loads(res)
		mb_id=''
		artist_id=''
		if result[u'artists']:
			#logger.debug('Player]gotTheAudiodb]result:{}'.format(result[:120]))
			result=result[u'artists'][0]
			logger.debug('Player]Theaudiodb]artistforart %s strArtist %s'  %(artistforart,self.getUnixErrorString(result['strArtist'])))
			if self.getUnixErrorString(result['strArtist'])==artistforart:
				try:
					artist_id=(result['idArtist'].encode())
				except:
					logger.exception('Player]gotTheAudiodb]idArtist...?')
				try:
					mb_id=(result['strMusicBrainzID'].encode())
				except:
					logger.exception('Player]gotTheAudiodb]strMusicBrainzID...?')
					mb_id=''
				mykey="strArtistFanart"
				if mykey in result and result[mykey]:
					self.externalurlliste.append(result[mykey].encode())
				for i in xrange(5):
					mykey="strArtistFanart"+str(i)
					if mykey in result and result[mykey]:
						self.externalurlliste.append((result[mykey]).encode())

		logger.debug('Player]gotTheaudiodb]artist_id %s mb_id %s self.externalurlliste %s'%(artist_id, mb_id, self.externalurlliste))
		self.getFanarttv(mb_id, artistdirforart, artistforart)

	def errorTheAudiodb(self, error, artistdirforart, artistforart):
		logger.debug('Player]errorTheAudiodb]error %s' %error)
		self.getArtistBackdropsFinish(artistdirforart, artistforart)

	def getFanarttv(self, mb_id, artistdirforart, artistforart):
		if mb_id:
			apikey='4e86e15f0f9bdf88537a252908679822'
			url='http://webservice.fanart.tv/v3/music/%s?api_key=%s'%(mb_id, apikey)
			logger.debug('Player]getFanarttv]mb_id present, try getFanarttv]url %s' %url)
			getPage(url, timeout=TWISTED_TIMEOUT).addCallback(self.gotFanarttv, artistdirforart, artistforart).addErrback(self.errorFanarttv, artistdirforart, artistforart)
		else:
			logger.debug('Player]getFanarttv]no mb_id, try htbackdrops...')
			self.getArtistBackdropsFinish(artistdirforart, artistforart)

	def gotFanarttv(self, res, artistdirforart, artistforart):
		domain='www.FANART.TV'
		result=json_loads(res)
		logger.debug('Player]gotFanarttv]result') # %s' %result)
		if result and result.has_key('artistbackground'):
			piclist=result['artistbackground']
			for pic in piclist[:5]:
				url=pic[u'url'].encode()
				self.externalurlliste.append(url)
				#logger.debug('Player]gotFanarttv]found picurl->%s' %url)

		logger.debug('Player]gotFanarttv]self.externalurlliste %s'%self.externalurlliste)
		self.getArtistBackdropsFinish(artistdirforart, artistforart)

	def errorFanarttv(self, error, artistdirforart, artistforart):
		logger.debug('Player]errorFanarttv]error %s' %error)
		self.getArtistBackdropsFinish(artistdirforart, artistforart)

	def getArtistBackdropsFinish(self, artistdirforart, artistforart):
		if len(self.externalurlliste) > 0 :# pics gefunden..
			if artistforart!='Default':
				self.downloadPiclist(self.externalurlliste[:config.plugins.musiccenter.artistartpicsmaxcount.value], artistdirforart)
			else:
				self.downloadPiclist(self.externalurlliste, artistdirforart)
		else:# keine Pics gefunden
			logger.debug('Player]getArtistBackdropsFinish] No external pics found, show default covers')
			self.getDefaultArtistPic()

	def downloadPiclist(self, urlliste, artistdirforart):
		pl=[]
		logger.debug('Player]downloadPiclist]: {} Pics found, try to download now'.format(len(urlliste)))
		dlcount=0
		for url in urlliste:
			if 'htbackdrops' in url:
				url=url.replace('http://htbackdrops.com/api/','http://htbackdrops.org/api/').rsplit('.jpg',1)[0] + '.jpg'
			fn=url.rsplit('/',1)[1]
			if fn=="fullsize.jpg":# htbackdrop
				fn=url.rsplit('/',2)[1] + ".jpg"
			ffn=os_path.join(artistdirforart, fn)
			pl.append(PicDownloadItem(url=url,filename=ffn, index=dlcount))
			dlcount += 1
			logger.debug('Player]downloadPiclist]dl url %s to File %s' %(url,ffn))
		ds=defer.DeferredSemaphore(tokens=2)#token= anzahl paralleler downloads)
		downloads=[ds.run(downloadFunction,item ).addErrback(self.errorPicDownload, item).addCallback(self.finishedPicDownload,item) for item in pl]
		finished=defer.DeferredList(downloads).addErrback(self.errorAllPicDownloads)

	def errorPicDownload(self, error=None, item=None):
		logger.debug('Player]errorPicDownload]error %s ' %(error))
		if item.index==0: # 
			self.getDefaultArtistPic()

	def finishedPicDownload(self, result, item):
		logger.debug('Player]finishedPicDownload]Index %s url %s to File %s result %s ' %(item.index, item.url, item.filename, result))
		if not item.error:
			artistdirforart, fakefn=os_path.split(item.filename)
			if item.index==0:
				logger.debug('Player]finishedPicDownload]first pic, show now-->%s ' %item.filename)
				self.artistShow(picpath=item.filename)
		else:
			logger.debug('Player]finishedPicDownload]item.error True,  %s ' %item.filename)

	def errorAllPicDownloads(self, error=None):
		if error is not None:
			logger.debug('Artistart]errorAllPicDownloads]error %s' %(error.getErrorMessage()))
		self.getDefaultArtistPic()

	def startGetDefaultArtistPics(self):
		self.session.openWithCallback(self.getDefaultPics, MessageBox, _("Keine Default Artist Wallpaper gefunden. Sollen Bilder von Google geladen werden?"), MessageBox.TYPE_YESNO)

	def getDefaultPics(self, answer):
		if answer:
			self.msgBox=self.session.open(MessageBox, _('Bitte lehne dich zurück, genieße die Musik, und warte bis dieser Dialog ausgeblendet wird...\n dann bin ich fertig!'), type=MessageBox.TYPE_INFO,timeout=600)
			self.msgBox.setTitle(_("MusicCenter"))
			url='https://www.google.de/search?q=wallpaper+music&tbm=isch&source=lnt&tbs=isz:ex,iszw:1920,iszh:1280,itp:photo'
			logger.debug('Player]getDefaultPics]url %s' %url)
			artistdirforart, artistforart=os_path.join(self.artistpicsroot,'Default/'), 'Default'
			mcgetPage(url, timeout=TWISTED_TIMEOUT+3).addCallback(self.gotDefaultArtistsOnGoogleResult, artistdirforart, artistforart ).addErrback(self.gotDefaultArtistsOnGoogleError, artistdirforart, artistforart)
		else:
			logger.debug('Player]getDefaultPics]abort! copy default Artistbackdrop')
			sh_copy2('/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/no_artist.jpg', os_path.join(self.artistpicsroot,'Default/'))
			
	def gotDefaultArtistsOnGoogleResult(self, result, artistdirforart, artistforart):
		logger.debug('Player]gotDefaultArtistsOnGoogleResult]result->%s' %result[:150])
		imageurls=re_findall(',"ou":"(.+?)","ow"',result)
		if imageurls:
			logger.debug('Player]gotDefaultArtistsOnGoogleResult]->%s' %imageurls[:5])
			self.downloadDefaultArtistsOnGoogle(imageurls, artistdirforart, artistforart)
		else:
			logger.debug('Player]gotDefaultArtistsOnGoogleResult]->No images found..., show no cover')
			self.msgBox.cancel()
			self.session.open(MessageBox, _("No images on Google found! :-("), type=MessageBox.TYPE_INFO, title="MusicCenter",timeout=6)

	def gotDefaultArtistsOnGoogleError(self, error, artistdirforart, artistforart):
		logger.debug("Player]gotDefaultArtistsOnGoogleError] %s " % (error))
		self.msgBox.cancel()
		self.session.open(MessageBox, _("Error Google search %s") %error, type=MessageBox.TYPE_INFO, title="MusicCenter",timeout=6)

	def downloadDefaultArtistsOnGoogle(self, imageurls, artistdirforart, artistforart):
		dllist=[]
		for imageurl in imageurls:
			filename=imageurl[8:].split('/',1)[-1].replace('/','_')
			local_filename=os_path.join(artistdirforart, filename)
			imageentry=PicDownloadItem(url=imageurl, filename=local_filename)
			if not fileExists(local_filename):
				dllist.append(imageentry)
		ds=defer.DeferredSemaphore(tokens=3)
		downloads=[ ds.run(mcdownloadPage,item.url, item.filename, timeout=20 ).addCallback(self.validateImage, item.filename).addErrback(self.validateImage, item.filename,) for item in dllist if not fileExists(item.filename) ]
		finished=defer.DeferredList(downloads).addCallback(self.finishedDownloadAllDefaultArtistsOnGoogle).addErrback(self.errorDownloadAllDefaultArtistsOnGoogle)

	def validateImage(self, result=True, filename=''):
		deferToThread(self.validateImageJob, filename).addErrback(self.errorValidateImageJob, filename)

	def validateImageJob(self, filename):
		logger.debug('Player]validateImageJob]filename:{}' .format(filename))
		try:
			im=Image.open(filename)
			logger.debug('Player]validateImageJob]done filename:{}'.format(filename))
		except:
			logger.exception('Player]validateImageJob]filename:{}'.format(filename))
			if fileExists(filename):
				os_remove(filename)

	def errorValidateImageJob(self, result, filename):
		logger.error('Player]errorValidateImageJob]filename:{} result:{}'.format(filename, result))

	def finishedDownloadAllDefaultArtistsOnGoogle(self, result):
		self.msgBox.cancel()
		logger.debug('Player]finishedDownloadAllDefaultArtistsOnGoogle]')
		artistfolder=os_path.join(self.artistpicsroot,'Default/')
		haspics=glob_glob(artistfolder + '*.jpg')
		haspics.extend(glob_glob('*.png'))
		if haspics:
			logger.debug('Player]finishedDownloadAllDefaultArtistsOnGoogle]%s' %artistfolder)
			self.artistShow(picpath=haspics[randrange(len(haspics))])
		else:
			logger.error('Player]finishedDownloadAllDefaultArtistsOnGoogle]no images downloaded?')

	def errorDownloadAllDefaultArtistsOnGoogle(self, error):
		self.msgBox.cancel()
		logger.error('Player]errorDownloadAllDefaultArtistsOnGoogle]error %s' %(error.getErrorMessage()))
		self.session.open(MessageBox, _("Error download Images %s") %error.getErrorMessage(), type=MessageBox.TYPE_INFO, title="MusicCenter",timeout=6 )

	def artistShow(self, picpath='', startwave=True):
		deferToThread(self.validateArtistPic, picpath).addCallback(self.showArtistPic, picpath, startwave).addErrback(self.errorValidateArtistPic, startwave, picpath)
		
	def validateArtistPic(self, picpath):
		im=Image.open(picpath)

	def errorValidateArtistPic(self, error, startwave, picpath):
		logger.error('Player]errorValidateArtistPic]picpath:{}error:{}'.format(picpath, error))
		if fileExists(picpath):
			os_remove(picpath)
		artistpicpath=picpath.rsplit('/')[0]
		logger.error('Player]errorValidateArtistPic]retry on artistpicpath:{}'.format(newartistpicpath))
		self.getLocalArtistPic(picpath.rsplit('/')[0])
		
	def showArtistPic(self, result, picpath, startwave):
		logger.debug('Player]showArtistPic]{}'.format(picpath))
		if not self.embededsonglistisshown:
			self['artistArt'].doshow(picpath)
		self.hlp['artistArtfn']=picpath
		if startwave:
			self.checkWave()

	def showWaveNow(self, slentry, currentIndex):
		if slentry.wave==1:
			logger.debug('Player]showWaveNow]file has wave , extract now')
			deferToThread(self.getWavwFromFile, slentry.filename).addCallback(self.gotWave, slentry.filename, currentIndex).addErrback(self.gotWaveError,) #haswave=self.getWavwFromFile(slentry.filename)
		elif isinstance(slentry.wave, list) and len(slentry.wave):
			logger.debug('Player]showWaveNow]have wavevalues, paint wave now...')
			self.gotWave(slentry.wave, slentry.filename, currentIndex)
		else:
			logger.debug('Player]showWaveNow]no wave, skip...')
			self.showWave((False, None, None))
			
	def gotWave(self, wavevalues, filename, currentIndex):
		logger.debug('Player]gotWave]...')
		if isinstance(wavevalues, list) and len(wavevalues):
			logger.debug('Player]gotWave]wave values found, paint wave now from list...')
			deferToThread(self.paintWaveformPNGNowonThread, wavevalues, self.currentPlayingSongfFilename, self.getCurrSonglistEntry().coverfn).addCallback(self.showWave,).addErrback(self.showWaveError)
		else:
			logger.debug('Player]gotWave]no wavevalues found, reset on songlist')
			self.songList[currentIndex][0].wave=0
			self.showWave((False, None, None))

	def gotWaveError(self, error):
		logger.error('Player]gotWaveError]:{}'.format(error))
		self.showWave((False, None, None))

	def getWavwFromFile(self,fn):
		logger.debug('Player]getWavwFromFile]->%s' %fn)
		id3, filetype=getID3raw(fn)
		if filetype=='MP3':
			if id3.has_key('WXXX:wave'):
				return eval(id3.get('WXXX:wave').url)
		elif filetype in ('OGG', 'FLAC'):
			if id3.has_key('WXXX:wave'):
				return eval(id3.get('WXXX:wave')[0])
		return []
	
	def checkWave(self):
		if self.playermode in (FILEMODE,DBMODE,):
			entry=self.getCurrSonglistEntry()
			if entry.wave==1:
				logger.debug('Player]checkWave]current song have wave, check next song')
				self.checkNextWave()
			else:
				current_Filename_in_generate=self.hlp.get('current_Filename_in_generate', '')
				logger.debug('Player]checkWave]current playing song have no wave current_Filename_in_generate:{}'.format(current_Filename_in_generate))
				if current_Filename_in_generate==entry.filename:
					logger.debug('Player]checkWave]skip, wave generate is running for current to showing wave :-), skip')
				else:
					logger.debug('Player]checkWave]start new run to create wave')
					self.startCalcWaveThread(entry.filename, entry.length, entry.songID, self.hlp.get('currIndex',0))

	def errorShowwave(self, error):
		if error!=None:
			logger.error('Player]errorShowwave]->%s' %error)

	def startCalcWaveThread(self, currentFilename, rawlength, song_id, index):
		logger.debug('Player]startCalcWaveThread]start WAVETHREADID')
		self.hlp['current_Filename_in_generate']=currentFilename
		self.calcWaveValusThreadInstance.Start(currentFilename, rawlength, song_id, index)

	def eWaveformGeneratorCallBack(self, msg):
		wavesongfFilename, wavevalues, song_id, index=self.calcWaveValusThreadInstance.Message.pop()
		self.hlp['current_Filename_in_generate']=''
		try:
			if wavesongfFilename==self.currentPlayingSongfFilename:# is current song
				self.songList[index][0].wave=wavevalues
				logger.debug('Player]eWaveformGeneratorCallBack]song is unchanged, show wave now and update songList')
				self.hlp['wave_changed']=True
				self.checkNextWave()
				deferToThread(self.paintWaveformPNGNowonThread, wavevalues, self.currentPlayingSongfFilename, self.songList[index][0].coverfn).addCallback(self.showWave,).addErrback(self.showWaveError)
			elif wavesongfFilename==self.songList[index][0].filename:# is next song
				logger.debug('Player]eWaveformGeneratorCallBack]update next song in songlist index:{} filename:{}'.format(index, self.songList[index][0].filename))
				self.songList[index][0].wave=wavevalues
			elif song_id in ('canceled',): # error
				logger.error('Player]eWaveformGeneratorCallBack]canceled result. abort error:{}'.format(wavesongfFilename))
				self.session.toastManager.showToast('Wavethread canceled, error:{}'.format(wavesongfFilename))
			else:
				logger.debug('Player]eWaveformGeneratorCallBack]song is changed, find now id song_id:{} wavesongfFilename:{} wave:{}'.format(song_id, wavesongfFilename, wavevalues[:10]))
				deferToThread(self.replaceSonglistentryOnThread, self.songList, song_id).addCallback(self.replaceSonglistentryOnThreadCallback, wavevalues).addErrback(self.replaceSonglistentryOnThreadErrback)
		except:
				logger.debug('Player]eWaveformGeneratorCallBack]error...')			

	def replaceSonglistentryOnThread(self, songList, song_id):
		logger.debug('Player]replaceSonglistentryOnThread]start')
		index=-1
		for i, v in enumerate(self.songList):
			if v[0].songID==song_id:
				index=i
				logger.debug('Player]replaceSonglistentryOnThread]index:{}'.format(index))
				break
		return index	
			
	def replaceSonglistentryOnThreadCallback(self, index, wavevalues):
		logger.debug('Player]replaceSonglistentryOnThreadCallback]songlist checked, add wave to songlist index:{}'.format(index))
		if index>-1:
			#logger.debug('Player]replaceSonglistentryOnThreadCallback]add wavevalues to songlist')
			self.songList[index][0].wave=wavevalues

	def replaceSonglistentryOnThreadErrback(self, error):
		logger.error('Player]replaceSonglistentryOnThreadErrback]:{}'.format(error))		
	
	def errorWaveformjob(self, error):
		self.hlp['current_Filename_in_generate']=''
		self.checkNextWave()
		if error!=None:
			logger.error('Player]errorWaveformjob]->%s' %error)

	def checkNextWave(self):
		lensl=len(self.songList)
		if lensl > self.hlp.get('currIndex',0)+1 and lensl > 0:
			index=self.hlp.get('currIndex',0)+1
		else:
			index=0
		nextentry=self.songList[index][0]
		wavevalues=self.getWavwFromFile(nextentry.filename)
		logger.debug('Player]checkNextWave]next index:{} wavevalues:{}'.format(index, wavevalues[:5]))
		if not wavevalues:
			#logger.debug('Player]checkNextWave]create waveheigth->%d' %(waveheigth))
			self.startCalcWaveThread(nextentry.filename, nextentry.length, nextentry.songID, index)
		else:
			logger.debug('Player]checkNextWave]next wave exists, abort')

	def showWave(self, result):
		logger.debug('Player]showWave]start')
		iswave, fgcolor, bgcolor=result
		if iswave:
			ptr=LoadPixmap('/tmp/mc/wave.png')
			self['wave'].instance.setPixmap(ptr)
			self['wave'].show()
			
			logger.debug('Player]showWave]fgcolor:{} bgcolor:{}'.format(fgcolor, bgcolor))
			im=Image.new('RGB',(self.hlp.get('wavelen'), self.hlp.get('waveheigth')*2),fgcolor)
			im.save('/tmp/mc/pointer.png')
			ptr=LoadPixmap('/tmp/mc/pointer.png')
			bghtml='#%02x%02x%02x' % bgcolor[:3] # no alphablend
			self['PositionGauge'].instance.setBackgroundColor(parseColor(bghtml))
			self['PositionGauge'].instance.setPointer(0, ptr,ePoint(self.hlp.get('wavelen'), self.hlp.get('waveheigth')/2)) #pointer=0, seek_pointer=1 und progress_pointer=2
			self['PositionGauge'].show()
			self['PositionGauge'].instance.show()
		else:
			self['PositionGauge'].hide()
			self['wave'].hide()
		# jukebox getNextEntries...
		if self.playermode in (DBMODE,) and not self.hlp.get('shuffle', False):
			if self.hlp.get('currIndex',0)+5 >= len(self.songList):
				if self.jukeboxinstance is not None:
					logger.debug('Player]showWave]jukeboxinstance.getNextEntries...')
					self.jukeboxinstance.getNextEntries(False)
		logger.debug('Player]showWave]done...')

	def showWaveError(self, error):
		logger.error('Player]showWaveError]:{}'.format(error))	

	def paintWaveformPNGNowonThread(self, wave_loudness_of_chunks=None, filename='', coverfn=''):
		if wave_loudness_of_chunks is None:
			wavevalues=self.getWavwFromFile(filename)
			wave_loudness_of_chunks=wavevalues
		logger.debug('Player]paintWaveformPNGNowonThread]start->%s' %wave_loudness_of_chunks[:15])
		wavefn='/tmp/mc/wave.png'
		pixel_x=1920
		pixel_y=int(float(pixel_x)/self.hlp.get('wavelen')*self.hlp.get('waveheigth'))
		max_rms=max(wave_loudness_of_chunks)
		scaled_loudness=[ int(float(loudness) / max_rms * pixel_y) for loudness in wave_loudness_of_chunks]
		logger.debug('Player]paintWaveformPNGNowonThread]paint pic pixel_x->%s pixel_y->%s' %(pixel_x, pixel_y))
		im=Image.new('RGBA',(pixel_x, pixel_y))
		
		if fileExists(coverfn):
			fgcolor, bgcolor=calcPointerColors(coverfn)
		else:
			fgcolor, bgcolor=(189,156,24),(255,255,255)
		color='black'
		try:
			for i in xrange(pixel_x):
				# filled top
				im.paste(color,(i, 0, i+1, pixel_y-scaled_loudness[i]))
				# filled bottom
				#im.paste(color,(i, pixel_y-scaled_loudness[i], i+1,pixel_y))
			im.save(wavefn)
			#logger.debug('Player]paintWaveformPNGNowonThread]end')
			return (True, fgcolor, bgcolor)
		except:
			logger.exception('Player]paintWaveformPNGNowonThread]...?')
			if fileExists(wavefn):
				os_remove(wavefn)
			logger.exception('Player]paintWaveformPNGNowonThread]end with error')
			return (False, fgcolor, bgcolor)

	def setPositionGauge_old(self, iswave, fgcolor=(189,156,24), bgcolor=(255,255,255)):
		logger.debug('Player]setPositionGauge]start')
		if iswave:
			im=Image.new('RGB',(self.hlp.get('wavelen'), self.hlp.get('waveheigth')*2),fgcolor)
			im.save('/tmp/mc/pointer.png')
			ptr=LoadPixmap('/tmp/mc/pointer.png')
			bghtml='#%02x%02x%02x' % bgcolor[:3] # no alphablend
			self['PositionGauge'].instance.setBackgroundColor(parseColor(bghtml))
			self['PositionGauge'].instance.setPointer(0, ptr,ePoint(self.hlp.get('wavelen'), self.hlp.get('waveheigth')/2)) #pointer=0, seek_pointer=1 und progress_pointer=2
			self['PositionGauge'].show()
			self['PositionGauge'].instance.show()
		else:
			self['PositionGauge'].hide()
			self['wave'].hide()
		if self.playermode in (DBMODE,) and not self.hlp.get('shuffle', False):
			if self.hlp.get('currIndex',0)+5 >= len(self.songList):
				if self.jukeboxinstance is not None:
					logger.debug('Player]setPositionGauge]jukeboxinstance.getNextEntries...')
					self.jukeboxinstance.getNextEntries(False)
		logger.debug('Player]setPositionGauge]done...')

	def embeddedCover(self):
		logger.debug('Player]embeddedCover]called...')
		self.hlp['embededcoverisshown']=True
		self.coverShow(picpath='/tmp/.id3coverart', covertext="Embeded cover")
		
	def coverShow(self, isfilecover=False, picpath=None, filename=None, covertext=''):
		self.stopCovertextTimer(restart=True)
		index=self.hlp.get('currIndex')
		if picpath is None:
			picpath=self.currentCoverFilename
		if filename is None:
			filename=self.currentPlayingSongfFilename
		
		if fileExists(picpath):
			self.hlp['currshowedcoverfn']=picpath
			logger.debug('Player]coverShow]show now with covertext:{}'.format(covertext))
			self['coverArtmini'].dosetPixmap(picpath)
			self['coverArt'].dosetPixmap(picpath)			
			if self.embededsonglistisshown:
				self['coverArtmini'].instance.show()
			else:
				self['coverArt'].instance.show()
			if self.TVScreen:
				self.TVScreen.updateCover(picpath)
			self['covertext'].setText(covertext)
			if covertext:
				self['coverArtBg'].setPixmapNum(1)
			else:
				self['coverArtBg'].setPixmapNum(0)
		
			entry=self.getCurrSonglistEntry() # Poster
			if self.playermode in (FILEMODE,DBMODE,):
				if isfilecover:
					if config.plugins.musiccenter.addcoverautotosong.value:
						self.paraforcoveradd=dict(coverfn=picpath, filename=filename, item=entry)
					if fileExists(entry.coverfn):
						logger.debug('Player]coverShow]old coverthumb found, remove')
						os_remove(entry.coverfn)
					logger.debug('Player]coverShow]create new coverthumb')
					coverfn=CoverLoader().load(filename, picpath)
					self.songList[index][0].cover=1
					self.songList[index][0].coverfn=coverfn
					logger.debug('Player]coverShow]rebuild wave, after got new cover!')
			else:
				self.paraforcoveradd=None
		self.startArtistart(self.songList[index][0].artist)
				
	def startArtistart(self, artist):
		if config.plugins.musiccenter.useartistart.value:
			bd_artist=fitArtistname(artist)
			artistdirforart=self.buildArtistArtDir(bd_artist)
			self.currartistdirforart=artistdirforart # for update Artist over key
			entry=self.getCurrSonglistEntry()
			if entry.artistpic and fileExists(entry.artistpic):
				logger.debug('Player]startArtistart]artistpic is in list show->%s' %entry.artistpic)
				if bd_artist!=self.artistforart: #artist neu
					logger.debug('Player]startArtistart]is new Artist, get...')
					self.artistforart=bd_artist
					logger.debug('Player]startArtistart]is new Artist, show pic artistdirforart is' + artistdirforart)
				self.artistShow(picpath=entry.artistpic)
			else:
				logger.debug('Player]startArtistart]no artistpic check update')
				if artist and artist!='n/a' : # artist vorhanden
					if bd_artist!=self.artistforart: #artist neu
						logger.debug('Player]startArtistart]is new Artist, get...')
						self.artistforart=bd_artist
						logger.debug('Player]startArtistart]is new Artist, getLocalPic artistdirforart is' + artistdirforart)
					self.getLocalArtistPic(artistdirforart)

				else: # kein artist vorhanden
					logger.debug('Player]startArtistart]NOT artist given, selectCurrentDefaultBackdrop now')
					self.artistforart=''
					self.getDefaultArtistPic()
		else:
			logger.debug('Player]startArtistart]not useartistart...')
			if self['artistArt'].getVisible():
				self['artistArt'].hide()
			self.checkWave()

	def buildArtistArtDir(self, bd_artist):
		return os_path.join(self.artistpicsroot, bd_artist[:1] + '/', bd_artist + '/')

	def createCoverfilename(self, artist, title, album, albumartist):
		nameforcoverfile, trysampler=buildCoverfilename(artist,title,album,albumartist, cleannames=True)
		if trysampler and self.playermode in (DBMODE, FILEMODE):
			#try:
			nextalbum, nextartist=self.getNextTitle()
			logger.debug('Player]createCoverfilename]try Sampler, start album->%s nextalbum->%s artist->%s nextartist->%s' %(album, nextalbum, artist, nextartist))
			#except:
			#	nextalbum, nextartist='',''
			album=cleanName(album)
			artist=cleanName(artist)
			nextalbum=cleanName(nextalbum)
			nextartist=cleanName(nextartist)
			if album==nextalbum and artist!=nextartist:
				logger.debug('Player]createCoverfilename]try Sampler, found')
				nameforcoverfile=(album)
			logger.debug('Player]createCoverfilename]Sampler, end album->%s nextalbum->%s artist->%s nextartist->%s' %(album, nextalbum, artist, nextartist))
		logger.debug('Player]createCoverfilename]end->%s' %nameforcoverfile)
		return nameforcoverfile

	def getLocalCover(self, nameforcoverfile):
		logger.debug('Player]getLocalCover] nameforcoverfile->%s' %nameforcoverfile)
		if not nameforcoverfile:
			logger.debug('Player]getLocalCover]no nameforcoverfile given, break.')
			self.showNoCover('No searchtterm given...')
		else:
			self.newCoverFilename=buildCoverpath(self.mcdownloaddir, nameforcoverfile)
			if self.newCoverFilename!=self.currentCoverFilename: # neuer covername
				logger.debug('Player]getLocalCover]is newCoverFilename, update cover->%s' %self.newCoverFilename)
				self.currentCoverFilename=self.newCoverFilename
				if fileExists(self.currentCoverFilename):
					logger.debug('Player]getLocalCover]coverfile found->%s' % (self.currentCoverFilename))
					self.coverShow(isfilecover=True, picpath=self.currentCoverFilename, covertext='Local cover')
				else:
					logger.debug('Player]getLocalCover]cover not found, try Google')
					self.buildImageSearchUrl(nameforcoverfile)
			else:
				logger.debug('Player]getLocalCover]coverfilename not changed')

	def buildImageSearchUrl(self, searchterm):
		#url='http://api.ababeen.com/api/images.php?q=%s&count=8' %quote(searchterm)
		url='https://www.google.de/search?q=%s+-youtube&tbm=isch&source=lnt&tbs=isz:ex,iszw:500,iszh:500' %quote(searchterm)
		logger.info('Player]buildImageSearchUrl]{}'.format(url))
		mygetPage(url, timeout=TWISTED_TIMEOUT).addCallback(self.getImageUrlsGoogleImageSiteSearch, searchterm).addErrback(self.googleDownloadError,)

	def getImageUrlsGoogleImageSiteSearch(self, result, searchterm):
		#logger.debug('Player]getImageUrlsGoogleImageSiteSearch]result->%s' %result) # [:300])
		imageurls=re_findall(',"ou":"(.+?)","ow"',result) # new on 08.02.2017 urlsraw=re_findall('imgres\?imgurl.+?&amp;imgrefurl',result)
		if imageurls:
			maxurls=8
			if len(imageurls)>maxurls:
				logger.debug('Player]getImageUrlsGoogleImageSiteSearch]urls->%d' %len(imageurls))
				self.googleDownloadImages(imageurls[:maxurls])
			else:
				logger.debug('Player]getImageUrlsGoogleImageSiteSearch]urls->%d' %len(imageurls))
				self.googleDownloadImages(imageurls)
		else:
			logger.debug('Player]getImageUrlsGoogleImageSiteSearch]->No images found., try to short searchterm')
			if '(' in searchterm:
				searchterm=searchterm.rsplit('(',1)[0]
				self.buildImageSearchUrl(searchterm)
			elif '[' in searchterm:
				searchterm=searchterm.rsplit('[',1)[0]
				self.buildImageSearchUrl(searchterm)
			elif '{' in searchterm:
				searchterm=searchterm.rsplit('{',1)[0]
				self.buildImageSearchUrl(searchterm)
			else:
				logger.debug('Player]getImageUrlsGoogleImageSiteSearch]->Nothing to shorten, show no cover')
				self.showNoCover('No images found')

	def googleDownloadImages(self, urls):
		url=urls.pop(0) #.replace('https://', 'http://')
		logger.info('Player]googleDownloadImages]%d dlurls try url->%s filename->%s' % (len(urls), url, self.currentCoverFilename))
		downloadPage(url, self.currentCoverFilename, agent='Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.56 Safari/537.17').addCallback(self.googleDownloadFinished, urls).addErrback(self.googleDownloadError, urls, url)

	def googleDownloadError(self, error, urls=[], url=''):
		logger.error("Player]googleDownloadError]url:{} error:{}".format(url, error))
		if 'sslv3 alert handshake failure' in str(error) and url.startswith('https://'):
			logger.debug("Player]googleDownloadError]-->ssl Error, replace https to http and retry")
			url=url.replace('https://','http://')
			self.googleDownloadImages(urls=[url]+urls)
		elif len(urls):
			logger.debug("Player]googleDownloadError]now %d urls try next url" %len(urls))
			self.googleDownloadImages(urls)
		else:
			logger.debug("Player]googleDownloadError]no cover downloaded, show now no cover")
			self.showNoCover(str(error))

	def showNoCover(self, text=''):
		self.coverShow(isfilecover=False, picpath=self.nocoverfn, covertext=text)

	def googleDownloadFinished(self, result, urls=[]):
		try: # check, is a valid image...
			im=Image.open(self.currentCoverFilename)
			logger.debug('Player]googleDownloadFinished]done, show cover')
			self.coverShow(isfilecover=True, picpath=self.currentCoverFilename, covertext='Google Cover')
		except:
			logger.exception('Player]googleDownloadFinished]no valid Image loaded...')
			if len(urls):
				self.googleDownloadImages(urls)
			else:
				self.showNoCover(error)

	def __evAudioDecodeError(self, isTrue):
		currPlay=self.session.nav.getCurrentService()
		sAudioType=currPlay.info().getInfoString(iServiceInformation.sUser+10)
		logger.error("Player]__evAudioDecodeError]audio-codec %s can't be decoded by hardware" % (sAudioType))
		if not isTrue:
			self.session.open(MessageBox, _("This Dreambox can't decode %s streams!") % sAudioType, type=MessageBox.TYPE_INFO, title="MusicCenter",timeout=20 )

	def __evPluginError(self):
		currPlay=self.session.nav.getCurrentService()
		message=currPlay.info().getInfoString(iServiceInformation.sUser+12)
		logger.error('Player]__evPluginError]Error: %s' %message)
		self.session.open(MessageBox, message, type=MessageBox.TYPE_ERROR, title="MusicCenter",timeout=20 )

	def doEofInternal(self, playing):
		logger.debug('Player]doEofInternal]Start, playNext:{}'.format(playing))
		if playing:
			self.playNext()

	def checkSkipShowHideLock(self): # InfoBarSeek n�tig???
		pass

	def doSeekRelative(self, pts): # InfoBarSeek n�tig???
		skiptime=pts+self.hlp.get('skiptime',0)
		self.hlp['skiptime']=skiptime
		logger.debug('Player]doSeekRelative]skiptime->%s' %skiptime)
		seekable=self.getSeek()
		if seekable is None:
			return
		prevstate=self.seekstate
		if self.seekstate==self.SEEK_STATE_EOF:
			if prevstate==self.SEEK_STATE_PAUSE:
				self.setSeekState(self.SEEK_STATE_PAUSE)
			else:
				self.setSeekState(self.SEEK_STATE_PLAY)
		seekable.seekRelative(pts<0 and -1 or 1, abs(pts))
		if abs(pts) > 100 and config.usage.show_infobar_on_skip.value:
			self.showAfterSeek()

	def pauseEntry(self):
		self.pauseService()
		if not self.hlp.get('isPause', False):
			#timestamp=self['PositionGauge'].get()
			#time=str(datetime_timedelta(milliseconds=timestamp[1]/90))[:-3]
			#logger.debug('Player]pauseEntry]time->%s timestamp->%s' %(time, str(timestamp)))
			self.setpause()
			self.hlp['isPause']=True
		else:
			for pic in ('coverArt', 'artistArt'):
				picpath=self.hlp.get(pic, None)
				if picpath!=None:
					self[pic].doshow(picpath)
					#self['artistArt'].show()
			self.hlp['isPause']=False

	def setpause(self):
		for pic in ('coverArt', 'artistArt'):
			picpath=self[pic].currentpic
			self.hlp[pic]=picpath
			if picpath!=None:
				im=Image.open(picpath).convert("RGB")
				stat=ImageStat.Stat(im)
				if sum(stat.sum)/3 == stat.sum[0]:
					im=im.point(lambda p: p > 160 and 255)
				else:
					r, g, b=im.split()
					im=Image.merge("RGB", (g,g,g))
				tmp='/tmp/mc/merge_{}.jpg'.format(pic)
				im.save(tmp)
				self[pic].doshow(tmp)
				
	def play(self): # play the current song from beginning again
		self.hlp['isPause']=False
		self.playSong(self.hlp.get('currIndex'))

	def unPauseService(self):
		self.setSeekState(self.SEEK_STATE_PLAY)

	def stopPlay(self):
		logger.debug('Player]stopPlay]start...')
		if self.playermode in (RADIODE, RADIOBROWSER):
			if self.eventUpdateTimer_mc_conn is not None:
				if self.eventUpdateTimer.isActive:
					self.eventUpdateTimer.stop()
					logger.debug('Player]stopPlay]eventUpdateTimer is running, kill now!')
		else:
			try: # empty list
				slentry=self.songList[self.hlp.get('currIndex')][0]
				self.updateRatingPlaycounterWaveCover(slentry)
			except:
				logger.exception('Player]stopPlay]error...')
		logger.debug('Player]stopPlay]clear list now...')
		if self.isgstreamer:
			self.session.nav.stopService()
		else:
			self.streamPlayer.play("")
		self.songListOrig=[]
		self.songList=[]
		self.hlp['currIndex']=-2 # to detect is stopPlay
		self.hlp['repeat']=False
		self['repeat'].setPixmapNum(0)
		self.hlp['shuffle']=False
		self['shuffle'].setPixmapNum(0)
		self.close()

	def changeSongOnTimeout(self):
		logger.info('Player]changeSongOnTimeout]self.play_next:{}'.format(self.play_next))
		if self.play_next:
			self.playNext()
		else:
			self.playLast()
	
	def rightPressed(self):
		logger.debug('Player]rightPressed]')
		self.resetScreenSaverTimer(restart=True)
		if self.embededsonglistisshown is False:
			self.play_next=True
			self.songChangeTimer.start(400,1)		
		elif self.embededsonglistisshown=='list':
			self.currembededlist.pageDown()
		elif self.embededsonglistisshown in('2dlist', 'coverwall'):
			self.currembededlist.MoveRight()		

	def playNext(self):
		logger.debug('Player]playNext]set index+1')
		self.updateRatingPlaycounterWaveCover()
		if not self.hlp.get('repeat', False):
			self.hlp['currIndex']+=1
			if self.embededsonglistisshown:
				logger.debug('Player]playNext]is embededsonglistisshown move listentry')
				if self.hlp.get('currIndex')==self.currembededlist.getCurrentIndex():
					self.showSongListDown()
				else:
					logger.debug('Player]playNext]no match index->%d and list index->%d' %(self.hlp.get('currIndex'), self.currembededlist.getCurrentIndex()))
		self.playNextAppend()

	def playNextAppend(self):
		lensonglist=len(self.songList)
		if lensonglist <= self.hlp.get('currIndex') and lensonglist > 0:
			self.hlp['currIndex']=0
		logger.debug('Player]playNextAppend]playSong indes->%d' %self.hlp.get('currIndex'))
		self.playSong(self.hlp.get('currIndex'))

	def leftPressed(self):
		logger.debug('Player]leftPressed]')
		self.resetScreenSaverTimer(restart=True)
		if self.embededsonglistisshown is False:
			self.play_next=False
			self.songChangeTimer.start(400,1)		
		elif self.embededsonglistisshown=='list':
			self.currembededlist.pageUp()
		elif self.embededsonglistisshown in('2dlist', 'coverwall'):
			self.currembededlist.MoveLeft()
		
	def playLast(self):
		logger.debug('Player]playLast]')
		self.updateRatingPlaycounterWaveCover()
		if not self.hlp.get('repeat', False):
			if self.hlp.get('currIndex') - 1 < 0:
				self.hlp['currIndex']=len(self.songList) - 1
			else:
				self.hlp['currIndex']-= 1
		self.playSong(self.hlp.get('currIndex'))

	def getNextTitle(self):
		logger.debug('Player]getNextTitle]Search for Sampler Album and Artist')
		if self.hlp.get('currIndex')+1 >= len(self.songList):
			index=0
		else:
			index=self.hlp.get('currIndex') + 1
		artist=self.songList[index][0].artist
		album=self.songList[index][0].album
		return album, artist

	def shuffleList(self):
		if self.playermode in (FILEMODE, DBMODE):
			self.hlp['shuffle']=not self.hlp.get('shuffle', False)
			if self.hlp.get('shuffle'):
				self['shuffle'].setPixmapNum(1)
				if not self.hlp.get('filtered', False):
					self.songListOrig=self.songList[:]
				shuffle(self.songList)
			else:
				self.songList=self.songListOrig[:]
				if not self.hlp.get('filtered', False):
					self.songListOrig=[]
				self['shuffle'].setPixmapNum(0)
			index=0
			for x in self.songList:
				if x[0].filename==self.currentPlayingSongfFilename:
					self.hlp['currIndex']=index
					break
				index += 1

	def repeatSong(self):
		if self.playermode in (FILEMODE, DBMODE):
			self.hlp['repeat']= not self.hlp.get('repeat', False)
			if self.hlp.get('repeat'):
				self['repeat'].setPixmapNum(1)
			else:
				self['repeat'].setPixmapNum(0)
# embededSonglist
	def showSongListUp(self):
		self.resetScreenSaverTimer(restart=True)
		if self.embededsonglistisshown=='list':
			self.currembededlist.up()
		elif self.embededsonglistisshown in('2dlist', 'coverwall'):
			self.currembededlist.MoveUp()
		else:
			self.showhideEmbededSonglist()

	def showSongListDown(self):
		self.resetScreenSaverTimer(restart=True)
		if self.embededsonglistisshown=='list':
			self.currembededlist.down()
		elif self.embededsonglistisshown in('2dlist', 'coverwall'):
			self.currembededlist.MoveDown()
		else:
			self.showhideEmbededSonglist()

	def showhideEmbededSonglist(self):
		#("list", _("list")), ("2dlist", _("2D Coverflow")), ("coverwall", _("Coverwall"))
		fullskinentrys=('artistArt', 'coverArt', 'coverArtBg', 'covertext','artistandtitle', 'albumyearalbartist', 'filename')
		if self.embededsonglistisshown:
			self.currembededlist.hide()
			if self.embededsonglistisshown in('2dlist', 'coverwall'):
				self['slrating'].setPixmapNum(11)
				for slskinentry in ('slartistandtitle','slalbumyearalbartist','slgenre','slplays','sltrack','slbitrate','slfilename','sllength', 'slbackground'):
					self[slskinentry].hide()
			self.showFullSkinparts(fullskinentrys)
			self.embededsonglistisshown=False
			if not streamripperinstance.isRunning:
				self['console'].hide()
		else:
			self.hideFullSkinparts(fullskinentrys)
			self['coverArtmini'].show()
			if streamripperinstance.isRunning:
				self['console'].setText('')# clear console
			if not self['console'].getVisible():
				self['console'].show()
			if config.plugins.musiccenter.songliststyle.value=='list':
				self['slpage'].hide()
				self.embededsonglistisshown='list'
				self['embededSonglistSimplelist'].show()
				self['embededSonglistSimplelist'].setList(self.songList)
				self['embededSonglistSimplelist'].moveToIndex(self.hlp.get('currIndex',0))
				self.currembededlist=self['embededSonglistSimplelist']
				return
			elif config.plugins.musiccenter.songliststyle.value=='2dlist':
				self['slpage'].hide()
				self.embededsonglistisshown='2dlist'
				self.buildAndShowCoverFlowlist(self.hlp.get('currIndex',0))
			elif config.plugins.musiccenter.songliststyle.value=='coverwall':
				self['slpage'].show()
				self.embededsonglistisshown='coverwall'
				self.buildAndShowCoverFlowlist(self.hlp.get('currIndex',0))
			else:
				logger.error('Player]showhideEmbededSonglist]why here?')
			for slskinentry in ('slartistandtitle','slalbumyearalbartist','slgenre','slplays','sltrack','slbitrate','slfilename','sllength', 'slbackground'):
				self[slskinentry].show()

	def errorCoverLoader(self, error):
		logger.error('Player]errorCoverLoader]->%s' %error)

	def showFullSkinparts(self, fullskinentrys):
		logger.debug('Player]showFullSkinparts]')
 		for skinentry in ('artistandtitlewithminicov', 'albumyearalbartistwithminicov', 'filenamewithminicov', 'coverArtmini', 'slpage'):
			self[skinentry].hide()
		for skinentry in fullskinentrys:
			self[skinentry].show()
		self['key_green'].setText("")
		self['key_yellow'].setText("")
		self['key_blue'].setText("")

	def hideFullSkinparts(self, fullskinentrys):
		logger.debug('Player]hideFullSkinparts]')
		for skinentry in fullskinentrys:
			self[skinentry].hide()
		self['key_green'].setText("Reveret sort order")
		self['key_yellow'].setText("Sort list")
		self['key_blue'].setText("Select Liststyle")
 		for skinentry in ('artistandtitlewithminicov', 'albumyearalbartistwithminicov', 'filenamewithminicov', 'coverArtmini', 'slpage'):
			self[skinentry].show()

	def buildAndShowCoverFlowlist(self, selectedindex):
		logger.debug('Player]buildAndShowCoverFlowlist]embededsonglistisshown->%s' %self.embededsonglistisshown)
		list=[]
		covers=[]
		for fake, entry in enumerate(self.songList):
			list.append((entry))
			if self.playermode in (RADIODE, RADIOBROWSER):
				cover=entry[0].stationicon
			elif self.playermode in (FILEMODE, DBMODE):
				cover=entry[0].coverfn
			covers.append(cover)
		logger.debug('Player]buildAndShowCoverFlowlist]set collection')
		if self.embededsonglistisshown=='2dlist':
			logger.debug('Player]buildAndShowCoverFlowlist]set collection-> 2dlist')
			self.currembededlist=self['embededSonglist2DFlow']
		elif self.embededsonglistisshown=='coverwall':
			logger.debug('Player]buildAndShowCoverFlowlist]set collection-> coverwall')
			self.currembededlist=self['embededSonglistCoverwall']
		else:
			logger.error('Player]buildAndShowCoverFlowlist]uihh, what is wrong?')
			return
		self.currembededlist.setList(list, covers, selectedindex)
		self.currembededlist.show()

	def songlist2DSelChanged(self, index):
		logger.debug('Player]songlist2DSelChanged]')
		entry=self.songList[index][0]
		self['slgenre'].setText(entry.genre)
		self['slpage'].setText(_('Page {} | {}'.format(self.currembededlist.getCurrentPage(), self.currembededlist.getTotalPages())))
		logger.debug('Player]songlist2DSelChanged]bitrate_raw:{}'.format(entry.bitrate))
		if self.playermode in (DBMODE, FILEMODE):
			slartistandtitle, slalbumyearalbartist, slfilename, sltrack, slplaycount=self.joinDisplaytextFiles(entry.artist, entry.title, entry.album, entry.date, entry.albumartist, entry.track, entry.playcount, entry.filename)
			self['slartistandtitle'].setText(slartistandtitle)
			self['slalbumyearalbartist'].setText(slalbumyearalbartist)
			self['sllength'].setText(entry.length)
			self['slbitrate'].setText(entry.bitrate)	
			self['slrating'].setPixmapNum(calcRating(entry.rating))
			self['slplays'].setText(slplaycount)
			self['sltrack'].setText(sltrack)
			self['slfilename'].setText(slfilename)
			#lcd
			self.summaries.setText(entry.artist, 1)
			self.summaries.setText(entry.title, 2)
			self.summaries.setText(slalbumyearalbartist, 3)
			self.summaries.setText('{} | {}'.format(entry.genre, entry.bitrate), 4)					
		else:		
			slartistandtitle='{} - {}'.format(entry.artist, entry.title)
			self['slartistandtitle'].setText(slartistandtitle)
			slalbumyearalbartist, bitrateandcodec, plays, radiotype=self.joinDisplaytextStream(entry.stationname, entry.location, entry.bitrate, entry.codec, entry.playcount, entry.rating, entry.filetype)
			self['slalbumyearalbartist'].setText('Station:'+slalbumyearalbartist)
			self['sllength'].setText(bitrateandcodec)
			self['slfilename'].setText(radiotype)
			# lcd
			self.summaries.setText(slartistandtitle, 1)
			self.summaries.setText(slalbumyearalbartist, 2)
			self.summaries.setText('{}|{}'.format(entry.genre, bitrateandcodec), 3)
			self.summaries.setText(plays, 4)
			
	def songlistSimpleSelChanged(self):
		logger.debug('Player]songlistSimpleSelChanged]')
		entry=self['embededSonglistSimplelist'].getCurrent()
		if entry is not None:
			logger.debug('Player]songlistSimpleSelChanged]bitrate_raw->%s' %str(entry.bitrate))
			if self.playermode in (DBMODE, FILEMODE):
				slartistandtitle, slalbumyearalbartist, slfilename, sltrack, slplaycount=self.joinDisplaytextFiles(entry.artist, entry.title, entry.album, entry.date, entry.albumartist, entry.track, entry.playcount, entry.filename)
				#lcd
				self.summaries.setText(entry.artist, 1)
				self.summaries.setText(entry.title, 2)
				self.summaries.setText(slalbumyearalbartist, 3)
				self.summaries.setText('{} | {}'.format(entry.genre, entry.bitrate), 4)					
			else:		
				slartistandtitle='{} - {}'.format(entry.artist, entry.title)
				slalbumyearalbartist, bitrateandcodec, plays, radiotype=self.joinDisplaytextStream(entry.stationname, entry.location, entry.bitrate, entry.codec, entry.playcount, entry.rating, entry.filetype)
				self.summaries.setText(slartistandtitle, 1)
				self.summaries.setText(slalbumyearalbartist, 2)
				self.summaries.setText('{}|{}'.format(entry.genre, bitrateandcodec), 3)
				self.summaries.setText(plays, 4)			

	def removeSongFromList(self, index=None):
		if index is None:
			index=self.currembededlist.getCurrentIndex()
		del self.songList[index]
		self.showhideEmbededSonglist()
		self.showhideEmbededSonglist()
		
	def removeSongFromListAndDisc(self):
		index=self.currembededlist.getCurrentIndex()
		l=len(self.songList)
		fn=os_path.realpath(self.songList[index][0].filename)
		logger.debug('Player]removeSongFromListAndDisc]%s' %fn)
		if l > 1:
			logger.debug('Player]removeSongFromListAndDisc]%s' %fn)
			mypath, filename=fn.rsplit('/',1)
			songID=self.songList[index][0].songID
			deferToThread(JCdeleteSongfileonThread, fn, songID).addCallback(self.finishedremoveSongFromListAndDisc,).addErrback(self.errorremoveSongFromListAndDisc,)
			self.removeSongFromList(index)
		elif l==1:
			self.delSelSong()
		
	def finishedremoveSongFromListAndDisc(self, result):
		logger.debug('Player]removeSongFromListAndDisc]result:{}'.format(result))

	def errorremoveSongFromListAndDisc(self, error):
		logger.error('Player]errorremoveSongFromListAndDisc]{}'.format(error))
		
	def bluePressed(self):
		self.resetScreenSaverTimer(restart=True)
		logger.debug('Player]bluePressed]...')
		if self.embededsonglistisshown:
			logger.debug('Player]bluePressed]is embededsonglistisshown, show selections')
			options=[]
			if config.plugins.musiccenter.songliststyle.value!='list':
				options.append((_("Style: Listbox High"), 'list'),)
			if config.plugins.musiccenter.songliststyle.value!='2dlist':
				options.append((_("Style: 2D Coverflow"), '2dlist'),)
			if config.plugins.musiccenter.songliststyle.value!='coverwall':
				options.append((_("Style: Coverwall"), 'coverwall'),)
			self.session.openWithCallback(self.bluePressedCallback, ChoiceBox, title=_("Select style..."), list=options,keys=MYKEYSORT, titlebartext=_("MusicCenter"))

	def bluePressedCallback(self, ret):
		self.resetScreenSaverTimer(restart=True)
		if ret:
			logger.debug('Player]bluePressedCallback]->%s' %str(ret))
			config.plugins.musiccenter.songliststyle.value=ret[1]
			config.plugins.musiccenter.songliststyle.save()
			configfile.save()
			if self.embededsonglistisshown!=config.plugins.musiccenter.songliststyle.value:
				logger.debug('Player]bluePressedCallback]liststyle changed, update list')
				self.showhideEmbededSonglist()
				self.showhideEmbededSonglist()

	def redPressed(self):
		self.resetScreenSaverTimer(restart=True)
		pass

	def greenPressed(self):
		self.resetScreenSaverTimer(restart=True)
		if self.embededsonglistisshown:
			self.songList.reverse()
			currsongID=self.getCurrSonglistEntry().songID
			logger.debug('Player]sortSonglistByTrack]get currsongID:{}'.format(currsongID))			
			self.updateEmbededSonglist(currsongID)

	def yellowPressed(self):
		self.resetScreenSaverTimer(restart=True)
		if self.embededsonglistisshown:
			options=[]
			options.append((_("Sort Songlist by Tracknr"), self.sortSonglistByTrack),)
			options.append((_("Sort Songlist by Title"), self.sortSonglistByTitle),)
			options.append((_("Sort Songlist by Artist"), self.sortSonglistByArtist),)
			options.append((_("Sort Songlist by Album"), self.sortSonglistByAlbum),)
			options.append((_("Sort Songlist by Date"), self.sortSonglistByDate),)
			options.append((_("Sort Songlist by Genre"), self.sortSonglistByGenre),)
			options.append((_("Sort Songlist by Favorite"), self.sortSonglistByFavorite),)
			self.session.openWithCallback(self.myCallback, ChoiceBox, title=_("Select list sort"), list=options,keys=MYKEYSORT, titlebartext=_("MusicCenter"))

	def myCallback(self, ret):
		self.resetScreenSaverTimer(restart=True)
		ret and ret[1]()

	def sortSonglistByTrack(self):
		currsongID=self.getCurrSonglistEntry().songID
		logger.debug('Player]sortSonglistByTrack]get currsongID:{}'.format(currsongID))
		self.songList.sort(key=lambda a:a[0].track)
		self.updateEmbededSonglist(currsongID)

	def sortSonglistByArtist(self):
		currsongID=self.getCurrSonglistEntry().songID
		logger.debug('Player]sortSonglistByArtist]get currsongID:{}'.format(currsongID))
		self.songList.sort(key=lambda a:a[0].artist)
		self.updateEmbededSonglist(currsongID)

	def sortSonglistByTitle(self):
		currsongID=self.getCurrSonglistEntry().songID
		logger.debug('Player]sortSonglistByTitle]get currsongID:{}'.format(currsongID))
		self.songList.sort(key=lambda a:a[0].title)
		self.updateEmbededSonglist(currsongID)

	def sortSonglistByAlbum(self):
		currsongID=self.getCurrSonglistEntry().songID
		logger.debug('Player]sortSonglistByAlbum]get currsongID:{}'.format(currsongID))
		self.songList.sort(key=lambda a:a[0].album)
		self.updateEmbededSonglist(currsongID)

	def sortSonglistByDate(self):
		currsongID=self.getCurrSonglistEntry().songID
		logger.debug('Player]sortSonglistByDate]get currsongID:{}'.format(currsongID))
		self.songList.sort(key=lambda a:a[0].date)
		self.updateEmbededSonglist(currsongID)

	def sortSonglistByGenre(self):
		currsongID=self.getCurrSonglistEntry().songID
		logger.debug('Player]sortSonglistByGenre]get currsongID:{}'.format(currsongID))
		self.songList.sort(key=lambda a:a[0].genre)
		self.updateEmbededSonglist(currsongID)

	def sortSonglistByFavorite(self):
		currsongID=self.getCurrSonglistEntry().songID
		logger.debug('Player]sortSonglistByFavorite]get currsongID:{}'.format(currsongID))
		self.songList.sort(key=lambda a:a[0].rating)
		self.updateEmbededSonglist(currsongID)

	def updateEmbededSonglist(self, currsongID):
		new_songList_Index=[ song[0].songID for song in self.songList].index(currsongID)
		logger.debug('Player]updateEmbededSonglist]set list and move to new_songList_Index:{}'.format(new_songList_Index))
		if self.embededsonglistisshown=='list':
			self.currembededlist.setList(self.songList)
			self.currembededlist.moveToIndex(new_songList_Index)
		elif self.embededsonglistisshown in ('2dlist', 'coverwall'):
			self.buildAndShowCoverFlowlist(new_songList_Index)
		self.hlp['currIndex']=new_songList_Index

	def infoPressed(self):
		logger.debug('Player]infoPressed]....')
		self.resetScreenSaverTimer(restart=True)
		options=[]
		if fileExists(resolveFilename(SCOPE_PLUGINS, 'Extensions/PicturePlayer/plugin.pyo')):
			options.append((_("Start Pictureviewer"), self.startPicshow),)
		if fileExists(resolveFilename(SCOPE_PLUGINS, 'Extensions/PicturePlayer2/plugin.pyo')):
			options.append((_("Start Pictureviewer2"), self.startPicshow2),)
		self.session.openWithCallback(self.infoPressedCB, ChoiceBox, title=_(" Infooptions"), list=options, keys=MYKEYSORT, titlebartext=_("MusicCenter"))

	def infoPressedCB(self, ret):
		ret and ret[1]()

	def startPicshow(self):
		self.resetScreenSaverTimer(restart=True)
		from Plugins.Extensions.PicturePlayer.plugin import picshow
		self.session.open(picshow)

	def startPicshow2(self):
		self.resetScreenSaverTimer(restart=True)
		from Plugins.Extensions.PicturePlayer2 import pictureplayer2
		self.session.open(pictureplayer2.picshow2)

# streamripper start
	def startStreamRipperDialog(self):
		logger.debug('Player]startStreamRipperDialog]')		
		self.session.openWithCallback(self.streamRipperSetTrackStartnumber, InputBox, windowTitle=_("Set recording length"),  title=_("Enter in minutes (0 means unlimited)"), text="0", type=Input.NUMBER)

	def streamRipperSetTrackStartnumber(self, record_length):
		if record_length is not None:
			self.hlp['record_length']=record_length
			if config.plugins.musiccenter.streamripper_addsequencenumber_on_outputfile.value in ('counter', 'date_and_counter'):
				self.session.openWithCallback(self.streamRipperSetMinimumSongLength, InputBox, windowTitle=_("Set track startnumber"),  title=_("Enter number"), text="0", type=Input.NUMBER)
			else:
				self.streamRipperSetMinimumSongLength(-1)
			
	def streamRipperSetMinimumSongLength(self, start_number):
		if start_number is not None:
			self.hlp['start_number']=int(start_number)
			self.session.openWithCallback(self.streamRipperSetMinimumSongLengthCallback, InputBox, windowTitle=_("Minimum song recording length"),  title=_("Enter in seconds (0 means unlimited)"), text="60", type=Input.NUMBER)

	def streamRipperSetMinimumSongLengthCallback(self, min_song_duration): # ret minimum song
		if min_song_duration is not None:
			if not pathExists(config.plugins.musiccenter.streamripper_base_directory.value):
				createDir(config.plugins.musiccenter.streamripper_base_directory.value)
			
			slentry=self.songList[self.hlp.get('currIndex')][0]
			url=slentry.filename
			stationname=slentry.stationname
			genre=slentry.genre
			
			if config.plugins.musiccenter.use_different_streamripper_useragent_for_rip.value:
				user_agent=config.plugins.musiccenter.different_streamripper_useragent.value
			else:
				user_agent=None
				
			record_length= int(self.hlp.get('record_length')) * 60
			if record_length==0:
				record_length=-1
		
			base_directory=config.plugins.musiccenter.streamripper_base_directory.value		
			check_for_dublicates=config.plugins.musiccenter.streamripper_check_for_dublicates.value
			save_dublicates=config.plugins.musiccenter.streamripper_save_dublicates.value
			
			streamripperinstance.Start(url, base_directory=base_directory, record_length=record_length, track_number_format=config.plugins.musiccenter.streamripper_addsequencenumber_on_outputfile.value, start_number=self.hlp.get('start_number'), min_song_duration=min_song_duration, user_agent=user_agent, stationname=stationname, genre=genre, check_for_dublicates=check_for_dublicates, save_dublicates=save_dublicates)
			logger.debug('Player]inputBoxStartRecordingCallback]ripper started')
			self['console'].show()

	def streamripperDataAvail(self, fake):
		msg=streamripperinstance.Message.pop()
		if msg[0]=='THREAD_WORKING' and not self.embededsonglistisshown:
			self['console'].setText('         {}'.format(msg[1]))
			
	def stopStreamRipper(self):
		self.session.openWithCallback(self.stopRecordingConfirmed, MessageBox, _("Do you really want to stop the recording?"))

	def stopRecordingConfirmed(self,val):
		if val:
			logger.debug('Player]stopRecordingConfirmed]')
			streamripperinstance.Cancel()
			self['console'].setText("")
			self['console'].hide()

	def updatePlaystate(self):
		self.playtime_station+=1
		m, s = divmod(self.playtime_station, 60)
		h, m = divmod(m, 60)
		stationstate= "%d:%02d:%02d" %(h, m, s)
		self.playtime_song+=1
		m, s = divmod(self.playtime_song, 60)
		h, m = divmod(m, 60)
		songstate= "%d:%02d:%02d" %(h, m, s)
		self['playstate'].setText('{}|{}'.format(songstate, stationstate))

	def updateSongListEntry(self, index=None, title=None, artist=None, album=None, track=None, albumartist=None, genre=None, date=None, cover=None, coverfn=None, filename=None, playcount=None):
		logger.debug('Player]updateSongListEntry]start')
		mustupdate=False
		if index is None:
			index=self.hlp.get('currIndex')

		if title is not None:
			self.songList[index][0].title=title
			mustupdate=True

		if artist is not None:
			self.songList[index][0].artist=artist
			mustupdate=True

		if album is not None:
			self.songList[index][0].album=album
			mustupdate=True

		if track is not None:
			self.songList[index][0].track=track
			mustupdate=True

		if albumartist is not None:
			self.songList[index][0].albumartist=albumartist
			mustupdate=True

		if genre is not None:
			self.songList[index][0].genre=genre
			mustupdate=True

		if date is not None:
			self.songList[index][0].date=date
			mustupdate=True

		if cover is not None:
			self.songList[index][0].cover=cover
			mustupdate=True

		if coverfn is not None:
			self.songList[index][0].coverfn=coverfn
			mustupdate=True

		if filename is not None:
			self.songList[index][0].filename=filename
			mustupdate=True

		if playcount is not None:
			self.songList[index][0].playcount=playcount
			mustupdate=True	
			
		if mustupdate:
			logger.info('Player]updateSongListEntry]call-> updateEvent')
			slentry=self.getCurrSonglistEntry()
			self.updateEvent(slentry)

	def updateRatingPlaycounterWaveCover(self, slentry=None):
		logger.debug('Player]updateRatingPlaycounterWaveCover]start...')
		if self.playermode in (FILEMODE, DBMODE) and not self.hlp.get('reload',False):
			playcountertriggerprozent=int(config.plugins.musiccenter.playcountertriggerprozent.value)
			playcountertriggertime=int(config.plugins.musiccenter.playcountertriggertime.value)
			length, playstate=self['PositionGauge'].get()
			rating_changed=self.hlp.pop('rating_changed',False)
			wave_changed=self.hlp.pop('wave_changed', False)
			skiptime=self.hlp.get('skiptime')
			id3_editid3_slentry=self.hlp.pop('id3_editid3_slentry', False)
			id3=self.hlp.pop('id3', False)
			paraforcoveradd=self.paraforcoveradd
			self.paraforcoveradd=None
			
			if slentry is None:
				slentry=self.getCurrSonglistEntry()
				
			deferToThread(self.updateRatingPlaycounterWaveCoverOnThread, slentry, playcountertriggerprozent, playcountertriggertime, length, playstate, rating_changed, wave_changed, skiptime, paraforcoveradd, id3_editid3_slentry, id3).addCallback(self.updateRatingPlaycounterWaveCoverOnThreadCB).addErrback(self.updateRatingPlaycounterWaveCoverOnThreadErrorCB)
		else:
			logger.debug('Player]updateRatingPlaycounterWaveCover]is stream, skip...')
# threaded....	
	def updateRatingPlaycounterWaveCoverOnThread(self, slentry, playcountertriggerprozent, playcountertriggertime, length, playstate, rating_changed, wave_changed, skiptime, paraforcoveradd, id3_editid3_slentry, id3):
		logger.debug('Player]updateRatingPlaycounterWaveCoverOnThread]start:{}'.format(slentry.filename))
		jobtype=None
		coverfn=None
		item=None
		playcount_changed=False
		is_editid3=False
		logger.debug('Player]updateRatingPlaycounterWaveCoverOnThread]rating_changed:{} wave_changed:{}'.format(rating_changed, wave_changed))
		if fileExists(slentry.filename) and os_access(slentry.filename, os_W_OK):
			if slentry.filetype in ('MP3','FLAC', 'OGG'):
				if id3_editid3_slentry:
					logger.debug('Player]updateRatingPlaycounterWaveCoverOnThread]id3_editid3_slentry.filename:{}'.format(id3_editid3_slentry.filename))
				if id3_editid3_slentry and id3_editid3_slentry.filename!=slentry.filename:
					logger.debug('Player]updateRatingPlaycounterWaveCoverOnThread]id3 from EditID3 found, but other song! Update old song now editid3name:{} filename:{}'.format(id3_editid3_slentry.filename, slentry.filename))
					job_manager.AddJob(Audio_ID3_Actions_Job(jobtype='saveID3Tags', item=id3_editid3_slentry, audio=id3))
					id3=None
				elif id3_editid3_slentry and id3_editid3_slentry.filename==slentry.filename:
					logger.debug('Player]updateRatingPlaycounterWaveCoverOnThread]id3 from EditID3 found, use it')
					is_editid3=True
				else:
					logger.debug('Player]updateRatingPlaycounterWaveCoverOnThread]no id3 from EditID3 found, get getID3raw now')
					id3=None

				if id3 is None:
					id3, filetype=getID3raw(slentry.filename, will_write=True)

				if playcountertriggerprozent!=0 or playcountertriggertime!=0 :
					logger.debug('Player]updateRatingPlaycounterWaveCoverOnThread]playstate:{} length:{} skiptime.{}'.format(playstate, length, skiptime))
					playstate-=skiptime
					if playstate>0 and length>0 and playstate*100/length > playcountertriggerprozent or  playstate/90000/60.0 > playcountertriggertime:
						slentry.playcount+=1
						if slentry.filetype=='MP3':
							logger.debug('Player]updateRatingPlaycounterWaveCoverOnThread]increase playcount MP3')
							id3['PCNT']=PCNT(encoding=3, count=slentry.playcount)
						elif slentry.filetype in ('FLAC','OGG'):
							logger.debug('Player]updateRatingPlaycounterWaveCoverOnThread]increase playcount FLAC OGG')
							id3['PCNT']='{}'.format(slentry.playcount)
						playcount_changed=True
				if rating_changed:
					logger.debug('Player]updateRatingPlaycounterWaveCoverOnThread]rating is changed:{}'.format(slentry.rating))
					if slentry.filetype=='MP3': #
						popm=[ id3[i] for i in id3.iterkeys() if 'POPM' in i]
					elif slentry.filetype in ('FLAC','OGG'):
						popm=[]
					if slentry.rating in range(256):
						if slentry.filetype=='MP3':
							if len(popm):
								logger.debug('Player]updateRatingPlaycounterWaveCoverOnThread]update rating:{} on POPM:{}'.format(slentry.rating,'POPM:'+popm[0].email))
								id3['POPM:'+popm[0].email].rating=slentry.rating
							else:
								logger.debug('Player]updateRatingPlaycounterWaveCoverOnThread]No Rating on Tag, add:{}'.format(slentry.rating))
								if slentry.filetype=='MP3':
									logger.debug('Player]updateRatingPlaycounterWaveCoverOnThread]change rating MP3')
									id3['POPM']=POPM(email=u'no@email', rating=slentry.rating, count=0)# Mediamonkey
						elif slentry.filetype in ('FLAC','OGG'):
							logger.debug('Player]updateRatingPlaycounterWaveCoverOnThread]change rating  FLAC OGG')
							id3['POPM']='%s' %slentry.rating
					else:
						#self.songList[self.hlp.get('currIndex',0)][0].rating=281
						if slentry.filetype=='MP3':
							for i in popm:
								logger.debug('Player]updateRatingPlaycounterWaveCoverOnThread]remove from ID3 Rating->%s' %'POPM:'+popm[0].email)
								id3.pop('POPM:'+i.email)
						elif slentry.filetype in ('FLAC','OGG'):
							id3.__delitem__('POPM')

				if wave_changed:
					if isinstance(slentry.wave,list) and len(slentry.wave):
						if slentry.filetype=='MP3':
							logger.debug('Player]updateRatingPlaycounterWaveCoverOnThread]add wave to MP3 WXXX ->%s' %repr(slentry.wave[:30]))
							id3['WXXX']=WXXX(encoding=3, desc=u'wave', url=u'%s' %repr(slentry.wave))
						elif slentry.filetype in ('FLAC','OGG'):
							logger.debug('Player]updateRatingPlaycounterWaveCoverOnThread]add wave to FLAC OGG WXXX wave->%s' %repr(slentry.wave[:30]))
							id3['WXXX:wave']=u'%s' %repr(slentry.wave)
					else:
						logger.error('Player]updateRatingPlaycounterWaveCoverOnThread]error add wave to FLAC OGG WXXX wave:{} is not list!!!'.format(slentry.wave))

				if paraforcoveradd is not None:
					logger.debug('Player]updateRatingPlaycounterWaveCoverOnThread]paraforcoveradd ID3 save now...')
					coverfn=paraforcoveradd['coverfn']
					filename=paraforcoveradd['filename']
					item=paraforcoveradd['item']
					jobtype='embedcoverandID3Tags'#job_manager.AddJob(Audio_ID3_Actions_Job(jobtype='embedcoverandID3Tags', coverfn=coverfn, item=item, audio=id3))
				else:
					logger.debug('Player]updateRatingPlaycounterWaveCoverOnThread]no paraforcoveradd check for changed id3')
					if playcount_changed or rating_changed or wave_changed or is_editid3:
						logger.debug('Player]updateRatingPlaycounterWaveCoverOnThread]no paraforcoveradd but changed id3 save now')
						jobtype='saveID3Tags'
						item=slentry#job_manager.AddJob(Audio_ID3_Actions_Job(jobtype='saveID3Tags', item=slentry, audio=id3))
					else:
						logger.debug('Player]updateRatingPlaycounterWaveCoverOnThread]no paraforcoveradd no changed id3, do nothing!')
			else:
				logger.error('Player]updateRatingPlaycounterWaveCoverOnThread]not supported filetype, break... ->%s' %slentry.filename)
		else:
			logger.eror('Player]updateRatingPlaycounterWaveCoverOnThread]file not exist, or not writeaccess!')
		return jobtype, coverfn, item, id3 

	def updateRatingPlaycounterWaveCoverOnThreadCB(self, result):
		#logger.info('Player]updateRatingPlaycounterWaveCoverOnThreadCB]start jobmanager now:{}'.format(str(result)[:300]))
		jobtype, coverfn, item, id3 = result
		if item is not None:
			job_manager.AddJob(Audio_ID3_Actions_Job(jobtype=jobtype, coverfn=coverfn, item=item, audio=id3))

	def updateRatingPlaycounterWaveCoverOnThreadErrorCB(self, error):
		logger.error('Player]updateRatingPlaycounterWaveCoverOnThreadErrorCB]{}'.format(error))

	def getCurrSonglistEntry(self):
		i=self.hlp.get('currIndex',0)
		try:
			return self.songList[i][0]
		except:
			logger.exception('Player]getCurrSonglistEntry]no Songlist?:{} present, return default Item'.format(self.songList))
			return Item()
# show TV
	def showTV(self, isScreenSaverMode=False):
		self.resetScreenSaverTimer(restart=False)
		logger.debug('Player]showTV]start TV isScreenSaverMode:{}'.format(isScreenSaverMode))
		if self.TVScreen:
			self.session.deleteDialog(self.TVScreen)
			self.TVScreen=None

		if not isScreenSaverMode:
			from Components.SystemInfo import SystemInfo
			if SystemInfo.get("NumVideoDecoders", 1) < 2:
				return
		self.TVScreen=self.session.instantiateDialog(MusicCenterPlayerTV, self.currentService, self.serviceList, isScreenSaverMode)
		self.session.execDialog(self.TVScreen)

		slentry=self.getCurrSonglistEntry()
		if self.playermode in (FILEMODE,DBMODE):
			artistandtitle=self['artistandtitle'].getText()
			albumyearalbartist=self['albumyearalbartist'].getText() 
			filename=self['filenamewithminicov'].getText()
			track=self['track'].getText()
			genre=self['genre'].getText()
			playcount=self['plays'].getText()
			bitrate=self['bitrate'].getText() 
			length=self['length'].getText()
			ratingnum=self.setRatingStars()
			self.updateMusicInformation(slentry.artist, slentry.title, slentry.album, slentry.genre, slentry.date, slentry.albumartist, slentry.bitrate, slentry.track, slentry.filetype, slentry.playcount, slentry.length, slentry.filename)
		else:
			self.updateMusicInformationStream(sTitle=self['artistandtitle'].getText(), station=slentry.stationname, location=slentry.location, genre=slentry.genre, bitrate=slentry.bitrate, codec=slentry.codec, stationicon=slentry.stationicon, clicks=slentry.playcount, rating=slentry.rating, votes=slentry.votes, filetype=slentry.filetype)

		self.TVScreen.updateCover(self.hlp.get('currshowedcoverfn'))

# close...
	def closePlayer(self):# called on exit and player running continius...
		self.resetScreenSaverTimer(restart=False)
		if self.embededsonglistisshown:
			logger.debug('Player]closePlayer]embededsonglistisshown -> showhideEmbededSonglist now')
			self.showhideEmbededSonglist()
		else:
			self.close()

	def __onClose(self):
		logger.info('Player]__onClose] kill timer...')
		self.covertextTimer_mc_conn=None
		self.streamripper_conn=None	
		self.screenSaverTimer_mc_conn=None
		if self.playermode in (FILEMODE,DBMODE):
			self.wg_conn=None
			self.mp3gaincontainer = None
			self.mp3gaincontainer_dataAvail = None
			self.mp3gaincontainer_stderrAvail = None
		elif self.playermode in (RADIODE, RADIOBROWSER):
			self.streamPlayer_mc_conn=None
			self.visuCleanerTimer_conn=None
			self.radioPollTimer_mc_conn=None
			self.eventUpdateTimer_mc_conn=None
			self.saveSoundvisualisation()
			# fallback to earlier enigma versions FIXME Delete that when commiting
			try:
				config.plugins.musiccenter.visualization.removeNotifier(self.visualizationConfigOnChange)
			except:
				logger.exception('Player]__onClose]...?')
				config.plugins.musiccenter.visualization.notifiers.remove(self.visualizationConfigOnChange) 
		logger.debug('Player]__onClose]del ePixmaps...')
		del self['coverArt']
		del self['artistArt']
		del self['coverArtmini']
		del self['stationicon']

	def createSummary(self):
		return MC_LCDText



from Components.ScreenAnimations import *
sa = ScreenAnimations()
sa.fromXML(resolveFilename(SCOPE_PLUGINS, "Extensions/MusicCenter/animations.xml"))
#mc_screensaver_blend

URLCACHE={}

# http://getwallpapers.com/ 
# http://ognature.com

class MusicCenterPlayerTV(Screen):

	if RESOLUTIONx>1800:
		skin="""
			<screen backgroundColor="#00000000" flags="wfNoBorder" position="0,0" size="1920,1080" title="MusicCenterPlayerTV">
				<!-- headerfield  -->
					<widget backgroundColor="transparent" name="video" position="0,0" size="1920,1080" zPosition="1"/>
					<widget name="textbase" position="20,20" size="1880,132" zPosition="3" />
					<widget name="screenSaver" position="0,0" size="2635,1482" zPosition="2" scale="fill full"/> 
					<widget name="coverArt" position="22,22" size="128,128" zPosition="4" scale="fill full"/>
				<!-- 1 zeile  -->
					<widget name="artistandtitlewithminicov" position="190,26" size="1480,42" font="SansReg;38" halign="left" valign="center" foregroundColor="#ffffff" backgroundColor="#191919" transparent="1" zPosition="4"/>
					<widget name="track" position="1675,26" size="225,42" font="SansReg;38" halign="center" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" transparent="1" zPosition="4"/>
				<!-- 2 zeile  -->
					<widget name="albumyearalbartistwithminicov" position="190,76" size="1185,34" font="SansReg;30" halign="left" valign="center" foregroundColor="#ffffff" backgroundColor="#191919" transparent="1" zPosition="4"/>
					<widget name="genre" position="1375,76" size="300,34" font="SansReg;30" halign="left" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" transparent="1" zPosition="4"/>
					<widget name="length" position="1675,76" size="225,34" font="SansReg;30" halign="center" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" transparent="1" zPosition="4"/>
				<!-- 3 zeile  -->
					<widget name="filenamewithminicov" position="190,117" size="985,30" font="SansReg;26" halign="left" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" transparent="1" zPosition="4"/>
					<widget name="rating" position="1175,116" size="300,32" alphatest="on" zPosition="4" scale="0" pixmaps="~/rating0.png,~/rating1.png,~/rating2.png,~/rating3.png,~/rating4.png,~/rating5.png,~/rating6.png,~/rating7.png,~/rating8.png,~/rating9.png,~/rating10.png,~/rating11.png"/>
					<widget name="plays" position="1475,117" size="200,30" font="SansReg;26" halign="center" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" transparent="1" zPosition="4"/>
					<widget name="bitrate" position="1675,117" size="225,30" font="SansReg;26" halign="center" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" transparent="1" zPosition="4"/>
			</screen>"""
	else:
		skin="""
			<screen backgroundColor="transparent" flags="wfNoBorder" position="0,0" size="1280,720" title="MusicCenterPlayerTV">
			<!-- headerfield  -->
				<widget backgroundColor="transparent" name="video" position="0,0" size="1280,720" zPosition="1"/>
				<widget name="textbase" position="12,12" size="1256,88" zPosition="3" />
				<widget name="screenSaver" position="0,0" size="1280,720" zPosition="2" scale="fill full"/>
				<widget name="coverArt" position="21,21" size="87,87" zPosition="4"  scale="fill full"/>
				<!-- 1 zeile  -->
					<widget name="artistandtitlewithminicov" position="190,26" size="1480,30" font="SansReg;26" halign="left" valign="center" foregroundColor="#ffffff" backgroundColor="#191919" transparent="1" zPosition="4"/>
					<widget name="track" position="1675,26" size="225,30" font="SansReg;26" halign="center" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" transparent="1" zPosition="4"/>
				<!-- 2 zeile  -->
					<widget name="albumyearalbartistwithminicov" position="190,76" size="1185,24" font="SansReg;22" halign="left" valign="center" foregroundColor="#ffffff" backgroundColor="#191919" transparent="1" zPosition="4"/>
					<widget name="genre" position="1375,76" size="300,24" font="SansReg;22" halign="left" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" transparent="1" zPosition="4"/>
					<widget name="length" position="1675,76" size="225,24" font="SansReg;22" halign="center" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" transparent="1" zPosition="4"/>
				<!-- 3 zeile  -->
					<widget name="filenamewithminicov" position="190,117" size="985,20" font="SansReg;18" halign="left" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" transparent="1" zPosition="4"/>
					<widget name="rating" position="1175,116" size="300,32" alphatest="on" zPosition="4" scale="0" pixmaps="~/rating0.png,~/rating1.png,~/rating2.png,~/rating3.png,~/rating4.png,~/rating5.png,~/rating6.png,~/rating7.png,~/rating8.png,~/rating9.png,~/rating10.png,~/rating11.png"/>
					<widget name="plays" position="1475,117" size="200,20" font="SansReg;18" halign="center" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" transparent="1" zPosition="4"/>
					<widget name="bitrate" position="1675,117" size="225,20" font="SansReg;18" halign="center" valign="center"  foregroundColor="#ffffff" backgroundColor="#191919" transparent="1" zPosition="4"/>
			</screen>"""

	def __init__(self, session, currentService, serviceList, isScreenSaverMode):
	
		logger.info('MusicCenterPlayerTV]__init__')
		self.skin_path='/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images'
		self.session=session
		Screen.__init__(self, session)
		
		self.onClose.append(self.__onClose)
		self['actions']=ActionMap(["OkCancelActions", "DirectionActions", "ChannelSelectBaseActions", "ChannelSelectEPGActions"],
		{
			"cancel": self.close,
			"ok": self.showHide,
			"right": self.nextService,
			"left": self.prevService,
			"nextBouquet": self.nextBouquet,
			"prevBouquet": self.prevBouquet,
			"showEPGList": self.openEventView,
		}, -1)
		self['actions2']=NumberActionMap(["NumberActions"],
		{
			"1": self.keyNumberGlobal,
			"2": self.keyNumberGlobal,
			"3": self.keyNumberGlobal,
			"4": self.keyNumberGlobal,
			"5": self.keyNumberGlobal,
			"6": self.keyNumberGlobal,
			"7": self.keyNumberGlobal,
			"8": self.keyNumberGlobal,
			"9": self.keyNumberGlobal,
		}, -1)
		self.epgcache=eEPGCache.getInstance()
		self. serviceList= serviceList
		self.isScreenSaverMode=isScreenSaverMode
		self.onFirstExecBegin.append(self._setDurationandAnimation)
		self.onLayoutFinish.append(self.startRun)

		self['textbase']=Pixmap()
		self['screenSaver']=PicLoaderScale(transparent=False, cached=False, name='screensaver')
		self.mc=-1
		self.ken_burns=''
		self.colorfavorite=''
		self.offset_x=0
		self.offset_y=0
		self.imageurls=[]
		self.currscreensaverfilename=''
		self['coverArt']=PicLoaderScale(transparent=False, cached=False, name='MusicCenterPlayerTV')
		self['artistandtitlewithminicov']=Label()
		self['albumyearalbartistwithminicov']=Label()
		self['genre']=Label()
		self['filenamewithminicov']=Label()
		self['plays']=Label()
		self['track']=Label()
		self['bitrate']=Label()
		self['length']=Label()
		self['rating']=MultiPixmap()
		self.cachedir=os_path.join(config.plugins.musiccenter.downloadcache.value, "screensaver/")
		self.skinelements=("artistandtitlewithminicov","albumyearalbartistwithminicov","genre","filenamewithminicov","plays","track",'bitrate',"length", 'coverArt', 'textbase', 'rating')
		self['video']=VideoWindow(fb_width=getDesktop(0).size().width(), fb_height=getDesktop(0).size().height())
		self.showHideTimer=eTimer()
		self.showHideTimer_conn=self.showHideTimer.timeout.connect(self.showHideTimerTimeout)
		self.changetimer=eTimer()
		if RESOLUTIONx>1800:
			self.changetimer_conn=self.changetimer.timeout.connect(self.changetimerAppend_1080)
		else:
			self.changetimer_conn=self.changetimer.timeout.connect(self.changetimerAppend_720)
		self.fadeouttimer=eTimer()
		self.fadeouttimer_conn=self.fadeouttimer.timeout.connect(self.initCallNewPicture)
		self.idx=20
		if self.idx:
		       self.showHideTimer.start(self.idx * 1000)
		self.displayShown=True
		self.session.nav.SleepTimer.on_state_change.append(self.sleepTimerEntryOnStateChange)

	def startRun(self):
		if self.isScreenSaverMode:
		
			logger.info('MusicCenterPlayerTV]startRun]')
			
			def __get_season(date):
				"""
				https://stackoverflow.com/questions/16139306/determine-season-given-timestamp-in-python-using-datetime
				convert date to month and day as integer (md), e.g. 4/21 = 421, 11/17 = 1117, etc.
				"""
				m = date.month * 100
				d = date.day
				md = m + d

				if ((md >= 301) and (md <= 531)):
					s = 'spring'
				elif ((md > 531) and (md < 901)):
					s = 'summer'
				elif ((md >= 901) and (md <= 1130)):
					s = 'fall'
				elif ((md > 1130) or (md <= 229)):
					s = 'winter'
				else:
					raise IndexError("Invalid date")
				return s

			date=datetime_datetime.now()
			season=__get_season(date)
			
			hour=date.hour
			if hour>=5 and hour<9:
				dr='morning'
				color='yellow', 'orange'
			elif hour>=9 and hour<17:
				dr='by day'
				if season=='winter':
					color='white', 'gray'
				else:
					color='teal'
			elif hour>=17 and hour<21:
				dr='afternoon'
				color='brown'
			else:
				dr='night'
				color='black'
			self.colorfavorite=color
			
			searchword='{} {} {}'.format(season, dr, 'landscape wallpaper')
			logger.info('MusicCenterPlayerTV]startRun]searchword:{}'.format(searchword))
			self.cachedir=os_path.join(self.cachedir, searchword.replace(':','_'))
			createDir(self.cachedir)
			logger.info('MusicCenterPlayerTV]startRun]screesavermode:{}'.format(self.cachedir))
			self.startImageSearch(searchword)
		else:
			logger.info('MusicCenterPlayerTV]startRun]TV mode')
			self['screenSaver'].hide()
			if self.serviceList is None:
				self.playService(currentService)
			else:
				current=ServiceReference(self. serviceList.getCurrentSelection())
				self.playService(current.ref)
	
	def _setDurationandAnimation(self):
		logger.error('MusicCenterPlayerTV]_setDurationandAnimation]start animation')
		try:
			sf='quick_fade' # quick_fade'#"zoom_and_fade"
			for element in self.skinelements:
				self[element].instance.setShowHideAnimation(sf)
			self['screenSaver'].instance.setShowHideAnimation("quick_fade")
		except:
			logger.exception('MusicCenterPlayerTV]_setDurationandAnimation]Hmm, klappt  nicht...')
		ptr=LoadPixmap('/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter/images/1880x132x8bit.png')
		self['textbase'].instance.setPixmap(ptr)

	def sleepTimerEntryOnStateChange(self, timer):
		if timer.state == TimerEntry.StateEnded:
			self.close()

	def showHide(self):
		if self.displayShown:
			if self.showHideTimer.isActive():
				self.showHideTimer.stop()
			for element in self.skinelements:
				self[element].hide()
		else:
			for element in self.skinelements:
				self[element].show()
			self.showHideTimer.start(self.idx * 1000)
		self.displayShown=not self.displayShown

	def showHideTimerTimeout(self):
		self.showHide()

	def updateDisplayText(self, artistandtitle, albumyearalbartist, filename, track, genre, playcount, bitrate, length, ratingnum):
		logger.debug('MusicCenterPlayerTV]updateDisplayText]artistandtitle:{} albumyearalbartist:{} filename:{} track:{} genre:{} playcount:{} bitrate:{} length:{} ratingnum:{}'.format(artistandtitle, albumyearalbartist, filename, track, genre, playcount, bitrate, length, ratingnum))
		if self.showHideTimer.isActive():
			self.showHideTimer.stop()
		self['artistandtitlewithminicov'].setText(artistandtitle)
		self['albumyearalbartistwithminicov'].setText(albumyearalbartist)
		self['genre'].setText(genre)
		self['filenamewithminicov'].setText(filename)
		self['plays'].setText(playcount)
		self['track'].setText(track)
		self['bitrate'].setText(bitrate)
		self['length'].setText(length)
		self['rating'].setPixmapNum(ratingnum)
		self.displayShown=False
		self.showHide()		
# Source Code taken from Virtual(Pip)Zap :-)
# switch with numbers
	def keyNumberGlobal(self, number):
		self.session.openWithCallback(self.numberEntered, NumberZap, number)

	def numberEntered(self, retval):
		if retval > 0:
			self.zapToNumber(retval)

	def searchNumberHelper(self, serviceHandler, num, bouquet):
		serviceList=serviceHandler.list(bouquet)
		if not  serviceList is None:
			while num:
				serviceIterator= serviceList.getNext()
				if not serviceIterator.valid(): #check end of list
					break
				playable=not (serviceIterator.flags & (eServiceReference.isMarker|eServiceReference.isDirectory))
				if playable:
					num -= 1;
			if not num: #found service with searched number ?
				return serviceIterator, 0
		return None, num

	def zapToNumber(self, number):
		bouquet=self. serviceList.bouquet_root
		service=None
		serviceHandler=eServiceCenter.getInstance()
		bouquetlist=serviceHandler.list(bouquet)
		if not bouquetlist is None:
			while number:
				bouquet=bouquetlist.getNext()
				if not bouquet.valid(): #check end of list
					break
				if bouquet.flags & eServiceReference.isDirectory:
					service, number=self.searchNumberHelper(serviceHandler, number, bouquet)
		if not service is None:
			if self. serviceList.getRoot() != bouquet: #already in correct bouquet?
				self. serviceList.clearPath()
				if self. serviceList.bouquet_root != bouquet:
					self. serviceList.enterPath(self. serviceList.bouquet_root)
				self. serviceList.enterPath(bouquet)
			self. serviceList.setCurrentSelection(service) #select the service in  serviceList
		# update infos, no matter if service is none or not
		current=ServiceReference(self. serviceList.getCurrentSelection())
		self.playService(current.ref)

	def nextService(self):
		if self. serviceList is not None:
			# get next service
			if self. serviceList.inBouquet():
				prev=self. serviceList.getCurrentSelection()
				if prev:
					prev=prev.toString()
					while True:
						if config.usage.quickzap_bouquet_change.value and self. serviceList.atEnd():
							self. serviceList.nextBouquet()
						else:
							self. serviceList.moveDown()
						cur=self. serviceList.getCurrentSelection()
						if not cur or (not (cur.flags & 64)) or cur.toString() == prev:
							break
			else:
				self. serviceList.moveDown()
			if self.isPlayable():
				current=ServiceReference(self. serviceList.getCurrentSelection())
				self.playService(current.ref)
			else:
				self.nextService()

	def prevService(self):
		if self. serviceList is not None:
			# get previous service
			if self. serviceList.inBouquet():
				prev=self. serviceList.getCurrentSelection()
				if prev:
					prev=prev.toString()
					while True:
						if config.usage.quickzap_bouquet_change.value:
							if self. serviceList.atBegin():
								self. serviceList.prevBouquet()
						self. serviceList.moveUp()
						cur=self. serviceList.getCurrentSelection()
						if not cur or (not (cur.flags & 64)) or cur.toString() == prev:
							break
			else:
				self. serviceList.moveUp()
			if self.isPlayable():
				current=ServiceReference(self. serviceList.getCurrentSelection())
				self.playService(current.ref)
			else:
				self.prevService()

	def isPlayable(self):
		# check if service is playable
		current=ServiceReference(self. serviceList.getCurrentSelection())
		return not (current.ref.flags & (eServiceReference.isMarker|eServiceReference.isDirectory))

	def updateLCD(self, text, line):
		self.summaries.setText(text,line)

	def updateCover(self, picpath):
		self['coverArt'].doshow(picpath)

	def nextBouquet(self):
		if self. serviceList is not None:
			# next bouquet with first service
			if config.usage.multibouquet.value:
				self. serviceList.nextBouquet()
				current=ServiceReference(self. serviceList.getCurrentSelection())
				self.playService(current.ref)

	def prevBouquet(self):
		if self. serviceList is not None:
			# previous bouquet with first service
			if config.usage.multibouquet.value:
				self. serviceList.prevBouquet()
				current=ServiceReference(self. serviceList.getCurrentSelection())
				self.playService(current.ref)

	def openSingleServiceEPG(self):
		# show EPGList
		current=ServiceReference(self. serviceList.getCurrentSelection())
		self.session.open(EPGSelection, current.ref)

	def openEventView(self):
		# show EPG Event
		epglist=[ ]
		self.epglist=epglist
		service=ServiceReference(self. serviceList.getCurrentSelection())
		ref=service.ref
		evt=self.epgcache.lookupEventTime(ref, -1)
		if evt:
			epglist.append(evt)
		evt=self.epgcache.lookupEventTime(ref, -1, 1)
		if evt:
			epglist.append(evt)
		if epglist:
			self.session.open(EventViewEPGSelect, epglist[0], service, self.eventViewCallback, self.openSingleServiceEPG, self.openMultiServiceEPG, self.openSimilarList)

	def eventViewCallback(self, setEvent, setService, val):
		epglist=self.epglist
		if len(epglist) > 1:
			tmp=epglist[0]
			epglist[0]=epglist[1]
			epglist[1]=tmp
			setEvent(epglist[0])

	def openMultiServiceEPG(self):
		# not supported
		pass

	def openSimilarList(self, eventid, refstr):
		self.session.open(EPGSelection, refstr, None, eventid)

	def playService(self, service):
		if service and (service.flags & eServiceReference.isGroup):
			ref=getBestPlayableServiceReference(service, eServiceReference())
		else:
			ref=service
		self.pipservice=eServiceCenter.getInstance().play(ref)
		if self.pipservice and not self.pipservice.setTarget(1):
			self.pipservice.start()
# googelimage
	def startImageSearch(self, searchterm):
		baseurl='https://www.google.de/search?q='
		exact='&tbs=isz:ex,iszw:1920,iszh:1080'
		groesser='&tbs=isz:lt,islt:4mp'
		typphoto='itp:photo'
		color=random_choice(tuple(self.colorfavorite))
		url=('{}{}&tbm=isch&source=lnt,{},ic:specific,isc:{}').format(baseurl, quote(searchterm), exact, color)
		logger.info('MusicCenterPlayerTV]startImageSearch]{}'.format(url))
		urls=URLCACHE.get(url, None)
		logger.debug('MusicCenterPlayerTV]startImageSearch]URLCACHE:{}'.format(urls))
		if urls is None:# not in cache -> &tbs=isz:lt,islt:4mp
			mygetPage(url, timeout=TWISTED_TIMEOUT).addCallback(self.getImageUrlsGoogleImageSiteSearch, url).addErrback(self.googleDownloadError,)
		else:
			logger.info('MusicCenterPlayerTV]startImageSearch]URLCACHE found, use it')
			self.imageurls=urls
			self.getImageUrlsGoogleImageSiteSearchAppend()
		
	def getImageUrlsGoogleImageSiteSearch(self, result, url):
		logger.debug('MusicCenterPlayerTV]getImageUrlsGoogleImageSiteSearch]result:{}'.format(result[:300]))
		self.imageurls=re_findall(',"ou":"(.+?)","ow"',result) # new on 08.02.2017 urlsraw=re_findall('imgres\?imgurl.+?&amp;imgrefurl',result)
		URLCACHE[url]=self.imageurls
		global URLCACHE
		self.getImageUrlsGoogleImageSiteSearchAppend()
		
	def getImageUrlsGoogleImageSiteSearchAppend(self):
		shuffle(self.imageurls)
		if self.imageurls:
			logger.debug('MusicCenterPlayerTV]getImageUrlsGoogleImageSiteSearch]urls->%d' %len(self.imageurls))
			self.downloadImageNow()
		else:
			logger.error('MusicCenterPlayerTV]getImageUrlsGoogleImageSiteSearch]->No images found')
			self.showNoScreensaver(False)

	def downloadImageNow(self, url=None):
		logger.info('MusicCenterPlayerTV]downloadImageNow]start url:{}'.format(url))
		if self.imageurls or url is not None:
			if url is None:
				logger.info('MusicCenterPlayerTV]downloadImageNow]pop now next url')
				url=self.imageurls.pop(0)
			str=url[8:].split('/',1)[-1].replace('/','_').lower()
			if len(str)>90:
				str=str[-90:]
				logger.debug('MusicCenterPlayerTV]downloadImageNow]short local filename to:{}'.format(str))
			filename=str
			if not filename.lower().endswith(('.jpg', '.png', '.jpeg', '.bmp', '.gif', '.svg')):
				endswith=None
				for end in ('.jpg', '.png', '.jpeg', '.bmp', '.gif', '.svg'):
					if end in filename:
						endswith=end
						break
				if endswith is not None:
					filename=''.join((filename, endswith))	
				
			currscreensaverfilename=os_path.join(self.cachedir, filename)
			if not fileExists(currscreensaverfilename):
				logger.info('MusicCenterPlayerTV]downloadImageNow]{} urls load url:{} to currscreensaverfilename:{}'.format(len(self.imageurls), url, currscreensaverfilename))
				downloadPage(url, currscreensaverfilename, agent='Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.56 Safari/537.17').addCallback(self.googleDownloadFinished, currscreensaverfilename).addErrback(self.googleDownloadError, url)
			else:
				logger.info('MusicCenterPlayerTV]downloadImageNow]load localcurrscreensaverfilename:{}'.format(currscreensaverfilename))
				self.googleDownloadFinished(True, currscreensaverfilename)
		else:
			haspics=os_listdir(self.cachedir)
			logger.info('MusicCenterPlayerTV]downloadImageNow]urllist empty, try to get local pic:{}'.format(len(haspics)))
			if haspics:
				currscreensaverfilename=os_path.join(self.cachedir, haspics[randrange(len(haspics))])
				logger.debug('Player]downloadImageNow]show local pic')
				self.googleDownloadFinished(True, currscreensaverfilename)
			else:
				logger.error('MusicCenterPlayerTV]downloadImageNow]haspics:{} is empty!'.format(len(haspics)))

	def googleDownloadError(self, error, url=''):
		logger.error("MusicCenterPlayerTV]googleDownloadError]url:{} error:{}".format(url, error))
		if 'sslv3 alert handshake failure' in str(error) and url.startswith('https://'):
			logger.debug("MusicCenterPlayerTV]googleDownloadError]-->ssl Error, replace https to http and start downloadImageNow")
			url=url.replace('https://','http://')
			self.downloadImageNow(url)
		elif len(self.imageurls):
			logger.debug("MusicCenterPlayerTV]googleDownloadError]now {} urls try next url start downloadImageNow".format(len(self.imageurls)))
			self.downloadImageNow()
		else:
			logger.debug("MusicCenterPlayerTV]googleDownloadError]no cover downloaded, show now no cover")
			self.showNoScreensaver(str(error))

	def showNoScreensaver(self, starttimer):
		picpath=drawImageJobWithLongMultilineText(text='NO-Pictures found', size=(1920,1080), fontsize=120, round=0, out=None, force=True)
		logger.error('MusicCenterPlayerTV]showNoScreensaver]...')
		self.prepareScreensaverShow(picpath)

	def googleDownloadFinished(self, result, currscreensaverfilename):
		try: # check, is a valid image...
			im=Image.open(currscreensaverfilename)
			logger.debug('MusicCenterPlayerTV]googleDownloadFinished]prepareScreensaverShow now')
			self.prepareScreensaverShow(currscreensaverfilename)
		except:
			logger.exception('MusicCenterPlayerTV]googleDownloadFinished]no valid Image, start download next Image Now, remove:{}'.format(currscreensaverfilename))
			os_remove(currscreensaverfilename)
			self.downloadImageNow()

	def prepareScreensaverShow(self, currscreensaverfilename):
		logger.debug('MusicCenterPlayerTV]prepareScreensaverShow]currscreensaverfilename:{}'.format(currscreensaverfilename))
		self.currscreensaverfilename=currscreensaverfilename	
		if self.mc==-1: # init screenSaver
			logger.info('MusicCenterPlayerTV]prepareScreensaverShow]screensaverShow now is init!')
			self.initCallNewPicture()

	def changetimerAppend_1080(self):
		self.mc+=1
		if self.mc==400:
			self['screenSaver'].hide()
			logger.debug('MusicCenterPlayerTV]changetimerAppend_1080]fade out picture, start timer for init new picture')
			self.fadeouttimer.start(900, 1)
		else:
			self.changetimer.start(35, 1)
			self.function()

	def changetimerAppend_720(self):
		self.screensaverShow_720(True)

	def getAnimationStyle(self):
		return random_choice(('zoom_in', 'zoom_out', 'move_from_left_top_to_right_bottom', 'move_zoomed_left_to_rigth', 'move_zoomed_rigth_to_left', 'move_from_rigth_top_to_left_bottom', 'move_from_left_bottom_to_right_top', 'move_from_rigth_bottom_to_left_top'))

	def initCallNewPicture(self):
		self.mc=0
		self.ken_burns=self.getAnimationStyle()
		logger.debug('MusicCenterPlayerTV]initCallNewPicture]reset movecounter, change animation to:{} and show new picture'.format(self.ken_burns))
		if RESOLUTIONx>1800: # call set new picture
			self.setNewPicture()
		else:
			self.screensaverShow_720(False)

	def setNewPicture(self):
		logger.debug('MusicCenterPlayerTV]setNewPicture]show:{}'.format(self.currscreensaverfilename))
		if self.ken_burns=='zoom_in':
			size_x, size_Y=1920, 1080
			pos_x, pos_y=0, 0
			self.function=(self.zoom_in)
			
		elif self.ken_burns=='zoom_out':
			size_x, size_Y=1920+402*1.778, 1080+402
			pos_x, pos_y=0, 0
			self.function=(self.zoom_out)
			
		elif self.ken_burns=='move_from_left_top_to_right_bottom':
			size_x, size_Y=1920+402*1.778, 1080+402
			pos_x, pos_y=0, 0
			self.function=(self.move_from_left_top_to_right_bottom)
					
		elif self.ken_burns=='move_from_rigth_top_to_left_bottom':
			size_x, size_Y=1920+402*1.778, 1080+402
			pos_x, pos_y=-402*1.778, 0
			self.function=(self.move_from_rigth_top_to_left_bottom)
			
		elif self.ken_burns=='move_from_left_bottom_to_right_top':
			size_x, size_Y=1920+402*1.778, 1080+402
			pos_x, pos_y=0, -402
			self.function=(self.move_from_left_bottom_to_right_top)
					
		elif self.ken_burns=='move_from_rigth_bottom_to_left_top':#
			size_x, size_Y=1920+402*1.778, 1080+402
			pos_x, pos_y=-715, -402
			self.function=(self.move_from_rigth_bottom_to_left_top)
			
		elif self.ken_burns=='move_zoomed_left_to_rigth':
			self.offset_y=randrange(225)*-1
			size_x, size_Y=1920+402, 1080+226
			pos_x, pos_y=0, self.offset_y
			self.function=(self.move_zoomed_left_to_rigth)

		elif self.ken_burns=='move_zoomed_rigth_to_left':
			self.offset_y=randrange(225)*-1
			size_x, size_Y=1920+402, 1080+226
			pos_x, pos_y=-402, self.offset_y
			self.function=(self.move_zoomed_rigth_to_left)

		self['screenSaver'].resize(size_x, size_Y)	
		self['screenSaver'].setPosition(pos_x, pos_y)
		self['screenSaver'].doshow(self.currscreensaverfilename)				
		self.mc+=1
		self.downloadImageNow()
		self.changetimer.start(1800, 1)

	def zoom_in(self):
		self['screenSaver'].resize(1920+int(self.mc*1.78), 1080+self.mc)
				
	def zoom_out(self):
		v=402-self.mc
		self['screenSaver'].resize(1920+int(v*1.78), 1080+v)	
				
	def move_from_left_top_to_right_bottom(self):
		self['screenSaver'].setPosition(0-int(self.mc*1.78), 0-self.mc)

	def move_from_left_bottom_to_right_top(self):
		self['screenSaver'].setPosition(0-int(self.mc*1.78), -402+self.mc)
		
	def move_from_rigth_bottom_to_left_top(self):
		self['screenSaver'].setPosition(-715+int(self.mc*1.78), -402+self.mc)
		
	def move_from_rigth_top_to_left_bottom(self):
		self['screenSaver'].setPosition(-715+int(self.mc*1.78), 0-self.mc)
		
	def move_zoomed_left_to_rigth(self):
		self['screenSaver'].setPosition(0-self.mc, self.offset_y)

	def move_zoomed_rigth_to_left(self):
		self['screenSaver'].setPosition(-402+self.mc, self.offset_y)
			
	def __onClose(self):
		self.session.nav.SleepTimer.on_state_change.remove(self.sleepTimerEntryOnStateChange)
		del self['coverArt'], self['screenSaver']
		self.pipservice=None
		if self.showHideTimer.isActive():
			self.showHideTimer.stop()

	def createSummary(self):
		return MC_LCDText


