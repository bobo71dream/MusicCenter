# -*- coding: UTF-8 -*-

#  Music Center E2
#
#  Coded by bobo71 (c) 2014
#  Support: www.dreambox-tools.info
#
#  All Files of this Software are licensed under the Creative Commons
#  Attribution-NonCommercial-ShareAlike 3.0 Unported
#  License if not stated otherwise in a Files Head. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.

#  Additionally, this plugin may only be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.

#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially
#  distributed other than under the conditions noted above.
#  This applies to the source code as a whole as well as to parts of it, unless
#  explicitely stated otherwise.

from base64 import b64decode as base64_b64decode, b64encode as base64_b64encode
from mutagen.asf import ASF
from mutagen.easyid3 import EasyID3
from mutagen.flac import FLAC, Picture
from mutagen.id3 import ID3, APIC, PCNT, TIT2, TPE1, TPE1, TALB, TCON, TDRC, TRCK, POPM, ID3NoHeaderError
from mutagen.mp3 import MP3
from mutagen.oggvorbis import OggVorbis
from os import stat as os_stat, access as os_access, W_OK as os_W_OK, remove as os_remove, path as os_path
from os.path import exists as os_path_exists, realpath as os_path_realpath
from PIL import Image
from shutil import move as os_move, copy as sh_copy2
from time import time as time_time

try:
	from myLogger import logger

except Exception, e: # not running in enigma2
	pass

		
'''
import sys
sys.path.append('/usr/lib/enigma2/python/Plugins/Extensions/MusicCenter')
import tagger
'''


def myenCode(value):
	returnValue="n/a"
	if value is not None:
		try:
			returnValue=value.encode("utf-8", 'ignore')
		except UnicodeDecodeError:
			try:
				returnValue=value.encode("iso8859-1", 'ignore')
			except UnicodeDecodeError:
				try:
					returnValue=value.decode("cp1252").encode("utf-8")
				except UnicodeDecodeError:
					try:
						returnValue=value.decode("utf-16").encode("utf-8")#, "replace")
					except UnicodeDecodeError:
						pass
	return returnValue


def getID3raw(filename, will_write=False):
	
	audio=None
	filetype=''
	
	if filename.lower().endswith(".mp3"):
	
		if not will_write:
			try:
				audio = MP3(filename)
				filetype="MP3"
			except Exception, e:
				logger.error('getID3raw]Error get mp3:%s' %e)			
		else:
			try: 
				audio = ID3(filename)
				filetype="MP3"
				
			except ID3NoHeaderError:
				logger.error('getID3raw]ID3NoHeaderError, Adding ID3 header, was not present')
				audio = ID3()

	elif filename.lower().endswith(".flac"):
		try:
			audio=FLAC(filename)
			filetype="FLAC"
		except Exception, e:
			logger.error('getID3raw]Error get flac:%s' %e)

	elif filename.lower().endswith(".ogg"):
		try:
			audio=OggVorbis(filename)
			filetype="OGG"
		except Exception, e:
			logger.error('getID3raw]Error get ogg:%s' %e)

	elif filename.lower().endswith(".wma"):
		try:
			audio=ASF(filename)
			filetype="WMA"
		except Exception, e:
			logger.error('getID3raw]Error get wma:%s' %e)
			
	elif filename.lower().endswith(".wav"):
		filetype="WAV"
		audio = True
		
	else:
		logger.info('getID3]no valid audotype')
	
	return audio, filetype


def getID3Tags(root,filename):
	'''
	version 31.08.15 length and bitrate raw
	
	'''
	class objectview(object):
		'''
		craete object attrib from dict
		'''
		def __init__(self, d):
			self.__dict__ = d

	title="n/a"
	genre="n/a"
	artist="n/a"
	album="n/a"
	tracknr='n/a'
	track="n/a"
	date="n/a"
	length="0"
	bitrate="n/a"
	albumartist="n/a"
	playcount=0
	rating=281
	wave=0
	hasapicframes=0
	
	starttime=time_time()
	audio, filetype=getID3raw(os_path.join(root, filename))
	timing=time_time()-starttime
	if timing > 0.5:
		f=os_path.join(root, filename)
		file_size=(os_path.getsize(f))
		logger.error('getID3Tags]slow!! filename:{} size:{} scantime:{}'.format(f, file_size, timing))
	if filetype:
		try:
			length=repr(audio.info.length)# myenCode(str(datetime_timedelta(seconds=int(audio.info.length))))
		except:
			length="0"
		try:	
			#if filetype != "FLAC":
			bitrate=audio.info.bitrate
			#else:
			#	bitrate=int(os.path.getsize(root + "/" + filename) / float(audio.info.length) * 8)
		except Exception, e:
			logger.error('getID3Tags]get bitrate:{}'.format(e))
			bitrate="n/a"
			
	if audio:
		if filetype=="WAV":
			pass

		elif filetype=="WMA":
			#print ('getID3Tags]is wma %s' %str(audio))
			title=myenCode(map(unicode, audio.get('Title', [filename]))[0])
			genre=myenCode(map(unicode, audio.get('WM/Genre', ['n/a']))[0])
			artist=myenCode(map(unicode, audio.get('Author', ['n/a']))[0])
			album=myenCode(map(unicode, audio.get('WM/AlbumTitle', ['n/a']))[0])
			tracknr=myenCode(map(unicode, audio.get('WM/AlbumTitle', ['n/a']))[0])
			track=myenCode(map(unicode, audio.get('WM/Track', ['n/a']))[0])
			date=myenCode(map(unicode, audio.get('WM/Year', ['n/a']))[0])
			albumartist=myenCode(map(unicode, audio.get('WM/AlbumArtist', ['n/a']))[0])
			framesraw=audio.get('WM/Picture','')
			if framesraw:
				hasapicframes=1
			audio=True

		elif filetype=="MP3":
			# Titel
			try:
				title=myenCode(audio.get('TIT2', [filename])[0])
				if not len(title):
					title=filename
			except Exception, e:
				logger.error('getID3Tags]MP3]title:{}'.format(e))
				title=filename

			# Genre
			try:
				genre=myenCode(audio.get('TCON', ['n/a'])[0])
				if not len(genre):
					genre='n/a'
			except Exception, e:
				logger.error('getID3Tags]MP3]genre:{}'.format(e))
				genre='n/a'
				
			#Artist
			try:
				artist=myenCode(audio.get('TPE1', ['n/a'])[0])
				if not len(artist):
					artist='n/a'
			except Exception, e:
				logger.error('getID3Tags]MP3]artist:{}'.format(e))
				artist='n/a'

			# Album
			try:
				album=myenCode(audio.get('TALB', ['n/a'])[0])
				if not len(album):
					album='n/a'
			except Exception, e:
				logger.error('getID3Tags]MP3]album:{}'.format(e))
				album='n/a'
				
			# Titelnummer
			try:
				track=myenCode(audio.get('TRCK', ['-1'])[0])
				if not len(track):
					track='-1'
				tracknr=track.split("/")[0]
			except Exception, e:
				logger.error('getID3Tags]MP3]track:{}'.format(e))
				track='-1'
			
			# Datum
			try:
				date=myenCode(audio.get('TDRC', [''])[0]).split('-')[0]# new 16.04.2016
				#date=myenCode(audio.get('TDRC', ['n/a'])[0])
				if not date:
					date='n/a'
			except Exception, e:
				logger.error('getID3Tags]MP3]date:{}'.format(e))
				date='n/a'
	
			# Albumartist
			try:
				albumartist=myenCode(audio.get('TPE2', ['n/a'])[0])
				if not albumartist:
					albumartist='n/a'
			except Exception, e:
				logger.error('getID3Tags]MP3]albumartist:{}'.format(e))
				albumartist='n/a'			
			
			#metadata=ID3(os_path.join(root, filename))
			playcount=audio.get('PCNT', PCNT(count=0)).count
			# rating das geht wohl auch besser...
			#rating=281
			popm=[ audio[i] for i in audio.iterkeys() if 'POPM' in i]
			if len(popm):
				rating=popm[0].rating
			# waveform list
			if audio.has_key('WXXX:wave'):
				wave=1#audio.get('WXXX:wave').url
			#apic
			if audio.has_key('APIC:3'):
				hasapicframes=1#audio.get('APIC:Front cover').data
			else:
				frameslist=[audio[i] for i in audio.keys()if 'APIC:' in i]
				if len(frameslist):
					hasapicframes=1 # frameslist[0].data
			audio=True

		else: # all other files
			title=myenCode(audio.get('title', [filename])[0])
			if not len(title):
				title='n/a'
			try:
				genre=myenCode(audio.get('genre', ['n/a'])[0])
				if not len(genre):
					genre='n/a'
			except:
				genre="n/a"

			artist=myenCode(audio.get('artist', ['n/a'])[0])
			if not len(artist):
				artist='n/a'

			album=myenCode(audio.get('album', ['n/a'])[0])
			if not len(album):
				album='n/a'

			try:
				tracknr=myenCode(audio.get('tracknumber', ['-1'])[0].split("/")[0])
			except:
				tracknr='-1'

			track=myenCode(audio.get('tracknumber', ['n/a'])[0])

			date=myenCode(audio.get('date', ['n/a'])[0])
			if not len(date):
				date='n/a'

			try:
				albumartist=myenCode(audio.get('performer', ['n/a'])[0])
			except:
				albumartist='n/a'
				
			playcount=0
			rating=281
			
			# wave
			if audio.has_key('WXXX:wave'):
				wave=1#audio.get('WXXX:wave')[0]
		
			if filetype=='FLAC':
				# rating not conform with standard
				if audio.has_key('popm'):
					rating=int(myenCode(audio['popm'][0]))
				# playcount not conform with standard
				if audio.has_key('pcnt'):
					playcount=int(myenCode(audio['pcnt'][0]))
				# cover
				pics=audio.pictures
				if pics:
					frames=str(pics[0].data)
					if len(frames) > 0:
						hasapicframes =1 # frames
			elif filetype=='OGG':
				# rating not conform with standard
				if audio.has_key('popm'):
					rating=int(myenCode(audio['popm'][0]))
				# playcount not conform with standard
				if audio.has_key('pcnt'):
					playcount=int(myenCode(audio['pcnt'][0]))
				# cover
				meta=audio.get('METADATA_BLOCK_PICTURE')
				if meta and len(meta)==1:
					hasapicframes=1 # Picture(base64_b64decode(meta[0])).data
					#if hasapicframes:
					#	status=hasapicframes
				elif meta:
					iscoverfront=False
					for cov in meta:
						covtype=Picture(base64_b64decode(cov)).type
						if covtype==3: # 3-Cover front
							hasapicframes=1 # Picture(base64_b64decode(cov)).data
							#if hasapicframes:
							#	status=hasapicframes
							#	iscoverfront=True
							#	break
					if not iscoverfront:
						hasapicframes=True # Picture(base64_b64decode(meta[0])).data
						#if hasapicframes:
						#	status=hasapicframes
							
			audio=True

	else:
		title=filename.strip().rsplit('.',1)[0]			
		audio=True

	#LOG('getID3Tags]->%s ->%s ->%s ->%s ->%s ->%s ->%s ->%s ->%s ->%s ->%s ->%s ->%s ->%s ->%s ->%s' %(audio, title, genre, artist, album, tracknr, track, date, length, bitrate, albumartist, filetype, playcount, rating, str(wave[:20]), str(hasapicframes[:30])))
	
	return objectview({
		"audio":audio, 
		"title":title,
		"genre":genre,
		"artist":artist,
		"album":album,
		"tracknr":tracknr,
		"track":track,
		"date":date,
		"length":length,
		"bitrate":bitrate,
		"albumartist":albumartist,
		"filetype":filetype,
		"playcount":playcount,
		"rating":rating,
		"wave":wave,
		"hasapicframes":hasapicframes})


def bin_to_pic(image):
	'''
	convert bin to apicframes
	found on puddletag 
	'''
	data = image.value
	(type, size) = struct_unpack_from("<bi", data)
	pos = 5
	mime = ""
	while data[pos:pos+2] != "\x00\x00":
		mime += data[pos:pos+2]
		pos += 2
	pos += 2
	description = ""
	while data[pos:pos+2] != "\x00\x00":
		description += data[pos:pos+2]
		pos += 2
	pos += 2
	image_data = data[pos:pos+size]
	return image_data


LOCKED={}

class TagWriter(object):
	
	def __init__(self):
		self.stat=0

	def embedCoverOnFile(self, songfile, coverfile, audio):
		result=False
		#try:
		logger.info('TagWriter]embedCoverOnFile] start adding FN: %s  CN:%s ' %(songfile, coverfile))
		if os_path_exists(songfile) and os_path_exists(coverfile) and os_access(songfile, os_W_OK):
		
			if not audio:
				audio, filetype=getID3raw(songfile, will_write=True)	
				
			if songfile.lower().endswith('mp3'):
				# remove all pics
				for tagentry in audio.iteritems():
					if 'APIC' in tagentry[0] and audio[tagentry[0]].type == 3:
						audio.pop(tagentry[0])
				imagedata=open(coverfile, 'rb').read()
				audio['APIC']=APIC(3, 'image/jpg', 3, 'Cover (front)', imagedata)
				#audio.tags.add(APIC(3, 'image/jpg', 3, 'Cover (front)', imagedata))
				
				result=self.saveID3Tags(audio, songfile)

			elif songfile.lower().endswith('flac'):
				im=Image.open(coverfile)
				img=Picture()
				
				pics = audio.pictures
				audio.clear_pictures()
				
				for pic in pics:
					if pic.type != 3:
						audio.add_picture(pic)

				with open(coverfile,'rb') as coverfnfile:
					imgdata=coverfnfile.read()
		
				img.mime=u'image/jpeg'
				img.type=3
				img.desc=u'Cover (front)'
				img.data=imgdata
				img.width=im.size[0]
				img.height=im.size[1]
				img.depth=self.getimageColorDepth(im)
				audio.add_picture(img)
				
				result=self.saveID3Tags(audio, songfile)
				
				del audio, imgdata, img, im

			elif songfile.lower().endswith('ogg'):
			
				new_METADATA_BLOCK_PICTURE=[]
				if audio.has_key('METADATA_BLOCK_PICTURE'):
					logger.info('TagWriter]embedCoverOnFile]oggfile has covers, check for old Frontcover...')
					for cov in iter(audio['METADATA_BLOCK_PICTURE']):
						covtype=Picture(base64_b64decode(cov)).type
						if covtype==3:
							logger.info('TagWriter]embedCoverOnFile]has old Frontcover, remove..')
						else:
							new_METADATA_BLOCK_PICTURE.append(cov)
							
				im=Image.open(coverfile)
				img=Picture()
				
				with open(coverfile,'rb') as coverfnfile:
					data=coverfnfile.read()
					
				img.data=data
				img.type=3
				img.desc=u'Cover (front)'
				img.mime=u'image/jpeg'
				img.width=im.size[0]
				img.height=im.size[1]
				img.depth=self.getimageColorDepth(im)
				
				tmp=img.write()
				tmp=base64_b64encode(tmp).decode('ascii') # new front cover
				
				new_METADATA_BLOCK_PICTURE.append(tmp)
				
				audio['METADATA_BLOCK_PICTURE']=new_METADATA_BLOCK_PICTURE
				
				logger.info('TagWriter]embedCoverOnFile]Picture save on tag...')
				result=self.saveID3Tags(audio, songfile)
				logger.info('TagWriter]embedCoverOnFile]done.')
			else:
				logger.info('TagWriter]EmbedCoverToFile]Filetype not suppoerted for coverembed! %s' %songfile)
				result=False
		else:
			logger.error('TagWriter]embedCoverOnFile] realfilename or coverfile not exists, or no writeaccess on path!')
			result=False
			
		#except Exception, e:
		#	logger.error('TagWriter]embedCoverOnFile]Error->%s' %e)
		#	result=False
	
		#if result: error import CoverLoader
		#	logger.info('TagWriter]embedCoverOnFile]create coverthumb!')
		#	coverfn=CoverLoader().load(songfile)
		logger.info('TagWriter]embedCoverOnFile]Embed end')
		return result

	def getimageColorDepth(self, imobject):
		mode_to_bpp = {'1':1, 'L':8, 'P':8, 'RGB':24, 'RGBA':32, 'CMYK':32, 'YCbCr':24, 'I':32, 'F':32}
		return mode_to_bpp.get(imobject.mode, 0)

	def saveID3Tags(self, audio, filename):
		'''
		rename file to prevent access
		make a copy of songfile save audio and replace the original file
		'''
		realfilename=os_path_realpath(filename)
		logger.info('saveID3Tags]start realfilename->%s' %realfilename)
		filename_tmp=realfilename + '''.tmp'''
		runisok=False
		try:
			if audio and os_path_exists(filename):
				#filename_renamed=realfilename + '''_renamed.tmp'''
				logger.info('saveID3Tags]rename original file to .tmp file')
				#os_move(realfilename, filename_renamed)
				
				filename_tmp=realfilename + '''.tmp'''
				os_move(realfilename, filename_tmp)
				#LOG('saveID3Tags]copy renamed to .tmp file')
				#sh_copy2(filename_renamed, filename_tmp)
				try:
					logger.info('saveID3Tags]audio.save...')
					audio.save(filename_tmp)
					runisok=True
					
				except Exception, e:
					logger.error('saveID3Tags]Error audio.save->%s' %repr(e.args[0]))

				if runisok:
					#LOG('saveID3Tags]rename renamed to .del file')
					#os_move(filename_renamed, filename_renamed + '.del')
					logger.info('saveID3Tags]rename .tmp to original file')
					os_move(filename_tmp, realfilename)
					logger.info('saveID3Tags]done')
				else:
					logger.info('saveID3Tags]audio.save finished with error')

				
		except Exception, e:
			logger.error('saveID3Tags]error->%s' %e)			
			
		finally:
			if os_path_exists(filename_tmp):
				logger.error('saveID3Tags]Oops, tmp file found, move to original name ->%s' %filename_tmp)
				os_move(filename_tmp, realfilename)
				
			#for todel in ('.tmp', '.del', '_renamed.tmp', '_renamed.tmp.del'):
			#	todelfilename=realfilename+todel
			#	logger.info('saveID3Tags]cleanup check ->%s' %todelfilename)
			#	if os_path_exists(todelfilename):
			#		logger.info('saveID3Tags]cleanup remove ->%s' %todelfilename)
			#		os_remove(todelfilename)
			self.delFromLock(filename)
			
		return runisok #return (filename, runisok)

	def addToLock(self, filename):
		logger.info('TagWriter]addToLock]->%s' %filename)
		LOCKED[filename]='in list'
		global LOCKED
		
	def isLocked(self, filename):
		if LOCKED.has_key(filename):
			logger.info('TagWriter]isLocked]:{} is locked:True'.format(LOCKED))
			return True
		else:
			logger.info('TagWriter]isLocked]:{} is locked:False'.format(LOCKED))
			return False

	def delFromLock(self, filename):
		res=LOCKED.pop(filename, 'Not in list')
		logger.info('TagWriter]delFromLock]->%s ->%s' %(filename, res))
		global LOCKED
		
tagWriter=TagWriter()
