# -*- coding: UTF-8 -*-

#  Music Center E2
#
#  Coded by bobo71 (c) 2014
#  Support: www.dreambox-tools.info
#
#  All Files of this Software are licensed under the Creative Commons
#  Attribution-NonCommercial-ShareAlike 3.0 Unported
#  License if not stated otherwise in a Files Head. To view a copy of this license, visit
#  http://creativecommons.org/licenses/by-nc-sa/3.0/ or send a letter to Creative
#  Commons, 559 Nathan Abbott Way, Stanford, California 94305, USA.

#  Additionally, this plugin may only be distributed and executed on hardware which
#  is licensed by Dream Multimedia GmbH.

#  This plugin is NOT free software. It is open source, you are allowed to
#  modify it (if you keep the license), but it may not be commercially
#  distributed other than under the conditions noted above.
#  This applies to the source code as a whole as well as to parts of it, unless
#  explicitely stated otherwise.

from Globals import *

class MusicCenterTasksScreen(Screen):# source from MyTube..

	if RESOLUTIONx>1800:
		skin = """
			<screen name="MusicCenterTasksScreen"  position="0,0" size="1920,1080" flags="wfNoBorder" backgroundColor="#00000000" zPosition="0" title="MusicCenter - Tasks">
				<widget name="title" position="90,75" size="900,75" zPosition="5" valign="center" halign="left" font="Regular;32" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget source="tasklist" render="Listbox" position="90,165" size="1650,863" zPosition="7" scrollbarMode="showOnDemand" transparent="1" >
					<convert type="TemplatedMultiContent">
						{"template": [
								MultiContentEntryText(pos = (0, 1), size = (500, 36), font=1, flags = RT_HALIGN_LEFT, text = 1), # index 1 is the name
								MultiContentEntryText(pos = (515, 1), size = (225, 36), font=1, flags = RT_HALIGN_RIGHT, text = 2), # index 2 is the state
								MultiContentEntryProgress(pos = (755, 1), size = (150, 36), percent = -3), # index 3 should be progress
								MultiContentEntryText(pos = (920, 1), size = (500, 36), font=1, flags = RT_HALIGN_RIGHT, text = 4), # index 4 is the percentage
							],
						"fonts": [gFont("Regular", 33),gFont("Regular", 27)],
						"itemHeight": 38
						}
					</convert>
				</widget>
				<widget name="buttonred" position="40,50" size="360,60" backgroundColor="red" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;30"/>
			</screen>"""
	else:
		skin = """
			<screen name="GoogleImageSearchScreen"  position="0,0" size="1280,720" flags="wfNoBorder" backgroundColor="#00000000" zPosition="0" title="MusicCenter - Tasks">
				<widget name="title" position="60,50" size="600,50" zPosition="5" valign="center" halign="left" font="Regular;21" transparent="1" foregroundColor="white" shadowColor="black" shadowOffset="-1,-1" />
				<widget source="tasklist" render="Listbox" position="60,110" size="1100,575" zPosition="7" scrollbarMode="showOnDemand" transparent="1" >
					<convert type="TemplatedMultiContent">
						{"template": [
								MultiContentEntryText(pos = (0, 1), size = (300, 24), font=1, flags = RT_HALIGN_LEFT, text = 1), # index 1 is the name
								MultiContentEntryText(pos = (310, 1), size = (150, 24), font=1, flags = RT_HALIGN_RIGHT, text = 2), # index 2 is the state
								MultiContentEntryProgress(pos = (470, 1), size = (100, 24), percent = -3), # index 3 should be progress
								MultiContentEntryText(pos = (580, 1), size = (100, 24), font=1, flags = RT_HALIGN_RIGHT, text = 4), # index 4 is the percentage
							],
						"fonts": [gFont("Regular", 22),gFont("Regular", 18)],
						"itemHeight": 25
						}
					</convert>
				</widget>
				<widget name="buttonred" position="40,50" size="240,40" backgroundColor="red" valign="center" halign="center" zPosition="2"  foregroundColor="white" font="Regular;20"/>
			</screen>"""

	def __init__(self, session, tasklist):
		Screen.__init__(self, session)
		self.session = session
		self.tasklist = tasklist
		self["tasklist"] = List(self.tasklist)

		self["shortcuts"] = ActionMap(["ShortcutActions", "WizardActions", "MediaPlayerActions"],
		{
			"ok": self.keyOK,
			"back": self.keyCancel,
			"red": self.keyCancel,
		}, -1)

		self["buttonred"] = Label(_("Back"))
		self["title"] = Label()

		self.onLayoutFinish.append(self.layoutFinished)
		self.onShown.append(self.setWindowTitle)
		self.onClose.append(self.__onClose)
		self.Timer = eTimer()
		self.Timer_mc_conn=self.Timer.timeout.connect(self.TimerFire)

	def __onClose(self):
		del self.Timer

	def layoutFinished(self):
		self["title"].setText(_("MusicCenter active jobs"))
		self.Timer.startLongTimer(2)

	def TimerFire(self):
		self.Timer.stop()
		self.rebuildTaskList()

	def rebuildTaskList(self):
		self.tasklist = []
		for job in job_manager.getPendingJobs():
			#self.tasklist.append((job,job.name,job.getStatustext()))
			self.tasklist.append((job,job.name,job.getStatustext(),int(100*job.progress/float(job.end)) ,str(100*job.progress/float(job.end)) + "%" ))
		self['tasklist'].setList(self.tasklist)
		self['tasklist'].updateList(self.tasklist)
		self.Timer.startLongTimer(2)

	def setWindowTitle(self):
		self.setTitle(_("MusicCenter activ jobslist"))

	def keyOK(self):
		current = self["tasklist"].getCurrent()
		print current
		if current:
			job = current[0]
			from Screens.TaskView import JobView
			self.session.openWithCallback(self.JobViewCB, JobView, job)

	def JobViewCB(self, why):
		print "WHY---",why

	def keyCancel(self):
		self.close()

	def keySave(self):
		self.close()
